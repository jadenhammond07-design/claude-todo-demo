import React from "react";
import { Composition } from "remotion";
import "@fontsource/inter/900.css";
import { Main } from "./Main";
import { NvidiaV4 } from "./videos/NvidiaV4";
import { DanceMain } from "./videos/DanceMain";
import { KanyeMain } from "./videos/KanyeMain";
import { AlertMain } from "./videos/AlertMain";
import { CarPfp } from "./videos/CarPfp";
import { BizMain } from "./videos/BizMain";
import { Mo3Main } from "./videos/Mo3Main";
import { ParkMain } from "./videos/ParkMain";
import { GhostMain } from "./videos/GhostMain";
import { JobsMain } from "./videos/JobsMain";
import { MeetMain } from "./videos/MeetMain";
import { GoneMain } from "./videos/GoneMain";
import { UnseenMain } from "./videos/UnseenMain";
import { MoonMain } from "./videos/MoonMain";
import { DejavuMain } from "./videos/DejavuMain";
import { BirdsMain } from "./videos/BirdsMain";
import { StrangersMain } from "./videos/StrangersMain";
import { EohMain } from "./videos/EohMain";
import { EohBMain } from "./videos/EohBMain";
// DURATION: set durationInFrames = ceil(voiceover_seconds * 30). Use --props or edit per video.
export const Root: React.FC = () => <>
  <Composition id="Main" component={Main} width={720} height={1280} fps={30} durationInFrames={60} />
  <Composition id="NvidiaV4" component={NvidiaV4} width={720} height={1280} fps={30} durationInFrames={661} />
  <Composition id="Dance" component={DanceMain} width={720} height={1280} fps={30} durationInFrames={1566} />
  <Composition id="Kanye" component={KanyeMain} width={720} height={1280} fps={30} durationInFrames={1493} />
  <Composition id="Alert" component={AlertMain} width={720} height={1280} fps={30} durationInFrames={1546} />
  <Composition id="CarPfp" component={CarPfp} width={1024} height={1024} fps={30} durationInFrames={1} />
  <Composition id="Biz" component={BizMain} width={720} height={1280} fps={30} durationInFrames={1762} />
  <Composition id="Mo3" component={Mo3Main} width={720} height={1280} fps={30} durationInFrames={1628} />
  <Composition id="Park" component={ParkMain} width={720} height={1280} fps={30} durationInFrames={1445} />
  <Composition id="Ghost" component={GhostMain} width={720} height={1280} fps={30} durationInFrames={1611} />
  <Composition id="Dejavu" component={DejavuMain} width={720} height={1280} fps={30} durationInFrames={1278} />
  <Composition id="Strangers" component={StrangersMain} width={720} height={1280} fps={30} durationInFrames={1288} />
  <Composition id="Birds" component={BirdsMain} width={720} height={1280} fps={30} durationInFrames={1263} />
  <Composition id="Moon" component={MoonMain} width={720} height={1280} fps={30} durationInFrames={1299} />
  <Composition id="Unseen" component={UnseenMain} width={720} height={1280} fps={30} durationInFrames={1470} />
  <Composition id="Gone" component={GoneMain} width={720} height={1280} fps={30} durationInFrames={1587} />
  <Composition id="Meet" component={MeetMain} width={720} height={1280} fps={30} durationInFrames={1255} />
  <Composition id="Jobs" component={JobsMain} width={720} height={1280} fps={30} durationInFrames={1555} />
  <Composition id="Eoh" component={EohMain} width={720} height={1280} fps={30} durationInFrames={1393} />
  <Composition id="EohB" component={EohBMain} width={720} height={1280} fps={30} durationInFrames={1393} />
</>;
