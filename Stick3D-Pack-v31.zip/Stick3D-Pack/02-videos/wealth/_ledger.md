# Income vs Wealth — LONG-FORM 16:9 (5:11, 9360 f, 1920x1080) — 2D cartoon style
Engine: engine/src/long/ (kit2d.ts = canvas-2D props/backgrounds + puppet characters; WealthBeats.ts = ~55 timed beats; Wealth.tsx = composition with crossfades + slow camera drift). Register `Wealth` 1920x1080 in Root (see Root.tsx.long). Render with --scale=1 (2D renders ~7 min per 2340 frames, no WebGL).
Voice: per-chapter TTS (am_adam speed 1.0, TTS_GAP=0.32), aligned per chapter, stitched with 3 s chapter cards (timeline.json).
Lesson: 848 words = ~5 min at natural long-form pace; 8-10 min needs ~1300-1500 words.
