import React, { useLayoutEffect, useRef } from "react";
import { AbsoluteFill, Audio, staticFile, useCurrentFrame } from "remotion";
import { W, H, resetPool, clamp } from "./kit2d";
import { BEATS } from "./WealthBeats";
const FPS = 30, XF = 0.22;
function drawBeat(c: CanvasRenderingContext2D, i: number, t: number, f: number) {
  const b = BEATS[i], end = BEATS[i + 1]?.s ?? b.s + 8, u = clamp((t - b.s) / Math.max(1, end - b.s));
  c.save(); if (!b.card) { const z = 1 + 0.035 * u; c.translate(W / 2, H / 2); c.scale(z, z); c.translate(-W / 2 + (i % 2 ? 1 : -1) * 18 * u, -H / 2); }
  b.draw(c, t, f); c.restore();
}
export const WealthMain: React.FC = () => {
  const f = useCurrentFrame(), t = f / FPS, ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const c = ref.current!.getContext("2d")!; resetPool();
    let i = 0; while (i + 1 < BEATS.length && BEATS[i + 1].s <= t) i++;
    const into = t - BEATS[i].s;
    if (i > 0 && into < XF) { drawBeat(c, i - 1, BEATS[i].s - 0.001, f); c.globalAlpha = into / XF; drawBeat(c, i, t, f); c.globalAlpha = 1; }
    else drawBeat(c, i, t, f);
  }, [f]);
  return (<AbsoluteFill style={{ background: "#000" }}><canvas ref={ref} width={W} height={H} style={{ width: "100%", height: "100%" }} /><Audio src={staticFile("wealth/mix.wav")} /></AbsoluteFill>);
};
