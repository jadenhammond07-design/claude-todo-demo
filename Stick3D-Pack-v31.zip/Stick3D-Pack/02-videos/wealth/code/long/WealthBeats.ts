// "Earning vs wealth" long-form — beats keyed to absolute narration times (02-videos/wealth/timeline.json).
import { W, H, INK, GROUND, clamp, lerp, lin, ease, pop, person, mk, rr, circ, line, T, label, stamp, cross, arrow, bgRoom, bgSky, bgStreet, bgPlain, bgOffice, bgNight, bill, coin, coinStack, bucket, faucet, jar, wallet, car, house, phone, calendar, piggy, safe, gear, tree, check, bars, stepsRoad } from "./kit2d";
type C = CanvasRenderingContext2D;
export type Beat = { s: number; card?: boolean; draw: (c: C, t: number, f: number) => void };

const sam = mk("#f2d0b0", "#2fa86a", "hoodie", "short", "#5a3a1a", { shoe: "#333" });
const rich = mk("#e8b88c", "#2b3350", "suit", "swept", "#2a1a10", { tie: "#e5233a", shirt: "#fff" });
const saver = mk("#8d5a3a", "#ff7a29", "shirt", "bob", "#1a1008");
const guru = mk("#f3d3b2", "#ffd23a", "blazer", "swept", "#c8a060", { shirt: "#e5233a", glasses: true });
const STEP_COL = ["#2f8cff", "#2fa86a", "#ff7a29", "#9a5ad8", "#e5233a", "#14a0a0", "#ffb000"];
const STEPS = ["INCOME vs WEALTH", "RAISE INCOME, NOT SPENDING", "BUILD AN EMERGENCY FUND", "INVEST CONSISTENTLY", "LET ASSETS PAY YOU", "PATIENCE BEATS GET-RICH-QUICK", "THE PATH"];

const card = (n: number, s: number): Beat => ({ s, card: true, draw: (c, t) => {
  const k = ease(t, s, 0.45), col = STEP_COL[n - 1];
  c.fillStyle = col; c.fillRect(0, 0, W, H); c.fillStyle = "rgba(255,255,255,.08)"; for (let i = -4; i < 12; i++) { c.beginPath(); c.moveTo(i * 240 + (t - s) * 60, 0); c.lineTo(i * 240 + 120 + (t - s) * 60, 0); c.lineTo(i * 240 - 300 + (t - s) * 60, H); c.lineTo(i * 240 - 420 + (t - s) * 60, H); c.fill(); }
  T(c, n < 7 ? `STEP ${n}` : "RECAP", lerp(-400, W / 2, k), 400, 150, "#ffe14a", 1);
  T(c, STEPS[n - 1], lerp(W + 900, W / 2, ease(t, s + 0.15, 0.5)), 600, 96, "#fff", 1);
} });

export const BEATS: Beat[] = [
  /* ================= INTRO ================= */
  { s: 0, draw: (c, t, f) => { bgOffice(c); const broke = pop(t, 3.3);
    for (let i = 0; i < 10 && broke < 0.5; i++) { const u = (t * 0.6 + i * 0.1) % 1; bill(c, 300 + i * 140, -60 + u * 900, 0.9, Math.sin(t * 3 + i)); }
    person(c, rich, { mood: broke > 0.5 ? "shock" : "grin", arms: broke > 0.5 ? undefined : "up", armK: 1, t: f, sweat: broke > 0.5 ? 1 : 0 }, 960, GROUND, 560);
    if (broke > 0.01) { wallet(c, 1340, 620, 1.3 * broke, true, t); stamp(c, "BROKE", 960, 220, 120, "#e5233a", broke); }
    T(c, "GOOD MONEY", 960, 150, 90, "#7ad07a", pop(t, 1.0) * (1 - broke)); } },
  { s: 4.0, draw: (c, t, f) => { bgPlain(c, "#fff4e0", "#f0d8b0"); c.fillStyle = "#e8d0b0"; c.fillRect(W / 2 - 6, 0, 12, H);
    person(c, rich, { mood: "worry", t: f }, 480, GROUND, 520); wallet(c, 760, 700, 1.0, true, t); label(c, "EARNS $$$$", 480, 180, 60, "#14141c", "#7ad07a", pop(t, 4.2));
    person(c, saver, { mood: "grin", t: f + 5 }, 1440, GROUND, 520); coinStack(c, 1180, 860, Math.round(12 * ease(t, 5.6, 0.8)), 46); coinStack(c, 1700, 860, Math.round(9 * ease(t, 5.8, 0.8)), 46);
    label(c, "EARNS $$", 1440, 180, 60, "#14141c", "#7ad07a", pop(t, 4.8)); stamp(c, "WEALTHY", 1440, 320, 90, "#1fa850", pop(t, 6.1)); stamp(c, "BROKE", 480, 320, 90, "#e5233a", pop(t, 4.5)); } },
  { s: 7.0, draw: (c, t, f) => { bgPlain(c, "#e8f4ff", "#b8d8f0");
    c.save(); c.translate(620, 520); c.scale(pop(t, 7.2), pop(t, 7.2)); [[0, -80], [80, 0], [0, 80], [-80, 0]].forEach(([x, y]) => circ(c, x, y, 80, "#3fae4a")); rr(c, -10, 60, 20, 200, 8, "#2a8a3a", 6); c.restore(); cross(c, 620, 520, 220, pop(t, 7.7));
    c.save(); c.translate(1300, 520); c.scale(pop(t, 8.4), pop(t, 8.4)); rr(c, -200, -150, 400, 300, 20, "#f0d8a0"); line(c, [[-140, -60], [100, -60]], "#a88a5a", 10); line(c, [[-140, 0], [140, 0]], "#a88a5a", 10); line(c, [[-140, 60], [60, 60]], "#a88a5a", 10); T(c, "SECRET", 0, -110, 50, "#e5233a"); c.restore(); cross(c, 1300, 520, 220, pop(t, 8.8));
    T(c, "NOT LUCK", 620, 150, 80, "#fff", pop(t, 7.7)); T(c, "NOT A SECRET", 1300, 150, 80, "#fff", pop(t, 8.8)); } },
  { s: 9.8, draw: (c, t, f) => { bgRoom(c, "#c8d8f0", "#8a7a6a");
    person(c, sam, { mood: "worry", t: f, lookX: Math.sin(t * 2) * 0.4, armR: [0.3, 0.8], armRK: 1 }, 960, GROUND, 540);
    label(c, "EARNING MONEY", 520, 300, 64, "#ffd23a", INK, pop(t, 10.9)); label(c, "BUILDING WEALTH", 1400, 300, 64, "#2fa86a", "#fff", pop(t, 11.6)); T(c, "≠", 960, 300, 140, "#e5233a", pop(t, 12.1));
    [0, 1, 2].forEach((i) => T(c, "?", 860 + i * 100, 360 + Math.sin(t * 4 + i) * 10, 80, "#9a5ad8", pop(t, 10.3 + i * 0.2))); } },
  { s: 12.8, draw: (c, t, f) => { bgSky(c); const k = ease(t, 16.9, 2.6);
    stepsRoad(c, t, k, 200, 860, 1700, 420, 6, 0); c.fillStyle = INK; rr(c, 1700, 240, 12, 200, 4, INK, 0); c.beginPath(); c.moveTo(1712, 240); c.lineTo(1830, 280); c.lineTo(1712, 320); c.fillStyle = "#ffd23a"; c.fill(); c.lineWidth = 6; c.strokeStyle = INK; c.stroke();
    label(c, "NOTHING", 260, 960, 44, "#8a8aa0", "#fff", pop(t, 19.0)); label(c, "FINANCIAL FREEDOM", 1600, 170, 54, "#2fa86a", "#fff", pop(t, 19.4)); label(c, "6 STEPS", 960, 140, 70, "#14141c", "#ffe14a", pop(t, 17.1));
    const wk = ease(t, 18.5, 3.0); person(c, sam, { mood: "smile", walk: f * 0.25, speed: wk > 0 && wk < 1 ? 0.6 : 0, t: f }, lerp(220, 520, wk), lerp(900, 790, wk), 360); } },
  { s: 21.0, draw: (c, t, f) => { bgPlain(c, "#ffe0d0", "#e8a090"); const k = pop(t, 21.8);
    c.save(); c.translate(960, 520); c.scale(k, k); c.beginPath(); c.moveTo(0, -260); c.lineTo(260, 200); c.lineTo(-260, 200); c.closePath(); c.fillStyle = "#ffd23a"; c.fill(); c.lineWidth = 16; c.strokeStyle = INK; c.stroke(); T(c, "!", 0, 40, 260, INK); c.restore();
    T(c, "THE BIGGEST MISTAKE", 960, 900, 100, "#fff", pop(t, 22.3)); } },
  card(1, 23.9),
  /* ================= 1. INCOME vs WEALTH ================= */
  { s: 26.9, draw: (c, t, f) => { bgRoom(c, "#e8f0f8", "#9a8a7a", false);
    c.save(); c.translate(540, 520); c.scale(pop(t, 26.9), pop(t, 26.9)); rr(c, -220, -130, 440, 260, 20, "#fff"); T(c, "PAYCHECK", 0, -70, 50, INK, 1, "#fff"); T(c, "$4,000", 0, 30, 90, "#1fa850"); c.restore();
    label(c, "INCOME = WHAT YOU EARN", 540, 860, 50, "#ffd23a", INK, pop(t, 27.6));
    piggy(c, 1380, 720, 1.4 * pop(t, 28.7), ease(t, 30.1)); label(c, "WEALTH = WHAT YOU KEEP + GROWS", 1380, 860, 46, "#2fa86a", "#fff", pop(t, 29.4)); } },
  { s: 31.1, draw: (c, t, f) => { bgRoom(c, "#dbe8f4", "#8a8aa0", false); const lvl = 0.15 + 0.6 * ease(t, 32.4, 4.0);
    faucet(c, 940, 250, 1.15, lin(t, 32.2, 0.4), t, "INCOME"); bucket(c, 980, 880, 1.25, lvl, t, 0, 0, "WEALTH");
    person(c, sam, { mood: "smile", lookX: 0.5, t: f }, 400, GROUND, 520); } },
  { s: 37.2, draw: (c, t, f) => { bgRoom(c, "#dbe8f4", "#8a8aa0", false); const holes = t > 37.9 ? 4 : 0, big = ease(t, 38.3, 0.6);
    faucet(c, 940, 250, 1.15, 0.5 + 0.9 * big, t, "INCOME"); bucket(c, 980, 880, 1.25, 0.32 + 0.03 * Math.sin(t * 2), t, holes, holes ? 1 : 0, "WEALTH");
    person(c, sam, { mood: "worry", sweat: 1, lookX: 0.5, t: f }, 400, GROUND, 520); T(c, "BIGGER POURS DON'T HELP", 960, 120, 70, "#fff", pop(t, 39.0)); label(c, "HOLES", 1380, 760, 48, "#e5233a", "#fff", pop(t, 37.9)); } },
  { s: 39.9, draw: (c, t, f) => { bgOffice(c); person(c, rich, { mood: "worry", t: f, sweat: 1, hunch: 0.3 }, 960, GROUND, 560);
    label(c, "HIGH EARNER", 960, 160, 70, "#2b3350", "#fff", pop(t, 40.8)); wallet(c, 1360, 640, 1.2, true, t); stamp(c, "BROKE", 1360, 400, 90, "#e5233a", pop(t, 41.5)); } },
  { s: 42.4, draw: (c, t, f) => { bgStreet(c, t); const p1 = ease(t, 42.6, 1.0), p2 = ease(t, 43.5, 1.0);
    arrow(c, 180, 700, 180, 300, "#2fd46a", 26, p1); label(c, "PAY ↑", 180, 230, 50, "#2fd46a", INK, pop(t, 42.6)); arrow(c, 380, 700, 380, 300, "#e5233a", 26, p2); label(c, "SPENDING ↑", 400, 230, 50, "#e5233a", "#fff", pop(t, 43.5));
    car(c, 900, 900, 1.3 * pop(t, 45.6), "#e5233a"); label(c, "NICER CAR", 900, 560, 46, "#fff", INK, pop(t, 45.6));
    c.save(); c.translate(1330, 470); c.scale(pop(t, 46.0), pop(t, 46.0)); rr(c, -150, -120, 300, 240, 16, "#fff"); T(c, "RENT", 0, -50, 60, INK, 1, "#fff"); T(c, "$2,400", 0, 40, 70, "#e5233a"); c.restore();
    phone(c, 1700, 600, 1.4 * pop(t, 46.6), Math.round(9 * ease(t, 46.8, 1.0))); label(c, "SUBSCRIPTIONS", 1700, 300, 40, "#9a5ad8", "#fff", pop(t, 46.8)); } },
  { s: 48.0, draw: (c, t, f) => { bgPlain(c, "#f4f0ff", "#c8c0e8"); const k = ease(t, 48.0, 2.2);
    line(c, [[200, 900], [200, 200]], INK, 8); line(c, [[200, 900], [1720, 900]], INK, 8);
    const pts = (off: number) => Array.from({ length: 12 }, (_, i) => [200 + i * 130, 820 - i * 50 - off] as number[]).slice(0, Math.max(2, Math.round(12 * k)));
    line(c, pts(60), "#2fd46a", 16); line(c, pts(20), "#e5233a", 16); label(c, "INCOME", 1640, 200, 40, "#2fd46a", INK, k > 0.95 ? 1 : 0); label(c, "SPENDING", 1640, 300, 40, "#e5233a", "#fff", k > 0.95 ? 1 : 0);
    T(c, "LIFESTYLE CREEP", 960, 130, 110, "#ffe14a", pop(t, 49.0)); person(c, sam, { mood: "worry", t: f }, 1700, GROUND, 300); } },
  { s: 50.4, draw: (c, t, f) => { bgPlain(c, "#f0fff4", "#b8e8c8"); line(c, [[200, 900], [1720, 900]], INK, 8); line(c, [[200, 900], [200, 200]], INK, 8);
    const g = ease(t, 51.0, 1.4); c.fillStyle = "rgba(47,212,106,.35)"; c.beginPath(); c.moveTo(200, 400); c.lineTo(1720, 300); c.lineTo(1720, lerp(300, 700, g)); c.lineTo(200, lerp(400, 700, g)); c.closePath(); c.fill();
    line(c, [[200, 400], [1720, 300]], "#2fd46a", 16); line(c, [[200, lerp(400, 700, g)], [1720, lerp(300, 700, g)]], "#e5233a", 16);
    label(c, "WHAT COMES IN", 600, 320, 40, "#2fd46a", INK, pop(t, 52.2)); label(c, "WHAT GOES OUT", 600, 760, 40, "#e5233a", "#fff", pop(t, 53.0)); T(c, "THE GAP", 1200, 500, 120, "#fff", pop(t, 51.4));
    jar(c, 1600, 880, 0.9 * pop(t, 54.0), ease(t, 54.3, 1.0), "", "#ffd23a"); } },
  card(2, 56.3),
  /* ================= 2. RAISE INCOME WITHOUT RAISING SPENDING ================= */
  { s: 59.3, draw: (c, t, f) => { bgPlain(c, "#eef8ff", "#b8d8f0"); line(c, [[200, 900], [1720, 900]], INK, 8); line(c, [[200, 900], [200, 200]], INK, 8);
    const k = ease(t, 60.6, 1.2); const st = [[200, 700], [600, 700], [600, 520], [1100, 520], [1100, 340], [1720, 340]]; line(c, st.slice(0, Math.max(2, Math.round(6 * k))), "#2fd46a", 18); label(c, "INCOME", 1600, 280, 40, "#2fd46a", INK, k > 0.9 ? 1 : 0);
    const l = ease(t, 62.1, 0.8); line(c, [[200, 760], [lerp(200, 1720, l), 760]], "#ff7a29", 18); label(c, "LIFESTYLE: SAME", 1450, 820, 40, "#ff7a29", "#fff", pop(t, 62.8));
    arrow(c, 1400, 740, 1400, 380, "#ffd23a", 22, ease(t, 63.6, 0.6)); label(c, "→ YOUR FUTURE", 1480, 560, 48, "#14141c", "#ffe14a", pop(t, 64.3)); T(c, "THE RULE", 960, 130, 100, "#fff", pop(t, 59.7)); } },
  { s: 65.2, draw: (c, t, f) => { bgRoom(c, "#f4e8d8", "#a8885a"); const r = pop(t, 65.4), fl = ease(t, 66.6, 1.6);
    person(c, sam, { mood: "grin", arms: "up", armK: r, t: f }, 420, GROUND, 520); label(c, "RAISE! +$500/mo", 420, 200, 56, "#2fd46a", INK, r);
    for (let i = 0; i < 6; i++) { const u = clamp(fl * 1.4 - i * 0.08); if (u <= 0 || u >= 1) continue; bill(c, lerp(560, i % 2 ? 1500 : 1100, u), lerp(420, 640, u) - Math.sin(u * Math.PI) * 160, 0.8, u * 4); }
    jar(c, 1100, 860, 1.0, ease(t, 67.2, 1.4), "SAVINGS", "#ffd23a"); jar(c, 1500, 860, 1.0, ease(t, 68.2, 1.4), "INVESTING", "#2fd46a");
    wallet(c, 1780, 480, 0.8, false, t); T(c, "SAME", 1780, 360, 40, "#ff7a29", pop(t, 69.4)); } },
  { s: 71.0, draw: (c, t, f) => { bgRoom(c, "#e0e8ff", "#8a8aa0"); T(c, "HOW?", 960, 150, 120, "#ffe14a", pop(t, 71.1));
    rr(c, 1050, 600, 340, 210, 14, "#2b3350"); rr(c, 1070, 620, 300, 170, 8, "#5ab0ff", 4); rr(c, 1010, 810, 420, 30, 8, "#8a8aa0");
    [0, 1, 2].forEach((i) => { rr(c, 380 + i * 40, 700 - i * 50, 240, 50, 6, ["#e5233a", "#2f8cff", "#ffd23a"][i], 6); });
    person(c, sam, { mood: "smile", t: f, armR: [0.4, 0.55], armRK: 1 }, 820, GROUND, 520);
    ["CODING", "SALES", "DESIGN"].forEach((s, i) => { const k = ease(t, 73.0 + i * 0.3, 0.8); rr(c, 1460, 300 + i * 90, 320, 50, 10, "#ddd", 5); rr(c, 1460, 300 + i * 90, 320 * k, 50, 10, "#2fd46a", 5); T(c, s, 1620, 325 + i * 90, 30, "#fff"); });
    label(c, "LEARN PAID SKILLS", 960, 960, 54, "#2f8cff", "#fff", pop(t, 72.7)); } },
  { s: 75.1, draw: (c, t, f) => { bgStreet(c, t); const w = ease(t, 75.4, 2.0);
    rr(c, 120, 300, 360, 480, 10, "#9aa8c0"); T(c, "JOB A", 300, 360, 50, "#fff"); rr(c, 1440, 240, 380, 540, 10, "#6ac08a"); T(c, "JOB B", 1630, 300, 50, "#fff");
    person(c, sam, { mood: "smile", walk: f * 0.25, speed: w > 0 && w < 1 ? 0.6 : 0, t: f }, lerp(420, 1360, w), GROUND - 30, 460);
    c.save(); c.translate(960, 330); c.scale(pop(t, 78.3), pop(t, 78.3)); rr(c, -320, -150, 640, 300, 20, "#fff"); T(c, "SWITCHING", -150, -90, 34, INK, 1, "#fff"); T(c, "WAITING", 150, -90, 34, INK, 1, "#fff");
    rr(c, -200, 120 - 200 * ease(t, 79.5, 0.8), 100, 200 * ease(t, 79.5, 0.8), 6, "#2fd46a", 5); rr(c, 100, 120 - 70 * ease(t, 80.3, 0.8), 100, 70 * ease(t, 80.3, 0.8), 6, "#c8c8d0", 5); c.restore(); } },
  { s: 81.9, draw: (c, t, f) => { bgNight(c); c.fillStyle = "#3a2a5a"; c.fillRect(0, GROUND - 40, W, H);
    rr(c, 640, 600, 640, 40, 8, "#8a5a32"); rr(c, 820, 420, 300, 190, 12, "#2b3350"); rr(c, 838, 438, 264, 150, 6, "#9fd4ff", 4);
    person(c, sam, { mood: "smile", t: f, armR: [0.4, 0.5], armRK: 1 }, 560, GROUND, 500);
    const items: [string, number, string][] = [["FREELANCING", 83.4, "#ff7a29"], ["SELLING A SERVICE", 84.4, "#2f8cff"], ["PAID WORK IN YOUR FIELD", 85.5, "#2fa86a"]];
    items.forEach(([s, a, col], i) => label(c, s, 1450, 280 + i * 140, 44, col, "#fff", pop(t, a))); T(c, "SIDE INCOME", 960, 130, 100, "#ffe14a", pop(t, 82.2)); } },
  { s: 87.4, draw: (c, t, f) => { bgRoom(c, "#dbe8f4", "#8a8aa0", false); const two = ease(t, 87.6, 0.6), fall = ease(t, 90.3, 0.7);
    faucet(c, 700, 250, 1.0, 0.7, t, "JOB"); faucet(c, 1150, 250, 1.0 * two, 0.6 * two, t, "SIDE");
    bucket(c, 900, 880, 1.2, 0.55, t, 0, 0, "");
    if (fall > 0) { line(c, [[1300, 820], [1800, 820]], "#c0402e", 10); for (let i = 0; i < 7; i++) line(c, [[1300 + i * 80, 780], [1340 + i * 80, 860]], "#c0402e", 5); person(c, sam, { mood: "shock", arms: "up", armK: 1, t: f }, 1550, lerp(300, 820, fall), 380); }
    label(c, "SAFETY NET", 1550, 960, 50, "#c0402e", "#fff", pop(t, 90.5)); T(c, "2 INCOME STREAMS", 700, 990, 80, "#fff", pop(t, 87.8)); } },
  { s: 91.8, draw: (c, t, f) => { bgPlain(c, "#fff8e8", "#f0d8a8");
    c.save(); c.translate(700, 540); c.scale(pop(t, 91.9), pop(t, 91.9)); rr(c, -340, -300, 680, 600, 20, "#fff"); check(c, -260, -170, 1, ease(t, 92.2), "RAISE INCOME"); check(c, -260, -40, 1, ease(t, 92.5), "SAVE THE EXTRA"); check(c, -260, 90, 1, 0, "SPEND MORE"); cross(c, -100, 90, 120, pop(t, 93.6)); c.restore();
    jar(c, 1420, 820, 1.4, 0.9, "STAYS PUT", "#ffd23a"); c.save(); c.translate(1420, 400); c.scale(pop(t, 97.2), pop(t, 97.2)); rr(c, -60, -20, 120, 100, 14, "#ffd23a"); c.beginPath(); c.arc(0, -20, 44, Math.PI, 0); c.lineWidth = 16; c.strokeStyle = INK; c.stroke(); c.restore(); } },
  card(3, 98.9),
  /* ================= 3. EMERGENCY FUND ================= */
  { s: 101.9, draw: (c, t, f) => { bgSky(c); const k = pop(t, 102.9);
    person(c, sam, { mood: "smile", t: f }, 960, GROUND, 540);
    c.save(); c.translate(1280, 560); c.scale(k, k); c.beginPath(); c.moveTo(0, -200); c.quadraticCurveTo(170, -170, 170, -40); c.quadraticCurveTo(170, 140, 0, 230); c.quadraticCurveTo(-170, 140, -170, -40); c.quadraticCurveTo(-170, -170, 0, -200); c.fillStyle = "#2f8cff"; c.fill(); c.lineWidth = 12; c.strokeStyle = INK; c.stroke(); T(c, "✓", 0, 10, 160, "#fff"); c.restore();
    T(c, "PROTECT YOURSELF FIRST", 960, 140, 90, "#fff", pop(t, 103.3)); } },
  { s: 104.2, draw: (c, t, f) => { bgRoom(c, "#fdf0e0", "#a8885a"); jar(c, 480, 860, 1.6 * pop(t, 104.3), 0.7, "EMERGENCY FUND", "#ff7a29");
    car(c, 1100, 520, 0.9 * pop(t, 107.7), "#2f8cff", 1, t); label(c, "CAR REPAIR", 1100, 280, 40, "#fff", INK, pop(t, 107.8));
    c.save(); c.translate(1500, 520); c.scale(pop(t, 108.6), pop(t, 108.6)); rr(c, -110, -150, 220, 300, 12, "#fff"); rr(c, -30, -110, 60, 20, 4, "#e5233a", 0); rr(c, -10, -130, 20, 60, 4, "#e5233a", 0); T(c, "$1,800", 0, 40, 46, INK, 1, "#fff"); c.restore(); label(c, "MEDICAL BILL", 1500, 280, 40, "#fff", INK, pop(t, 108.7));
    c.save(); c.translate(1300, 860); c.scale(pop(t, 109.4), pop(t, 109.4)); rr(c, -140, -100, 280, 100, 8, "#c8a070"); line(c, [[-80, -100], [-60, -170], [-20, -160]], "#5a8a3a", 10); rr(c, 20, -150, 60, 50, 6, "#fff", 5); c.restore(); label(c, "JOB LOSS", 1300, 640, 40, "#e5233a", "#fff", pop(t, 109.9)); } },
  { s: 110.7, draw: (c, t, f) => { bgPlain(c, "#fff4ec", "#f0c8a8"); const n = Math.round(6 * ease(t, 111.6, 1.4));
    for (let i = 0; i < 6; i++) { const on = i < n; calendar(c, 330 + i * 250, 480 + (i % 2) * 30, 0.9 * pop(t, 111.0 + i * 0.12), "MONTH", String(i + 1), i < 3 ? "#ff7a29" : on ? "#ffb000" : "#c8c8d0"); }
    label(c, "3–6 MONTHS OF ESSENTIALS", 960, 170, 64, "#14141c", "#ffe14a", pop(t, 112.3)); label(c, "YOUR NUMBER DEPENDS ON YOU", 960, 860, 48, "#fff", INK, pop(t, 115.3)); } },
  { s: 117.1, draw: (c, t, f) => { bgRoom(c, "#e8e0f0", "#8a7a9a"); const hit = pop(t, 118.8);
    person(c, sam, { mood: hit > 0.5 ? "shock" : "worry", sweat: hit > 0.5 ? 1 : 0, t: f }, 560, GROUND, 520); T(c, "NO FUND?", 560, 150, 90, "#fff", pop(t, 117.6));
    c.save(); c.translate(1150, 420); c.scale(pop(t, 121.4), pop(t, 121.4)); rr(c, -190, -120, 380, 240, 22, "#2b3350"); rr(c, -190, -70, 380, 50, 0, INK, 0); T(c, "DEBT", 0, 60, 70, "#e5233a"); c.restore();
    c.save(); c.translate(1550, 640); c.scale(pop(t, 122.6), pop(t, 122.6)); rr(c, -200, -150, 400, 300, 14, "#fff"); line(c, [[-170, -100], [-80, -60], [0, -110], [60, 80], [170, 120]], "#e5233a", 12); T(c, "SELL AT A LOSS", 0, 120, 34, INK, 1, "#fff"); c.restore();
    stamp(c, "WORST TIME", 1550, 880, 60, "#e5233a", pop(t, 124.1)); } },
  { s: 124.9, draw: (c, t, f) => { bgSky(c, "#9ad0ff", "#e8f8ff"); person(c, sam, { mood: "grin", t: f }, 560, GROUND, 520);
    jar(c, 1100, 880, 1.3, ease(t, 126.4, 1.2), "", "#ffd23a"); label(c, "$1,000", 1100, 360, 70, "#2fd46a", INK, pop(t, 126.7)); T(c, "OR", 1380, 520, 60, "#fff", pop(t, 127.9)); calendar(c, 1620, 560, 1.0 * pop(t, 128.0), "MONTH", "1", "#ff7a29");
    T(c, "START SMALL", 960, 140, 100, "#fff", pop(t, 125.3)); T(c, "CHANGES EVERYTHING", 960, 990, 70, "#ffe14a", pop(t, 129.7)); } },
  { s: 130.6, draw: (c, t, f) => { bgStreet(c, t); rr(c, 300, 260, 600, 520, 10, "#e8e8f0"); c.beginPath(); c.moveTo(260, 260); c.lineTo(600, 120); c.lineTo(940, 260); c.closePath(); c.fillStyle = "#c8c8d8"; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke(); for (let i = 0; i < 4; i++) rr(c, 360 + i * 140, 320, 60, 400, 6, "#fff", 6); T(c, "BANK", 600, 210, 60, INK, 1, "#fff");
    label(c, "HIGH-YIELD SAVINGS", 600, 860, 50, "#2fa86a", "#fff", pop(t, 131.4)); label(c, "SAFE + EASY TO REACH", 600, 960, 40, "#fff", INK, pop(t, 132.9));
    c.save(); c.translate(1420, 520); c.scale(pop(t, 134.6), pop(t, 134.6)); rr(c, -250, -180, 500, 360, 16, "#fff"); line(c, [[-220, 60], [-120, -60], [-40, 80], [60, -120], [140, 40], [220, -20]], "#e5233a", 12); T(c, "STOCK MARKET", 0, -140, 40, INK, 1, "#fff"); c.restore(); cross(c, 1420, 520, 200, pop(t, 134.9)); } },
  { s: 136.1, draw: (c, t, f) => { bgSky(c, "#9ad0ff", "#fff0d0", "#e8d090", false); c.fillStyle = "#e8d090"; c.fillRect(0, GROUND - 20, W, H);
    rr(c, 260, GROUND - 40, 520, 90, 6, "#9aa0aa"); T(c, "EMERGENCY FUND", 520, GROUND + 6, 34, "#fff"); house(c, 520, GROUND - 40, 1.3 * pop(t, 137.9), "#f0d890");
    const sink = ease(t, 139.6, 1.2); house(c, 1400, GROUND - 10, 1.3 * pop(t, 139.3), "#c8a0d8", "#6a4a9a", sink * 120, -0.25 * sink);
    label(c, "FOUNDATION", 520, 150, 64, "#2fa86a", "#fff", pop(t, 137.9)); label(c, "SAND", 1400, 150, 64, "#e5233a", "#fff", pop(t, 140.1)); } },
  card(4, 141.6),
  /* ================= 4. INVEST CONSISTENTLY ================= */
  { s: 144.6, draw: (c, t, f) => { bgPlain(c, "#eaf6ff", "#a8c8e8"); const k = pop(t, 145.0);
    c.save(); c.translate(960, 560); c.scale(k, k); rr(c, -420, -220, 840, 440, 30, "#5a6a8a"); gear(c, -170, 0, 140, t * 1.5, "#ffd23a"); gear(c, 130, -40, 100, -t * 2.1, "#2fd46a"); gear(c, 290, 110, 70, t * 3, "#ff7a29"); c.restore();
    for (let i = 0; i < 5; i++) { const u = (t * 0.5 + i / 5) % 1; coin(c, lerp(1420, 1800, u), 700 - Math.sin(u * Math.PI) * 200, 26); }
    T(c, "THE ENGINE: INVESTING", 960, 140, 90, "#fff", pop(t, 146.2)); label(c, "CONSISTENTLY", 960, 950, 60, "#2fa86a", "#fff", pop(t, 147.4)); } },
  { s: 148.7, draw: (c, t, f) => { bgRoom(c, "#f0f4e8", "#9a9a7a"); const k = pop(t, 152.2);
    c.save(); c.translate(620, 760); c.scale(k, k); c.beginPath(); c.moveTo(-260, -200); c.lineTo(260, -200); c.lineTo(200, 60); c.lineTo(-200, 60); c.closePath(); c.fillStyle = "#c8945a"; c.fill(); c.lineWidth = 10; c.strokeStyle = INK; c.stroke();
    for (let i = 0; i < 12; i++) rr(c, -230 + (i % 6) * 78, -290 - Math.floor(i / 6) * 70, 64, 64, 10, ["#e5233a", "#2f8cff", "#ffd23a", "#2fd46a", "#9a5ad8", "#ff7a29"][i % 6], 5); c.restore();
    label(c, "INDEX FUND = MANY COMPANIES", 620, 220, 50, "#14141c", "#ffe14a", pop(t, 150.2)); label(c, "LOW COST", 620, 330, 44, "#2fa86a", "#fff", pop(t, 149.5));
    c.save(); c.translate(1420, 560); c.scale(pop(t, 153.7), pop(t, 153.7)); circ(c, 0, 0, 180, "#fff"); circ(c, 0, 0, 120, "#e5233a"); circ(c, 0, 0, 60, "#fff"); circ(c, 0, 0, 20, "#e5233a"); c.restore(); cross(c, 1420, 560, 200, pop(t, 154.7)); label(c, "PICKING WINNERS", 1420, 860, 44, "#fff", INK, pop(t, 154.4)); } },
  { s: 155.6, draw: (c, t, f) => { bgPlain(c, "#fff4e8", "#f0c8a0");
    c.save(); c.translate(520, 520); c.scale(pop(t, 157.2), pop(t, 157.2)); [[-70, 0], [70, 0]].forEach(([x], i) => { c.save(); c.translate(x, 0); c.rotate(0.3 * (i ? 1 : -1) + Math.sin(t * 5) * 0.1); rr(c, -80, -80, 160, 160, 26, "#fff"); circ(c, -35, -35, 16, INK, 0); circ(c, 35, 35, 16, INK, 0); circ(c, 0, 0, 16, INK, 0); c.restore(); }); c.restore(); cross(c, 520, 520, 220, pop(t, 157.8)); label(c, "ONE LUCKY BET", 520, 820, 50, "#fff", INK, pop(t, 157.4));
    const sl = ease(t, 159.1, 0.8); c.save(); c.translate(1400, 560); c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 250, -0.2, Math.PI * 1.6); c.closePath(); c.fillStyle = "#5ab0ff"; c.fill(); c.lineWidth = 10; c.strokeStyle = INK; c.stroke();
    c.save(); c.translate(sl * 90, -sl * 60); c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 250 + 30 * ease(t, 160.8, 1.0), Math.PI * 1.6, Math.PI * 1.6 + 0.6 + Math.PI * 0.02); c.closePath(); c.fillStyle = "#ffd23a"; c.fill(); c.stroke(); c.restore(); c.restore();
    label(c, "A SLICE OF THE ECONOMY", 1400, 900, 50, "#2fa86a", "#fff", pop(t, 159.1)); } },
  { s: 161.7, draw: (c, t, f) => { bgPlain(c, "#fffbe8", "#f0e0a8"); stamp(c, "ILLUSTRATION, NOT A PROMISE", 960, 520, 96, "#e5233a", pop(t, 162.0), -0.06); } },
  { s: 164.0, draw: (c, t, f) => { bgRoom(c, "#e8f4ec", "#8a9a8a"); person(c, sam, { mood: "smile", t: f }, 420, GROUND, 520);
    const n = Math.round(9 * ease(t, 164.4, 3.6)); for (let i = 0; i < 3; i++) { const u = ((t - 164.3) * 1.2 + i / 3) % 1; if (t > 164.3) coin(c, 1000, 200 + u * 420, 30); }
    jar(c, 1000, 880, 1.4, n / 9, "", "#ffd23a"); label(c, "$300 / MONTH", 1000, 150, 70, "#14141c", "#7ad07a", pop(t, 164.7)); label(c, "7% / YEAR (AVERAGE)", 1500, 420, 50, "#2fa86a", "#fff", pop(t, 167.1)); } },
  { s: 168.7, draw: (c, t, f) => { bgPlain(c, "#f4f8ff", "#c8d8f0");
    const years = 30, vals: [number, number][] = Array.from({ length: years }, (_, i) => { const n = (i + 1) * 12, r = 0.07 / 12, fv = 300 * ((Math.pow(1 + r, n) - 1) / r), inn = 300 * n; return [inn / 1000, (fv - inn) / 1000]; });
    const prog = t < 176.4 ? lerp(0, 20 / 30, ease(t, 168.9, 2.2)) : lerp(20 / 30, 1, ease(t, 176.4, 1.4)); bars(c, 200, 900, 1500, 680, vals, prog, 380);
    T(c, "YEARS →", 1600, 960, 40, INK, 1, "#fff"); rr(c, 230, 160, 40, 40, 6, "#5ab0ff", 5); T(c, "YOU PUT IN", 400, 180, 34, INK, 1, "#fff", "left"); rr(c, 230, 220, 40, 40, 6, "#2fd46a", 5); T(c, "GROWTH", 400, 240, 34, INK, 1, "#fff", "left");
    const x20 = 200 + 19.5 * 50, x30 = 200 + 29.5 * 50;
    label(c, "20 YRS: ~$156K", x20 - 260, 360, 46, "#14141c", "#7ad07a", pop(t, 172.0)); label(c, "you put in $72K", x20 - 260, 440, 34, "#fff", INK, pop(t, 173.9));
    label(c, "30 YRS: ~$366K", x30 - 300, 120, 46, "#14141c", "#ffe14a", pop(t, 179.0)); label(c, "you put in $108K", x30 - 300, 200, 34, "#fff", INK, pop(t, 180.8)); } },
  { s: 183.3, draw: (c, t, f) => { bgSky(c, "#5a9ae0", "#c8e4ff", "#e8f0fa", false); c.beginPath(); c.moveTo(0, 520); c.lineTo(W, 1000); c.lineTo(W, H); c.lineTo(0, H); c.closePath(); c.fillStyle = "#f4f8ff"; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke();
    const g = ease(t, 183.4, 3.2), x = lerp(160, 1480, g), r = lerp(40, 200, g * g), gy = 520 + (x / W) * 480; c.save(); c.translate(x, gy - r); c.rotate(g * 12); circ(c, 0, 0, r, "#ffffff"); line(c, [[-r * 0.5, 0], [r * 0.5, 0]], "#b8cce0", 8); line(c, [[0, -r * 0.5], [0, r * 0.5]], "#b8cce0", 8); c.restore();
    T(c, "GROWTH ON TOP OF GROWTH", 960, 180, 90, "#2f8cff", pop(t, 183.9)); label(c, "COMPOUNDING", 960, 330, 80, "#2fd46a", "#fff", pop(t, 185.4)); } },
  { s: 186.6, draw: (c, t, f) => { bgPlain(c, "#fff0f0", "#f0c0c0"); const k = ease(t, 186.8, 2.4);
    const pts = [[160, 640], [360, 520], [520, 600], [700, 420], [860, 760], [1000, 560], [1180, 380], [1340, 700], [1520, 460], [1760, 300]]; line(c, pts.slice(0, Math.max(2, Math.round(pts.length * k))), "#2f8cff", 16);
    label(c, "MARKETS DROP", 860, 900, 50, "#e5233a", "#fff", pop(t, 188.9)); label(c, "7% = ASSUMPTION", 960, 150, 64, "#14141c", "#ffe14a", pop(t, 191.8)); stamp(c, "NOT A GUARANTEE", 960, 290, 70, "#e5233a", pop(t, 192.8)); } },
  { s: 193.9, draw: (c, t, f) => { bgRoom(c, "#eef0ff", "#8a8aa0");
    c.save(); c.translate(500, 500); c.scale(pop(t, 195.8), pop(t, 195.8)); for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2; circ(c, Math.cos(a) * 110, Math.sin(a) * 75, 80, "#ff9ab8", 6); } circ(c, 0, 0, 100, "#ff9ab8", 0); c.restore(); cross(c, 500, 500, 200, pop(t, 196.2)); label(c, "BRILLIANCE", 500, 760, 50, "#fff", INK, pop(t, 196.0));
    c.save(); c.translate(1250, 480); c.scale(pop(t, 196.7), pop(t, 196.7)); circ(c, 0, 0, 170, "#fff"); line(c, [[0, 0], [0, -110]], INK, 12); line(c, [[0, 0], [Math.cos(t) * 80, Math.sin(t) * 80]], "#e5233a", 10); c.restore(); calendar(c, 1600, 520, pop(t, 197.3), "EVERY", "MONTH", "#2fa86a");
    label(c, "TIME + CONSISTENCY", 1420, 800, 60, "#2fa86a", "#fff", pop(t, 197.3)); } },
  { s: 198.5, draw: (c, t, f) => { bgPlain(c, "#f0fff4", "#c0e8cc"); const k = ease(t, 198.6, 3.6);
    const pts = Array.from({ length: 12 }, (_, i) => [220 + i * 130, 420 + Math.sin(i * 1.3) * 120 - i * 12] as number[]); line(c, pts.slice(0, Math.max(2, Math.round(12 * k))), "#2f8cff", 12);
    pts.forEach(([x, y], i) => { if (i / 12 < k) { const up = i === 0 || y <= pts[i - 1][1]; circ(c, x, y, 16, up ? "#2fd46a" : "#e5233a", 5); coin(c, x, 820, 28); } });
    label(c, "SAME AMOUNT, EVERY MONTH", 960, 150, 56, "#14141c", "#ffe14a", pop(t, 199.2)); label(c, "DOLLAR-COST AVERAGING", 960, 960, 64, "#2fa86a", "#fff", pop(t, 202.6)); stamp(c, "NO EMOTION", 1500, 300, 60, "#9a5ad8", pop(t, 204.7)); } },
  card(5, 207.2),
  /* ================= 5. ASSETS ================= */
  { s: 210.2, draw: (c, t, f) => { bgSky(c); tree(c, 1200, GROUND, 1.5 * pop(t, 210.3), Math.round(10 * ease(t, 211.0, 2.0)), t); person(c, sam, { mood: "grin", t: f, armR: [0.4, 0.8], armRK: 1 }, 620, GROUND, 520);
    T(c, "MONEY EARNING FOR YOU", 960, 130, 90, "#fff", pop(t, 211.7)); } },
  { s: 213.2, draw: (c, t, f) => { bgPlain(c, "#fffbe8", "#f0dca8"); label(c, "ASSETS", 960, 140, 90, "#14141c", "#ffe14a", pop(t, 213.2));
    const items: [string, number, (x: number, y: number, k: number) => void][] = [
      ["DIVIDEND STOCKS", 216.4, (x, y, k) => { c.save(); c.translate(x, y); c.scale(k, k); rr(c, -120, -90, 240, 180, 12, "#fff"); line(c, [[-90, 50], [-30, 0], [20, 20], [90, -60]], "#2fd46a", 12); c.restore(); for (let i = 0; i < 3; i++) coin(c, x - 60 + i * 60, y + 140 + ((t * 40 + i * 30) % 40) * k, 20 * k); }],
      ["RENTAL PROPERTY", 218.1, (x, y, k) => house(c, x, y + 120, 0.8 * k, "#a8d8a0")],
      ["A BUSINESS", 219.1, (x, y, k) => { c.save(); c.translate(x, y); c.scale(k, k); rr(c, -130, -80, 260, 200, 8, "#fff"); for (let i = 0; i < 5; i++) rr(c, -130 + i * 52, -120, 52, 60, 4, i % 2 ? "#e5233a" : "#fff", 4); rr(c, -40, 30, 80, 90, 4, "#6a4426", 5); c.restore(); }],
      ["BONDS", 219.7, (x, y, k) => { c.save(); c.translate(x, y); c.scale(k, k); rr(c, -130, -90, 260, 180, 6, "#f8f0d8"); rr(c, -110, -70, 220, 140, 4, "#f8f0d8", 4); circ(c, 70, 40, 28, "#e5233a", 4); c.restore(); }],
      ["ROYALTIES", 220.6, (x, y, k) => { c.save(); c.translate(x, y); c.scale(k, k); rr(c, -100, -120, 200, 240, 10, "#9a5ad8"); rr(c, -80, -100, 20, 200, 4, "#7a3ab8", 0); T(c, "♪", 20, 0, 110, "#ffe14a"); c.restore(); }]];
    items.forEach(([s, a, d], i) => { const x = 230 + i * 365, y = 480, k = pop(t, a); if (k > 0.01) { d(x, y, k); label(c, s, x, 760, 32, "#fff", INK, k); } }); } },
  { s: 222.9, draw: (c, t, f) => { bgPlain(c, "#eef8ff", "#c0d8f0"); const pick = ease(t, 224.8, 0.6); const names = ["STOCKS", "RENTAL", "BUSINESS", "BONDS", "ROYALTIES"];
    names.forEach((s, i) => { const on = i === 0, x = lerp(260 + i * 350, on ? 960 : 260 + i * 350, pick), y = lerp(520, on ? 520 : 760, pick), k = on ? 1 + 0.4 * pick : 1 - 0.5 * pick; c.globalAlpha = on ? 1 : 1 - 0.6 * pick; c.save(); c.translate(x, y); c.scale(k, k); rr(c, -150, -100, 300, 200, 20, on ? "#2fd46a" : "#fff"); T(c, s, 0, 0, 40, on ? "#fff" : INK, 1, INK); c.restore(); c.globalAlpha = 1; });
    T(c, "YOU DON'T NEED ALL OF THEM", 960, 150, 80, "#fff", pop(t, 223.0)); T(c, "START WITH ONE", 960, 960, 80, "#ffe14a", pop(t, 225.0)); } },
  { s: 225.8, draw: (c, t, f) => { bgRoom(c, "#f8f0e0", "#a8885a"); const cov = ease(t, 228.5, 2.0);
    ["RENT", "FOOD", "POWER", "PHONE"].forEach((s, i) => { const x = 300 + i * 260; rr(c, x - 100, 300, 200, 260, 12, "#fff"); T(c, s, x, 360, 36, INK, 1, "#fff"); if (cov * 4 > i + 0.5 && i < 2) stamp(c, "PAID", x, 470, 46, "#1fa850", pop(t, 228.8 + i * 0.4)); });
    rr(c, 260, 660, 1000, 60, 20, "#ddd"); rr(c, 260, 660, 1000 * 0.5 * cov, 60, 20, "#2fd46a"); T(c, "LIVING COSTS COVERED BY ASSETS", 760, 780, 40, "#fff");
    tree(c, 1600, GROUND, 1.0, 6, t); label(c, "SOME OF IT", 1600, 200, 50, "#14141c", "#ffe14a", pop(t, 229.3)); } },
  { s: 230.9, draw: (c, t, f) => { bgOffice(c); const sw = ease(t, 232.6, 0.8);
    person(c, sam, { mood: sw > 0.5 ? "grin" : "deadpan", t: f, armR: [0.4, 0.5], armRK: 1 - sw }, lerp(560, 300, sw), GROUND, 520);
    if (sw > 0.01) for (let i = 0; i < 5; i++) { const x = 800 + i * 200, y = 820 + Math.abs(Math.sin(t * 8 + i)) * -30; coin(c, x, y - 60, 46 * sw); line(c, [[x - 20, y - 20], [x - 30 + Math.sin(t * 10 + i) * 14, y + 30]], INK, 7); line(c, [[x + 20, y - 20], [x + 30 - Math.sin(t * 10 + i) * 14, y + 30]], INK, 7); }
    label(c, "WORKING FOR MONEY", 560, 160, 54, "#8a8aa0", "#fff", pop(t, 231.8) * (1 - sw)); label(c, "MONEY WORKING FOR YOU", 1200, 160, 60, "#2fa86a", "#fff", pop(t, 232.8)); } },
  { s: 234.7, draw: (c, t, f) => { bgPlain(c, "#f4fff0", "#c8e8b8"); line(c, [[200, 900], [1720, 900]], INK, 8); line(c, [[200, 900], [200, 200]], INK, 8);
    const k = ease(t, 234.8, 3.6), pts = Array.from({ length: 40 }, (_, i) => { const u = i / 39; return [200 + u * 1500, 880 - Math.pow(u, 3) * 640] as number[]; }); line(c, pts.slice(0, Math.max(2, Math.round(40 * k))), "#2fd46a", 18);
    label(c, "SLOWLY…", 500, 760, 50, "#fff", INK, pop(t, 235.2)); label(c, "THEN FASTER", 1450, 260, 60, "#2fd46a", "#fff", pop(t, 236.8)); T(c, "THE MORE YOU OWN, THE MORE IT PRODUCES", 960, 120, 56, "#fff", pop(t, 237.6)); } },
  card(6, 240.4),
  /* ================= 6. PATIENCE ================= */
  { s: 243.4, draw: (c, t, f) => { bgSky(c); const jump = ease(t, 244.6, 0.9);
    for (let i = 0; i < 6; i++) { const x = 300 + i * 260; rr(c, x - 90, GROUND - 40 - i * 30, 180, 40 + i * 30, 8, i === 5 ? "#ffb000" : "#c8c8d0"); T(c, String(i + 1), x, GROUND - 80 - i * 30, 50, INK, 1, "#fff"); }
    person(c, sam, { mood: "grin", arms: "up", armK: jump, t: f }, lerp(1080, 1900, jump), GROUND - 180 - Math.sin(jump * Math.PI) * 260, 380); label(c, "THE STEP EVERYONE SKIPS", 960, 140, 60, "#14141c", "#ffe14a", pop(t, 244.5)); } },
  { s: 245.9, draw: (c, t, f) => { bgNight(c); c.fillStyle = "#2a1a4a"; c.fillRect(0, GROUND - 40, W, H);
    rr(c, 1000, 160, 800, 260, 30, "#14141c", 10, "#ff3ad8"); T(c, "GET RICH QUICK!!!", 1400, 260, 76, "#ff3ad8", 1, "#fff"); T(c, "100x IN 30 DAYS", 1400, 360, 46, "#ffe14a");
    person(c, guru, { mood: "grin", arms: "up", armK: 1, t: f }, 560, GROUND, 540); label(c, "SELLS: SPEED", 560, 200, 54, "#ff3ad8", "#fff", pop(t, 247.1)); } },
  { s: 248.0, draw: (c, t, f) => { bgRoom(c, "#e8e8e8", "#9a9a9a"); person(c, sam, { mood: "deadpan", t: f, hunch: 0.2 }, 460, GROUND, 520); T(c, "BORING", 460, 180, 90, "#8a8aa0", pop(t, 248.7));
    const steps: [string, number][] = [["SAVE", 249.5], ["INVEST", 249.9], ["REPEAT", 250.4]]; steps.forEach(([s, a], i) => { const ang = -Math.PI / 2 + i * (Math.PI * 2 / 3) + t * 0.6; label(c, s, 1300 + Math.cos(ang) * 260, 520 + Math.sin(ang) * 260, 50, ["#2fd46a", "#2f8cff", "#ff7a29"][i], "#fff", pop(t, a)); });
    calendar(c, 1300, 520, 0.8 * pop(t, 251.0), "YEARS", String(1 + Math.floor(Math.max(0, t - 251) * 4) % 30), "#2b3350"); } },
  { s: 251.8, draw: (c, t, f) => { bgPlain(c, "#fff0e8", "#f0b8a0"); const k = pop(t, 253.1);
    c.save(); c.translate(960, 480); c.scale(k, k); rr(c, -560, -230, 1120, 460, 26, "#ffe14a", 14); T(c, "GUARANTEED RETURNS!", 0, -90, 80, "#e5233a", 1, INK); T(c, "HUGE PROFITS, NO RISK!", 0, 60, 70, INK, 1, "#fff"); c.restore();
    c.save(); c.translate(960, 900); c.scale(pop(t, 256.7), pop(t, 256.7)); c.beginPath(); c.moveTo(0, -110); c.lineTo(120, 90); c.lineTo(-120, 90); c.closePath(); c.fillStyle = "#e5233a"; c.fill(); c.lineWidth = 10; c.strokeStyle = INK; c.stroke(); T(c, "!", 0, 20, 120, "#fff"); c.restore(); T(c, "BE CAREFUL", 960, 110, 80, "#fff", pop(t, 251.9)); } },
  { s: 257.5, draw: (c, t, f) => { bgSky(c, "#3a8ad8", "#9ad0ff", "#1f6ad8", false); const bob = Math.sin(t * 2) * 20;
    line(c, [[960, 0], [960, 520 + bob]], "#e8e8e8", 5); c.beginPath(); c.arc(960, 560 + bob, 40, 0, Math.PI); c.lineWidth = 10; c.strokeStyle = "#9a9aa8"; c.stroke(); bill(c, 960, 620 + bob, 1.4, 0.1);
    T(c, "TOO GOOD TO BE TRUE?", 960, 160, 90, "#fff", pop(t, 257.9)); T(c, "IT USUALLY IS.", 960, 900, 90, "#ffe14a", pop(t, 259.1)); } },
  { s: 260.3, draw: (c, t, f) => { bgSky(c, "#ffb070", "#ffe8c0", "#c8b088", false); line(c, [[0, 960], [W, 860]], "#e8d8b8", 90); const w = ease(t, 263.5, 2.6);
    [0, 1].forEach((i) => person(c, [rich, guru][i], { mood: "deadpan", t: f + i * 5, flip: true }, 200 + i * 220, GROUND + 30, 340)); label(c, "QUIT", 310, 520, 40, "#8a8aa0", "#fff", pop(t, 262.0));
    person(c, sam, { mood: "smile", walk: f * 0.25, speed: 0.6, t: f }, lerp(700, 1500, (t - 260.3) / 6), GROUND - 20, 400);
    T(c, "NO TRICK", 1300, 180, 80, "#fff", pop(t, 262.7)); label(c, "KEEP GOING", 1300, 320, 70, "#2fa86a", "#fff", pop(t, 264.2)); void w; } },
  card(7, 266.7),
  /* ================= CLOSE ================= */
  { s: 269.7, draw: (c, t, f) => { bgPlain(c, "#f4f8ff", "#c8d8f0"); const items: [string, number][] = [["Separate income from wealth", 270.9], ["Raise income, not spending", 272.2], ["Build an emergency fund", 275.1], ["Invest consistently", 277.3], ["Build assets that pay you", 279.0], ["Give it time", 280.5]];
    items.forEach(([s, a], i) => check(c, 420, 190 + i * 130, 1.1, ease(t, a, 0.4), s.toUpperCase())); person(c, sam, { mood: "grin", t: f }, 1650, GROUND, 460); } },
  { s: 281.6, draw: (c, t, f) => { bgPlain(c, "#fffbe8", "#f0dca8"); wallet(c, 520, 620, 1.6, true, t); cross(c, 520, 560, 200, pop(t, 282.6)); label(c, "START WITH MONEY", 520, 880, 46, "#fff", INK, pop(t, 282.1));
    gear(c, 1300, 500, 140, t, "#ffd23a"); gear(c, 1520, 650, 100, -t * 1.4, "#2fd46a"); gear(c, 1530, 380, 70, -t * 2, "#ff7a29"); label(c, "START WITH A SYSTEM", 1400, 880, 54, "#2fa86a", "#fff", pop(t, 284.5)); } },
  { s: 285.5, draw: (c, t, f) => { bgRoom(c, "#e8f4ec", "#8a9a8a", false); T(c, "YOUR CHALLENGE: ONE STEP THIS WEEK", 960, 130, 70, "#ffe14a", pop(t, 285.8));
    const opts: [string, number, string][] = [["OPEN A SAVINGS ACCOUNT", 288.6, "#2f8cff"], ["AUTOMATE AN INVESTMENT", 290.1, "#2fa86a"], ["SAVE +1% MORE", 292.3, "#ff7a29"]];
    opts.forEach(([s, a, col], i) => { const k = pop(t, a), x = 420 + i * 540; c.save(); c.translate(x, 520); c.scale(k, k); rr(c, -230, -170, 460, 340, 26, col); T(c, String(i + 1), 0, -60, 110, "#fff"); T(c, s, 0, 90, 30, "#fff"); c.restore(); });
    person(c, sam, { mood: "grin", arms: "point", armK: 1, t: f }, 1700, GROUND + 40, 300); } },
  { s: 295.0, draw: (c, t, f) => { bgSky(c); const k = ease(t, 295.0, 2.0); for (let i = 0; i < 8; i++) { if (i / 8 > k) continue; rr(c, 300 + i * 160, GROUND - 40 - i * 60, 160, 40 + i * 60, 6, "#ffd23a"); }
    person(c, sam, { mood: "grin", t: f }, 300 + Math.min(7, Math.floor(k * 8)) * 160 + 80, GROUND - 40 - Math.min(7, Math.floor(k * 8)) * 60, 300); T(c, "SMALL MOVES, REPEATED", 960, 130, 90, "#fff", pop(t, 295.3)); } },
  { s: 297.6, draw: (c, t, f) => { bgPlain(c, "#f4f4f8", "#d0d0dc"); c.save(); c.translate(960, 480); c.scale(pop(t, 297.7), pop(t, 297.7)); rr(c, -620, -200, 1240, 400, 30, "#fff"); T(c, "EDUCATION, NOT FINANCIAL ADVICE", 0, -60, 64, INK, 1, "#fff"); T(c, "Do your own research or talk to a licensed professional", 0, 70, 38, "#5a5a6a", 1, "#fff"); c.restore(); } },
  { s: 305.8, draw: (c, t, f) => { bgPlain(c, "#fff0f0", "#f0c8c8"); const pr = ease(t, 306.6, 0.25), b = 1 - 0.08 * Math.sin(pr * Math.PI);
    c.save(); c.translate(960, 380); c.scale(b * pop(t, 306.0), b * pop(t, 306.0)); rr(c, -300, -90, 600, 180, 90, pr > 0.5 ? "#8a8aa0" : "#e5233a"); T(c, pr > 0.5 ? "SUBSCRIBED" : "SUBSCRIBE", 0, 4, 72, "#fff"); c.restore();
    c.save(); c.translate(1380, 380); c.rotate(Math.sin(t * 14) * 0.25 * ease(t, 307.0, 0.3)); c.scale(pop(t, 307.0), pop(t, 307.0)); c.beginPath(); c.moveTo(-60, 50); c.quadraticCurveTo(-60, -80, 0, -80); c.quadraticCurveTo(60, -80, 60, 50); c.closePath(); c.fillStyle = "#ffd23a"; c.fill(); c.lineWidth = 9; c.strokeStyle = INK; c.stroke(); circ(c, 0, 66, 16, "#ffd23a"); c.restore();
    label(c, "WHICH STEP ARE YOU STARTING WITH?", 960, 720, 56, "#14141c", "#ffe14a", pop(t, 308.2)); T(c, "COMMENT BELOW ↓", 960, 860, 64, "#fff", pop(t, 308.7)); } },
];
