// 2D cartoon kit for long-form 16:9 videos (canvas 2D, fast to render). All coords in a 1920x1080 space.
import { drawPuppet, Look, Pose } from "../style/puppet";
export const W = 1920, H = 1080, INK = "#14141c", GROUND = 900;
export const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const lin = (t: number, a: number, d = 0.4) => clamp((t - a) / d);
export const ease = (t: number, a: number, d = 0.6) => { const s = lin(t, a, d); return 0.5 - 0.5 * Math.cos(Math.PI * s); };
export const pop = (t: number, a: number, d = 0.35) => { const s = lin(t, a, d); if (s <= 0) return 0; const c1 = 2.2, c3 = c1 + 1; return 1 + c3 * Math.pow(s - 1, 3) + c1 * Math.pow(s - 1, 2); };
type C = CanvasRenderingContext2D;

/* ---------- characters ---------- */
const pool: HTMLCanvasElement[] = []; let pi = 0;
export const resetPool = () => { pi = 0; };
export function person(c: C, look: Look, pose: Partial<Pose>, x: number, fy = GROUND, h = 520) {
  const cv = pool[pi] || (pool[pi] = Object.assign(document.createElement("canvas"), { width: 512, height: 768 })); pi++;
  drawPuppet(cv.getContext("2d")!, 512, 768, look, { t: 0, ...pose } as Pose);
  const w = h * 512 / 768;
  c.save(); c.fillStyle = "rgba(0,0,0,.18)"; c.beginPath(); c.ellipse(x, fy, w * 0.32, h * 0.03, 0, 0, 7); c.fill(); c.restore();
  c.drawImage(cv, x - w / 2, fy - h * 0.983, w, h);
}
export const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });

/* ---------- primitives ---------- */
export function rr(c: C, x: number, y: number, w: number, h: number, r: number, fill: string, lw = 8, stroke = INK) {
  c.beginPath(); c.roundRect(x, y, w, h, r); c.fillStyle = fill; c.fill(); if (lw > 0) { c.lineWidth = lw; c.strokeStyle = stroke; c.stroke(); }
}
export function circ(c: C, x: number, y: number, r: number, fill: string, lw = 8) { c.beginPath(); c.arc(x, y, Math.max(0.1, r), 0, 7); c.fillStyle = fill; c.fill(); if (lw > 0) { c.lineWidth = lw; c.strokeStyle = INK; c.stroke(); } }
export function line(c: C, pts: number[][], col = INK, lw = 8) { c.beginPath(); pts.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y))); c.strokeStyle = col; c.lineWidth = lw; c.lineCap = "round"; c.lineJoin = "round"; c.stroke(); }
/** big outlined text, scaled by k around (x,y) */
export function T(c: C, s: string, x: number, y: number, size: number, fill = "#fff", k = 1, stroke = INK, align: CanvasTextAlign = "center") {
  if (k <= 0.01) return; c.save(); c.translate(x, y); c.scale(k, k); c.font = `900 ${size}px Inter, Arial`; c.textAlign = align; c.textBaseline = "middle";
  c.lineJoin = "round"; c.lineWidth = size * 0.2; c.strokeStyle = stroke; c.strokeText(s, 0, 0); c.fillStyle = fill; c.fillText(s, 0, 0); c.restore();
}
/** label badge */
export function label(c: C, s: string, x: number, y: number, size: number, bg: string, fg = "#fff", k = 1, rot = 0) {
  if (k <= 0.01) return; c.save(); c.translate(x, y); c.rotate(rot); c.scale(k, k); c.font = `900 ${size}px Inter, Arial`; const w = c.measureText(s).width + size * 1.1, h = size * 1.6;
  rr(c, -w / 2, -h / 2, w, h, h * 0.3, bg, Math.max(5, size * 0.13)); c.fillStyle = fg; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(s, 0, size * 0.05); c.restore();
}
export function stamp(c: C, s: string, x: number, y: number, size: number, col: string, k: number, rot = -0.12) {
  if (k <= 0.01) return; c.save(); c.translate(x, y); c.rotate(rot); c.scale(k, k); c.font = `900 ${size}px Inter, Arial`; const w = c.measureText(s).width + size * 0.8, h = size * 1.4;
  c.strokeStyle = col; c.lineWidth = size * 0.12; c.strokeRect(-w / 2, -h / 2, w, h); c.fillStyle = col; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(s, 0, size * 0.05); c.restore();
}
export function cross(c: C, x: number, y: number, r: number, k: number) { if (k <= 0.01) return; const a = r * k; line(c, [[x - a, y - a], [x + a, y + a]], "#e5233a", r * 0.22); line(c, [[x + a, y - a], [x - a, y + a]], "#e5233a", r * 0.22); }
export function arrow(c: C, x1: number, y1: number, x2: number, y2: number, col: string, lw = 18, k = 1) {
  if (k <= 0.01) return; const x = lerp(x1, x2, k), y = lerp(y1, y2, k), a = Math.atan2(y - y1, x - x1);
  line(c, [[x1, y1], [x, y]], INK, lw + 10); line(c, [[x1, y1], [x, y]], col, lw);
  c.save(); c.translate(x, y); c.rotate(a); c.beginPath(); c.moveTo(lw * 1.8, 0); c.lineTo(-lw, lw * 1.6); c.lineTo(-lw, -lw * 1.6); c.closePath(); c.fillStyle = col; c.fill(); c.lineWidth = 6; c.strokeStyle = INK; c.stroke(); c.restore();
}

/* ---------- backgrounds ---------- */
export function bgRoom(c: C, wall = "#f0c890", floor = "#b8865a", win = true) {
  c.fillStyle = wall; c.fillRect(0, 0, W, GROUND - 40);
  c.fillStyle = "rgba(0,0,0,.05)"; for (let x = 0; x < W; x += 120) c.fillRect(x, 0, 60, GROUND - 40);
  c.fillStyle = floor; c.fillRect(0, GROUND - 40, W, H); c.strokeStyle = "rgba(0,0,0,.18)"; c.lineWidth = 4; for (let y = GROUND; y < H; y += 60) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
  c.fillStyle = "#6a4426"; c.fillRect(0, GROUND - 60, W, 22);
  if (win) { rr(c, 1380, 140, 380, 300, 10, "#9fd4ff"); c.fillStyle = "#7ab0e8"; [[1400, 330, 60, 110], [1470, 290, 70, 150], [1550, 350, 50, 90], [1610, 270, 80, 170], [1700, 320, 50, 120]].forEach(([x, y, w, h]) => c.fillRect(x, y, w, h)); line(c, [[1570, 140], [1570, 440]], INK, 8); line(c, [[1380, 290], [1760, 290]], INK, 8); }
}
export function bgSky(c: C, top = "#7ab8f0", bottom = "#d8f0ff", grass = "#7ac25a", hills = true) {
  const g = c.createLinearGradient(0, 0, 0, GROUND); g.addColorStop(0, top); g.addColorStop(1, bottom); c.fillStyle = g; c.fillRect(0, 0, W, GROUND);
  if (hills) { c.fillStyle = "#9ad07a"; c.beginPath(); c.ellipse(300, GROUND + 40, 700, 220, 0, 0, 7); c.fill(); c.beginPath(); c.ellipse(1600, GROUND + 60, 800, 260, 0, 0, 7); c.fill(); }
  c.fillStyle = grass; c.fillRect(0, GROUND - 10, W, H); c.fillStyle = "rgba(0,0,0,.06)"; c.fillRect(0, GROUND - 10, W, 14);
  [[250, 160, 1], [900, 110, 1.3], [1500, 190, 0.9]].forEach(([x, y, s]) => { c.fillStyle = "#fff"; [[-60, 0, 50], [0, -20, 65], [60, 0, 50]].forEach(([dx, dy, r]) => { c.beginPath(); c.arc(x + dx * s, y + dy * s, r * s, 0, 7); c.fill(); }); });
}
export function bgStreet(c: C, t: number, dusk = false) {
  bgSky(c, dusk ? "#ff9a6a" : "#7ab8f0", dusk ? "#ffe0b0" : "#d8f0ff", "#8a8a96", false);
  const cols = ["#e8a87c", "#9ac0e8", "#f0d890", "#c8a0d8", "#a8d8a0", "#f0b0b0"];
  for (let i = 0; i < 7; i++) { const x = -60 + i * 300, h = 260 + (i % 3) * 50; rr(c, x, GROUND - 120 - h, 260, h, 6, cols[i % 6]); c.beginPath(); c.moveTo(x - 20, GROUND - 120 - h); c.lineTo(x + 130, GROUND - 220 - h); c.lineTo(x + 280, GROUND - 120 - h); c.closePath(); c.fillStyle = "#a84a3a"; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke();
    rr(c, x + 40, GROUND - 60 - h, 70, 70, 4, "#ffe9a8", 6); rr(c, x + 150, GROUND - 60 - h, 70, 70, 4, "#ffe9a8", 6); rr(c, x + 100, GROUND - 230, 60, 110, 4, "#6a4426", 6); }
  c.fillStyle = "#c8c8d0"; c.fillRect(0, GROUND - 120, W, 60); c.fillStyle = "#5a5a66"; c.fillRect(0, GROUND - 60, W, H); c.fillStyle = "#ffd23a"; for (let x = ((-t * 0) % 200); x < W; x += 200) c.fillRect(x, GROUND + 60, 100, 14);
}
export function bgPlain(c: C, a: string, b: string) { const g = c.createRadialGradient(W / 2, H * 0.45, 80, W / 2, H / 2, W * 0.75); g.addColorStop(0, a); g.addColorStop(1, b); c.fillStyle = g; c.fillRect(0, 0, W, H); }
export function bgOffice(c: C) {
  bgRoom(c, "#d8e0ec", "#8a8aa0", true);
  rr(c, 260, GROUND - 260, 620, 40, 8, "#a8784a"); rr(c, 300, GROUND - 220, 30, 220, 4, "#6a4426", 6); rr(c, 810, GROUND - 220, 30, 220, 4, "#6a4426", 6);
  rr(c, 440, GROUND - 470, 260, 190, 10, "#2b3350"); rr(c, 458, GROUND - 452, 224, 150, 6, "#5ab0ff", 4); rr(c, 550, GROUND - 285, 40, 30, 4, "#2b3350", 5);
}
export function bgNight(c: C) { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#0a1030"); g.addColorStop(1, "#2a2060"); c.fillStyle = g; c.fillRect(0, 0, W, H); for (let i = 0; i < 90; i++) { c.fillStyle = "rgba(255,255,240,.8)"; c.fillRect((i * 7919) % W, (i * 104729) % (H * 0.6), 3, 3); } }

/* ---------- props ---------- */
export function bill(c: C, x: number, y: number, s = 1, rot = 0) { c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); rr(c, -60, -30, 120, 60, 6, "#7ad07a", 5); circ(c, 0, 0, 16, "#5ab05a", 4); c.fillStyle = INK; c.font = "900 22px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("$", 0, 1); c.restore(); }
export function coin(c: C, x: number, y: number, r = 28) { circ(c, x, y, r, "#ffd23a", 5); circ(c, x, y, r * 0.65, "#ffe680", 3); c.fillStyle = "#b8860b"; c.font = `900 ${r * 0.9}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("$", x, y + 1); }
export function coinStack(c: C, x: number, y: number, n: number, r = 34) { for (let i = 0; i < n; i++) { c.beginPath(); c.ellipse(x, y - i * 14, r, r * 0.38, 0, 0, 7); c.fillStyle = i % 2 ? "#ffd23a" : "#f0c020"; c.fill(); c.lineWidth = 4; c.strokeStyle = INK; c.stroke(); } }
/** bucket: level 0..1, holes count, leak 0..1 */
export function bucket(c: C, x: number, y: number, s: number, level: number, t: number, holes = 0, leak = 0, lab = "") {
  c.save(); c.translate(x, y); c.scale(s, s);
  c.beginPath(); c.moveTo(-150, -260); c.lineTo(150, -260); c.lineTo(115, 0); c.lineTo(-115, 0); c.closePath(); c.fillStyle = "#c8d0dc"; c.fill();
  const ly = -260 * level; if (level > 0.01) { c.save(); c.clip(); c.fillStyle = "#3a9af0"; c.fillRect(-160, ly + Math.sin(t * 3) * 4, 320, -ly + 10); c.fillStyle = "rgba(255,255,255,.35)"; c.fillRect(-160, ly - 4 + Math.sin(t * 3) * 4, 320, 12); c.restore(); }
  c.beginPath(); c.moveTo(-150, -260); c.lineTo(150, -260); c.lineTo(115, 0); c.lineTo(-115, 0); c.closePath(); c.lineWidth = 9; c.strokeStyle = INK; c.stroke();
  c.beginPath(); c.ellipse(0, -260, 150, 26, 0, 0, 7); c.stroke(); line(c, [[-150, -250], [-40, -380], [40, -380], [150, -250]], INK, 7);
  for (let i = 0; i < holes; i++) { const hx = -80 + i * 55, hy = -40 - (i % 2) * 60; circ(c, hx, hy, 9, INK, 0); if (leak > 0) { for (let j = 0; j < 4; j++) { const u = (t * 2 + j / 4 + i * 0.3) % 1; circ(c, hx - 10 - u * 60 * (i % 2 ? -1 : 1), hy + u * 140, 7, "#3a9af0", 0); } } }
  if (lab) label(c, lab, 0, -130, 40, "#14141c", "#ffe14a");
  c.restore();
}
export function faucet(c: C, x: number, y: number, s: number, flow: number, t: number, lab = "") {
  c.save(); c.translate(x, y); c.scale(s, s); rr(c, -200, -40, 220, 60, 12, "#b8c0cc"); rr(c, 0, -40, 60, 120, 12, "#b8c0cc"); rr(c, -120, -90, 60, 50, 8, "#e5233a");
  if (flow > 0) { const w = 18 + 40 * flow; c.fillStyle = "#3a9af0"; c.fillRect(30 - w / 2, 80, w, 420); for (let i = 0; i < 6; i++) { const u = (t * 3 + i / 6) % 1; circ(c, 30 + Math.sin(i * 3) * w * 0.6, 80 + u * 420, 6, "#bfe4ff", 0); } }
  if (lab) label(c, lab, -90, -140, 40, "#2fa86a", "#fff"); c.restore();
}
export function jar(c: C, x: number, y: number, s: number, level: number, lab = "", col = "#ffd23a") {
  c.save(); c.translate(x, y); c.scale(s, s); rr(c, -110, -260, 220, 260, 40, "rgba(220,240,255,.7)"); rr(c, -80, -290, 160, 40, 10, "#8a5a32");
  const n = Math.round(level * 9); for (let i = 0; i < n; i++) coin(c, -50 + (i % 3) * 50, -30 - Math.floor(i / 3) * 52, 24);
  if (lab) label(c, lab, 0, 50, 34, col, "#14141c"); c.restore();
}
export function wallet(c: C, x: number, y: number, s: number, empty: boolean, t = 0) { c.save(); c.translate(x, y); c.scale(s, s); if (!empty) { bill(c, -10, -60, 0.9, -0.2); bill(c, 20, -70, 0.9, 0.15); } rr(c, -100, -60, 200, 130, 20, "#8a5a32"); rr(c, 30, -20, 80, 50, 12, "#6a4426"); circ(c, 70, 5, 10, "#ffd23a", 4);
  if (empty) { const u = (t * 0.8) % 1; c.fillStyle = "#b8b0a0"; c.beginPath(); c.ellipse(-20 + Math.sin(t * 6) * 10, -90 - u * 120, 22, 12, Math.sin(t * 20) * 0.6, 0, 7); c.fill(); c.lineWidth = 3; c.strokeStyle = INK; c.stroke(); } c.restore(); }
export function car(c: C, x: number, y: number, s: number, col = "#e5233a", smoke = 0, t = 0) { c.save(); c.translate(x, y); c.scale(s, s); rr(c, -170, -110, 340, 80, 24, col); rr(c, -100, -170, 190, 70, 24, col); rr(c, -80, -158, 70, 48, 8, "#bfe4ff", 5); rr(c, 0, -158, 70, 48, 8, "#bfe4ff", 5); circ(c, -100, -30, 36, "#333"); circ(c, 100, -30, 36, "#333"); circ(c, -100, -30, 14, "#aaa", 4); circ(c, 100, -30, 14, "#aaa", 4);
  for (let i = 0; i < 4 && smoke > 0; i++) { const u = (t * 0.7 + i / 4) % 1; circ(c, 160 + u * 40, -120 - u * 160, 20 + u * 30, `rgba(90,90,100,${0.7 * (1 - u) * smoke})`, 0); } c.restore(); }
export function house(c: C, x: number, y: number, s: number, col = "#f0d890", roof = "#c0402e", sink = 0, tilt = 0) { c.save(); c.translate(x, y + sink); c.rotate(tilt); c.scale(s, s); rr(c, -130, -200, 260, 200, 4, col); c.beginPath(); c.moveTo(-160, -200); c.lineTo(0, -320); c.lineTo(160, -200); c.closePath(); c.fillStyle = roof; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke(); rr(c, -30, -110, 60, 110, 4, "#6a4426", 6); rr(c, -105, -160, 55, 55, 4, "#bfe4ff", 6); rr(c, 50, -160, 55, 55, 4, "#bfe4ff", 6); c.restore(); }
export function phone(c: C, x: number, y: number, s: number, icons: number) { c.save(); c.translate(x, y); c.scale(s, s); rr(c, -90, -170, 180, 340, 26, "#2b3350"); rr(c, -76, -150, 152, 290, 12, "#f4f4fa", 4); const cols = ["#e5233a", "#1fa850", "#2f8cff", "#ff7a29", "#9a5ad8", "#14141c"]; for (let i = 0; i < icons; i++) rr(c, -60 + (i % 3) * 44, -130 + Math.floor(i / 3) * 50, 34, 34, 8, cols[i % 6], 3); c.restore(); }
export function calendar(c: C, x: number, y: number, s: number, top: string, big: string, col = "#e5233a") { c.save(); c.translate(x, y); c.scale(s, s); rr(c, -110, -120, 220, 240, 16, "#fff"); rr(c, -110, -120, 220, 70, 16, col); c.fillStyle = "#fff"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(top, 0, -84); c.fillStyle = INK; c.font = `900 ${big.length > 3 ? 54 : 84}px Inter, Arial`; c.fillText(big, 0, 30); c.restore(); }
export function piggy(c: C, x: number, y: number, s: number, glow = 0) { c.save(); c.translate(x, y); c.scale(s, s); if (glow > 0) { const g = c.createRadialGradient(0, -100, 10, 0, -100, 260); g.addColorStop(0, `rgba(255,230,120,${0.7 * glow})`); g.addColorStop(1, "rgba(255,230,120,0)"); c.fillStyle = g; c.fillRect(-300, -360, 600, 520); }
  [[-80, 0], [60, 0]].forEach(([lx]) => rr(c, lx, -40, 34, 50, 8, "#ff9ab8", 5)); c.beginPath(); c.ellipse(0, -110, 160, 110, 0, 0, 7); c.fillStyle = "#ff9ab8"; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke(); rr(c, 140, -140, 50, 60, 16, "#ff7aa0", 6); circ(c, 70, -150, 10, INK, 0); rr(c, -40, -230, 80, 14, 6, INK, 0);
  c.beginPath(); c.moveTo(-60, -200); c.lineTo(-30, -250); c.lineTo(-10, -200); c.fillStyle = "#ff7aa0"; c.fill(); c.stroke(); c.restore(); }
export function safe(c: C, x: number, y: number, s: number, open = 0) { c.save(); c.translate(x, y); c.scale(s, s); rr(c, -150, -300, 300, 300, 20, "#6a7a8a"); rr(c, -120, -270, 240, 240, 14, "#8a9aaa", 6); circ(c, 0, -150, 50, "#5a6a7a"); for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2 + open * 2; line(c, [[0, -150], [Math.cos(a) * 46, -150 + Math.sin(a) * 46]], INK, 8); } c.restore(); }
export function gear(c: C, x: number, y: number, r: number, rot: number, col = "#ffd23a") { c.save(); c.translate(x, y); c.rotate(rot); c.beginPath(); for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2, rr2 = i % 2 ? r : r * 1.2; c.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } c.closePath(); c.fillStyle = col; c.fill(); c.lineWidth = 8; c.strokeStyle = INK; c.stroke(); circ(c, 0, 0, r * 0.35, "#fff8e0"); c.restore(); }
export function tree(c: C, x: number, y: number, s: number, coins: number, t = 0) { c.save(); c.translate(x, y); c.scale(s, s); rr(c, -30, -260, 60, 260, 10, "#8a5a32"); [[0, -330, 170], [-120, -260, 110], [120, -260, 110]].forEach(([dx, dy, r]) => circ(c, dx, dy, r, "#4cbf5a")); for (let i = 0; i < coins; i++) coin(c, -130 + (i * 97) % 260, -380 + ((i * 61) % 200), 24); c.restore(); }
export function check(c: C, x: number, y: number, s: number, on: number, text: string, col = "#2fd46a") { rr(c, x - 36 * s, y - 36 * s, 72 * s, 72 * s, 12 * s, "#fff", 6); if (on > 0) line(c, [[x - 22 * s, y], [x - 5 * s, y + 20 * s * on], [x + 26 * s * on, y - 24 * s * on]], col, 12 * s); c.font = `900 ${46 * s}px Inter, Arial`; c.textAlign = "left"; c.textBaseline = "middle"; c.lineWidth = 9 * s; c.strokeStyle = INK; c.strokeText(text, x + 60 * s, y + 2); c.fillStyle = on > 0.5 ? "#fff" : "#c8c8d0"; c.fillText(text, x + 60 * s, y + 2); }
export function bars(c: C, x: number, y: number, w: number, h: number, vals: [number, number][], prog: number, max: number, cols = ["#5ab0ff", "#2fd46a"]) {
  line(c, [[x, y - h], [x, y], [x + w, y]], INK, 8); const n = vals.length, bw = w / n * 0.62;
  vals.forEach(([a, b], i) => { const k = clamp(prog * n - i); const bx = x + (i + 0.5) * (w / n) - bw / 2, ha = (a / max) * h * k, hb = (b / max) * h * k; if (k <= 0) return; rr(c, bx, y - ha, bw, ha, 4, cols[0], 4); rr(c, bx, y - ha - hb, bw, hb, 4, cols[1], 4); });
}
export function stepsRoad(c: C, t: number, k: number, x0: number, y0: number, x1: number, y1: number, n: number, lit: number) {
  line(c, [[x0, y0], [x1, y1]], "#c8b898", 70); line(c, [[x0, y0], [x1, y1]], "#e8d8b8", 54);
  for (let i = 0; i < n; i++) { const u = (i + 1) / (n + 1), kk = clamp(k * (n + 1) - i); if (kk <= 0) continue; const x = lerp(x0, x1, u), y = lerp(y0, y1, u) - 10; circ(c, x, y, 44 * Math.min(1, kk * 1.3), i < lit ? "#ffd23a" : "#fff"); T(c, String(i + 1), x, y + 2, 46, INK, Math.min(1, kk * 1.3), "#fff"); }
}
