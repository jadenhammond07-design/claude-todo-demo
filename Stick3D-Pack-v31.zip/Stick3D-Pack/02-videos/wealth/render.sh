#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack; cd /tmp/claude-0/gw/engine; mkdir -p $P/02-videos/wealth/chunks
for r in "0-2339" "2340-4679" "4680-7019" "7020-9359"; do
  [ -s $P/02-videos/wealth/chunks/c_$r.mp4 ] && continue
  npx remotion render Wealth $P/02-videos/wealth/chunks/c_$r.mp4 --frames=$r --scale=1 --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
