# ACTION LIBRARY (what exists; extend and log new entries)
## Implemented in engine/src/style/puppet.ts
- Pose params: mood (smile, grin, laugh, shock, worry, gulp, angry, deadpan), arms (down, up, hold, point, head, chest, box, shrug) + armK blend, nerv (tremble > 0.5, blush, brow twitch), sweat (sliding + flung drops), squash (+stretch/-squash), tilt, lookX, flip, hunch, air, walk phase + speed.
- Outfits: suit(+tie), blazer, leather, hoodie, shirt; hair: short, swept, bob, grey; glasses, badge, hat, shoe colour.
## Implemented patterns in examples/NvidiaDemo.tsx (copy, then adapt)
- Jump-back shock (anticipation squash -> stretch air -> landing squash), analytic stair hops + tumble + slide, walk-to-door-reach-open-walk-through, carrying a box (box follows hand with bob), crowd cheering behind a door with camera flashes, quake (throne shake with decay), counters, calendar circle draw, chart line draw.
## To build the first time they are needed (recipe)
- Throw: wind-up (arm back, squash) -> release at hand position -> projectile parabola p = p0 + v t + g t^2/2, spin, impact reaction.
- Pick up / put down: reach (arms: point to object height), grasp frame, object parented to hand with offset, release with settle.
- Eat / drink: object to mouth along arc, mouth opens (laugh/gulp mouth), chew bob 6 Hz small, swallow = throat dip + eyes close.
- Fight: stance, wind-up, strike with extended arm + stretch, hit-stop 3 frames, target knock-back with squash and tilt, cartoon-safe.
- Farm work: dig (arm arc + tool prop), sow (hand scatter + seed sprites), water (can tilt + droplet particles), growth (scale spring on sprout meshes timed to words), harvest (pull + carry basket).
- Fear / cry / celebrate: cower (hunch + tremble + arms head), tears particles, jump with arms up + confetti.
- Sit / stand: pose with chair contact, hips lower, legs bent (add `sit` leg mode to puppet.ts).
- Day->night: sun/moon on arc meshes + sky gradient plane + directional light colour + window glow; stars as small additive Glow sprites with twinkle; lamp glow turns on at dusk.
Add every new pose/prop here with its pose-param names and the scene where first used.
## Added in nvidia-v4 (engine/src/style/extra.tsx + puppet.ts)
- puppet.ts: `armR` / `armL` IK hand targets ([x, y] in puppet-height units, x from body centre, y from feet) + `armRK` / `armLK` blend. Used for: sipping a mug, lifting a crown off the head, carrying it, pushing a domino, holding press cameras / phones.
- extra.tsx helpers: `Cam` (Catmull-Rom camera path, micro handheld <=0.004, impact shake decaying < 0.5 s, FOV kicks), `camAt`, `FaceGroup` + `hand()` (props that stay glued to a puppet's hand).
- extra.tsx props: Arrow3D, Extrude (any outlined polygon), Domino (pivots on its leading edge; chain rule: next starts when angle = asin(gap/h), rest angle = acos(th/spacing)), Globe, Crown, Throne, SpotCone, Curtain, Lectern, Building (lit windows), StreetLamp, StreetSign, Taxi, Hydrant, Bench, Bin, Barrier, PressCam, ChipStack, Card, Dice, HangLamp, Mug, Stars.
- Patterns in videos/NvidiaV4.tsx: cable snap + falling arrow spearing the floor (parabolic drop + rotation + crack decal + debris arcs); mug released into a ballistic arc then a puddle; crown lift -> carry -> place with settle bounce; domino chain + winding small chain + hinged sign flipping up; 240 Hz crown physics sliding off a shaking throne and bouncing on a sphere; whip transition (translateX + blur).
## Added in dance-1518 (engine/src/style/medieval.tsx + puppet.ts + videos/dancecommon.tsx)
- puppet.ts: `Look.shoeCross` (white cross on shoes), `Look.hatKind` ("cap" | "tall" | "cowl").
- medieval.tsx: `Sky` (gradient + stars + horizon glow), `Timber` (half-timbered house, lit windows), `Minster`, `Barrel`, `Crate`, `Well`, `Cart`, `Torch`, `Banner`, `Flame`, `Note`, `CrowdField` (instanced cheap crowd for hundreds), `danceBeat(t,i,k)` (grim stiff dance: hop, squash, tilt, IK arms), `mixHex`.
- Patterns (videos/Dance.tsx, Dance2.tsx): sun/moon time-lapse + multiply tint; door opened by hand then walked through; planks dropping with landing bounce; hammer swing via armR IK + FaceGroup hammer; coin purse parabola; benches sliding with friction / barrels rolling; collapse = tilt to +-1.45 rad; heart thump slowing then cracking; gavel slam with impact shake; pressure pot (gauge needle, lid ballistic) + fear wave that flips each villager; sign burning from the bottom via destination-out mask + Flame cones; flame growing out of a puppet head (y = 0.78 h).
- Stills tool: scripts/stills.mjs now finds the browser through /opt/pw-browsers/chromium_headless_shell symlink as well.
## Added in kanye-through-the-wire (engine/src/style/studio.tsx, videos/Kanye.tsx)
- puppet.ts: `Look.wire` (silver jaw wire across the mouth).
- studio.tsx: `Console` (animated faders/knobs/meters), `Speaker`, `MicStand`, `GoldDisc`, `Palm`, `Car` (convertible, crumple), `Vinyl`.
- Patterns: hamster wheel with runner + dangling goal on a stick; car crash (speed, impact shake, crumple, thrown driver, smoke, debris, rolling hubcap); X-ray canvas with jaw cracks + wire drawing; lying puppet = rotate the whole Person in a 3D group (canvas tilt > ~0.4 rad is clipped by the billboard); thought-bubble mini animation drawn on a CanvasPlane; sticker/name-tag pinned on a puppet chest via FaceGroup; mic-height rule: stand h = mouth height - 0.5.
## Added in alert-test (engine/src/style/studio2.tsx, videos/Alert.tsx)
- studio2.tsx: `AnalogClock` (settable h/m), `Phone`, `Heart`/`drawHeart`, `Robot` (grows, power off, droop), `Router`, `Clapper`.
- Patterns: canvas US-map with a time-zone alert wave + vibrating phones; rumor sprinter chased by a rolling clock (tracking camera keys computed from the runner function); ATM balance counting to $0.00 + tumbleweed; stamp slam with impact shake; AI robot growing then unplugged (cable drawn as sagging segments, plug pulled with spark); "nothing happened" museum diorama with verdict stickers; clapperboard finale.
- Gotchas: canvas arc() radius must be >= 0 (guard modulo of negatives); aligner splits "2:20" on the colon, so write "2.20" in script.txt and patch engine/public/script.json back to "2:20" after prep_voice.
## Added in small-business-ideas (engine/src/style/biz.tsx, videos/Biz.tsx)
- biz.tsx: `Vending` (animated snack drop), `Atm`, `Bill`, `Truck`. Patterns: coin staircase to a skyline + sprout; machine buy/drop/coin-jar; handshake + pie chart + 20 machines popping in; ATM bills + counters + background-check ticks; car wash with spray, foam and a day/night window; laundromat board (95% open, year counter); storage units rising + box truck; mousetrap snap with 4 warning plaques; wealth meter with machines popping in.
- Script tip: numbers/symbols need placeholders in script.txt (P1500, PCT25, A247) + spoken.json overrides, then patch engine/public/script.json back to the display text.
## Added in rivalry-courtroom (engine/src/videos/Mo3.tsx)
- Patterns: interstate with passing cars + gantry sign; brake-to-stop car with brake lights; tracking runner crossing lanes with a freight truck passing in front (runner hidden, sneaker left); ambulance + flashing lights; cold-case courtroom with calendar years + cobweb; two-mic rivalry stage with bouncing text bubbles; evidence corkboard on one canvas (cards pop, red strings draw); handcuffs via FaceGroup rings; year ticker + candles lighting one per year; verdict stamp slam; gavel strike + lyric pages falling.
- Sensitive true-crime rule: generic stick figures, no weapons shown, no gore, somber tint, state that facts come from the user's script.
## Added in parking-lot-business (engine/src/style/lot.tsx, videos/Park.tsx)
- lot.tsx: `LotLines`, `CarField` (instanced cheap cars, per-car grow-in), `SpaceXY`, `PayStand`, `PSign`.
- Patterns: bills floating from parked cars to the owner; walls/inventory X'd out until only ground + pay stand remain; 20 then 200 spaces filling with a growing revenue counter + day counter; shoppers/commuters/office workers vignettes; lease handshake + profit-share pie; table-top model with 3 gold "invested" spaces; guide margin bar with an unfilled VERIFIED? box; location pin drop; downtown money printer vs suburban tumbleweed; neighbourhood map with a pulsing "?" parcel.
## Added in ghost-army (engine/src/style/mil.tsx, videos/Ghost.tsx)
- mil.tsx: `Tank` (puff/wobble/ghost variants), `HalfTrack` (speaker horns + spinning tape reels), `RadioSet`, `Easel`.
- Patterns: tank inflating with pump + 4 men lifting/carrying; sound rings from horns; oscilloscope showing a fake operator matching a real one; 1,000+ crew vignettes; fashion sketch drawing itself + colour-block painting building; map with 20+ pins; 12 decoy tanks popping in vs real tanks slipping away; 1,100 vs 30,000 bars; TOP SECRET stamp + year ticker 1945->1995; homecoming with hearts.
- ENGINE FIX (toon.tsx CanvasPlane): canvas size is now clamped to >= 2 px and the texture is recreated when px changes. Before, a sign created while scaled to ~0 got a 0x0 canvas and rendered as a BLACK box in chunked renders. Also: pass `k` for pop-in scale and keep w/h fixed.
