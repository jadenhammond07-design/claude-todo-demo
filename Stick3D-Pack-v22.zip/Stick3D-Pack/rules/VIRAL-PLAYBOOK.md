# VIRAL PLAYBOOK (read with the other rules; apply to EVERY video)
Source: web research of published creator/vendor analyses (directional, NOT measured data; no real per-video viral dataset was available). Treat as best-effort guidance; the user's own analytics are the final judge.

## Build rules (apply while making the video)
1. HOOK IN THE FIRST 2 SECONDS: scene 1 must be the most striking visual of the video, reacting to the script's first line (big prop, bold pop-in sign on the key word, camera move starting at frame 0). No slow fade-ins, no logo, no empty room.
2. Visual change every 2-4 s (cut, camera push, prop pop-in, pose change). Never hold one static frame longer than ~3 s.
3. Captions: big, word-by-word, synced (already in Main.tsx). Keep emphasis words readable; never cover the figure's face.
4. Story-style scripts (true crime / history / psychology) work best 30-50 s. Length is set by the user's voiceover; do not pad. If the audio is over ~60 s, say so in one line when delivering.
5. Last scene: if the script ends on a question or twist, land the final visual ON that last word and hold it (loop-friendly ending; replays count as retention).
6. Pattern interrupt around the 40-60% mark of the video: a flash/whip transition + a new visual idea, so viewers who drift get re-hooked.
7. Sparse quiet SFX only (see RULES.md); sound must not fight the voice.

## Delivery rules (every time a video is sent)
Alongside the mp4, give in ONE short block:
- Caption (1-2 lines, curiosity-first, first line = hook) + 4-6 hashtags (mix 1-2 broad, 2-3 niche).
- On-screen first-line suggestion if the script's opening is weak (suggest only; the user's script is never changed without being asked).
- Posting time suggestion: weekday evenings (about 6-10 PM in the audience's time zone) or Saturday afternoon, then check the user's own analytics. State honestly that it is a guess.
- Tell the user honestly which playbook rules the video meets and which it could not (e.g. length fixed by voiceover).

## Optional (only if the user provides a ScrapeCreators key or viral video links)
Use the installed `outlier-post-finder`, `trend-discovery`, `comment-mining` and `transcript-intelligence` skills to replace the guesses above with real numbers for the user's niche, and update this file with what is found.

## USER STANDING ORDER (from the user, applies to EVERY video from now on; goal = go viral)
- Every video gets an ON-SCREEN HOOK (`HookOverlay` in `engine/src/videos/viral.tsx`, first ~2.5 s, top of frame, short punchy question/claim tied to the topic) AND an END QUESTION card (`EndQuestion`, last ~2.5 s, "COMMENT BELOW" + an interesting question tied to the topic that makes people comment). Add both in the video's Main. Write the texts yourself; do not ask.
- Plus every other tip in this file. Always deliver caption + hashtags + post-time block with the video.
- QUALITY: output is 1080x1920 (not 720x1280). The layout is still authored at 720x1280; `engine/remotion.config.ts` sets `Config.setScale(1.5)`, JPEG quality 98 and CRF 14. HD renders take ~2.3x longer (about 90 min for a 40 s video): tell the user honestly. Mux with `-c:v copy -c:a aac -b:a 192k`. Also give a smaller copy only if asked (GitHub rejects >100 MB; HD files are ~40-60 MB).
