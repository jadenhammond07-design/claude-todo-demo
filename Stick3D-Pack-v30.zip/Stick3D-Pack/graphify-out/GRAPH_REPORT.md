# Graph Report - Stick3D-Pack  (2026-11-23)

## Corpus Check
- 91 files · ~78,502 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 5 file(s) not represented in the graph (top: .log 4, (none) 1)

## Summary
- 603 nodes · 2653 edges · 35 communities (12 shown, 23 thin omitted)
- Extraction: 97% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 67 edges (avg confidence: 0.88)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Dance.tsx
- Box
- NvidiaV4.tsx
- Biz.tsx
- sys
- package.json
- NvidiaDemo.tsx
- Alert.tsx
- Kanye.tsx
- compilerOptions
- MASTER PROMPT — "Stick-in-3D" video factory (9:16, locked)
- ENV-REPORT.md
- bench_render.sh
- setup.sh
- alert/_ledger.md
- alert/render.sh
- biz/_ledger.md
- biz/render.sh
- dance/_ledger.md
- dance/render.sh
- kanye/_ledger.md
- kanye/render.sh
- nvidia-v4/_ledger.md
- CLAUDE.md
- CREATIVE-FREEDOM.md
- LEDGER.template.md
- QUALITY-CHECKLIST.md
- RULES.md
- STYLE-RULES-v2.md
- STYLE-SPEC.md
- START-HERE.md
- bootstrap_remotion.sh
- env_report.sh
- forensics.sh

## God Nodes (most connected - your core abstractions)
1. `Box()` - 107 edges
2. `CanvasPlane()` - 98 edges
3. `Cyl()` - 82 edges
4. `seg()` - 77 edges
5. `Person()` - 71 edges
6. `Lights()` - 71 edges
7. `Glow()` - 69 edges
8. `Cam()` - 66 edges
9. `lerp()` - 64 edges
10. `Dust()` - 62 edges

## Surprising Connections (you probably didn't know these)
- `Added in nvidia-v4 (engine/src/style/extra.tsx + puppet.ts)` --references--> `Cam()`  [INFERRED]
  rules/ACTION-LIBRARY.md → engine/src/style/extra.tsx
- `Added in nvidia-v4 (engine/src/style/extra.tsx + puppet.ts)` --references--> `camAt()`  [INFERRED]
  rules/ACTION-LIBRARY.md → engine/src/style/extra.tsx
- `Added in nvidia-v4 (engine/src/style/extra.tsx + puppet.ts)` --references--> `FaceGroup()`  [INFERRED]
  rules/ACTION-LIBRARY.md → engine/src/style/extra.tsx
- `Added in nvidia-v4 (engine/src/style/extra.tsx + puppet.ts)` --references--> `hand()`  [INFERRED]
  rules/ACTION-LIBRARY.md → engine/src/style/extra.tsx
- `Added in dance-1518 (engine/src/style/medieval.tsx + puppet.ts + videos/dancecommon.tsx)` --references--> `mixHex()`  [INFERRED]
  rules/ACTION-LIBRARY.md → engine/src/style/medieval.tsx

## Import Cycles
- None detected.

## Communities (35 total, 23 thin omitted)

### Community 0 - "Dance.tsx"
Cohesion: 0.06
Nodes (108): SNACK, Truck(), Extrude(), Key, V3, Banner(), Barrel(), Cart() (+100 more)

### Community 1 - "Box"
Cohesion: 0.18
Nodes (82): S1(), S2(), S4(), S5(), Demo(), Atm(), Bill(), Vending() (+74 more)

### Community 2 - "NvidiaV4.tsx"
Cohesion: 0.06
Nodes (76): Arrow3D(), Barrier(), Bench(), Bin(), Building(), camAt(), Card(), ChipStack() (+68 more)

### Community 3 - "Biz.tsx"
Cohesion: 0.05
Nodes (50): Captions(), Ctx, FPS, G, groups, hero, Inner(), LEAD (+42 more)

### Community 4 - "sys"
Cohesion: 0.08
Nodes (5): note(), save(), t(), circle_logo(), square_crop()

### Community 5 - "package.json"
Cohesion: 0.06
Nodes (39): dependencies, @fontsource/inter@^5.3.0, lucide-react@^1.73.0, react@^18.3.1, react-dom@^18.3.1, @react-three/fiber@^8.17.10, remotion@^4.0.250, @remotion/cli@^4.0.250 (+31 more)

### Community 6 - "NvidiaDemo.tsx"
Cohesion: 0.09
Nodes (39): analyst, Captions(), ceo, ceoPos(), crowdLooks, Ctx, CUTS, G (+31 more)

### Community 7 - "Alert.tsx"
Cohesion: 0.07
Nodes (29): drawHeart(), Heart(), BUB, DOTS, drawHeart(), drawRail(), ease, hero (+21 more)

### Community 8 - "Kanye.tsx"
Cohesion: 0.09
Nodes (21): Mug(), Vinyl(), boss, carX(), ease, K1, K10, K11 (+13 more)

### Community 9 - "compilerOptions"
Cohesion: 0.15
Nodes (12): compilerOptions, allowJs, esModuleInterop, jsx, module, moduleResolution, noEmit, resolveJsonModule (+4 more)

### Community 10 - "MASTER PROMPT — "Stick-in-3D" video factory (9:16, locked)"
Cohesion: 0.20
Nodes (9): 0. FIRST MESSAGE BEHAVIOUR (do this immediately, no questions first), 1. LOCKED SPEC, 2. WHAT "TOP TIER" MEANS HERE (non-negotiable quality), 3. CREATIVE FREEDOM (anti-template), 4. WHAT EXISTS (reuse, do not rewrite), 5. PUPPET / ENGINE FACTS LEARNED (avoid these bugs), 6. PIPELINE PER VIDEO, 7. HONEST LIMITS (state them, never over-promise) (+1 more)

### Community 11 - "ENV-REPORT.md"
Cohesion: 0.33
Nodes (5): Chromium, GPU, Network (HTTP status; 000 = blocked/unreachable), Python libs, Tools

## Knowledge Gaps
- **23 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `react` connect `Dance.tsx` to `NvidiaV4.tsx`, `Biz.tsx`, `package.json`, `NvidiaDemo.tsx`, `Alert.tsx`, `Kanye.tsx`?**
  _High betweenness centrality (0.053) - this node is a cross-community bridge._
- **Should `Dance.tsx` be split into smaller, more focused modules?**
  _Cohesion score 0.05939324882495371 - nodes in this community are weakly interconnected._
- **Why does `remotion` connect `Biz.tsx` to `Dance.tsx`, `NvidiaV4.tsx`, `package.json`, `NvidiaDemo.tsx`, `Alert.tsx`, `Kanye.tsx`?**
  _High betweenness centrality (0.048) - this node is a cross-community bridge._
- **Should `NvidiaV4.tsx` be split into smaller, more focused modules?**
  _Cohesion score 0.05777345017851347 - nodes in this community are weakly interconnected._
- **Why does `Box()` connect `Box` to `Dance.tsx`, `NvidiaV4.tsx`, `Biz.tsx`, `NvidiaDemo.tsx`, `Alert.tsx`, `Kanye.tsx`?**
  _High betweenness centrality (0.030) - this node is a cross-community bridge._
- **Should `Biz.tsx` be split into smaller, more focused modules?**
  _Cohesion score 0.0519774011299435 - nodes in this community are weakly interconnected._
- **Should `sys` be split into smaller, more focused modules?**
  _Cohesion score 0.07922705314009662 - nodes in this community are weakly interconnected._