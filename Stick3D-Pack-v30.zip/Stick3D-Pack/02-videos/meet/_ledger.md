# Meet your past self (41.74 s, 1255 f)
10 scenes S1-S10 in engine/src/videos/Meet.tsx, cuts in MeetMain.tsx. Lesson: wide layouts need the `wide(keys,k)` camera helper (pull back 1.4-2.2x) at 9:16, or figures crop at the sides.
Reused: Cafe (table for two), Cloud bubble, Sign pop-in via k, brain-scan canvas, podium chump/champion.
