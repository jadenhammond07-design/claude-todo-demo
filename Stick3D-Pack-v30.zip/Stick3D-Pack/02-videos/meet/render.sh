#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/meet/chunks_hd
GL=$(cat ../.gl-flag)
for r in "0-313" "314-627" "628-941" "942-1254"; do
  [ -s ../02-videos/meet/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Meet ../02-videos/meet/chunks_hd/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
