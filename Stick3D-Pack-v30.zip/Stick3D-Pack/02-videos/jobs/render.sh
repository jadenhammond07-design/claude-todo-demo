#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/jobs/chunks
GL=$(cat ../.gl-flag)
for r in "0-388" "389-777" "778-1166" "1167-1554"; do
  [ -s ../02-videos/jobs/chunks/c_$r.mp4 ] && continue
  npx remotion render Jobs ../02-videos/jobs/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
