# Every stranger has a story (42.86 s, 1288 f, HD) — voice: generated, Kokoro am_adam
9 scenes in engine/src/videos/Strangers.tsx (Sidewalk, Train interior, Bubble, thought-cloud, ride chart, story book, solitude walls).
Hook: "EVERY STRANGER YOU PASS HAS A STORY". End question: "Would YOU talk to the stranger next to you? Yes or no?"
Lesson: wrap camera keys with low() (look y -2) so figures sit above the caption band.
