# Birds grounded for a day (42.01 s, 1263 f, HD) — voice: Kokoro am_adam
10 scenes in engine/src/videos/Birds.tsx; new props style/birds.tsx (Bird swift/humming/hawk/owl/gull/sparrow with flap 0..1, Flower, Fish, Mouse).
Hook: "EVERY BIRD ON EARTH GROUNDED FOR 1 DAY". End question: "Which animal do you think we'd miss the MOST?"
Lessons: folded wings must hug the body (flap<0.05 -> small side ovals), never vertical boards. Avoid emoji in canvas text (no emoji font in headless renderer).
