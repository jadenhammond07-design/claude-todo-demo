#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/biz/chunks
GL=$(cat ../.gl-flag)
for r in "0-440" "441-881" "882-1322" "1323-1761"; do
  [ -s ../02-videos/biz/chunks/c_$r.mp4 ] && continue
  npx remotion render Biz ../02-videos/biz/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
