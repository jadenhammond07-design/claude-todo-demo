#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/alert/chunks
GL=$(cat ../.gl-flag)
for r in "0-385" "386-771" "772-1157" "1158-1545"; do
  [ -s ../02-videos/alert/chunks/c_$r.mp4 ] && continue
  npx remotion render Alert ../02-videos/alert/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
