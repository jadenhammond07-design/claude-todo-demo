#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack; cd /tmp/claude-0/gw/engine; mkdir -p $P/02-videos/unseen/chunks_hd
for r in "0-367" "368-735" "736-1103" "1104-1469"; do
  [ -s $P/02-videos/unseen/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Unseen $P/02-videos/unseen/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
