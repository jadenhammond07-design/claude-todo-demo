# The unseen universe (48.92 s, 1470 f, HD 1080x1920)
9 scenes in engine/src/videos/Unseen.tsx (Galaxy canvas spiral, Telescope, observable-universe bubble, afterglow ring, expansion gauge).
Hook: "THERE ARE GALAXIES WE'LL NEVER SEE". End question: "Do you think there's life in the part we can't see?"
Lessons: on black space backgrounds give signs a white outline and scale them up 1.3x; keep figures in the upper-middle of frame (captions sit at y=880 of 1280).
