#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/mo3/chunks
GL=$(cat ../.gl-flag)
for r in "0-406" "407-813" "814-1220" "1221-1627"; do
  [ -s ../02-videos/mo3/chunks/c_$r.mp4 ] && continue
  npx remotion render Mo3 ../02-videos/mo3/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
