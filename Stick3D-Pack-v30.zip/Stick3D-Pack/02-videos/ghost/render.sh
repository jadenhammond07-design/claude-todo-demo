#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/ghost/chunks
GL=$(cat ../.gl-flag)
for r in "0-402" "403-805" "806-1208" "1209-1610"; do
  [ -s ../02-videos/ghost/chunks/c_$r.mp4 ] && continue
  npx remotion render Ghost ../02-videos/ghost/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
