#!/usr/bin/env bash
# renders from the isolated engine copy (/tmp/claude-0/gw/engine) so engine/public of the pack is not disturbed
P=/tmp/claude-0/pack/Stick3D-Pack
until grep -q ALLDONE $P/02-videos/meet/render_hd.log 2>/dev/null; do sleep 30; done
cd /tmp/claude-0/gw/engine; mkdir -p $P/02-videos/gone/chunks_hd
for r in "0-396" "397-793" "794-1190" "1191-1586"; do
  [ -s $P/02-videos/gone/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Gone $P/02-videos/gone/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --log=error && echo "DONE $r"
done
echo ALLDONE
