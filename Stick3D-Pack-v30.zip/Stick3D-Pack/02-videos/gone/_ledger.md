# Earth without humans (52.82 s, 1587 f, HD 1080x1920)
11 scenes in engine/src/videos/Gone.tsx; new props in style/nature.tsx (Tree, Bush, Weed, Water, Animal wolf/boar/deer, Cap).
Hook: "EVERY HUMAN GONE. WHAT'S LEFT?" End question: "What do YOU think would be the last thing left of us?"
Lessons: heavy scene-boundary frames can exceed the 30 s render timeout at HD -> always pass --timeout=180000. Sign text must fit its canvas (px = w*100): keep ~10 px per character of font size.
To re-render: copy 02-videos/gone/{words,script}.json + mix.wav into engine/public first.
