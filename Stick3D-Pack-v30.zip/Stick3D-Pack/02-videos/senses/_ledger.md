# New human senses (42.72 s, 1284 f, HD) — voice: Kokoro am_adam speed 1.2
10 scenes in engine/src/videos/Senses.tsx (grey room -> color burst, Antenna on head, sound Rings, wire chamber with rotating field arcs, EEG wave monitor, compass in head).
Hook: "YOU MIGHT ALREADY HAVE A 6TH SENSE". End question: "Which new sense would YOU want?"
