#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack
until grep -q ALLDONE $P/02-videos/bajau/render_hd.log 2>/dev/null; do sleep 30; done
cd /tmp/claude-0/gw2/engine; mkdir -p $P/02-videos/senses/chunks_hd
for r in "0-320" "321-641" "642-962" "963-1283"; do
  [ -s $P/02-videos/senses/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Senses $P/02-videos/senses/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
