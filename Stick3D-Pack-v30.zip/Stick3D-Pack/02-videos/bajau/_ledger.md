# Bajau divers (42.83 s, 1288 f, HD) — voice: Kokoro am_adam speed 1.2
9 scenes in engine/src/videos/Bajau.tsx (Under set with shafts/bubbles, horizontal Swimmer, stilt houses, depth gauge, Spleen, DNA helix).
Hook: "SOME HUMANS ARE EVOLVING FOR THE OCEAN". End question: "What do you think humans evolve into next?"
Lesson: aligner rejects some names; map to dictionary words (Bajau->badger) since only timing matters, captions keep the script spelling.
