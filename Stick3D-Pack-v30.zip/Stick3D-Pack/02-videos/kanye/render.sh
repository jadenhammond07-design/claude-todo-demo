#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/kanye/chunks
GL=$(cat ../.gl-flag)
for r in "0-372" "373-745" "746-1118" "1119-1492"; do
  [ -s ../02-videos/kanye/chunks/c_$r.mp4 ] && continue
  npx remotion render Kanye ../02-videos/kanye/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
