#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/eoh/chunksB
GL=$(cat ../.gl-flag)
for r in "0-347" "348-695" "696-1043" "1044-1392"; do
  [ -s ../02-videos/eoh/chunksB/c_$r.mp4 ] && continue
  npx remotion render EohB ../02-videos/eoh/chunksB/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
