#!/usr/bin/env bash
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/park/chunks
GL=$(cat ../.gl-flag)
for r in "0-360" "361-722" "723-1083" "1084-1444"; do
  [ -s ../02-videos/park/chunks/c_$r.mp4 ] && continue
  npx remotion render Park ../02-videos/park/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
