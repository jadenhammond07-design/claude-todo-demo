# Deja vu (42.52 s, 1278 f, HD) — voice: Kokoro am_adam
10 scenes in engine/src/videos/Dejavu.tsx (ghost double, Room with same-layout variants, VR grid, top-down room plans, Brain with temporal lobe).
Hook: "DÉJÀ VU MIGHT BE ANOTHER LIFE". End question: "Other life or brain glitch? Comment 1 or 2"
Lesson: accented words (déjà) get split by the aligner into "d","j" -> merge those pairs in words.json.
