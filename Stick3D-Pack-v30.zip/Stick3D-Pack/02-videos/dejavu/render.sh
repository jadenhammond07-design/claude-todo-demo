#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack
until grep -q ALLDONE $P/02-videos/birds/render_hd.log 2>/dev/null; do sleep 30; done
cd /tmp/claude-0/gw/engine; mkdir -p $P/02-videos/dejavu/chunks_hd
for r in "0-319" "320-639" "640-959" "960-1277"; do
  [ -s $P/02-videos/dejavu/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Dejavu $P/02-videos/dejavu/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
