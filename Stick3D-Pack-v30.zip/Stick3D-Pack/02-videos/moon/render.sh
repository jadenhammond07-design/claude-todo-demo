#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack
until grep -q ALLDONE $P/02-videos/strangers/render_hd.log 2>/dev/null; do sleep 30; done
cd /tmp/claude-0/gw2/engine; mkdir -p $P/02-videos/moon/chunks_hd
for r in "0-324" "325-649" "650-974" "975-1298"; do
  [ -s $P/02-videos/moon/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Moon $P/02-videos/moon/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
