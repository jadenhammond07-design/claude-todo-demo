# What if the Moon came closer (43.22 s, 1299 f, HD) — voice: generated, Kokoro am_adam
10 scenes in engine/src/videos/Moon.tsx (Moon with craters, laser ranging pulse, round-trip timer, tides/Water, Roche ring debris, ruler + fingernail).
Hook: "WHAT IF THE MOON STARTED COMING BACK?" End question: "Would you rather it come closer or keep leaving?"
Lesson: a number like "18,000" is spoken as 2 words but is 1 caption token -> merge the two aligned word timings in words.json so captions stay in sync.
