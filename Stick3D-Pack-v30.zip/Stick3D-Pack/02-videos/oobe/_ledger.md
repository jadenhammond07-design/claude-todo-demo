# Out-of-body in a lab (44.96 s, 1351 f, HD) — voice: Kokoro am_adam
9 scenes in engine/src/videos/Oobe.tsx (Goggles at EYE=H*0.73, tripod Camera, live Feed canvas with rod/hammer, Brain with stimulated spot, you-are-here pin).
Hook: "SCIENTISTS PULLED PEOPLE OUT OF THEIR BODIES". End question: "Would YOU try the goggle experiment? Yes or no?"
Lesson: head-worn props sit at ~0.73 x figure height (eyes), not 0.88 (that's the hair top).
