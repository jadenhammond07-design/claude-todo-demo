#!/usr/bin/env bash
P=/tmp/claude-0/pack/Stick3D-Pack; cd /tmp/claude-0/gw/engine; mkdir -p $P/02-videos/oobe/chunks_hd
for r in "0-337" "338-675" "676-1013" "1014-1350"; do
  [ -s $P/02-videos/oobe/chunks_hd/c_$r.mp4 ] && continue
  npx remotion render Oobe $P/02-videos/oobe/chunks_hd/c_$r.mp4 --frames=$r --gl=swangle --concurrency=4 --muted --timeout=180000 --log=error && echo "DONE $r"
done
echo ALLDONE
