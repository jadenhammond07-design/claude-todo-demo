# Your bones are already changing (44.41 s, 1335 f, HD) — voice: Kokoro am_adam
9 scenes in engine/src/videos/Bones.tsx (cartoon Bone with thickness, Xray panel, Racket, astronaut helmet, remodeling tissue canvas, step/lift/sit vote).
Hook: "YOUR BONES ARE CHANGING SHAPE RIGHT NOW". End question: "Be honest: do you sit more or move more?"
Lesson: in non-low() cameras the caption band sits around y=2-3; keep labels at y>=6 there.
