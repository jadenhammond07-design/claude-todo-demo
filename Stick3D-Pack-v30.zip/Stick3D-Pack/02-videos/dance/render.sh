#!/usr/bin/env bash
# chunked render (recoverable): frames 0-1561 in 4 pieces
cd "$(dirname "$0")/../../engine"; mkdir -p ../02-videos/dance/chunks
GL=$(cat ../.gl-flag)
for r in "0-389" "390-779" "780-1169" "1170-1561"; do
  [ -s ../02-videos/dance/chunks/c_$r.mp4 ] && continue
  npx remotion render Dance ../02-videos/dance/chunks/c_$r.mp4 --frames=$r --gl=$GL --concurrency=4 --muted --log=error && echo "DONE $r"
done
