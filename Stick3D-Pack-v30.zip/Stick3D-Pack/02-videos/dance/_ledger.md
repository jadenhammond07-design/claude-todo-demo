# Ledger — Dancing Plague 1518 (52.0 s, 14 scenes)
| # | time | words | idea (layout / camera / action / colour world) |
|---|------|-------|-----|
| 1 | 0-2.65 | Strasbourg, July 1518 | crane-down over a cobbled street, banner across street, minster spire at the end; dawn orange |
| 2 | 2.65-5.8 | Frau Troffea steps into the street... | frontal timber facade, real doorway, hand reaches, leaf opens AWAY, she walks out and starts to dance; warm interior vs cool street |
| 3 | 5.8-10.45 | No music. No joy. next morning, feet bleeding | low orbit in plaza; sun/moon time-lapse day->dusk->night->dawn; crossed-out note + smile signs; camera drops to bleeding feet |
| 4 | 10.45-15 | 34 joined / hundreds | counter board 1->34, spiral of joiners, crane-up reveals hundreds (instanced crowd); hot orange |
| 5 | 15-18.7 | doctors: hot blood, more dancing | study interior; flask+thermometer heat up, prescription scroll unrolls "MORE DANCING"; wood/teal-brown |
| 6 | 18.7-22.4 | council builds stage, hires drummers, pipers | planks fall & land, carpenters hammer (IK), purse thrown on a parabola, musicians climb on; golden hour |
| 7 | 22.4-25.2 | clears the guildhalls | double doors swing open, benches slide + barrels roll with friction, dancers stream in; brick red/blue |
| 8 | 25.2-31 | music pulls more dancers, collapse | note spirals pull villagers to stage, 4 collapses, heart thumps slower and cracks; dusk purple |
| 9 | 31-34.5 | panicked council bans music | council hall, panic hops, gavel slam + BANNED decree, guards enter; crimson |
| 10 | 34.5-38.3 | march to shrine in red shoes with crosses | tracking shot on hill road, shrine reveal pan, low shoe close-up (crosses on shoes); green/violet dusk |
| 11 | 38.3-41 | historians argue over ergot | library, two scholars trade ?! bubbles, giant rye ear with ergot, toxic skull; brown/green |
| 12 | 41-44.6 | starving, terrified | drought, cracked earth, empty bread stall, bowls, shock on "terrified"; sickly yellow |
| 13 | 44.6-48.6 | stress nowhere to go -> contagious | pressure pot gauge rises, lid blows, purple fear wave flips each villager into dancing; purple night |
| 14 | 48.6-52 | plague -> a mind catching fire | PLAGUE board burns away from the bottom, flame bursts from her head; black/red |
