// Alert-test props: analog clock with settable time, phone, heart, robot, router, clapperboard. Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3, clamp } from "./kit";
import { Glow } from "./props";

export const AnalogClock: React.FC<{ p: V3; r?: number; h: number; m: number; rot?: V3; rim?: string }> = ({ p, r = 1, h, m, rot, rim = "#e23b3b" }) => (
  <CanvasPlane p={p} rot={rot} s={[r * 2, r * 2]} px={[300, 300]} draw={(c, W, H) => {
    c.clearRect(0, 0, W, H); c.fillStyle = rim; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.arc(W / 2, H / 2, W / 2 - 6, 0, 7); c.fill(); c.stroke();
    c.fillStyle = "#fff"; c.beginPath(); c.arc(W / 2, H / 2, W / 2 - 30, 0, 7); c.fill(); c.stroke();
    c.fillStyle = INK; c.font = "800 30px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle";
    for (let i = 1; i <= 12; i++) { const a = i / 12 * Math.PI * 2 - Math.PI / 2; c.fillText(String(i), W / 2 + Math.cos(a) * 98, H / 2 + Math.sin(a) * 98); }
    const hand = (a: number, l: number, wd: number, col: string) => { c.strokeStyle = col; c.lineWidth = wd; c.lineCap = "round"; c.beginPath(); c.moveTo(W / 2, H / 2); c.lineTo(W / 2 + Math.sin(a) * l, H / 2 - Math.cos(a) * l); c.stroke(); };
    hand(((h % 12) + m / 60) / 12 * Math.PI * 2, 62, 11, INK); hand(m / 60 * Math.PI * 2, 100, 7, INK);
    c.fillStyle = INK; c.beginPath(); c.arc(W / 2, H / 2, 9, 0, 7); c.fill();
  }} />
);
export const Phone: React.FC<{ p: V3; rot?: V3; s?: number; draw?: (c: CanvasRenderingContext2D, W: number, H: number) => void; glow?: string; o?: number }> = ({ p, rot, s = 1, draw, glow, o = 0.5 }) => (
  <group position={p} rotation={rot} scale={s}>
    <Box p={[0, 0, 0]} s={[0.52, 1.0, 0.08]} color="#1a1a24" line={2} />
    <CanvasPlane p={[0, 0, 0.05]} s={[0.44, 0.9]} px={[88, 180]} draw={draw ?? ((c, W, H) => { c.fillStyle = "#2a4a8a"; c.fillRect(0, 0, W, H); })} />
    {glow ? <Glow p={[0, 0, 0.4]} r={0.9} color={glow} o={o} /> : null}
  </group>
);
export const drawHeart = (c: CanvasRenderingContext2D, W: number, H: number, col = "#ff3b6b") => { c.clearRect(0, 0, W, H); c.fillStyle = col; c.strokeStyle = INK; c.lineWidth = W * 0.05; c.beginPath(); c.moveTo(W / 2, H * 0.88); c.bezierCurveTo(-W * 0.1, H * 0.5, W * 0.1, H * 0.08, W / 2, H * 0.32); c.bezierCurveTo(W * 0.9, H * 0.08, W * 1.1, H * 0.5, W / 2, H * 0.88); c.fill(); c.stroke(); };
export const Heart: React.FC<{ p: V3; s?: number; col?: string }> = ({ p, s = 1, col }) => <CanvasPlane p={p} s={[s, s]} px={[120, 120]} face draw={(c, W, H) => drawHeart(c, W, H, col)} />;
export const Robot: React.FC<{ p: V3; k?: number; eye?: string; power?: number; droop?: number; t?: number }> = ({ p, k = 1, eye = "#4ad0ff", power = 1, droop = 0, t = 0 }) => (
  <group position={p} scale={k}>
    <Box p={[-0.35, 0.5, 0]} s={[0.36, 1.0, 0.4]} color="#6a7890" line={3} /><Box p={[0.35, 0.5, 0]} s={[0.36, 1.0, 0.4]} color="#6a7890" line={3} />
    <Box p={[0, 1.7, 0]} s={[1.4, 1.5, 0.9]} color="#8a98b0" line={3} /><Box p={[-0.95, 1.7 - droop * 0.5, 0]} s={[0.3, 1.2, 0.3]} color="#6a7890" rot={[0, 0, droop * 0.5]} line={3} /><Box p={[0.95, 1.7 - droop * 0.5, 0]} s={[0.3, 1.2, 0.3]} color="#6a7890" rot={[0, 0, -droop * 0.5]} line={3} />
    <CanvasPlane p={[0, 1.8, 0.47]} s={[0.9, 0.6]} px={[180, 120]} draw={(c, W, H) => { c.fillStyle = "#0b0d1a"; c.fillRect(0, 0, W, H); c.fillStyle = power > 0.5 ? eye : "#222"; c.font = "900 80px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("AI", W / 2, H / 2 + 4); }} />
    <group position={[0, 3.0 - droop * 0.35, 0]} rotation={[droop * 0.6, 0, droop * 0.35]}><Box p={[0, 0, 0]} s={[1.1, 0.85, 0.85]} color="#9aa8c0" line={3} />
      <Ball p={[-0.25, 0.08, 0.45]} r={0.14} color={power > 0.5 ? eye : "#2a2a30"} ink={0.03} /><Ball p={[0.25, 0.08, 0.45]} r={0.14} color={power > 0.5 ? eye : "#2a2a30"} ink={0.03} />
      <Cyl p={[0, 0.65, 0]} rt={0.03} h={0.5} color="#c9d3e0" line={1} /><Ball p={[0, 0.95, 0]} r={0.1} color={power > 0.5 ? "#ff3b3b" : "#444"} ink={0.03} /></group>
    {power > 0.5 ? <Glow p={[0, 3.0, 0.7]} r={1.6} color={eye === "#ff3b3b" ? "rgba(255,60,60,1)" : "rgba(80,210,255,1)"} o={0.35} /> : null}
  </group>
);
export const Router: React.FC<{ p: V3; t: number; on?: number }> = ({ p, t, on = 1 }) => (
  <group position={p}><Box p={[0, 0.2, 0]} s={[1.8, 0.4, 1.1]} color="#e8eef8" line={3} />{[-0.6, 0.6].map((x) => <Cyl key={x} p={[x, 0.9, -0.3]} rt={0.05} h={1.0} color="#e8eef8" line={2} />)}
    {[0, 1, 2, 3].map((i) => <React.Fragment key={i}><Ball p={[-0.6 + i * 0.4, 0.28, 0.56]} r={0.07} color={on && (Math.sin(t * 9 + i * 2) > -0.3) ? "#2fd46a" : "#2a4a30"} ink={0.02} /></React.Fragment>)}
    {on ? <Glow p={[0, 0.5, 0.8]} r={1.4} color="rgba(60,255,120,1)" o={0.3} /> : null}</group>
);
export const Clapper: React.FC<{ p: V3; open: number; s?: number }> = ({ p, open, s = 1 }) => (
  <group position={p} scale={s}>
    <CanvasPlane p={[0, 0.7, 0.11]} s={[3, 1.4]} px={[300, 140]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#14141c"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.textAlign = "left"; c.fillText("SCENE: THE APOCALYPSE", 14, 38); c.fillText("TAKE: 1", 14, 80); c.fillText("WRITTEN BY: EVERYONE", 14, 122); }} />
    <group position={[-1.5, 1.5, 0]} rotation={[0, 0, open]}><Box p={[1.5, 0.14, 0]} s={[3, 0.28, 0.24]} color="#f4f4f4" line={3} />
      {[0, 1, 2, 3, 4].map((i) => <Box key={i} p={[0.3 + i * 0.6, 0.14, 0.13]} s={[0.3, 0.26, 0.02]} color="#14141c" rot={[0, 0, 0.5]} line={0} />)}</group>
  </group>
);
