// Recording-studio / street / car props (kanye-through-the-wire). Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3 } from "./kit";
import { Glow } from "./props";

/* mixing console: body + slanted panel with animated faders / knobs / meters */
export const Console: React.FC<{ p: V3; w?: number; t: number; live?: number; color?: string }> = ({ p, w = 6, t, live = 1, color = "#2c2c3c" }) => (
  <group position={p}>
    <Box p={[0, 0.7, 0]} s={[w, 1.4, 1.6]} color={color} />
    <group position={[0, 1.55, 0.1]} rotation={[-0.38, 0, 0]}>
      <Box p={[0, 0, 0]} s={[w + 0.1, 0.12, 1.5]} color="#3a3a4e" />
      <CanvasPlane p={[0, 0.08, 0]} rot={[-Math.PI / 2, 0, 0]} s={[w - 0.2, 1.36]} px={[Math.round(w * 90), 122]} draw={(c, W, H) => {
        c.fillStyle = "#23232f"; c.fillRect(0, 0, W, H); const n = Math.floor(W / 34);
        for (let i = 0; i < n; i++) { const x = 17 + i * 34; c.fillStyle = ["#e5233a", "#ffc23a", "#2fd46a", "#2f8cff"][i % 4]; c.beginPath(); c.arc(x, 20, 8, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 2.5; c.stroke(); c.fillStyle = "#0b0d1a"; c.fillRect(x - 3, 40, 6, 62); const fy = 48 + ((Math.sin(t * 1.7 * live + i * 1.3) * 0.5 + 0.5) * 44); c.fillStyle = "#e8e8f0"; c.fillRect(x - 10, fy, 20, 11); c.strokeRect(x - 10, fy, 20, 11);
          const m = Math.abs(Math.sin(t * 7 * live + i * 2.1)) * live; c.fillStyle = m > 0.8 ? "#e5233a" : m > 0.5 ? "#ffc23a" : "#2fd46a"; c.fillRect(x - 3, 108 - m * 14, 6, m * 14 + 1); }
      }} />
    </group>
  </group>
);
export const Speaker: React.FC<{ p: V3; s?: number; t?: number; beat?: number }> = ({ p, s = 1, t = 0, beat = 0 }) => (
  <group position={p} scale={s}><Box p={[0, 1.1, 0]} s={[1.3, 2.2, 1.1]} color="#1f1f2a" />
    <Ball p={[0, 0.7, 0.58]} r={0.4 + 0.04 * beat * Math.sin(t * 25)} color="#3a3a4a" s={[1, 1, 0.3]} ink={0.04} /><Ball p={[0, 1.6, 0.58]} r={0.22 + 0.03 * beat * Math.sin(t * 25)} color="#3a3a4a" s={[1, 1, 0.3]} ink={0.03} /></group>
);
export const MicStand: React.FC<{ p: V3; h?: number; pop?: boolean }> = ({ p, h = 3.0, pop = false }) => (
  <group position={p}><Cyl p={[0, 0.06, 0]} rt={0.5} h={0.12} color="#2a2a38" line={2} /><Cyl p={[0, h / 2, 0]} rt={0.05} h={h} color="#aab0c0" line={2} /><Cyl p={[0, h + 0.25, 0.1]} rt={0.1} rb={0.08} h={0.4} color="#3a3a46" line={2} /><Ball p={[0, h + 0.5, 0.1]} r={0.13} color="#6a6a7a" ink={0.03} />
    {pop ? <Cyl p={[0, h + 0.2, 0.55]} rt={0.42} h={0.04} color="#1a1a22" line={2} rot={[Math.PI / 2, 0, 0]} /> : null}</group>
);
export const GoldDisc: React.FC<{ p: V3; s?: number; text?: string; rot?: V3 }> = ({ p, s = 1, text = "", rot }) => (
  <group position={p} rotation={rot} scale={s}><Box p={[0, 0, -0.04]} s={[1.5, 1.5, 0.08]} color="#3a2a14" line={2} /><Cyl p={[0, 0, 0.03]} rt={0.6} h={0.06} color="#ffc928" line={3} rot={[Math.PI / 2, 0, 0]} /><Cyl p={[0, 0, 0.07]} rt={0.18} h={0.04} color="#c9402e" line={2} rot={[Math.PI / 2, 0, 0]} />
    {text ? <CanvasPlane p={[0, -0.9, 0.02]} s={[1.3, 0.34]} px={[260, 68]} draw={(c, W, H) => { c.fillStyle = "#e8d8a0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 2); }} /> : null}</group>
);
export const Palm: React.FC<{ p: V3; h?: number; sway?: number }> = ({ p, h = 6, sway = 0 }) => (
  <group position={p}><Cyl p={[0.2, h / 2, 0]} rt={0.18} rb={0.3} h={h} color="#8a6a42" line={2} rot={[0, 0, -0.07]} />
    {[0, 1, 2, 3, 4, 5].map((i) => <Box key={i} p={[Math.cos(i * 1.05) * 0.9, h + 0.1 - Math.abs(Math.sin(i * 1.05)) * 0.2, Math.sin(i * 1.05) * 0.9]} s={[1.9, 0.08, 0.5]} rot={[0, -i * 1.05, -0.4 + sway * 0.05]} color={i % 2 ? "#2f8a3a" : "#3aa04a"} line={2} />)}</group>
);
/* convertible, faces +x. crumple 0..1 shortens the hood */
export const Car: React.FC<{ p: V3; color?: string; crumple?: number; rotZ?: number }> = ({ p, color = "#e5233a", crumple = 0, rotZ = 0 }) => (
  <group position={p} rotation={[0, 0, rotZ]}>
    <Box p={[0, 0.65, 0]} s={[3.2, 0.7, 1.6]} color={color} /><Box p={[1.0 - crumple * 0.35, 0.95, 0]} s={[1.3 - crumple * 0.7, 0.3, 1.5]} color={color} rot={[0, 0, -0.05 + crumple * 0.25]} />
    <Box p={[-0.5, 1.05, 0]} s={[1.3, 0.55, 1.4]} color="#2a2a38" /><Box p={[0.35, 1.25, 0]} s={[0.1, 0.55, 1.5]} color="#8fd0ff" rot={[0, 0, -0.5]} line={2} />
    <Cyl p={[0.18, 1.3, 0]} rt={0.28} h={0.05} color="#2a2a38" line={2} rot={[0.9, 0, 0.2]} />
    {[-1.0, 1.05].map((x) => [-0.82, 0.82].map((z) => <Cyl key={x + "_" + z} p={[x, 0.38, z]} rt={0.38} h={0.2} color="#14141c" line={2} rot={[Math.PI / 2, 0, 0]} />))}
    <Ball p={[1.62 - crumple * 0.5, 0.78, 0.5]} r={0.16} color="#fff6c0" ink={0.03} /><Ball p={[1.62 - crumple * 0.5, 0.78, -0.5]} r={0.16} color="#fff6c0" ink={0.03} /><Box p={[-1.62, 0.55, 0]} s={[0.1, 0.3, 1.2]} color="#c01a2e" line={2} />
  </group>
);
export const Vinyl: React.FC<{ p: V3; r?: number; spin: number; label?: string; rot?: V3 }> = ({ p, r = 1.2, spin, label = "", rot }) => (
  <group position={p} rotation={rot}><group rotation={[0, 0, spin]}>
    <CanvasPlane p={[0, 0, 0]} s={[r * 2, r * 2]} px={[300, 300]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#111118"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.arc(150, 150, 144, 0, 7); c.fill(); c.stroke(); c.strokeStyle = "rgba(255,255,255,.14)"; c.lineWidth = 2; for (let k = 40; k < 140; k += 12) { c.beginPath(); c.arc(150, 150, k, 0.2, 2.2); c.stroke(); } c.fillStyle = "#ffc23a"; c.beginPath(); c.arc(150, 150, 48, 0, 7); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 15px Inter, Arial"; c.textAlign = "center"; c.fillText(label, 150, 154); }} /></group></group>
);
