// Birds & co: Bird (swift / humming / hawk / owl / gull / sparrow), Flower, Fish, Mouse.
import React from "react";
import { Box, Cyl, Ball } from "./toon";
type V3 = [number, number, number];
export type BirdKind = "swift" | "humming" | "hawk" | "owl" | "gull" | "sparrow";
const C: Record<BirdKind, { body: string; wing: string; belly: string; beak: string; span: number; len: number }> = {
  swift: { body: "#2a2a36", wing: "#1e1e28", belly: "#d8d8e0", beak: "#111", span: 1.5, len: 0.8 },
  humming: { body: "#2fbf6a", wing: "#9fe8c0", belly: "#e5233a", beak: "#111", span: 0.6, len: 0.55 },
  hawk: { body: "#8a5a32", wing: "#6a4426", belly: "#f0e0c0", beak: "#ffc23a", span: 1.8, len: 1.0 },
  owl: { body: "#9a7a5a", wing: "#7a5e44", belly: "#e8d8b8", beak: "#ffc23a", span: 1.4, len: 0.9 },
  gull: { body: "#f4f4f8", wing: "#9aa4b8", belly: "#ffffff", beak: "#ffb23a", span: 1.7, len: 0.9 },
  sparrow: { body: "#a8784a", wing: "#7a5432", belly: "#f0e0c8", beak: "#e8a030", span: 0.9, len: 0.6 },
};
/** flap: 0 = wings folded (grounded), 1 = flapping. Faces +x unless flip. */
export const Bird: React.FC<{ p: V3; kind: BirdKind; t: number; flap?: number; s?: number; flip?: boolean; rate?: number }> = ({ p, kind, t, flap = 1, s = 1, flip, rate = 10 }) => {
  const c = C[kind], a = 0.5 + 0.6 * Math.sin(t * rate), L = c.len;
  return (<group position={p} scale={[flip ? -s : s, s, s]}>
    <Ball p={[0, 0, 0]} r={L * 0.42} s={[1.5, 1, 1]} color={c.body} ink={0.05} />
    <Ball p={[L * 0.05, -L * 0.08, L * 0.12]} r={L * 0.3} s={[1.4, 0.8, 1]} color={c.belly} ink={0.02} />
    <Ball p={[L * 0.6, L * 0.22, 0]} r={L * (kind === "owl" ? 0.36 : 0.26)} color={c.body} ink={0.05} />
    <Ball p={[L * (kind === "owl" ? 0.66 : 0.7), L * 0.3, L * 0.2]} r={L * (kind === "owl" ? 0.12 : 0.06)} color={kind === "owl" ? "#ffd23a" : "#111"} ink={0.02} />
    {kind === "owl" ? <Ball p={[L * 0.66, L * 0.3, -L * 0.2]} r={L * 0.12} color="#ffd23a" ink={0.02} /> : null}
    <Box p={[L * (kind === "humming" ? 1.15 : 0.88), L * 0.18, 0]} s={[L * (kind === "humming" ? 0.8 : 0.25), L * 0.08, L * 0.08]} rot={[0, 0, kind === "hawk" ? -0.4 : 0]} color={c.beak} line={1} />
    <Box p={[-L * 0.75, 0, 0]} s={[L * 0.6, L * 0.06, L * (kind === "swift" ? 0.18 : 0.3)]} rot={[0, 0, 0.15]} color={c.wing} line={2} />
    {flap > 0.05 ? [1, -1].map((side, i) => <group key={i} position={[0, L * 0.1, side * L * 0.25]} rotation={[side * a, 0, 0]}>
      <Box p={[-L * 0.1, 0, side * c.span * 0.45 * flap]} s={[L * (kind === "swift" ? 0.35 : 0.6), L * 0.06, c.span * 0.9 * flap + 0.01]} rot={[0, side * (kind === "swift" ? 0.5 : 0.15), 0]} color={c.wing} line={2} />
    </group>) : [1, -1].map((side, i) => <Ball key={i} p={[-L * 0.15, L * 0.02, side * L * 0.3]} r={L * 0.32} s={[1.7, 0.75, 0.35]} color={c.wing} ink={0.04} />)}
  </group>);
};
export const Flower: React.FC<{ p: V3; h?: number; color?: string; droop?: number; s?: number }> = ({ p, h = 1.4, color = "#ff5a8a", droop = 0, s = 1 }) => (
  <group position={p} scale={[s, s, s]}>
    <Cyl p={[0, h / 2, 0]} rt={0.05} h={h} color="#3a9a3a" line={2} />
    <group position={[0, h, 0]} rotation={[0, 0, droop * 0.8]}>
      {Array.from({ length: 6 }, (_, i) => { const a = (i / 6) * Math.PI * 2; return <Ball key={i} p={[Math.cos(a) * 0.22, 0.05, Math.sin(a) * 0.22]} r={0.16} color={color} ink={0.03} />; })}
      <Ball p={[0, 0.1, 0]} r={0.13} color="#ffd23a" ink={0.03} />
    </group>
  </group>
);
export const Fish: React.FC<{ p: V3; t: number; s?: number; color?: string; flip?: boolean }> = ({ p, t, s = 1, color = "#ffa23a", flip }) => (
  <group position={p} scale={[flip ? -s : s, s, s]} rotation={[0, 0, Math.sin(t * 4 + p[0]) * 0.1]}>
    <Ball p={[0, 0, 0]} r={0.3} s={[1.6, 1, 0.6]} color={color} ink={0.04} /><Box p={[-0.55, 0, 0]} s={[0.25, 0.4, 0.05]} rot={[0, 0, Math.PI / 4]} color={color} line={2} />
    <Ball p={[0.3, 0.06, 0.14]} r={0.05} color="#111" ink={0} />
  </group>
);
export const Mouse: React.FC<{ p: V3; t: number; flip?: boolean }> = ({ p, t, flip }) => (
  <group position={[p[0], p[1] + Math.abs(Math.sin(t * 14)) * 0.05, p[2]]} scale={[flip ? -1 : 1, 1, 1]}>
    <Ball p={[0, 0.18, 0]} r={0.2} s={[1.5, 1, 1]} color="#9a9aa8" ink={0.04} /><Ball p={[0.3, 0.24, 0]} r={0.12} color="#9a9aa8" ink={0.03} />
    <Ball p={[0.26, 0.38, 0.06]} r={0.07} color="#e8b8c0" ink={0.02} /><Box p={[-0.42, 0.14, 0]} s={[0.4, 0.03, 0.03]} rot={[0, 0, 0.3]} color="#e8b8c0" line={0} />
  </group>
);
