// Small-business props: vending machine, ATM, box truck, storage unit, bills. Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3 } from "./kit";
import { Glow } from "./props";

const SNACK = ["#e5233a", "#ffc23a", "#2fd46a", "#2f8cff", "#ff7a29", "#c24fff"];
export const Vending: React.FC<{ p: V3; s?: number; color?: string; seed?: number; yaw?: number; t?: number; drop?: number }> = ({ p, s = 1, color = "#d8283a", seed = 1, yaw = 0, t = 0, drop = -1 }) => (
  <group position={p} rotation={[0, yaw, 0]} scale={s}>
    <Box p={[0, 2.2, 0]} s={[2.6, 4.4, 1.6]} color={color} line={4} />
    <CanvasPlane p={[-0.3, 2.65, 0.82]} s={[1.7, 3.2]} px={[170, 320]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#0d1830"; c.fillRect(0, 0, W, H); for (let r = 0; r < 5; r++) for (let k = 0; k < 4; k++) { const col = SNACK[(r * 3 + k * 2 + seed) % 6]; c.fillStyle = col; c.strokeStyle = INK; c.lineWidth = 3; c.fillRect(10 + k * 40, 14 + r * 60, 32, 40); c.strokeRect(10 + k * 40, 14 + r * 60, 32, 40); c.fillStyle = "rgba(255,255,255,.8)"; c.fillRect(10 + k * 40, 58 + r * 60, 32, 5); } }} />
    <Box p={[0.95, 2.6, 0.82]} s={[0.55, 2.4, 0.06]} color="#2a2a38" line={2} />{[0, 1, 2, 3].map((i) => <Box key={i} p={[0.95, 3.4 - i * 0.28, 0.88]} s={[0.3, 0.18, 0.04]} color="#c9d3e0" line={1} />)}<Box p={[0.95, 2.1, 0.88]} s={[0.12, 0.34, 0.04]} color="#111" line={1} />
    <Box p={[-0.3, 0.55, 0.84]} s={[1.7, 0.7, 0.05]} color="#05070e" line={2} /><Box p={[-0.3, 4.1, 0.84]} s={[1.7, 0.34, 0.05]} color="#ffe14a" line={1} />
    <Glow p={[-0.3, 2.6, 1.4]} r={2.6} color="rgba(255,255,230,1)" o={0.22} />
    {drop >= 0 ? <Box p={[-0.3, drop < 1 ? 3.2 - (3.2 - 0.62) * drop * drop : 0.62 + 0.12 * Math.exp(-(drop - 1) * 8) * Math.abs(Math.sin((drop - 1) * 40)), 0.86]} s={[0.4, 0.5, 0.1]} color="#ffc23a" line={2} /> : null}
  </group>
);
export const Atm: React.FC<{ p: V3; s?: number; draw?: (c: CanvasRenderingContext2D, W: number, H: number) => void; glow?: string }> = ({ p, s = 1, draw, glow = "rgba(60,255,150,1)" }) => (
  <group position={p} scale={s}><Box p={[0, 2.4, 0]} s={[2.8, 4.8, 1.5]} color="#2a3a50" line={4} /><Box p={[0, 3.5, 0.78]} s={[2.2, 1.6, 0.05]} color="#0b0d1a" line={2} />
    <CanvasPlane p={[0, 3.5, 0.82]} s={[2.0, 1.4]} px={[200, 140]} draw={draw ?? ((c, W, H) => { c.fillStyle = "#052a14"; c.fillRect(0, 0, W, H); c.fillStyle = "#3dff7a"; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.fillText("ATM", W / 2, H / 2 + 12); })} />
    <Box p={[0, 2.2, 0.78]} s={[1.6, 0.7, 0.05]} color="#4a5a70" line={2} />{[0, 1, 2].map((r) => [0, 1, 2].map((k) => <Box key={r + "_" + k} p={[-0.3 + k * 0.3, 2.35 - r * 0.2, 0.83]} s={[0.22, 0.14, 0.04]} color="#c9d3e0" line={1} />))}
    <Box p={[0, 1.35, 0.78]} s={[1.5, 0.2, 0.1]} color="#05070e" line={2} /><Box p={[0.95, 3.5, 0.8]} s={[0.1, 0.9, 0.05]} color="#2f8cff" line={1} /><Glow p={[0, 3.5, 1.6]} r={3} color={glow} o={0.4} /></group>
);
export const Bill: React.FC<{ p: V3; rot?: V3; s?: number }> = ({ p, rot, s = 1 }) => (
  <group position={p} rotation={rot} scale={s}><Box p={[0, 0, 0]} s={[0.8, 0.36, 0.03]} color="#6fd08a" line={2} /><CanvasPlane p={[0, 0, 0.02]} s={[0.5, 0.3]} px={[80, 40]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#14502a"; c.font = "900 32px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("$", W / 2, H / 2 + 2); }} /></group>
);
export const Truck: React.FC<{ p: V3; color?: string; label?: string }> = ({ p, color = "#ff7a29", label = "TRUCK RENTAL" }) => (
  <group position={p}><Box p={[-0.9, 1.7, 0]} s={[3.8, 2.6, 1.9]} color="#f4f4f4" line={3} /><CanvasPlane p={[-0.9, 1.8, 0.97]} s={[3.4, 1.0]} px={[340, 100]} draw={(c, W, H) => { c.fillStyle = color; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(label, W / 2, H / 2 + 3); }} />
    <Box p={[1.9, 1.2, 0]} s={[1.6, 1.8, 1.9]} color={color} line={3} /><Box p={[2.3, 1.7, 0.97]} s={[0.8, 0.8, 0.04]} color="#8fd0ff" line={2} /><Box p={[0.2, 0.4, 0]} s={[6.2, 0.3, 1.7]} color="#2a2a38" line={2} />
    {[-1.6, 1.8].map((x) => [-0.95, 0.95].map((z) => <Cyl key={x + "_" + z} p={[x, 0.45, z]} rt={0.45} h={0.25} color="#14141c" line={2} rot={[Math.PI / 2, 0, 0]} />))}<Ball p={[3.0, 0.9, 0.5]} r={0.14} color="#fff6c0" ink={0.03} /></group>
);
