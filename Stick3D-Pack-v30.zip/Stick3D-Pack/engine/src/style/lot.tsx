// Parking-lot props: lines, cheap instanced car field, pay stand, "P" sign. Logged in rules/ACTION-LIBRARY.md.
import React, { useMemo, useRef, useLayoutEffect } from "react";
import * as THREE from "three";
import { Box, Cyl, CanvasPlane, INK } from "./toon";
import { V3 } from "./kit";

export const LotLines: React.FC<{ p: V3; cols: number; rows: number; w?: number; d?: number; color?: string; asphalt?: string }> = ({ p, cols, rows, w = 2.8, d = 5.2, color = "#f4f4f4", asphalt = "#3a3a44" }) => (
  <group position={p}>
    <Box p={[0, -0.04, 0]} s={[cols * w + 1.2, 0.08, rows * d + 1.2]} color={asphalt} line={0} />
    {Array.from({ length: rows }, (_, r) => Array.from({ length: cols + 1 }, (_, c) => <Box key={r + "_" + c} p={[-cols * w / 2 + c * w, 0.02, -rows * d / 2 + d * (r + 0.5)]} s={[0.12, 0.03, d * 0.86]} color={color} line={0} />))}
  </group>
);
export const SpaceXY = (c: number, r: number, cols: number, rows: number, w = 2.8, d = 5.2): [number, number] => [-cols * w / 2 + (c + 0.5) * w, -rows * d / 2 + d * (r + 0.5)];
export const CarField: React.FC<{ p: V3; cols: number; rows: number; w?: number; d?: number; filled: (i: number) => number; seed?: number }> = ({ p, cols, rows, w = 2.8, d = 5.2, filled, seed = 1 }) => {
  const n = cols * rows, body = useRef<THREE.InstancedMesh>(null), cab = useRef<THREE.InstancedMesh>(null), inkB = useRef<THREE.InstancedMesh>(null), inkC = useRef<THREE.InstancedMesh>(null);
  const PAL = ["#e5233a", "#2f8cff", "#f4f4f4", "#2a2a38", "#ffc23a", "#2fd46a", "#ff7a29", "#c24fff"];
  const colors = useMemo(() => Array.from({ length: n }, (_, i) => new THREE.Color(PAL[(i * 5 + seed * 3) % PAL.length])), [n, seed]);
  useLayoutEffect(() => {
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), ps = new THREE.Vector3(), sc = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      const c = i % cols, r = Math.floor(i / cols), [x, z] = SpaceXY(c, r, cols, rows, w, d), k = Math.max(0.0001, filled(i));
      const put = (mesh: THREE.InstancedMesh | null, y: number, s: V3, grow: number) => { if (!mesh) return; ps.set(p[0] + x, p[1] + y * k, p[2] + z + (1 - k) * 0); sc.set(s[0] * k * grow, s[1] * k * grow, s[2] * k * grow); m.compose(ps, q, sc); mesh.setMatrixAt(i, m); };
      put(body.current, 0.62, [1.7, 0.7, 3.4], 1); put(cab.current, 1.2, [1.4, 0.6, 1.8], 1); put(inkB.current, 0.62, [1.7, 0.7, 3.4], 1.06); put(inkC.current, 1.2, [1.4, 0.6, 1.8], 1.08);
      body.current?.setColorAt(i, colors[i]); cab.current?.setColorAt(i, new THREE.Color("#1c2434"));
    }
    for (const r of [body, cab, inkB, inkC]) if (r.current) { r.current.instanceMatrix.needsUpdate = true; if (r.current.instanceColor) r.current.instanceColor.needsUpdate = true; }
  });
  return (<>
    <instancedMesh ref={body} args={[undefined, undefined, n]}><boxGeometry args={[1, 1, 1]} /><meshBasicMaterial /></instancedMesh>
    <instancedMesh ref={cab} args={[undefined, undefined, n]}><boxGeometry args={[1, 1, 1]} /><meshBasicMaterial /></instancedMesh>
    <instancedMesh ref={inkB} args={[undefined, undefined, n]}><boxGeometry args={[1, 1, 1]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></instancedMesh>
    <instancedMesh ref={inkC} args={[undefined, undefined, n]}><boxGeometry args={[1, 1, 1]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></instancedMesh>
  </>);
};
export const PayStand: React.FC<{ p: V3; s?: number; text?: string; t?: number }> = ({ p, s = 1, text = "PAY", t = 0 }) => (
  <group position={p} scale={s}><Box p={[0, 1.2, 0]} s={[0.9, 2.4, 0.7]} color="#2f6ad8" line={3} /><Box p={[0, 2.0, 0.37]} s={[0.7, 0.8, 0.04]} color="#0b0d1a" line={2} />
    <CanvasPlane p={[0, 2.0, 0.4]} s={[0.64, 0.7]} px={[64, 70]} draw={(c, W, H) => { c.fillStyle = "#052a14"; c.fillRect(0, 0, W, H); c.fillStyle = "#3dff7a"; c.font = "900 22px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2); }} />
    <Box p={[0, 1.2, 0.37]} s={[0.5, 0.3, 0.05]} color="#c9d3e0" line={1} /><Cyl p={[0, 2.7, 0]} rt={0.4} h={0.12} color="#ffc23a" line={2} /></group>
);
export const PSign: React.FC<{ p: V3; s?: number }> = ({ p, s = 1 }) => (
  <group position={p} scale={s}><Cyl p={[0, 1.8, 0]} rt={0.07} h={3.6} color="#5a5a6a" line={2} /><CanvasPlane p={[0, 3.9, 0.05]} s={[1.5, 1.5]} px={[150, 150]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#1f4ad8"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 120px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("P", W / 2, H / 2 + 6); }} /></group>
);
