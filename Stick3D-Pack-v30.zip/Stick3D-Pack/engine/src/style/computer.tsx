// Generic early all-in-one computer (no logos) + keyboard. Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import { Box, Cyl, CanvasPlane } from "./toon";
import { V3 } from "./kit";
import { Glow } from "./props";
export const Compact: React.FC<{ p: V3; s?: number; yaw?: number; draw: (c: CanvasRenderingContext2D, W: number, H: number) => void; glow?: number; color?: string }> = ({ p, s = 1, yaw = 0, draw, glow = 0.3, color = "#e8dcc0" }) => (
  <group position={p} rotation={[0, yaw, 0]} scale={s}>
    <Box p={[0, 1.4, 0]} s={[2.1, 2.8, 2.1]} color={color} line={4} /><Box p={[0, 1.9, 1.06]} s={[1.6, 1.25, 0.04]} color="#1a1a22" line={2} />
    <CanvasPlane p={[0, 1.9, 1.09]} s={[1.44, 1.1]} px={[288, 220]} draw={draw} />
    <Box p={[0.4, 0.75, 1.06]} s={[0.7, 0.08, 0.04]} color="#2a2a30" line={1} />
    <Box p={[0, -0.02, 1.9]} s={[1.9, 0.16, 0.8]} color={color} line={3} />{Array.from({ length: 4 }, (_, r) => <Box key={r} p={[0, 0.08, 1.65 + r * 0.16]} s={[1.6, 0.04, 0.1]} color="#c8bca0" line={0} />)}
    <Glow p={[0, 1.9, 1.6]} r={1.6} color="rgba(220,240,255,1)" o={glow} />
  </group>
);
