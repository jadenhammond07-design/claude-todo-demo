// Nature-reclaims props: Tree, Bush, Weed, Water (translucent rising volume), Animal (wolf / boar / deer), Cap (bottle cap).
import React from "react";
import { Box, Cyl, Ball } from "./toon";
type V3 = [number, number, number];

export const Tree: React.FC<{ p: V3; h?: number; k?: number; color?: string; sway?: number }> = ({ p, h = 5, k = 1, color = "#3fae4a", sway = 0 }) => {
  const s = Math.max(0.001, k);
  return (<group position={p} scale={[s, s, s]} rotation={[0, 0, sway]}>
    <Cyl p={[0, h * 0.3, 0]} rt={0.18 * h / 5} rb={0.28 * h / 5} h={h * 0.6} color="#6a4426" line={3} />
    <Ball p={[0, h * 0.72, 0]} r={h * 0.26} color={color} />
    <Ball p={[-h * 0.16, h * 0.6, 0.1]} r={h * 0.19} color={color} />
    <Ball p={[h * 0.17, h * 0.62, 0.05]} r={h * 0.18} color={color} />
  </group>);
};
export const Bush: React.FC<{ p: V3; s?: number; color?: string }> = ({ p, s = 1, color = "#4cc25a" }) => {
  const k = Math.max(0.001, s);
  return (<group position={p} scale={[k, k, k]}><Ball p={[0, 0.35, 0]} r={0.5} color={color} /><Ball p={[0.45, 0.28, 0]} r={0.36} color={color} /><Ball p={[-0.45, 0.26, 0.05]} r={0.34} color={color} /></group>);
};
export const Weed: React.FC<{ p: V3; k?: number; color?: string }> = ({ p, k = 1, color = "#5cd24a" }) => {
  const s = Math.max(0.001, k);
  return (<group position={p} scale={[s, s, s]}>
    {[-0.5, 0, 0.5].map((a, i) => <Box key={i} p={[Math.sin(a) * 0.25, 0.4, 0]} s={[0.1, 0.8 + i * 0.1, 0.1]} rot={[0, 0, a]} color={color} line={2} />)}
  </group>);
};
/** translucent water volume, top surface at y=level */
export const Water: React.FC<{ p: V3; w: number; d: number; level: number; color?: string; o?: number }> = ({ p, w, d, level, color = "#3a8ad8", o = 0.75 }) => {
  const h = Math.max(0.001, level);
  return (<group position={p}>
    <mesh position={[0, h / 2, 0]}><boxGeometry args={[w, h, d]} /><meshBasicMaterial color={color} transparent opacity={o} depthWrite={false} /></mesh>
    <mesh position={[0, h + 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[w, d]} /><meshBasicMaterial color="#9fd4ff" transparent opacity={0.6} depthWrite={false} /></mesh>
  </group>);
};
/** simple toon animal. kind: wolf (grey, pointed ears), boar (brown, tusks, low), deer (tan, long legs, antlers). Faces +x unless flip. */
export const Animal: React.FC<{ p: V3; kind: "wolf" | "boar" | "deer"; t: number; walk?: number; flip?: boolean; s?: number }> = ({ p, kind, t, walk = 0, flip, s = 1 }) => {
  const c = kind === "wolf" ? { body: "#8a8f9a", leg: 0.7, len: 1.6, h: 0.7, head: "#9aa0aa" } : kind === "boar" ? { body: "#6a4a32", leg: 0.45, len: 1.5, h: 0.8, head: "#5a3e2a" } : { body: "#c08a52", leg: 1.1, len: 1.5, h: 0.65, head: "#c99660" };
  const ph = t * 9 * walk, bob = Math.abs(Math.sin(ph)) * 0.06 * walk;
  return (<group position={[p[0], p[1] + bob, p[2]]} scale={[flip ? -s : s, s, s]}>
    <Box p={[0, c.leg + c.h / 2, 0]} s={[c.len, c.h, 0.6]} color={c.body} line={3} />
    {[[-0.55, 0.2], [0.55, 0.2], [-0.55, -0.2], [0.55, -0.2]].map(([x, z], i) => { const sw = Math.sin(ph + (i % 2 ? Math.PI : 0)) * 0.35 * walk; return <group key={i} position={[x * c.len / 1.6, c.leg, z]} rotation={[0, 0, sw]}><Box p={[0, -c.leg / 2, 0]} s={[0.14, c.leg, 0.14]} color={c.body} line={2} /></group>; })}
    {/* head */}
    <group position={[c.len / 2 + 0.25, c.leg + c.h * (kind === "deer" ? 1.1 : 0.75), 0]}>
      <Box p={[0, 0, 0]} s={[0.55, 0.45, 0.45]} color={c.head} line={3} />
      <Box p={[0.32, -0.08, 0]} s={[0.3, 0.24, 0.3]} color={kind === "boar" ? "#e8a0a0" : c.head} line={2} />
      <Ball p={[0.12, 0.08, 0.23]} r={0.06} color="#111" ink={0} />
      {kind === "wolf" ? <><Box p={[-0.1, 0.3, 0.12]} s={[0.12, 0.22, 0.08]} rot={[0, 0, 0.2]} color={c.head} line={2} /><Box p={[-0.1, 0.3, -0.12]} s={[0.12, 0.22, 0.08]} rot={[0, 0, 0.2]} color={c.head} line={2} /></> : null}
      {kind === "boar" ? <><Box p={[0.42, 0.02, 0.15]} s={[0.05, 0.16, 0.04]} rot={[0, 0, -0.5]} color="#fff" line={1} /><Box p={[0.42, 0.02, -0.15]} s={[0.05, 0.16, 0.04]} rot={[0, 0, -0.5]} color="#fff" line={1} /></> : null}
      {kind === "deer" ? <>{[0.14, -0.14].map((z, i) => <group key={i} position={[-0.05, 0.25, z]}><Box p={[0, 0.25, 0]} s={[0.06, 0.5, 0.06]} color="#7a5230" line={1} /><Box p={[0.12, 0.38, 0]} s={[0.22, 0.05, 0.05]} rot={[0, 0, 0.6]} color="#7a5230" line={1} /></group>)}</> : null}
    </group>
    {kind === "wolf" ? <Box p={[-c.len / 2 - 0.3, c.leg + c.h * 0.7, 0]} s={[0.6, 0.16, 0.16]} rot={[0, 0, 0.5]} color={c.body} line={2} /> : null}
  </group>);
};
export const Cap: React.FC<{ p: V3; r?: number; color?: string }> = ({ p, r = 0.5, color = "#e5233a" }) => (
  <group position={p}><Cyl p={[0, r * 0.25, 0]} rt={r} h={r * 0.5} color={color} line={4} /><Cyl p={[0, r * 0.52, 0]} rt={r * 0.82} h={0.04} color="#ff6a7a" line={1} /></group>
);
