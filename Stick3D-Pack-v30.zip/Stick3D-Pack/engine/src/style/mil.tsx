// WWII decoy props: inflatable tank, half-track with speaker, radio set, easel. Cartoon-safe, no insignia beyond a white star. Logged in rules/ACTION-LIBRARY.md.
import React from "react";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3 } from "./kit";
import { Glow } from "./props";

export const Tank: React.FC<{ p: V3; s?: number; yaw?: number; color?: string; puff?: number; wob?: number; ghost?: boolean }> = ({ p, s = 1, yaw = 0, color = "#6a7a3a", puff = 1, wob = 0, ghost }) => {
  const k = Math.max(0.05, puff), c = ghost ? "#cfe0ff" : color, tr = ghost ? "#a8b8e0" : "#2a2a30";
  return (<group position={p} rotation={[0, yaw, 0]} scale={[s * (1 + 0.1 * wob), s * k * (1 - 0.1 * wob), s * (1 + 0.1 * wob)]}>
    <Box p={[0, 0.95, 0]} s={[4.4, 1.0, 2.4]} color={c} line={4} /><Box p={[0, 0.5, 1.28]} s={[4.8, 0.9, 0.5]} color={tr} line={3} /><Box p={[0, 0.5, -1.28]} s={[4.8, 0.9, 0.5]} color={tr} line={3} />
    <Box p={[-0.2, 1.7, 0]} s={[1.9, 0.7, 1.6]} color={c} line={3} /><Cyl p={[1.8, 1.75, 0]} rt={0.12} h={2.2} color={ghost ? "#b8c8f0" : "#4a5a2a"} line={2} rot={[0, 0, Math.PI / 2]} />
    <CanvasPlane p={[-0.2, 1.7, 0.83]} s={[0.8, 0.8]} px={[80, 80]} draw={(cx, W, H) => { cx.clearRect(0, 0, W, H); cx.fillStyle = "#fff"; cx.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 - Math.PI / 2, r = i % 2 ? 16 : 36; cx.lineTo(40 + Math.cos(a) * r, 40 + Math.sin(a) * r); } cx.closePath(); cx.fill(); }} />
  </group>);
};
export const HalfTrack: React.FC<{ p: V3; s?: number; t?: number }> = ({ p, s = 1, t = 0 }) => (
  <group position={p} scale={s}>
    <Box p={[1.2, 1.3, 0]} s={[2.0, 1.2, 2.0]} color="#6a7a3a" line={3} /><Box p={[2.4, 1.0, 0]} s={[0.9, 0.7, 1.8]} color="#6a7a3a" line={3} /><Box p={[-1.0, 1.1, 0]} s={[3.4, 0.8, 2.2]} color="#5a6a2a" line={3} />
    <Box p={[-1.0, 0.45, 1.15]} s={[3.4, 0.6, 0.3]} color="#2a2a30" line={2} /><Box p={[-1.0, 0.45, -1.15]} s={[3.4, 0.6, 0.3]} color="#2a2a30" line={2} />
    {[2.2].map((x) => [-1.0, 1.0].map((z) => <Cyl key={x + "_" + z} p={[x, 0.45, z]} rt={0.45} h={0.3} color="#14141c" line={2} rot={[Math.PI / 2, 0, 0]} />))}
    <Box p={[-2.0, 2.0, 0]} s={[1.4, 1.2, 1.6]} color="#2a2a38" line={3} />
    {[-0.5, 0.5].map((z) => <Cyl key={z} p={[-2.9, 2.4, z]} rt={0.7} rb={0.18} h={1.1} color="#c9a032" line={3} rot={[0, 0, Math.PI / 2]} />)}
    <CanvasPlane p={[-1.2, 1.55, 1.12]} s={[1.2, 0.7]} px={[120, 70]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.fillRect(0, 0, W, H); for (const x of [32, 88]) { c.save(); c.translate(x, 36); c.rotate(t * 6); c.strokeStyle = "#c9d3e0"; c.lineWidth = 4; c.beginPath(); c.arc(0, 0, 22, 0, 7); c.moveTo(-22, 0); c.lineTo(22, 0); c.moveTo(0, -22); c.lineTo(0, 22); c.stroke(); c.restore(); } }} />
  </group>
);
export const RadioSet: React.FC<{ p: V3; t?: number; s?: number }> = ({ p, t = 0, s = 1 }) => (
  <group position={p} scale={s}><Box p={[0, 0.5, 0]} s={[1.6, 1.0, 0.9]} color="#4a5a2a" line={3} /><Cyl p={[0.6, 1.9, 0]} rt={0.03} h={1.8} color="#c9d3e0" line={1} />
    <CanvasPlane p={[-0.3, 0.6, 0.47]} s={[0.7, 0.5]} px={[70, 50]} draw={(c, W, H) => { c.fillStyle = "#0b1a10"; c.fillRect(0, 0, W, H); c.strokeStyle = "#3dff7a"; c.lineWidth = 2; c.beginPath(); for (let x = 0; x < W; x++) { const y = H / 2 + Math.sin(x * 0.5 + t * 20) * 8 * Math.sin(x * 0.07); x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }} />
    {[0, 1].map((i) => <Cyl key={i} p={[0.4 + i * 0.3, 0.6, 0.47]} rt={0.1} h={0.1} color="#c9d3e0" line={1} rot={[Math.PI / 2, 0, 0]} />)}
    <Box p={[0, 1.04, 0.55]} s={[0.5, 0.1, 0.3]} color="#14141c" line={2} /></group>
);
export const Easel: React.FC<{ p: V3; w?: number; h?: number; draw: (c: CanvasRenderingContext2D, W: number, H: number) => void }> = ({ p, w = 1.8, h = 2.2, draw }) => (
  <group position={p}>{[[-0.8, 0.2], [0.8, 0.2], [0, -0.5]].map(([x, z], i) => <Cyl key={i} p={[x * 0.6, 1.4, z]} rt={0.05} h={2.8} color="#8a6a42" line={2} rot={[z < 0 ? -0.25 : 0.12, 0, x * 0.1]} />)}
    <CanvasPlane p={[0, 2.0, 0.35]} s={[w, h]} px={[Math.round(w * 100), Math.round(h * 100)]} frame="#5a4228" draw={draw} /></group>
);
