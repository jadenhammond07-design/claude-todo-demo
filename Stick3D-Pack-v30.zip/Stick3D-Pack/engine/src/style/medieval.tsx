// Medieval-town props + dance/crowd helpers (dance-1518). Logged in rules/ACTION-LIBRARY.md.
import React, { useMemo, useRef, useLayoutEffect } from "react";
import * as THREE from "three";
import { Box, Cyl, Ball, CanvasPlane, INK } from "./toon";
import { V3, lerp, clamp } from "./kit";
import { Glow } from "./props";
import { Extrude } from "./extra";

export const hex = (h: string): [number, number, number] => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
export const mixHex = (a: string, b: string, k: number) => { const A = hex(a), B = hex(b), c = clamp(k); return "#" + A.map((v, i) => Math.round(v + (B[i] - v) * c).toString(16).padStart(2, "0")).join(""); };

/* ---- sky dome plane: vertical gradient + optional stars (0..1) ---- */
export const Sky: React.FC<{ p: V3; s: [number, number]; top: string; bottom: string; stars?: number; t?: number; glowAt?: [number, string]; rot?: V3 }> = ({ p, s, top, bottom, stars = 0, t = 0, glowAt, rot }) => (
  <CanvasPlane p={p} rot={rot} s={s} px={[256, 256]} draw={(c, W, H) => {
    const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, top); g.addColorStop(1, bottom); c.fillStyle = g; c.fillRect(0, 0, W, H);
    if (glowAt) { const rg = c.createRadialGradient(W / 2, H, 4, W / 2, H, W * 0.9); rg.addColorStop(0, glowAt[1]); rg.addColorStop(1, "rgba(0,0,0,0)"); c.globalAlpha = glowAt[0]; c.fillStyle = rg; c.fillRect(0, 0, W, H); c.globalAlpha = 1; }
    if (stars > 0.02) for (let i = 0; i < 90; i++) { const x = ((i * 7919) % 1000) / 1000 * W, y = ((i * 104729) % 1000) / 1000 * H * 0.8, tw = 0.5 + 0.5 * Math.sin(t * 3 + i); c.fillStyle = `rgba(255,255,235,${stars * (0.3 + 0.7 * tw)})`; c.beginPath(); c.arc(x, y, 0.9 + (i % 3) * 0.6, 0, 7); c.fill(); }
  }} />
);

/* ---- half-timbered house (facade +z). windows glow when lit>0 ---- */
export const Timber: React.FC<{ p: V3; s: V3; wall?: string; beam?: string; roof?: string; lit?: number; seed?: number; rh?: number; yaw?: number; shutter?: string }> = ({ p, s, wall = "#f1dfb8", beam = "#4a2a18", roof = "#a8442c", lit = 0, seed = 1, rh, yaw = 0, shutter = "#2f6a4a" }) => {
  const [w, h, d] = s, R = rh ?? w * 0.42;
  return (<group position={p} rotation={[0, yaw, 0]}>
    <Box p={[0, h / 2, 0]} s={s} color={wall} />
    <CanvasPlane p={[0, h / 2, d / 2 + 0.02]} s={[w, h]} px={[Math.round(w * 40), Math.round(h * 40)]} draw={(c, W, H) => {
      c.clearRect(0, 0, W, H); c.strokeStyle = beam; c.lineWidth = 9; c.strokeRect(4, 4, W - 8, H - 8);
      const rows = Math.max(1, Math.round(h / 2.2)), cols = Math.max(2, Math.round(w / 1.8));
      for (let r = 1; r < rows; r++) { c.beginPath(); c.moveTo(0, (H * r) / rows); c.lineTo(W, (H * r) / rows); c.stroke(); }
      for (let k = 1; k < cols; k++) { c.beginPath(); c.moveTo((W * k) / cols, 0); c.lineTo((W * k) / cols, H); c.stroke(); }
      c.lineWidth = 6; for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) { const x0 = (W * k) / cols, x1 = (W * (k + 1)) / cols, y0 = (H * r) / rows, y1 = (H * (r + 1)) / rows; if ((r + k + seed) % 2) { c.beginPath(); c.moveTo(x0, y1); c.lineTo(x1, y0); c.stroke(); } }
      // windows
      for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) { if ((r * 3 + k * 5 + seed) % 3 === 0 && r > 0 || (r === 0 && false)) continue; const cx = (W * (k + 0.5)) / cols, cy = (H * (r + 0.5)) / rows, ww = W / cols * 0.42, hh = H / rows * 0.46; c.fillStyle = lit > 0 && (r + k + seed) % 2 === 0 ? "#ffd36a" : "#6f93b8"; c.fillRect(cx - ww / 2, cy - hh / 2, ww, hh); c.strokeStyle = INK; c.lineWidth = 5; c.strokeRect(cx - ww / 2, cy - hh / 2, ww, hh); c.beginPath(); c.moveTo(cx, cy - hh / 2); c.lineTo(cx, cy + hh / 2); c.moveTo(cx - ww / 2, cy); c.lineTo(cx + ww / 2, cy); c.stroke(); c.fillStyle = shutter; c.fillRect(cx - ww / 2 - ww * 0.32, cy - hh / 2, ww * 0.28, hh); c.fillRect(cx + ww / 2 + ww * 0.04, cy - hh / 2, ww * 0.28, hh); }
    }} />
    <Extrude p={[0, h, 0]} pts={[[-w / 2 - 0.3, 0], [w / 2 + 0.3, 0], [0, R]]} depth={d + 0.6} color={roof} line={4} />
    <Box p={[w * 0.28, h + R * 0.7, -d * 0.2]} s={[0.5, R * 0.9, 0.5]} color="#7a5a48" line={3} />
  </group>);
};

/* ---- red-sandstone minster tower with spire ---- */
export const Minster: React.FC<{ p: V3; s?: number; lit?: number }> = ({ p, s = 1, lit = 0 }) => (
  <group position={p} scale={s}>
    <Box p={[0, 6, 0]} s={[5, 12, 5]} color="#b9553e" />
    <CanvasPlane p={[0, 6, 2.52]} s={[5, 12]} px={[200, 480]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#7a2f20"; c.lineWidth = 3; for (let y = 20; y < H; y += 26) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); } for (const y of [70, 200, 330]) { c.fillStyle = lit > 0 ? "#ffd36a" : "#2a2d4a"; c.beginPath(); c.moveTo(W * 0.34, y + 60); c.lineTo(W * 0.34, y + 14); c.arc(W * 0.5, y + 14, W * 0.16, Math.PI, 0); c.lineTo(W * 0.66, y + 60); c.closePath(); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.stroke(); } c.fillStyle = "#e9c7a0"; c.beginPath(); c.arc(W / 2, 420, 38, 0, 7); c.fill(); c.stroke(); }} />
    <Cyl p={[0, 14, 0]} rt={1.6} rb={2.0} h={4} color="#c4624a" /><Cyl p={[0, 20.5, 0]} rt={0.0} rb={1.7} h={9} color="#a8442c" line={4} />
    <Box p={[0, 25.4, 0]} s={[0.12, 1.2, 0.12]} color="#f2c744" line={2} /><Box p={[0, 25.1, 0]} s={[0.6, 0.12, 0.12]} color="#f2c744" line={2} />
  </group>
);

export const Barrel: React.FC<{ p: V3; s?: number }> = ({ p, s = 1 }) => (<group position={p} scale={s}><Cyl p={[0, 0.5, 0]} rt={0.42} rb={0.36} h={1.0} color="#8a5a32" /><Cyl p={[0, 0.3, 0]} rt={0.43} rb={0.43} h={0.07} color="#2b2a35" line={2} /><Cyl p={[0, 0.75, 0]} rt={0.43} rb={0.43} h={0.07} color="#2b2a35" line={2} /></group>);
export const Crate: React.FC<{ p: V3; s?: number; rotY?: number }> = ({ p, s = 1, rotY = 0 }) => (<group position={p} rotation={[0, rotY, 0]} scale={s}><Box p={[0, 0.4, 0]} s={[0.8, 0.8, 0.8]} color="#b5823e" /><Box p={[0, 0.4, 0.41]} s={[0.8, 0.1, 0.02]} color="#7a5224" line={1} /></group>);
export const Well: React.FC<{ p: V3 }> = ({ p }) => (<group position={p}><Cyl p={[0, 0.5, 0]} rt={0.9} rb={0.95} h={1.0} color="#9a9aa8" /><Cyl p={[0, 1.02, 0]} rt={0.7} h={0.06} color="#1d4a6a" line={2} /><Box p={[-0.9, 1.7, 0]} s={[0.14, 1.6, 0.14]} color="#6a4426" line={2} /><Box p={[0.9, 1.7, 0]} s={[0.14, 1.6, 0.14]} color="#6a4426" line={2} /><Box p={[0, 2.55, 0]} s={[2.1, 0.14, 0.14]} color="#6a4426" line={2} /></group>);
export const Cart: React.FC<{ p: V3; rotY?: number; load?: string }> = ({ p, rotY = 0, load = "#d8b24a" }) => (<group position={p} rotation={[0, rotY, 0]}><Box p={[0, 0.9, 0]} s={[2.2, 0.2, 1.2]} color="#8a5a32" /><Box p={[0, 1.2, 0.6]} s={[2.2, 0.5, 0.1]} color="#7a4a26" line={2} /><Box p={[0, 1.2, -0.6]} s={[2.2, 0.5, 0.1]} color="#7a4a26" line={2} />{[-0.8, 0.8].map((x) => <Cyl key={x} p={[x, 0.5, 0.7]} rt={0.5} h={0.1} color="#5a3a22" rot={[Math.PI / 2, 0, 0]} />)}{[-0.8, 0.8].map((x) => <Cyl key={"b" + x} p={[x, 0.5, -0.7]} rt={0.5} h={0.1} color="#5a3a22" rot={[Math.PI / 2, 0, 0]} />)}<Ball p={[0, 1.35, 0]} r={0.55} color={load} s={[1.5, 0.6, 0.8]} /></group>);
export const Torch: React.FC<{ p: V3; t: number; on?: number }> = ({ p, t, on = 1 }) => (<group position={p}><Cyl p={[0, 0.7, 0]} rt={0.06} h={1.4} color="#5a3a22" line={2} /><Flame p={[0, 1.5, 0]} t={t} s={0.55 * on} /></group>);
export const Banner: React.FC<{ p: V3; s: [number, number]; text: string; bg?: string; fg?: string; rot?: V3; size?: number; sub?: string }> = ({ p, s, text, bg = "#9c1f2e", fg = "#f5e2b0", rot, size = 90, sub }) => (
  <group position={p} rotation={rot}><Box p={[0, s[1] / 2 + 0.06, 0]} s={[s[0] + 0.3, 0.1, 0.1]} color="#4a2a18" line={2} />
    <CanvasPlane p={[0, 0, 0.02]} s={s} px={[Math.round(s[0] * 120), Math.round(s[1] * 120)]} draw={(c, W, H) => { c.fillStyle = bg; c.beginPath(); c.moveTo(0, 0); c.lineTo(W, 0); c.lineTo(W, H); c.lineTo(W / 2, H * 0.88); c.lineTo(0, H); c.closePath(); c.fill(); c.strokeStyle = INK; c.lineWidth = 8; c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, sub ? H * 0.38 : H * 0.44); if (sub) { c.font = `900 ${size * 0.6}px Inter, Arial`; c.fillText(sub, W / 2, H * 0.62); } }} /></group>
);

/* ---- fire (additive cones + glow, flickers) ---- */
export const Flame: React.FC<{ p: V3; t: number; s?: number; hot?: string }> = ({ p, t, s = 1, hot = "#ffb21e" }) => {
  if (s <= 0.01) return null;
  const fl = 1 + 0.14 * Math.sin(t * 23) + 0.08 * Math.sin(t * 41);
  return (<group position={p} scale={s}>
    {[[0, 1.0, 0.5, "#ff5a14"], [0.12, 0.8, 0.34, hot], [-0.1, 0.6, 0.22, "#fff0a0"]].map(([dx, h, r, col], i) => (
      <mesh key={i} position={[dx as number + Math.sin(t * 9 + i) * 0.03, (h as number) * fl * 0.5, 0]} scale={[1, fl, 1]}><coneGeometry args={[r as number, (h as number) * 1.4, 10]} /><meshBasicMaterial color={col as string} transparent opacity={0.9} /></mesh>))}
    <Glow p={[0, 0.6, 0.3]} r={1.6} color="rgba(255,150,40,1)" o={0.55 * fl} />
  </group>);
};

/* ---- music note sprite (additive-free, readable) ---- */
export const Note: React.FC<{ p: V3; s?: number; color?: string; o?: number }> = ({ p, s = 0.6, color = "#ffe08a", o = 1 }) => (
  <CanvasPlane p={p} s={[s, s]} px={[96, 96]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.globalAlpha = o; c.fillStyle = color; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.ellipse(34, 70, 20, 14, -0.4, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.moveTo(50, 64); c.lineTo(50, 16); c.lineTo(76, 30); c.lineTo(76, 44); c.lineTo(50, 32); c.stroke(); c.lineWidth = 9; c.strokeStyle = INK; c.beginPath(); c.moveTo(51, 64); c.lineTo(51, 18); c.stroke(); }} />
);

/* ---- cheap distant crowd: instanced bodies+heads with ink backface, bobbing like dancers ---- */
const PAL = ["#d63b3b", "#e8a63a", "#3b7fd6", "#5aa05a", "#8a4fb8", "#c8754a", "#e6e0cf", "#4a6a8a"];
export const CrowdField: React.FC<{ n: number; t: number; at: (i: number) => V3; size?: number; rate?: number; mood?: number }> = ({ n, t, at, size = 1, rate = 5.5, mood = 0 }) => {
  const bodies = useRef<THREE.InstancedMesh>(null), heads = useRef<THREE.InstancedMesh>(null), inkB = useRef<THREE.InstancedMesh>(null), inkH = useRef<THREE.InstancedMesh>(null);
  const colors = useMemo(() => Array.from({ length: n }, (_, i) => new THREE.Color(PAL[(i * 5 + 3) % PAL.length])), [n]);
  useLayoutEffect(() => {
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), sc = new THREE.Vector3(), ps = new THREE.Vector3();
    for (let i = 0; i < n; i++) {
      const P = at(i), ph = i * 1.7, hop = Math.abs(Math.sin(t * rate + ph)) * 0.35 * size, sw = Math.sin(t * rate * 0.5 + ph) * 0.18;
      const put = (mesh: THREE.InstancedMesh | null, y: number, k: number) => { if (!mesh) return; ps.set(P[0], P[1] + hop + y * size, P[2]); e.set(0, 0, sw); q.setFromEuler(e); sc.set(size * k, size * k, size * k); m.compose(ps, q, sc); mesh.setMatrixAt(i, m); };
      put(bodies.current, 0.65, 1); put(heads.current, 1.55, 1); put(inkB.current, 0.65, 1.14); put(inkH.current, 1.55, 1.2);
      bodies.current?.setColorAt(i, colors[i]); heads.current?.setColorAt(i, new THREE.Color(mood > 0.5 ? "#f0c9a8" : "#f6d8bd"));
    }
    for (const r of [bodies, heads, inkB, inkH]) if (r.current) { r.current.instanceMatrix.needsUpdate = true; if (r.current.instanceColor) r.current.instanceColor.needsUpdate = true; }
  });
  return (<>
    <instancedMesh ref={bodies} args={[undefined, undefined, n]}><cylinderGeometry args={[0.34, 0.42, 1.3, 8]} /><meshBasicMaterial /></instancedMesh>
    <instancedMesh ref={heads} args={[undefined, undefined, n]}><sphereGeometry args={[0.36, 10, 8]} /><meshBasicMaterial /></instancedMesh>
    <instancedMesh ref={inkB} args={[undefined, undefined, n]}><cylinderGeometry args={[0.34, 0.42, 1.3, 8]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></instancedMesh>
    <instancedMesh ref={inkH} args={[undefined, undefined, n]}><sphereGeometry args={[0.36, 10, 8]} /><meshBasicMaterial color={INK} side={THREE.BackSide} /></instancedMesh>
  </>);
};

/* ---- dancing pose generator: grim, stiff, no joy (k = intensity 0..1) ---- */
export const danceBeat = (t: number, i = 0, k = 1, rate = 5.2) => {
  const b = t * rate + i * 1.3, hop = Math.abs(Math.sin(b)) * 0.38 * k, s = Math.sin(b), c = Math.cos(b);
  const hopPhase = Math.abs(Math.sin(b)); // 0 at contact
  return {
    y: hop,
    pose: {
      squash: -0.1 * k * (1 - hopPhase) * (1 - hopPhase) + 0.06 * k * hopPhase, air: hop > 0.12 * k ? 1 : 0, tilt: 0.13 * s * k,
      armR: [0.3 + 0.04 * c, 0.68 + 0.2 * Math.sin(b + 1)] as [number, number], armL: [-0.3 - 0.04 * c, 0.68 + 0.2 * Math.sin(b + 1 + Math.PI)] as [number, number],
      armRK: k, armLK: k, lookX: 0.4 * Math.sin(b * 0.5),
    },
  };
};
