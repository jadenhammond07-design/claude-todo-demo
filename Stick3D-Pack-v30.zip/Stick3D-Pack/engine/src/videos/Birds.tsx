// WHAT IF BIRDS STOPPED FLYING FOR A DAY — 10 scenes.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Dust } from "../style/props";
import { Cam, Globe, Stars } from "../style/extra";
import { Sky } from "../style/medieval";
import { Tree, Bush, Water } from "../style/nature";
import { Bird, Flower, Fish, Mouse } from "../style/birds";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Meadow: React.FC<{ top?: string; bottom?: string; grass?: string }> = ({ top = "#6ab0f0", bottom = "#d8f0ff", grass = "#6ab84a" }) => (<>
  <Sky p={[0, 26, -40]} s={[200, 90]} top={top} bottom={bottom} />
  <Surface p={[0, 0, 0]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={grass} b={grass} />
  <Ball p={[-9, -7, -16]} r={11} color="#5aa84a" ink={0.02} /><Ball p={[9, -8, -18]} r={12} color="#4e9a40" ink={0.02} />
</>);
const Cloud: React.FC<{ p: V3; s?: number }> = ({ p, s = 1 }) => <group position={p} scale={[s, s, s]}>{[[-0.8, 0, 0.5], [0, 0.3, 0.7], [0.8, 0, 0.5], [0.3, -0.2, 0.55]].map(([x, y, r], i) => <Ball key={i} p={[x, y, 0]} r={r} color="#ffffff" ink={0.03} />)}</group>;

/* ============ S1 0 – 3.94  hook: every bird drops out of the sky ============ */
export const S1 = ({ t, f }: Ctx) => {
  const drop = (i: number) => seg(t, 1.82 + (i % 6) * 0.08, 2.6 + (i % 6) * 0.08, Easing.in(Easing.quad));
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 4.4, 15], look: [0, 5.4, 0], fov: 58 }, { t: 4.1, pos: [0, 3.8, 13.5], look: [0, 4.6, 0], fov: 56 }])} />
    <Lights warm="#fff4e0" />
    <Meadow />
    <Cloud p={[-3.5, 9, -8]} s={1.4} /><Cloud p={[3.8, 10.5, -10]} s={1.6} />
    {Array.from({ length: 18 }, (_, i) => { const d = drop(i), x0 = -5 + (i % 6) * 2 + ((t * 1.4) % 2) * (1 - d), y0 = 5.5 + Math.floor(i / 6) * 1.5 + Math.sin(i * 3) * 0.4; return <Bird key={i} p={[x0, lerp(y0, 0.3, d), -2 - (i % 3)]} kind={(["sparrow", "swift", "gull"] as const)[i % 3]} t={t + i} flap={1 - d} s={0.9} />; })}
    <Person p={[0, 0, 2.6]} h={3.2} look={you} f={f} pose={{ mood: t > 2.4 ? "worry" : "smile", lookX: 0.1, armR: [0.3, 0.78], armRK: seg(t, 2.6, 3.0) }} />
  </>);
};

/* ============ S2 3.94 – 10.42  swifts: 10 months on the wing ============ */
export const S2 = ({ t, f }: Ctx) => {
  const mo = seg(t, 7.06, 7.4, back), icons: [string, number, string][] = [["EAT", 7.92, "#ff7a29"], ["SLEEP", 8.32, "#6a3ad8"], ["MATE", 9.36, "#ff5a8a"]];
  return (<>
    <Cam t={t} keys={[{ t: 3.8, pos: [0, 5.2, 12], look: [0, 5.2, 0], fov: 58 }, { t: 10.6, pos: [0.6, 5.6, 11], look: [0.6, 5.4, 0], fov: 56 }]} />
    <Lights warm="#fff4e0" />
    <Sky p={[0, 10, -30]} s={[120, 80]} top="#3a8ae0" bottom="#bfe4ff" />
    {Array.from({ length: 6 }, (_, i) => <Cloud key={i} p={[((i * 4.2 - t * 3) % 24 + 24) % 24 - 12, 2 + (i % 3) * 3, -6 - (i % 2) * 3]} s={1.2 + (i % 2) * 0.4} />)}
    <Bird p={[0, 5.6 + Math.sin(t * 1.5) * 0.4, 1.2]} kind="swift" t={t} s={2.2} rate={12} />
    <Sign p={[0, 8.6, 0.6]} w={3.8} h={0.95} text="10 MONTHS" k={mo} size={60} bg="#14141c" fg="#ffe14a" />
    {icons.map(([txt, at, col], i) => <Sign key={i} p={[-2.2 + i * 2.2, 3.0, 1.6]} w={1.8} h={0.75} text={txt} k={seg(t, at, at + 0.3, back)} size={36} bg={col} fg="#fff" />)}
    <Sign p={[0, 7.4, 0.8]} w={3.6} h={0.75} text="NEVER LANDS" k={seg(t, 6.25, 6.55, back) * (1 - mo)} size={40} bg="#fff" fg="#14141c" />
  </>);
};

/* ============ S3 10.42 – 14.76  forced down; can't take off ============ */
export const S3 = ({ t, f }: Ctx) => {
  const fall = seg(t, 10.75, 11.3, Easing.in(Easing.quad)), bad = seg(t, 12.99, 13.3, back), hop = Math.abs(Math.sin(t * 6)) * 0.25 * seg(t, 12.0, 12.4);
  return (<>
    <Cam t={t} keys={low([{ t: 10.3, pos: [0, 3.2, 10], look: [0, 3.0, 0], fov: 56 }, { t: 14.9, pos: [0.3, 2.6, 8.5], look: [0.3, 2.6, 0], fov: 52 }])} />
    <Lights warm="#fff0d8" />
    <Meadow grass="#8a7a5a" />
    <Surface p={[0, 0.01, 0]} s={[60, 30]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#b8b0a0" b="#a8a090" unit={1.4} />
    <Bird p={[0, lerp(6, 0.35, fall) + hop, 1.2]} kind="swift" t={t} flap={1 - fall * 0.4} s={1.8} rate={fall > 0.9 ? 22 : 12} />
    {fall > 0.9 ? Array.from({ length: 4 }, (_, i) => <Ball key={i} p={[Math.sin(t * 5 + i) * 1.2, 0.3 + ((t * 2 + i / 4) % 1) * 0.6, 1.4]} r={0.12} color="#d8d0c0" ink={0.02} />) : null}
    <Sign p={[0, 5.0, 1.2]} w={3.8} h={0.9} text="CAN'T TAKE OFF" k={bad} size={44} bg="#e5233a" fg="#fff" />
    <Sign p={[0, 6.6, 0.8]} w={3.6} h={0.9} text="FORCED DOWN" k={seg(t, 10.75, 11.05, back) * (1 - bad)} size={44} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S4 14.76 – 18.14  hummingbirds can't reach flowers ============ */
export const S4 = ({ t, f }: Ctx) => {
  const fuel = 1 - seg(t, 15.72, 18.0), cant = seg(t, 16.64, 16.95, back);
  return (<>
    <Cam t={t} keys={low([{ t: 14.6, pos: [0, 3.4, 9.5], look: [0, 3.6, 0], fov: 56 }, { t: 18.3, pos: [0, 3.2, 8.5], look: [0, 3.4, 0], fov: 54 }])} />
    <Lights warm="#fff0d8" />
    <Meadow />
    <Flower p={[1.4, 0, 0]} h={4.0} color="#ff3a7a" s={1.3} /><Flower p={[2.6, 0, -1]} h={3.4} color="#ff9a3a" s={1.2} />
    <Bird p={[-1.2, 0.3 + Math.abs(Math.sin(t * 12)) * 0.15, 1.0]} kind="humming" t={t} flap={0.15} s={2.2} rate={40} />
    {/* fuel gauge */}
    <CanvasPlane p={[-0.4, 4.4, 1.0]} s={[2.4, 0.7]} px={[240, 70]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(3, 3, W - 6, H - 6, 12); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 22px Inter, Arial"; c.textAlign = "left"; c.textBaseline = "middle"; c.fillText("FUEL", 12, H / 2); c.fillStyle = "#333"; c.fillRect(80, 18, 145, 34); c.fillStyle = fuel > 0.5 ? "#2fd46a" : fuel > 0.25 ? "#ffd23a" : "#e5233a"; c.fillRect(80, 18, 145 * fuel, 34); }} />
    <Sign p={[0, 6.8, 0.6]} w={3.8} h={0.85} text="CAN'T REACH" k={cant} size={46} bg="#ff3a7a" fg="#fff" />
  </>);
};

/* ============ S5 18.14 – 19.66  hawks and owls can't hunt ============ */
export const S5 = ({ t, f }: Ctx) => {
  const mx = lerp(-4, 4.5, seg(t, 18.4, 19.6)), hunt = seg(t, 19.21, 19.45, back);
  return (<>
    <Cam t={t} keys={low([{ t: 18.0, pos: [0, 3.2, 10], look: [0, 3.0, 0], fov: 56 }, { t: 19.8, pos: [0, 3.0, 9.4], look: [0, 3.0, 0], fov: 55 }])} />
    <Lights warm="#ffe8c8" />
    <Meadow grass="#7aa84a" top="#e89a6a" bottom="#ffe0b0" />
    <Bird p={[-1.6, 0.55, 0]} kind="hawk" t={t} flap={0} s={1.6} />
    <Bird p={[1.8, 0.55, 0]} kind="owl" t={t} flap={0} s={1.6} flip />
    <Mouse p={[mx, 0, 1.8]} t={t} />
    <Sign p={[0, 5.0, 0.6]} w={3.4} h={0.85} text="CAN'T HUNT" k={hunt} size={48} bg="#14141c" fg="#ff5a6a" />
  </>);
};

/* ============ S6 19.66 – 25.07  migrants stranded; seabirds can't reach fish ============ */
export const S6 = ({ t, f }: Ctx) => {
  const path = seg(t, 19.7, 21.2, ease), str = seg(t, 21.27, 21.6, back), sea = seg(t, 22.4, 23.0, ease), fishK = seg(t, 23.9, 24.2, back);
  return (<>
    <Cam t={t} keys={[{ t: 19.5, pos: [0, 5.0, 13], look: [0, 4.0, 0], fov: 58 }, { t: 22.3, pos: [0, 5.0, 13], look: [0, 4.0, 0], fov: 58 }, { t: 25.2, pos: [0, 3.0, 11], look: [0, 2.2, 0], fov: 56 }]} />
    <Lights warm="#f0f4ff" />
    {sea < 0.5 ? <>
      {/* migration map */}
      <CanvasPlane p={[0, 4.6, -1]} s={[7.2, 6.4]} px={[540, 480]} draw={(c, W, H) => { c.fillStyle = "#2f7de0"; c.fillRect(0, 0, W, H); c.fillStyle = "#3fbf5a"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.ellipse(170, 130, 140, 100, 0.3, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.ellipse(360, 360, 120, 110, -0.2, 0, 7); c.fill(); c.stroke();
        c.strokeStyle = "#ffe14a"; c.lineWidth = 8; c.setLineDash([22, 16]); c.beginPath(); c.moveTo(150, 120); c.quadraticCurveTo(320, 160, 380, 340); c.stroke(); c.setLineDash([]);
        const u = 0.45 * path, x = (1 - u) * (1 - u) * 150 + 2 * u * (1 - u) * 320 + u * u * 380, y = (1 - u) * (1 - u) * 120 + 2 * u * (1 - u) * 160 + u * u * 340; c.fillStyle = "#e5233a"; c.beginPath(); c.arc(x, y, 18, 0, 7); c.fill(); c.stroke();
        c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.fillText("✕", x - 10, y - 26); }} />
      <Sign p={[0, 8.6, 0]} w={3.4} h={0.85} text="BILLIONS" k={seg(t, 19.66, 19.95, back) * (1 - str)} size={50} bg="#14141c" fg="#ffe14a" />
      <Sign p={[0, 8.6, 0.2]} w={3.4} h={0.85} text="STRANDED" k={str} size={50} bg="#e5233a" fg="#fff" />
    </> : <>
      {/* sea cliff */}
      <Sky p={[0, 26, -40]} s={[200, 90]} top="#7ab8e8" bottom="#e0f0ff" />
      <Box p={[-2.6, 1.4, -1]} s={[3.4, 2.8, 6]} color="#8a7a6a" line={4} />
      <Water p={[2, -3, 0]} w={30} d={20} level={3} color="#1f6ad8" o={0.85} />
      {[0, 1, 2].map((i) => <Bird key={i} p={[-3.4 + i * 0.9, 3.2, 0.6 - i * 0.6]} kind="gull" t={t + i} flap={0} s={1.2} />)}
      {Array.from({ length: 5 }, (_, i) => <Fish key={i} p={[1.0 + i * 0.8, -0.6 - (i % 2) * 0.5, 1.6]} t={t} s={1.1} flip={i % 2 === 1} />)}
      <Sign p={[1.0, 2.4, 1.4]} w={2.0} h={0.7} text="FISH" k={fishK} size={44} bg="#ffa23a" fg="#14141c" />
      <Sign p={[0, 5.6, 0.6]} w={3.4} h={0.85} text="OUT OF REACH" k={seg(t, 23.5, 23.8, back)} size={40} bg="#14141c" fg="#ffe14a" />
    </>}
  </>);
};

/* ============ S7 25.07 – 28.75  seeds stop, flowers wait ============ */
export const S7 = ({ t, f }: Ctx) => {
  const wait = seg(t, 26.94, 27.3), none = seg(t, 28.25, 28.5, back);
  return (<>
    <Cam t={t} keys={low([{ t: 24.9, pos: [0, 3.4, 11.5], look: [0, 3.4, 0], fov: 56 }, { t: 28.9, pos: [0, 3.0, 10], look: [0, 3.0, 0], fov: 54 }])} />
    <Lights warm="#fff0d8" />
    <Meadow />
    <Tree p={[-2.6, 0, -2.5]} h={5.5} color="#3fae4a" />
    {Array.from({ length: 6 }, (_, i) => <Ball key={i} p={[-2.6 + Math.cos(i) * 0.9, 3.4 + Math.sin(i * 2) * 0.5, -1.4]} r={0.13} color="#c04a2e" ink={0.02} />)}
    <Sign p={[-1.0, 6.6, -0.6]} w={3.4} h={0.8} text="SEEDS: STUCK" k={seg(t, 25.43, 25.7, back)} size={40} bg="#14141c" fg="#ffe14a" />
    {Array.from({ length: 6 }, (_, i) => <Flower key={i} p={[0.2 + (i % 3) * 1.3, 0, 0.4 + Math.floor(i / 3) * 1.2]} h={1.6} color={["#ff5a8a", "#ffd23a", "#9a5ad8"][i % 3]} droop={wait * (0.3 + (i % 2) * 0.3)} s={1.1} />)}
    <Sign p={[1.6, 4.4, 1.2]} w={3.6} h={0.8} text="NO VISITORS" k={none} size={42} bg="#fff" fg="#e5233a" />
  </>);
};

/* ============ S8 28.75 – 32.28  midnight: wings return ============ */
export const S8 = ({ t, f }: Ctx) => {
  const mid = seg(t, 29.02, 29.3, back), up = seg(t, 29.93, 31.0, Easing.out(Easing.quad)), day = seg(t, 30.6, 31.8, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 28.6, pos: [0, 3.8, 13], look: [0, 4.6, 0], fov: 58 }, { t: 32.4, pos: [0, 4.0, 13], look: [0, 5.4, 0], fov: 58 }])} />
    <Lights warm={day > 0.5 ? "#fff4e0" : "#8a9ad8"} />
    {day < 0.5 ? <Stars p={[0, 12, -30]} s={[110, 70]} t={t} top="#05061a" bottom="#1a2050" n={160} /> : <Sky p={[0, 26, -40]} s={[200, 90]} top="#ffb070" bottom="#ffe8c0" glowAt={[0.9, "rgba(255,220,140,1)"]} />}
    <Surface p={[0, 0, 0]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={day > 0.5 ? "#6ab84a" : "#1a3a2a"} b={day > 0.5 ? "#6ab84a" : "#1a3a2a"} />
    <Sign p={[0, 8.6, -2]} w={3.2} h={1.1} text="12:00 AM" k={mid * (1 - day)} size={64} bg="#14141c" fg="#ff5a6a" />
    {Array.from({ length: 14 }, (_, i) => { const x = -4.5 + (i % 7) * 1.5, z = -1 - Math.floor(i / 7) * 1.4, u = seg(t, 29.93 + (i % 5) * 0.1, 31.0 + (i % 5) * 0.1, Easing.out(Easing.quad)); return <Bird key={i} p={[x + u * 2, lerp(0.35, 5 + (i % 4) * 1.1, u), z]} kind={(["sparrow", "gull", "swift", "hawk"] as const)[i % 4]} t={t + i} flap={u > 0.02 ? 1 : 0} s={0.9} />; })}
    <Sign p={[0, 2.2, 1.6]} w={3.4} h={0.85} text="WINGS RETURN" k={seg(t, 29.93, 30.2, back) * (1 - seg(t, 31.4, 31.7))} size={42} bg="#2fd46a" fg="#14141c" />
  </>);
};

/* ============ S9 32.28 – 37.78  the planet depends on it; "background" ============ */
export const S9 = ({ t, f }: Ctx) => {
  const web = seg(t, 34.42, 35.6, ease), bg = seg(t, 36.99, 37.4, back);
  const nodes: [V3, string][] = [[[-2.6, 7.2, 0], "FLOWERS"], [[2.6, 7.2, 0], "SEEDS"], [[-2.6, 2.0, 0], "FISH"], [[2.6, 2.0, 0], "BUGS"]];
  return (<>
    <Cam t={t} keys={[{ t: 32.1, pos: [0, 4.6, 14], look: [0, 4.6, 0], fov: 58 }, { t: 37.9, pos: [0, 4.6, 13], look: [0, 4.6, 0], fov: 58 }]} />
    <Lights warm="#e8f0ff" />
    <Stars p={[0, 10, -30]} s={[110, 70]} t={t} top="#0a1a3a" bottom="#1a3a6a" n={90} />
    <Globe p={[0, 4.6, -1]} r={1.8} rotY={t * 0.4} />
    {Array.from({ length: 6 }, (_, i) => { const a = t * 0.8 + i * (Math.PI / 3); return <Bird key={i} p={[Math.cos(a) * 2.7, 4.6 + Math.sin(a) * 2.2, Math.sin(a) * 0.6]} kind={(["sparrow", "gull", "swift"] as const)[i % 3]} t={t + i} s={0.7} flip={Math.sin(a) < 0} />; })}
    {nodes.map(([p, emo], i) => <React.Fragment key={i}>
      <Box p={[p[0] / 2, (p[1] + 4.6) / 2, 0.2]} s={[Math.hypot(p[0], p[1] - 4.6) * web + 0.01, 0.06, 0.06]} rot={[0, 0, Math.atan2(p[1] - 4.6, p[0])]} color="#ffe14a" line={0} />
      <Sign p={p} w={2.4} h={0.75} text={emo} k={seg(t, 34.42 + i * 0.15, 34.8 + i * 0.15, back)} size={38} bg="#ffffff" fg="#14141c" />
    </React.Fragment>)}
    <Sign p={[0, 9.2, 0]} w={3.8} h={0.85} text="WE BARELY NOTICE" k={seg(t, 35.43, 35.7, back) * (1 - bg)} size={38} bg="#14141c" fg="#ffe14a" />
    <Sign p={[0, 9.2, 0.2]} w={3.6} h={0.85} text="background" k={bg} size={46} bg="#6a6a7a" fg="#c8c8d0" />
  </>);
};

/* ============ S10 37.78 – end  "what else is keeping the world running above your head?" ============ */
export const S10 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={low([{ t: 37.6, pos: [0, 3.0, 12], look: [0, 4.6, 0], fov: 58 }, { t: 42.2, pos: [0, 2.8, 10.5], look: [0, 5.0, -1], fov: 56 }])} />
  <Lights warm="#fff4e0" />
  <Meadow top="#5aa0e8" bottom="#e0f4ff" />
  <Cloud p={[-3.5, 9, -8]} s={1.4} /><Cloud p={[3.8, 10, -10]} s={1.6} />
  {Array.from({ length: 10 }, (_, i) => <Bird key={i} p={[((i * 2.3 + t * 1.6) % 14) - 7, 6 + (i % 3) * 1.4, -3 - (i % 2) * 2]} kind={(["sparrow", "swift", "gull"] as const)[i % 3]} t={t + i} s={0.8} />)}
  <Person p={[0, 0, 1.8]} h={3.4} look={you} f={f} pose={{ mood: "smile", lookX: 0, armR: [0.3, 0.8], armRK: seg(t, 41.18, 41.6) }} />
  <Dust t={t} area={[8, 6, 5]} color="rgba(255,255,240,.8)" />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
