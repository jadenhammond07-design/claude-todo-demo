import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Meet";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const MCUTS = [0, 2.5, 6.0, 8.4, 12.7, 17.6, 23.7, 31.8, 35.6, 37.9, 41.8];
const BG = ["#24204a", "#b8804a", "#b8804a", "#5a6a88", "#2a3a5a", "#6a4a8a", "#12203a", "#2a3a6a", "#ffb070", "#b8804a"];
const TR: Trans[] = ["ghost", "zoom", "ghost", "flash", "whip", "ghost", "zoom", "ghost", "flash", "ghost"];
export const MeetMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={MCUTS[i]} end={MCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"WOULD YOU RECOGNIZE YOUR PAST SELF?"} until={2.6} />
    <EndQuestion text={"What would you say to the you from 10 years ago?"} from={39.2} end={41.74} />
  </AbsoluteFill>
);
