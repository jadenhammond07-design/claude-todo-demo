// DÉJÀ VU — 10 scenes. Ghost double, familiar room, VR layout experiment (Cleary), brain pattern vs source, temporal lobe.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Dust, Plant, Frame, Lamp, Chair, Rug, Shelf } from "../style/props";
import { Cam } from "../style/extra";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const ghost = mk("#e8e0ff", "#b8a8ff", "hoodie", "short", "#8a7ac8", { glasses: true, shoe: "#9a8ad8" });
const sci = mk("#f3d3b2", "#f4f4f4", "shirt", "bob", "#7a4a20", { glasses: true, badge: "#2f8cff" });
const vol = mk("#8d5a3a", "#2fd4a0", "hoodie", "short", "#111");
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
/** cosy room; variant changes colors but keeps the SAME layout */
const Room: React.FC<{ v?: number; dim?: number }> = ({ v = 0, dim = 0 }) => {
  const wall = v ? "#5a7ab8" : "#c8865a", wall2 = v ? "#4e6ea8" : "#b87a50", rug = v ? ["#2fd4a0", "#1fa880"] : ["#c0402e", "#a8341f"];
  return (<>
    <Floor kind="plank" a={v ? "#8a8aa0" : "#7a5a3a"} b={v ? "#7a7a90" : "#6a4c30"} unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a={wall} b={wall} base={v ? "#2a3a5a" : "#5a2e18"} /><SideWall x={-7} kind="plain" a={wall2} b={wall2} /><SideWall x={7} kind="plain" a={wall2} b={wall2} />
    <Lamp p={[-3.6, 0, -3.4]} h={3.0} color={v ? "#bfe8ff" : "#ffe9a8"} /><Plant p={[3.8, 0, -3.4]} s={1.4} pot={v ? "#2f8cff" : "#c0643a"} />
    <Frame p={[0, 4.8, -4.9]} s={[2.2, 1.5]} art={v ? 3 : 1} /><Chair p={[1.8, 0, -2.2]} rotY={-0.4} color={v ? "#e5233a" : "#3b4a8a"} />
    <Rug p={[0, 0.02, 0.4]} s={[4.4, 2.8]} a={rug[0]} b={rug[1]} />
    {dim > 0 ? <mesh position={[0, 4, -1]}><planeGeometry args={[40, 20]} /><meshBasicMaterial color="#ffffff" transparent opacity={0.6 * dim} depthWrite={false} /></mesh> : null}
  </>);
};
const Brain: React.FC<{ p: V3; s?: number; t: number; lobe?: number; tint?: string }> = ({ p, s = 1, t, lobe = 0, tint = "#ff9ab8" }) => (
  <group position={p} scale={[s, s, s]}>
    {Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * Math.PI * 2; return <Ball key={i} p={[Math.cos(a) * 1.1, Math.sin(a) * 0.75 + 0.1, ((i * 37) % 5) * 0.06]} r={0.55} color={tint} ink={0.04} />; })}
    <Ball p={[0, 0.1, 0.1]} r={1.0} s={[1.3, 0.9, 0.7]} color={tint} ink={0.04} />
    <Cyl p={[0.2, -1.05, -0.1]} rt={0.22} h={0.8} color="#e88aa8" line={2} />
    {lobe > 0 ? <><Ball p={[0.4, -0.45, 0.45]} r={0.55} s={[1.5, 0.7, 0.6]} color="#ffd23a" ink={0.04} /><Glow p={[0.4, -0.45, 0.9]} r={1.4 + 0.3 * Math.sin(t * 6)} color="rgba(255,220,80,1)" o={0.7 * lobe} /></> : null}
  </group>
);

/* ============ S1 0 – 3.78  hook: you and another version of you ============ */
export const S1 = ({ t, f }: Ctx) => {
  const split = seg(t, 1.6, 2.6, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 3.6, 12], look: [0, 3.4, 0], fov: 56 }, { t: 3.9, pos: [0, 3.4, 10.5], look: [0, 3.2, 0], fov: 54 }])} />
    <Lights warm="#e8e0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#2a2050" b="#221a44" unit={2} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#1a1438" line={3} />
    {Array.from({ length: 16 }, (_, i) => <Ball key={i} p={[Math.sin(i * 2.3) * 5, 2 + ((t * 0.4 + i * 0.37) % 1) * 7, -3 + Math.cos(i) * 2]} r={0.06} color="#d8c8ff" ink={0} />)}
    <Glow p={[lerp(0, 1.5, split), 2.0, 0.6]} r={3.2} color="rgba(180,160,255,1)" o={0.6 * split} />
    <Person p={[lerp(0, 1.5, split), 0, 0.8]} h={3.5} look={ghost} f={f + 7} pose={{ mood: "smile", flip: true, lookX: -0.5 }} />
    <Person p={[lerp(0, -1.5, split), 0, 1.2]} h={3.5} look={you} f={f} pose={{ mood: split > 0.6 ? "worry" : "deadpan", lookX: 0.5 }} />
  </>);
};

/* ============ S2 3.78 – 7.59  a room you've never entered feels familiar ============ */
export const S2 = ({ t, f }: Ctx) => {
  const walk = seg(t, 3.9, 5.2, ease), fam = seg(t, 6.96, 7.25, back);
  const spark = (i: number) => seg(t, 5.85 + i * 0.2, 6.2 + i * 0.2);
  return (<>
    <Cam t={t} keys={low([{ t: 3.6, pos: [0, 4.2, 13], look: [0, 3.6, -1], fov: 58 }, { t: 7.7, pos: [0, 4.0, 12], look: [0, 3.6, -1], fov: 56 }])} />
    <Lights warm="#fff0d8" />
    <Room />
    {[[-3.6, 3.2, -3.2], [3.8, 2.0, -3.2], [0, 4.8, -4.6], [1.8, 1.6, -2.0]].map((p, i) => spark(i) > 0 ? <React.Fragment key={i}><Glow p={p as V3} r={1.2} color="rgba(190,170,255,1)" o={0.8 * spark(i)} /><Ball p={p as V3} r={0.12} color="#ffffff" ink={0} /></React.Fragment> : null)}
    <Person p={[lerp(-5, -0.6, walk), 0, 1.4]} h={3.4} look={you} f={f} pose={{ mood: t > 6.5 ? "worry" : "smile", walk: walk < 1 ? t * 3 : undefined, speed: walk < 1 ? 0.5 : 0, lookX: 0.2 }} />
    <Sign p={[0, 7.0, 0.4]} w={3.4} h={0.85} text="FAMILIAR…" k={fam} size={48} bg="#b8a8ff" fg="#14141c" />
  </>);
};

/* ============ S3 7.59 – 9.33  you even feel what comes next ============ */
export const S3 = ({ t, f }: Ctx) => {
  const prev = seg(t, 7.72, 8.2), fall = seg(t, 8.48, 9.0, Easing.in(Easing.quad));
  return (<>
    <Cam t={t} keys={low([{ t: 7.4, pos: [0, 4.0, 10.5], look: [0, 3.4, -1], fov: 54 }, { t: 9.5, pos: [0.4, 3.8, 9.5], look: [0.4, 3.4, -1], fov: 52 }])} />
    <Lights warm="#fff0d8" />
    <Room />
    <Box p={[1.6, 0.9, -0.6]} s={[1.6, 1.8, 1.0]} color="#6a4426" line={3} />
    {/* ghost preview of the falling cup, then the real one */}
    {prev > 0 && fall < 0.05 ? <group position={[2.4, 1.2, -0.4]}><Cyl p={[0, 0, 0]} rt={0.22} h={0.4} color="#d8c8ff" line={1} /></group> : null}
    <group position={[lerp(1.9, 2.5, fall), lerp(2.0, 0.22, fall), -0.4]} rotation={[0, 0, -fall * 1.4]}><Cyl p={[0, 0, 0]} rt={0.22} h={0.4} color="#2f8cff" line={2} /></group>
    <Person p={[-0.8, 0, 1.2]} h={3.4} look={you} f={f} pose={{ mood: "worry", arms: "point", armK: prev, lookX: 0.6 }} />
    <Sign p={[0, 5.4, 0.6]} w={3.8} h={0.85} text="YOU KNOW IT…" k={prev} size={44} bg="#14141c" fg="#b8a8ff" />
  </>);
};

/* ============ S4 9.33 – 12.46  most people, teens and twenties ============ */
export const S4 = ({ t, f }: Ctx) => {
  const most = seg(t, 9.33, 9.6, back), bars = seg(t, 10.48, 11.6, ease);
  const h = [0.35, 0.9, 1.0, 0.75, 0.5, 0.35, 0.25];
  return (<>
    <Cam t={t} keys={[{ t: 9.2, pos: [0, 4.2, 12], look: [0, 4.0, 0], fov: 56 }, { t: 12.6, pos: [0, 4.2, 11], look: [0, 4.0, 0], fov: 54 }]} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8dcef" b="#c8cce0" unit={1.6} />
    <Box p={[0, 6, -4]} s={[30, 12, 0.3]} color="#3a2a6a" line={3} />
    <CanvasPlane p={[0, 4.8, -3.7]} s={[6.0, 4.2]} px={[600, 420]} draw={(c, W, H) => { c.fillStyle = "#fff"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6); c.fillStyle = "#14141c"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.fillText("DÉJÀ VU BY AGE", W / 2, 44);
      const labels = ["10", "15", "20", "25", "30", "40", "50+"]; h.forEach((v, i) => { const x = 50 + i * 76, bh = 280 * v * bars; c.fillStyle = i >= 1 && i <= 3 ? "#9a5ad8" : "#c8c0e0"; c.fillRect(x, 380 - bh, 56, bh); c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(x, 380 - bh, 56, bh); c.fillStyle = "#14141c"; c.font = "800 22px Inter, Arial"; c.fillText(labels[i], x + 28, 408); }); }} />
    <Sign p={[0, 8.4, -2]} w={3.6} h={0.85} text="MOST PEOPLE" k={most} size={48} bg="#14141c" fg="#ffe14a" />
    <Sign p={[-0.4, 7.0, -1.4]} w={3.6} h={0.8} text="TEENS + 20s" k={seg(t, 11.17, 11.5, back)} size={42} bg="#9a5ad8" fg="#fff" />
  </>);
};

/* ============ S5 12.46 – 18.0  Anne Cleary's VR experiments ============ */
export const S5 = ({ t, f }: Ctx) => {
  const name = seg(t, 14.67, 15.0, back), vr = seg(t, 16.51, 16.8, back), walk = seg(t, 16.0, 18.0);
  return (<>
    <Cam t={t} keys={low([{ t: 12.3, pos: [0, 4.4, 13], look: [0, 3.8, 0], fov: 58 }, { t: 18.1, pos: [0.4, 4.2, 12], look: [0.4, 3.6, 0], fov: 56 }])} />
    <Lights warm="#c8e8ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0a1028" b="#0a1028" />
    {/* neon grid "virtual room" */}
    {Array.from({ length: 13 }, (_, i) => <Box key={i} p={[-6 + i, 0.02, -1]} s={[0.04, 0.02, 12]} color="#3affd8" line={0} />)}
    {Array.from({ length: 12 }, (_, i) => <Box key={"z" + i} p={[0, 0.02, -7 + i]} s={[12, 0.02, 0.04]} color="#3affd8" line={0} />)}
    <Box p={[0, 3, -5]} s={[12, 6, 0.05]} color="#101838" line={2} />
    {[[-3.6, -3.4, 1.8], [3.8, -3.4, 1.4], [1.8, -2.2, 1.2]].map(([x, z, h], i) => <mesh key={i} position={[x, h / 2, z]}><boxGeometry args={[1.0, h, 1.0]} /><meshBasicMaterial color="#3affd8" wireframe /></mesh>)}
    <Person p={[-2.2, 0, 1.6]} h={3.4} look={sci} f={f} pose={{ mood: "smile", armR: [0.3, 0.6], armRK: 1, lookX: 0.5 }} />
    <Box p={[-1.8, 2.0, 1.9]} s={[0.55, 0.75, 0.05]} color="#c9a870" line={2} />
    <Person p={[lerp(0.6, 2.0, walk), 0, 1.0]} h={3.4} look={vol} f={f + 4} pose={{ mood: "smile", walk: walk > 0 && walk < 1 ? t * 3 : undefined, speed: 0.4, lookX: 0 }} />
    <Box p={[lerp(0.6, 2.0, walk), 2.98, 1.35]} s={[0.9, 0.38, 0.3]} color="#14141c" line={2} />
    <Sign p={[-1.3, 6.0, 1.2]} w={3.0} h={0.75} text="ANNE CLEARY" k={name} size={36} bg="#fff" fg="#14141c" />
    <Sign p={[1.4, 7.4, 0.6]} w={3.0} h={0.8} text="VR ROOMS" k={vr} size={44} bg="#3affd8" fg="#14141c" />
  </>);
};

/* ============ S6 18.0 – 25.48  same layout, new room -> déjà vu, can't remember ============ */
export const S6 = ({ t, f }: Ctx) => {
  const lay = seg(t, 19.53, 20.0, ease), dv = seg(t, 22.24, 22.55, Easing.out(Easing.back(3))), forget = seg(t, 23.79, 24.6, ease), sw = seg(t, 18.0, 18.6, ease);
  return (<>
    <Cam t={t} keys={[{ t: 17.8, pos: [0, 8.0, 14], look: [0, 1.4, -1], fov: 58 }, { t: 25.6, pos: [0, 8.4, 13], look: [0, 1.2, -1], fov: 58 }]} />
    <Lights warm="#f0f0ff" />
    <Surface p={[0, -0.02, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a1438" b="#1a1438" />
    {/* two top-down room plans: OLD (left, fades) and NEW (right) */}
    {[0, 1].map((v) => { const x = v ? 2.3 : -2.3, o = v ? 1 : 1 - 0.85 * forget; return <group key={v} position={[x, 0.05, 0]}>
      <CanvasPlane p={[0, 0, 0]} rot={[-Math.PI / 2, 0, 0]} s={[4.0, 4.8]} px={[400, 480]} draw={(c, W, H) => { c.globalAlpha = o; c.fillStyle = v ? "#5a7ab8" : "#c8865a"; c.fillRect(0, 0, W, H); c.strokeStyle = "#fff"; c.lineWidth = 10; c.strokeRect(5, 5, W - 10, H - 10);
        const items: [number, number, number, number, string][] = [[40, 40, 70, 70, v ? "#bfe8ff" : "#ffe9a8"], [290, 40, 70, 70, v ? "#2f8cff" : "#3fae4a"], [240, 160, 90, 90, v ? "#e5233a" : "#3b4a8a"], [110, 250, 180, 120, v ? "#2fd4a0" : "#c0402e"]];
        for (const [ix, iy, iw, ih, col] of items) { c.fillStyle = col; c.fillRect(ix, iy, iw, ih); c.strokeStyle = INK; c.lineWidth = 5; c.strokeRect(ix, iy, iw, ih); }
        c.fillStyle = "#fff"; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.fillText(v ? "NEW ROOM" : "EARLIER ROOM", W / 2, H - 24); c.globalAlpha = 1; }} />
    </group>; })}
    {/* dashed links between matching items */}
    {[[-3.6, -1.85], [-1.2, -1.85], [-1.6, -0.35], [-2.4, 0.9]].map(([x, z], i) => <Box key={i} p={[x + 2.3, 0.12, z]} s={[4.6 * lay + 0.01, 0.05, 0.05]} color="#ffe14a" line={0} />)}
    <Sign p={[0, 4.4, 0.6]} w={3.6} h={0.85} text="SAME LAYOUT" k={lay * (1 - dv)} size={46} bg="#ffe14a" fg="#14141c" />
    <Sign p={[0, 4.4, 0.8]} w={3.4} h={1.0} text="DÉJÀ VU!" k={dv} size={60} bg="#9a5ad8" fg="#fff" />
    <Sign p={[-2.3, 2.6, 1.6]} w={3.6} h={0.8} text="CAN'T REMEMBER" k={seg(t, 23.79, 24.1, back)} size={38} bg="#14141c" fg="#ff5a8a" />
  </>);
};

/* ============ S7 25.48 – 30.65  brain recognizes the pattern, loses the source ============ */
export const S7 = ({ t, f }: Ctx) => {
  const pat = seg(t, 27.26, 27.6, back), tag = seg(t, 28.78, 30.3, Easing.in(Easing.quad));
  return (<>
    <Cam t={t} keys={[{ t: 25.3, pos: [0, 4.4, 11.5], look: [0, 4.4, 0], fov: 56 }, { t: 30.8, pos: [0, 4.4, 10.5], look: [0, 4.4, 0], fov: 54 }]} />
    <Lights warm="#fff0f4" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2a1a40" b="#2a1a40" />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#2a1a40" line={0} />
    <Brain p={[0, 4.2, -1]} s={1.4} t={t} />
    <Sign p={[-1.3, 7.4, 0.4]} w={2.5} h={0.75} text="✓ PATTERN" k={pat} size={36} bg="#2fd46a" fg="#14141c" />
    {/* the "source" tag flying off */}
    <group position={[lerp(1.4, 6.5, tag), lerp(7.4, 10.5, tag), 0.4]} rotation={[0, 0, tag * 1.5]}><Sign p={[0, 0, 0]} w={2.6} h={0.75} text="SOURCE: ???" k={seg(t, 28.06, 28.4, back)} size={30} bg="#ff5a8a" fg="#fff" /></group>
  </>);
};

/* ============ S8 30.65 – 35.49  temporal lobes ============ */
export const S8 = ({ t, f }: Ctx) => {
  const lobe = seg(t, 33.08, 33.5, back), mem = seg(t, 34.21, 34.5, back);
  return (<>
    <Cam t={t} keys={[{ t: 30.5, pos: [0, 4.4, 11.5], look: [0, 4.4, 0], fov: 56 }, { t: 35.6, pos: [0, 4.4, 11], look: [0, 4.4, 0], fov: 55 }]} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0e1a30" b="#0e1a30" />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#0e1a30" line={0} />
    <Brain p={[0, 4.2, -1]} s={1.4} t={t} lobe={lobe} />
    <Sign p={[0, 8.2, 0.4]} w={3.8} h={0.85} text="TEMPORAL LOBE" k={lobe} size={42} bg="#ffd23a" fg="#14141c" />
    <Sign p={[1.0, 7.0, 0.8]} w={2.6} h={0.75} text="MEMORIES" k={mem} size={40} bg="#fff" fg="#14141c" />
    <Sign p={[0, 8.2, 0.6]} w={2.6} h={0.75} text="DOCTORS" k={seg(t, 30.65, 30.95, back) * (1 - lobe)} size={38} bg="#2f8cff" fg="#fff" />
  </>);
};

/* ============ S9 35.49 – 41.01  maybe your brain borrowed the memory ============ */
export const S9 = ({ t, f }: Ctx) => {
  const fade = seg(t, 36.36, 37.2), card = seg(t, 39.56, 40.4, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 35.3, pos: [0, 4.0, 12], look: [0, 3.6, 0], fov: 56 }, { t: 41.1, pos: [0, 4.2, 11], look: [0, 3.8, 0], fov: 54 }])} />
    <Lights warm="#e8e0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#2a2050" b="#221a44" unit={2} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#1a1438" line={3} />
    {fade < 1 ? <Person p={[1.6, 0, 0.8]} h={3.5} look={ghost} f={f + 7} pose={{ mood: "smile", flip: true, lookX: -0.5, squash: -0.2 * fade }} /> : null}
    <Glow p={[1.6, 2.0, 1.0]} r={3} color="rgba(180,160,255,1)" o={0.6 * (1 - fade)} />
    <Person p={[-1.2, 0, 1.2]} h={3.5} look={you} f={f} pose={{ mood: "smile", lookX: 0.4 }} />
    {/* memory card sliding into your head */}
    <group position={[lerp(3.2, -1.2, card), lerp(5.6, 3.4, card), 1.6]} scale={[1 - 0.7 * card, 1 - 0.7 * card, 1]}><Sign p={[0, 0, 0]} w={2.4} h={0.8} text="MEMORY" k={seg(t, 38.77, 39.1, back)} size={40} bg="#b8a8ff" fg="#14141c" /></group>
    <Sign p={[0, 7.2, 0.4]} w={3.8} h={0.85} text="BORROWED?" k={seg(t, 40.07, 40.35, back)} size={48} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S10 41.01 – end  "which would you rather believe?" ============ */
export const S10 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={[{ t: 40.8, pos: [0, 3.0, 11], look: [0, 2.6, 0], fov: 56 }, { t: 42.7, pos: [0, 3.0, 10], look: [0, 2.6, 0], fov: 54 }]} />
  <Lights warm="#f0e8ff" />
  <Surface p={[-5, 0, 0]} s={[10, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a2a7a" b="#3a2a7a" />
  <Surface p={[5, 0, 0]} s={[10, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a4a7a" b="#1a4a7a" />
  <Box p={[-5, 6, -4]} s={[10, 12, 0.3]} color="#4a3a9a" line={0} /><Box p={[5, 6, -4]} s={[10, 12, 0.3]} color="#1a5a9a" line={0} />
  <Person p={[-1.5, 0, 0.4]} h={3.0} look={ghost} f={f + 7} pose={{ mood: "smile", lookX: 0.3 }} /><Glow p={[-1.5, 1.8, 0.8]} r={2.4} color="rgba(180,160,255,1)" o={0.5} />
  <Brain p={[1.6, 1.8, 0]} s={0.7} t={t} />
  <Sign p={[-1.35, 4.0, 1.0]} w={2.4} h={0.7} text="1: OTHER LIFE" k={seg(t, 41.01, 41.3, back)} size={27} bg="#b8a8ff" fg="#14141c" />
  <Sign p={[1.35, 4.0, 1.0]} w={2.4} h={0.7} text="2: BRAIN GLITCH" k={seg(t, 41.18, 41.5, back)} size={25} bg="#5ab0ff" fg="#14141c" />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
