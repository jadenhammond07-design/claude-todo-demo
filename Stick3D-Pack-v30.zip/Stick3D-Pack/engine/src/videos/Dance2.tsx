// DANCING PLAGUE 1518 — scenes 8-14.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, Extrude, Curtain, Globe, Bench } from "../style/extra";
import { Sky, Timber, Barrel, Crate, Well, Torch, Banner, Flame, Note, CrowdField, danceBeat } from "../style/medieval";
import { Plaza } from "./Dance";
import { Ctx, WALK, troffeaBleed, villagers, councilor, councilor2, drummer, piper, guard, historian, historian2, shrineWalker } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const fall = (t: number, t0: number, d: number, e: (x: number) => number = Easing.in(Easing.quad)) => e(clamp((t - t0) / d));

/* ============ S8 25.2 – 31.0  "The music pulls in more dancers, and some collapse from exhaustion, strokes, and failing hearts." ============ */
const K8: Key[] = [
  { t: 25.0, pos: [-9, 4.2, 13.5], look: [0, 2.0, -3], fov: 60 },
  { t: 26.8, pos: [8, 5.0, 14], look: [0, 2.0, -2], fov: 60 },
  { t: 27.8, pos: [-1.0, 3.4, 13.0], look: [-2.0, 1.2, 2.0], fov: 56 },
  { t: 29.0, pos: [0.4, 3.4, 12.5], look: [0.2, 1.2, 2.4], fov: 56 },
  { t: 30.1, pos: [2.6, 3.6, 11.5], look: [2.2, 1.8, 1.8], fov: 52 },
  { t: 31.4, pos: [2.6, 3.7, 10.0], look: [2.4, 2.4, 1.8], fov: 50 },
];
const FALLERS: { x: number; z: number; t0: number; side: number }[] = [{ x: -2.8, z: 2.0, t0: 27.8, side: 1 }, { x: -0.9, z: 3.2, t0: 29.0, side: -1 }, { x: 1.0, z: 2.4, t0: 29.65, side: 1 }, { x: 2.8, z: 1.6, t0: 30.05, side: -1 }];
export const S8 = ({ t, f }: Ctx) => {
  const notes = Array.from({ length: 14 }, (_, i) => { const u = (t * 0.55 + i / 14) % 1, a = i * 2.4, r = u * 9; return { p: [Math.cos(a) * r, 3.3 + Math.sin(u * 6 + i) * 0.9 - u * 1.6, -3 + Math.sin(a) * r * 0.9 + 1.5] as V3, o: Math.min(1, u * 5) * (1 - u) }; });
  const pulled = Array.from({ length: 9 }, (_, i) => { const a = i * 0.7 + 0.4, r1 = 11 + (i % 3) * 2.5, r2 = 4.2 + (i % 4) * 0.7, k = seg(t, 25.3 + i * 0.1, 27.5 + i * 0.1, ease); const r = lerp(r1, r2, k); return { x: Math.cos(a) * r * 1.0, z: 0.2 - Math.abs(Math.sin(a)) * r * 0.5, i, k }; });
  const heartT = Math.max(0, t - 30.05), per = 0.32 + heartT * 0.55, ph = (heartT % per) / per, hs = heartT < 0.95 ? 1 + 0.35 * Math.exp(-ph * 7) : 1;
  return (<>
    <Cam t={t} keys={K8} impacts={[[27.95, 0.02]]} />
    <Lights warm="#ffc0a0" />
    <Plaza t={t} top="#6a3a9a" bot="#ff9a60" glowO={0.8} ground={["#9a8a7a", "#8a7a6a"]} />
    <Box p={[0, 0.45, -3.3]} s={[8.2, 0.9, 4]} color="#c9985a" /><Box p={[0, 0.9, -1.28]} s={[8.2, 0.12, 0.08]} color="#6a4426" line={2} />
    <Banner p={[0, 5.0, -5.3]} s={[4.4, 1.7]} text="STRASBOURG" size={52} />{[-3.6, 3.6].map((x) => <Cyl key={x} p={[x, 2.8, -5.2]} rt={0.1} h={3.8} color="#6a4426" line={2} />)}
    <Torch p={[-4.6, 0.9, -1.5]} t={t} on={1} /><Torch p={[4.6, 0.9, -1.5]} t={t} on={1} /><Barrel p={[-6.4, 0, -2]} /><Crate p={[6.6, 0, -1]} /><Plant p={[7.2, 0, 3]} s={1.2} pot="#b5603a" /><Well p={[-7.8, 0, 4]} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,200,150,.9)" />
    <Person p={[-1.8, 0.9, -3.0]} sy={0.9} h={3.2} look={drummer} f={f} pose={{ mood: "grin", armR: [0.25, 0.55 + 0.2 * Math.max(0, Math.sin(t * 8))], armRK: 1, tilt: 0.04 * Math.sin(t * 4) }} />
    <Person p={[1.8, 0.9, -3.0]} sy={0.9} h={3.2} look={piper} f={f + 3} pose={{ mood: "smile", flip: true, armR: [0.14, 0.62], armRK: 1, tilt: 0.05 * Math.sin(t * 3) }} />
    <Cyl p={[-1.2, 1.9, -2.9]} rt={0.5} h={0.7} color="#c9402e" line={3} rot={[0.3, 0, 0]} />
    {notes.map((n, i) => n.o > 0.05 ? <Note key={i} p={n.p} s={0.75} o={n.o} color={["#ffe08a", "#ff9ac8", "#9ae0ff"][i % 3]} /> : null)}
    <CrowdField n={60} t={t} at={(i) => { const a = i * 2.399, r = 12 + (i % 7) * 1.6; return [Math.cos(a) * r, 0, -2 - Math.abs(Math.sin(a)) * r * 0.5] as V3; }} size={1.2} />
    {pulled.map((d) => { const b = danceBeat(t, d.i + 4, 0.8); return <Person key={d.i} p={[d.x, b.y, d.z]} sy={0} h={3.0} look={villagers[d.i % 8]} f={f + d.i * 3} pose={{ mood: d.k < 1 ? "shock" : "worry", sweat: d.k > 0.9 ? 1 : 0, ...b.pose }} />; })}
    {FALLERS.map(({ x, z, t0, side }, i) => {
      const k = fall(t, t0, 0.45, Easing.in(Easing.cubic)), b = danceBeat(t, i + 11, 0.85 * (1 - k)), sag = i === 1 ? seg(t, 28.4, 28.9) : 0, stroke = i === 2 ? seg(t, 29.16, 29.6) : 0;
      return <Person key={i} p={[x, b.y * (1 - k), z]} sy={0} h={3.3} look={troffeaBleed} f={f + i * 4} pose={{ mood: k > 0.5 ? "shock" : "worry", sweat: t > t0 - 1.5 ? 1 : 0, hunch: Math.max(sag, k) * 0.9, ...b.pose, tilt: b.pose.tilt * (1 - k) + side * 1.45 * k, squash: b.pose.squash * (1 - k) - 0.08 * sag, arms: stroke > 0 && k < 0.5 ? "head" : undefined, armK: stroke, armRK: stroke > 0 ? 0 : b.pose.armRK, armLK: stroke > 0 ? 0 : b.pose.armLK, nerv: stroke > 0 ? 0.9 : 0 }} />; })}
    {t > 29.2 && t < 29.8 ? [0, 1, 2].map((j) => <Ball key={j} p={[1.0 + Math.cos(t * 12 + j * 2.1) * 0.5, 4.3 + Math.sin(t * 5) * 0.1, 2.4 + Math.sin(t * 12 + j * 2.1) * 0.5]} r={0.1} color="#ffe94a" ink={0.03} />) : null}
    {t > 30.05 ? <CanvasPlane p={[2.8, 4.7, 1.8]} s={[0.95 * hs, 0.95 * hs]} px={[160, 160]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = heartT > 0.95 ? "#6a1a2a" : "#e5233a"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.moveTo(80, 140); c.bezierCurveTo(-20, 70, 20, 8, 80, 52); c.bezierCurveTo(140, 8, 180, 70, 80, 140); c.fill(); c.stroke(); if (heartT > 0.95) { c.beginPath(); c.moveTo(82, 50); c.lineTo(66, 82); c.lineTo(92, 96); c.lineTo(76, 130); c.stroke(); } }} /> : null}
  </>);
};

/* ============ S9 31.0 – 34.5  "Panicked, the council bans the music and marches" ============ */
const K9: Key[] = [
  { t: 30.8, pos: [-1.5, 4.0, 11.5], look: [0, 3.0, -1], fov: 60 },
  { t: 32.0, pos: [0.4, 3.8, 9.2], look: [0, 3.0, -1], fov: 56 },
  { t: 32.8, pos: [0.2, 3.9, 8.2], look: [0, 3.1, -1], fov: 52 },
  { t: 34.7, pos: [1.6, 3.6, 8.8], look: [1.4, 3.0, -2], fov: 54 },
];
export const S9 = ({ t, f }: Ctx) => {
  const panic = t > 31.12 && t < 32.0, jump = (i: number) => { const u = clamp((t - 31.15 - i * 0.06) / 0.4); return Math.sin(u * Math.PI) * 0.7; };
  const slam = t >= 32.27, raise = seg(t, 31.9, 32.2, Easing.out(Easing.cubic)), down = seg(t, 32.2, 32.28, Easing.linear), decree = seg(t, 32.3, 32.62, Easing.out(Easing.back(2.2)));
  const handY = lerp(lerp(0.52, 0.95, raise), 0.5, down), door = seg(t, 33.0, 33.4, ease), gz = (k: number) => lerp(-6.2, -2.6, seg(t, 33.35 + k * 0.1, 34.6, ease));
  return (<>
    <Cam t={t} keys={K9} impacts={[[32.27, 0.045]]} />
    <Lights warm="#ffd2c0" />
    <Floor kind="tile" a="#3a1a24" b="#5a2434" unit={1.8} w={36} d={24} />
    <WallDoor z={-6.4} W={36} kind="wood" a="#5a2230" b="#4e1c2a" door={{ x: 7.2, w: 2.4, h: 4.6 }} base="#2a0e18" /><SideWall x={-10} kind="wood" a="#5a2230" b="#4e1c2a" /><SideWall x={11} kind="wood" a="#5a2230" b="#4e1c2a" />
    <group position={[8.4, 0, -6.35]} rotation={[0, door * 1.4, 0]}><Box p={[1.2, 2.3, 0]} s={[2.4, 4.6, 0.14]} color="#6a3a22" /></group>
    <CanvasPlane p={[-3.6, 5.3, -6.3]} s={[4.2, 3.8]} px={[300, 270]} frame="#2a0e18" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#7a4aa8"); g.addColorStop(1, "#ffb070"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "#c9985a"; c.fillRect(70, 170, 160, 30); c.fillStyle = "#4a2a18"; c.fillRect(0, 200, W, 70); for (let i = 0; i < 5; i++) { const x = 50 + i * 50, b = Math.abs(Math.sin(t * 5 + i)) * 10 * (t < 32.27 ? 1 : 0); c.fillStyle = INK; c.beginPath(); c.arc(x, 150 - b, 7, 0, 7); c.fill(); c.fillRect(x - 3, 150 - b, 6, 24); } if (t < 32.27) { c.fillStyle = "#ffe08a"; for (let i = 0; i < 4; i++) { const u = (t * 0.7 + i / 4) % 1; c.font = "900 30px Inter, Arial"; c.fillText("♪", 90 + i * 40, 150 - u * 110); } } c.fillStyle = "#7a1a1a"; c.fillRect(0, 0, 14, H); c.fillRect(W - 14, 0, 14, H); }} />
    <Curtain p={[-7.6, 4.6, -6.2]} s={[2.4, 9.2]} color="#8a1a2e" /><Curtain p={[0.4, 4.6, -6.2]} s={[2.4, 9.2]} color="#8a1a2e" />
    <Banner p={[-8.4, 5.0, -6.2]} s={[1.8, 3.2]} text="†" bg="#1f4a8a" size={120} /><Banner p={[5.0, 5.0, -6.2]} s={[1.8, 3.2]} text="⚖" bg="#c9a032" fg="#4a1a1a" size={110} />
    <CanvasPlane p={[0.8, 5.4, -6.2]} s={[3.2 * decree + 0.001, 4.2 * decree + 0.001]} px={[320, 420]} frame="#4a2a18" draw={(c, W, H) => { c.fillStyle = "#f3e2b4"; c.fillRect(0, 0, W, H); c.fillStyle = "#b3122e"; c.textAlign = "center"; c.textBaseline = "middle"; c.font = "900 66px Inter, Arial"; c.fillText("BANNED", W / 2, 60); c.fillStyle = INK; c.beginPath(); c.ellipse(120, 280, 46, 32, -0.4, 0, 7); c.fill(); c.lineWidth = 16; c.strokeStyle = INK; c.beginPath(); c.moveTo(158, 262); c.lineTo(158, 150); c.lineTo(232, 182); c.stroke(); c.strokeStyle = "#e5233a"; c.lineWidth = 24; c.beginPath(); c.arc(160, 240, 140, 0, 7); c.moveTo(70, 150); c.lineTo(250, 330); c.stroke(); }} />
    <Box p={[0, 1.75, -0.4]} s={[9.2, 0.24, 2.4]} color="#8a4a2a" /><Box p={[-4.2, 0.85, -0.4]} s={[0.4, 1.7, 2]} color="#5a2e1a" line={2} /><Box p={[4.2, 0.85, -0.4]} s={[0.4, 1.7, 2]} color="#5a2e1a" line={2} />
    <Cyl p={[-3.0, 2.02, 0.2]} rt={0.12} h={0.3} color="#f3e8d0" line={2} /><Flame p={[-3.0, 2.2, 0.2]} t={t} s={0.2} /><Cyl p={[3.0, 2.02, 0.2]} rt={0.12} h={0.3} color="#f3e8d0" line={2} /><Flame p={[3.0, 2.2, 0.2]} t={t} s={0.2} />
    <Box p={[1.4, 1.95, 0.4]} s={[0.7, 0.14, 0.5]} color="#c9985a" line={2} /><Box p={[-1.8, 1.89, 0.5]} s={[1.3, 0.03, 0.9]} color="#f3e8d0" line={1} />
    {[-5, 5].map((x) => <React.Fragment key={x}><Cyl p={[x, 8.2, -0.5]} rt={0.03} h={2.4} color="#2a1a14" line={1} /><Cyl p={[x, 6.6, -0.5]} rt={0.9} rb={0.4} h={0.3} color="#c9a032" line={2} /><Flame p={[x, 6.7, -0.5]} t={t} s={0.3} /></React.Fragment>)}
    <Rug p={[0, 0.01, 4]} s={[9, 4.5]} a="#6a1a2a" b="#c9a032" /><Glow p={[0, 5.5, 0]} r={8} color="rgba(255,160,90,1)" o={0.3} /><Dust t={t} area={[7, 5, 3]} color="rgba(255,200,170,.9)" />
    {[-3.0, -1.0, 1.4, 3.2].map((xx, i) => { const head = i === 2; return <Person key={i} p={[xx, jump(i) * (panic ? 1 : 0), -1.7]} sy={0} h={3.5} look={i % 2 ? councilor2 : councilor} f={f + i * 4} pose={{ mood: t < 31.12 ? "worry" : slam ? (head ? "angry" : "shock") : "shock", sweat: t > 31.1 ? 1 : 0, nerv: panic ? 0.7 : 0.2, arms: panic || (t > 32.28 && !head) ? "head" : undefined, armK: panic ? 1 : seg(t, 32.28, 32.5) * 0.8,
      armR: head && t >= 31.9 ? [0.12, handY] : undefined, armRK: head ? seg(t, 31.9, 32.0) : 0, tilt: panic ? 0.05 * Math.sin(t * 30) : 0, squash: panic ? -0.04 : 0, hunch: head ? 0 : 0.2 }} />; })}
    {t >= 31.9 ? <FaceGroup p={[1.4, 0, -1.7]}><Box p={hand(3.5, [0.12, handY + 0.07], 0, false, 0.1)} s={[0.5, 0.22, 0.22]} color="#6a4426" line={2} /></FaceGroup> : null}
    {[-1, 1].map((k, i) => <Person key={"g" + i} p={[8.4 + k * 0.7, 0, gz(i)]} h={3.4} look={guard} f={f + i * 6} pose={{ mood: "angry", walk: t > 33.35 ? (gz(i) + 6.2) * WALK * 1.2 : undefined, speed: t > 33.35 && t < 34.6 ? 0.8 : 0, arms: "hold", armK: 0.6 }} />)}
  </>);
};

/* ============ S10 34.5 – 38.3  "the survivors to a shrine of Saint Vitus in red shoes marked with crosses." ============ */
const lead = (t: number) => lerp(-2, 7.4, seg(t, 34.5, 38.5, Easing.linear));
const K10: Key[] = [
  { t: 34.3, pos: [lead(34.3) + 0.5, 2.4, 10.0], look: [lead(34.3) + 0.5, 2.1, 0], fov: 58 },
  { t: 35.3, pos: [lead(35.3) + 3.5, 2.8, 10.5], look: [8.0, 3.2, -5], fov: 56 },
  { t: 36.0, pos: [lead(36.0) + 2.2, 2.6, 9.0], look: [lead(36.0) + 4.5, 3.0, -2], fov: 54 },
  { t: 36.4, pos: [lead(36.4) + 0.6, 0.6, 4.2], look: [lead(36.4) - 0.2, 0.45, 0], fov: 50 },
  { t: 37.6, pos: [lead(37.6) + 0.3, 0.5, 3.2], look: [lead(37.6) - 0.3, 0.38, 0], fov: 46 },
  { t: 38.6, pos: [lead(38.6) + 0.3, 0.5, 3.0], look: [lead(38.6) - 0.3, 0.38, 0], fov: 46 },
];
export const S10 = ({ t, f }: Ctx) => {
  const trees: [number, number, number][] = [[-5, -5, 1.2], [3, -9, 1.5], [9, -11, 1.3], [-2, -14, 1.7], [14, 2, 1.4], [16, -6, 1.2], [-8, -2, 1.3], [6, -18, 1.8]];
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#ffc890" />
    <Sky p={[0, 26, -90]} s={[300, 150]} top="#5a3a8a" bottom="#ffa060" glowAt={[0.9, "rgba(255,190,110,1)"]} />
    <Ball p={[18, 3, -86]} r={6} color="#ffe0a0" ink={0} /><Glow p={[18, 3, -85]} r={28} color="rgba(255,170,80,1)" o={0.55} />
    <Surface p={[0, 0, -20]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#5a9a42" b="#5a9a42" />
    <Surface p={[7, 0.02, 0]} s={[44, 3.6]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#b89a6a" b="#a88a5a" unit={1.2} />
    {[[-30, -40, 22], [10, -45, 28], [40, -38, 20]].map(([x, z, r], i) => <Ball key={i} p={[x, -r * 0.55, z]} r={r} color={["#4a8a3a", "#3f7a34", "#5a9a42"][i]} ink={0.2} />)}
    {trees.map(([x, z, s], i) => <group key={i} position={[x, 0, z]} scale={s}><Cyl p={[0, 1, 0]} rt={0.25} rb={0.35} h={2} color="#6a4426" line={2} /><Ball p={[0, 3, 0]} r={1.3} color={["#2f7a3a", "#3a8a3a", "#4a9a3a"][i % 3]} /></group>)}
    <group position={[10.5, 0, -6]} scale={1.2}>
      <Box p={[0, 3, 0]} s={[8, 6, 6]} color="#d8cfc0" /><Extrude p={[0, 6, 0]} pts={[[-4.4, 0], [4.4, 0], [0, 3.2]]} depth={6.6} color="#7a3a2a" line={4} />
      <Box p={[0, 10.5, 0]} s={[0.25, 2.2, 0.25]} color="#f2c744" line={2} /><Box p={[0, 10.9, 0]} s={[1.2, 0.25, 0.25]} color="#f2c744" line={2} />
      <CanvasPlane p={[0, 4.2, 3.02]} s={[3, 3]} px={[300, 300]} frame="#4a3a2a" draw={(c, W, H) => { const g = c.createRadialGradient(150, 150, 10, 150, 150, 150); g.addColorStop(0, "#fff0a0"); g.addColorStop(1, "#c8302e"); c.fillStyle = g; c.beginPath(); c.arc(150, 150, 146, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 8; c.stroke(); for (let i = 0; i < 8; i++) { c.beginPath(); c.moveTo(150, 150); c.lineTo(150 + Math.cos(i * 0.785) * 146, 150 + Math.sin(i * 0.785) * 146); c.stroke(); } c.fillStyle = "#2f6bd6"; c.beginPath(); c.arc(150, 112, 30, 0, 7); c.fill(); c.stroke(); c.fillRect(120, 140, 60, 100); c.strokeRect(120, 140, 60, 100); c.fillStyle = "#ffd23a"; c.beginPath(); c.ellipse(150, 78, 36, 9, 0, 0, 7); c.fill(); c.stroke(); }} />
      <Box p={[0, 1.5, 3.05]} s={[1.8, 3, 0.2]} color="#4a2a18" line={3} /><Glow p={[0, 3.6, 3.6]} r={4.5} color="rgba(255,200,110,1)" o={0.45} />
      <Banner p={[-3.2, 5.2, 3.2]} s={[1.5, 2.6]} text="S. VITUS" bg="#9c1f2e" size={36} /><Torch p={[-1.8, 0, 3.8]} t={t} on={1} /><Torch p={[1.8, 0, 3.8]} t={t} on={1} />
    </group>
    <Barrel p={[-3, 0, 2]} /><Crate p={[8.8, 0, 2.4]} rotY={0.3} />
    <Dust t={t} area={[9, 6, 4]} color="rgba(255,200,150,.9)" />
    {[0, 1, 2, 3, 4, 5].map((j) => { const x = lead(t) - j * 1.7, ph = x * WALK; return <Person key={j} p={[x, 0, 0]} h={3.4} look={shrineWalker(j)} f={f + j * 5} pose={{ mood: j % 2 ? "worry" : "deadpan", walk: ph, speed: 0.55, hunch: 0.6, sweat: j % 2 ? 1 : 0, nerv: 0.1, lookX: 0.3 }} />; })}
    {[-3.6, -7.0].map((dx, k) => { const x = lead(t) + dx + 4.5 - k * 2, ph = x * WALK; return <Person key={"g" + k} p={[x, 0, -1.6]} h={3.4} look={guard} f={f + k * 7} pose={{ mood: "angry", walk: ph, speed: 0.6, arms: "hold", armK: 0.7 }} />; })}
  </>);
};

/* ============ S11 38.3 – 41.0  "Historians still argue over ergot poisoning." ============ */
const K11: Key[] = [
  { t: 38.1, pos: [-3.5, 3.4, 11.0], look: [0, 3.0, 0], fov: 58 },
  { t: 39.6, pos: [0.4, 3.5, 11.0], look: [0, 3.0, 0], fov: 56 },
  { t: 40.4, pos: [1.0, 3.6, 10.0], look: [0.2, 3.1, 0.4], fov: 52 },
  { t: 41.2, pos: [1.2, 3.6, 9.2], look: [0.2, 3.1, 0.4], fov: 50 },
];
export const S11 = ({ t, f }: Ctx) => {
  const sw = Math.sin(t * 7), a1 = Math.max(0, Math.sin(t * 5.2)), a2 = Math.max(0, Math.sin(t * 5.2 + Math.PI));
  const tox = seg(t, 40.3, 40.6, Easing.out(Easing.back(2)));
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#ffe0b0" />
    <Floor kind="plank" a="#7a5232" b="#6a4528" unit={1.7} w={30} d={24} />
    <WallDoor z={-6} W={30} kind="wood" a="#5a3a28" b="#4e3020" base="#2a1a10" /><SideWall x={-9} kind="wood" a="#5a3a28" b="#4e3020" /><SideWall x={9} kind="wood" a="#5a3a28" b="#4e3020" />
    {[-6.4, -2.2, 2.2, 6.4].map((x, i) => <Shelf key={x} p={[x, 0, -5.5]} w={3.4} rows={5} seed={i + 3} wood="#3a2412" />)}
    <Globe p={[-6.8, 2.6, -2]} r={0.9} rotY={t * 0.3} /><Box p={[-6.8, 0.9, -2]} s={[0.3, 1.8, 0.3]} color="#6a4426" line={2} />
    <Box p={[0, 1.7, 0]} s={[4.2, 0.22, 2.4]} color="#9a6a3a" />{[-1.8, 1.8].map((x) => [-0.9, 0.9].map((z) => <Box key={x + "_" + z} p={[x, 0.85, z]} s={[0.3, 1.7, 0.3]} color="#6a4426" line={2} />))}
    <Box p={[-1.9, 1.9, 0.5]} s={[1.0, 0.2, 0.8]} color="#2f6a4a" line={2} /><Box p={[-1.9, 2.1, 0.5]} s={[0.9, 0.2, 0.7]} color="#9c1f2e" line={2} /><Box p={[2.0, 1.88, 0.3]} s={[1.2, 0.04, 0.9]} color="#f3e8d0" line={1} />
    <group position={[0.2, 1.8, 0.2]}><Cyl p={[0, 1.2, 0]} rt={0.05} h={2.4} color="#c9a032" line={2} />
      {Array.from({ length: 12 }, (_, i) => <Ball key={i} p={[(i % 2 ? 0.14 : -0.14), 2.0 + Math.floor(i / 2) * 0.24, 0]} r={0.12} color="#e0b84a" s={[0.8, 1.5, 0.8]} ink={0.03} />)}
      {[[0.22, 2.3], [-0.22, 2.7], [0.2, 3.1]].map(([x, y], i) => <Ball key={"e" + i} p={[x, y, 0.05]} r={0.14} color="#2a0f3a" s={[0.8, 2.6, 0.8]} ink={0.04} />)}</group>
    <Glow p={[0.2, 3.9, 0.6]} r={2.2 * tox + 0.001} color="rgba(90,255,90,1)" o={0.55} />
    {tox > 0.02 ? <CanvasPlane p={[0.2, 5.0, 0.6]} s={[1.0 * tox, 1.0 * tox]} px={[160, 160]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#f4f4ea"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.arc(80, 68, 52, 0, 7); c.fill(); c.stroke(); c.fillRect(54, 100, 52, 30); c.strokeRect(54, 100, 52, 30); c.fillStyle = INK; c.beginPath(); c.arc(60, 66, 14, 0, 7); c.arc(100, 66, 14, 0, 7); c.fill(); c.beginPath(); c.moveTo(80, 82); c.lineTo(72, 98); c.lineTo(88, 98); c.fill(); }} /> : null}
    <Cyl p={[-1.1, 2.1, 1.0]} rt={0.4} rb={0.4} h={0.05} color="#bfe8ff" line={3} rot={[Math.PI / 2, 0, 0]} /><Cyl p={[-0.7, 1.9, 1.0]} rt={0.05} h={0.9} color="#6a4426" line={2} rot={[0, 0, 0.9]} />
    <Lamp p={[6.4, 0, -4]} h={3.6} color="#ffe0a0" /><Chair p={[-5.2, 0, 2.6]} rotY={0.6} color="#6a4426" /><Rug p={[0, 0.01, 3.2]} s={[8, 4]} a="#2a4a6a" b="#c9a032" /><Plant p={[7, 0, 1]} s={1.2} pot="#b5603a" />
    <Glow p={[0, 5.4, 0]} r={7} color="rgba(255,200,120,1)" o={0.25} /><Shaft p={[-2, 8.5, -4]} s={[2.6, 8]} rot={[0, 0, 0.35]} color="255,235,170" o={0.18} /><Dust t={t} area={[6, 5, 3]} color="rgba(255,230,180,.9)" />
    <Person p={[-2.0, 0, -1.7]} h={3.4} look={historian} f={f} pose={{ mood: "angry", armR: [0.36 + 0.06 * sw, 0.62 + 0.2 * a1], armRK: 1, tilt: 0.06 * sw, lookX: 0.7 }} />
    <Person p={[2.3, 0, -1.7]} h={3.4} look={historian2} f={f + 5} pose={{ mood: "angry", flip: true, armR: [0.36 - 0.06 * sw, 0.62 + 0.2 * a2], armRK: 1, tilt: -0.06 * sw, lookX: -0.7 }} />
    {[[-1.2, a1], [1.5, a2]].map(([x, a], i) => (a as number) > 0.5 ? <CanvasPlane key={i} p={[x as number, 5.5, 0.8]} s={[1.1, 0.85]} px={[130, 100]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 24, 18); c.fill(); c.stroke(); c.fillStyle = "#e5233a"; c.font = "900 56px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(i ? "!?" : "?!", W / 2, H / 2 - 8); }} /> : null)}
  </>);
};

/* ============ S12 41.0 – 44.6  "The stranger theory fits better: starving, terrified people" ============ */
const K12: Key[] = [
  { t: 40.8, pos: [7.5, 2.8, 9.0], look: [3, 2.2, 0], fov: 58 },
  { t: 42.7, pos: [1.0, 2.7, 8.2], look: [-1, 2.2, 0], fov: 56 },
  { t: 43.6, pos: [-2.6, 2.7, 6.0], look: [-3.6, 2.6, 0], fov: 48 },
  { t: 44.9, pos: [-3.0, 2.8, 5.0], look: [-3.8, 2.6, 0], fov: 44 },
];
export const S12 = ({ t, f }: Ctx) => {
  const hungry = seg(t, 42.74, 43.0), fear = seg(t, 43.52, 43.8, Easing.out(Easing.back(2)));
  const xs = [-3.8, -1.6, 0.6, 2.8, 5.0];
  return (<>
    <Cam t={t} keys={K12} />
    <Lights warm="#e8e0b0" />
    <Sky p={[0, 26, -80]} s={[300, 150]} top="#b8b070" bottom="#efe4b8" glowAt={[0.5, "rgba(255,240,170,1)"]} />
    <Ball p={[14, 22, -75]} r={5} color="#fff6c0" ink={0} /><Glow p={[14, 22, -74]} r={22} color="rgba(255,240,170,1)" o={0.5} />
    <Surface p={[0, 0, -10]} s={[90, 60]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#b4a070" b="#b4a070" />
    <CanvasPlane p={[0, 0.03, -3]} rot={[-Math.PI / 2, 0, 0]} s={[40, 22]} px={[800, 440]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#5a4628"; c.lineWidth = 3; for (let i = 0; i < 70; i++) { let x = (i * 137) % W, y = (i * 59) % H; c.beginPath(); c.moveTo(x, y); for (let k = 0; k < 4; k++) { x += ((i * 31 + k * 17) % 41) - 20; y += ((i * 11 + k * 23) % 33) - 16; c.lineTo(x, y); } c.stroke(); } }} />
    {[-16, -10, 11, 17].map((x, i) => <Timber key={x} p={[x, 0, -14 - (i % 2) * 3]} s={[6, 6, 5]} wall="#d8c8a0" roof="#8a6a4a" seed={i + 2} shutter="#6a5a3a" />)}
    <Box p={[1.2, 1.0, -2.6]} s={[10.4, 0.25, 1.8]} color="#8a6a3a" /><Box p={[1.2, 0.5, -2.6]} s={[10, 1.0, 1.4]} color="#6a4a2a" line={2} />{[-3.8, 6.2].map((x) => <Cyl key={x} p={[x, 2.4, -3.2]} rt={0.09} h={3.2} color="#5a3a22" line={2} />)}
    <Box p={[1.2, 3.9, -3.0]} s={[11, 0.15, 2.8]} color="#a8802a" rot={[0.25, 0, 0]} line={3} />
    {[-2.8, -0.6, 1.6, 3.8].map((x, i) => <group key={i} position={[x, 1.2, -2.6]}><Cyl p={[0, 0.12, 0]} rt={0.55} rb={0.42} h={0.28} color="#b5823e" line={2} /><Cyl p={[0, 0.2, 0]} rt={0.44} h={0.02} color="#3a2a18" line={1} />{i === 1 ? <Ball p={[0.1, 0.32, 0]} r={0.12} color="#c9a860" ink={0.02} s={[1.4, 0.7, 1]} /> : null}</group>)}
    <Banner p={[1.2, 3.1, -1.7]} s={[3.2, 0.9]} text="BREAD" size={44} bg="#6a5a3a" fg="#d8c8a0" />
    {[-7.5, 8.5].map((x) => <group key={x} position={[x, 0, -2]}>{[-0.6, 0, 0.6].map((dx) => <Cyl key={dx} p={[dx, 1.0, 0]} rt={0.03} h={2} color="#6a5a30" line={1} rot={[0, 0, dx * 0.5]} />)}</group>)}
    <Cyl p={[-8.6, 2.5, -7]} rt={0.18} rb={0.3} h={5} color="#5a4a30" line={2} />{[0, 1, 2].map((i) => <Cyl key={i} p={[-8.6 + (i - 1) * 0.8, 4.6 + i * 0.1, -7]} rt={0.05} h={1.7} color="#5a4a30" line={1} rot={[0, 0, (i - 1) * 0.9]} />)}
    <Box p={[8.5, 0.35, -5]} s={[1.5, 0.7, 0.8]} color="#e8e0cc" line={2} /><Barrel p={[7.4, 0, 1.0]} /><Crate p={[-6.4, 0, 1.4]} /><Dust t={t} area={[9, 5, 4]} color="rgba(230,215,160,.9)" />
    {xs.map((x, i) => { const near = i === 0, jit = Math.sin(f * 0.5 + i), c = Math.min(1, fear * (near ? 1 : 0.8)), nl = fear > 0.2 ? 0.9 : 0.15, zz = -0.2 + (i % 2) * 0.4, sk = villagers[(i + 3) % 8].skin;
      return <React.Fragment key={i}><Person p={[x, near ? 0.3 * Math.sin(clamp((t - 43.52) / 0.5) * Math.PI) : 0, zz]} sy={0} h={3.3} look={{ ...villagers[(i + 3) % 8], skin: fear > 0.2 ? "#e8dccf" : sk }} f={f + i * 5} pose={{ mood: fear > 0.2 ? "shock" : "worry", hunch: 0.5 + 0.3 * hungry, sweat: fear > 0.2 ? 1 : 0, nerv: nl * 0.9, lookX: Math.sin(t * 2.2 + i * 2), tilt: 0.04 * jit + 0.1 * hungry, arms: fear > 0.2 ? "head" : undefined, armK: c, armR: fear < 0.2 ? [0.3, 0.5] : undefined, armRK: fear < 0.2 ? 1 : 0, squash: -0.03 * hungry }} />
        {fear < 0.2 ? <FaceGroup p={[x, 0, zz]}><Cyl p={hand(3.3, [0.3, 0.5], 0, false, 0.14).map((v, k) => k === 1 ? v + 0.05 : v) as V3} rt={0.3} rb={0.18} h={0.18} color="#9a7a4a" line={2} /></FaceGroup> : null}</React.Fragment>; })}
    {hungry > 0 && fear < 0.2 ? xs.map((x, i) => <CanvasPlane key={"w" + i} p={[x, 1.6, 0.5 + (i % 2) * 0.4]} s={[0.9, 0.4]} px={[90, 40]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); for (let k = 0; k < 80; k++) { const px2 = 5 + k, py = 20 + Math.sin(k * 0.5 + t * 14) * 8; k ? c.lineTo(px2, py) : c.moveTo(px2, py); } c.stroke(); }} />) : null}
  </>);
};

/* ============ S13 44.6 – 48.6  "whose stress had nowhere to go, until fear itself turned contagious." ============ */
const K13: Key[] = [
  { t: 44.4, pos: [-3.2, 3.4, 10.5], look: [-2.2, 3.0, 0], fov: 54 },
  { t: 46.3, pos: [-3.0, 3.8, 11.0], look: [-2.2, 3.2, 0], fov: 54 },
  { t: 46.9, pos: [0.4, 4.0, 12.8], look: [1.8, 2.8, 0], fov: 58 },
  { t: 48.3, pos: [4.8, 4.4, 15.0], look: [5.4, 2.6, 0], fov: 60 },
  { t: 49.2, pos: [5.0, 4.6, 15.5], look: [5.4, 2.6, 0], fov: 60 },
];
const BX = -2.2, VX = [1.8, 3.6, 5.4, 7.2, 9.0], FZ = [0.4, -1.0, 0.6, -0.8, 0.5];
export const S13 = ({ t, f }: Ctx) => {
  const p = seg(t, 44.6, 46.35, Easing.in(Easing.quad)), boom = t >= 46.39, dt = Math.max(0, t - 46.39);
  const lidY = boom ? 3.1 + 15 * dt - 12 * dt * dt : 3.1 + Math.sin(t * 40) * 0.05 * p, lidRot = boom ? dt * 6 : Math.sin(t * 38) * 0.05 * p;
  const front = BX + dt * 7.5, needle = lerp(-2.2, 2.2, boom ? 1 : p);
  const steam = Array.from({ length: 6 }, (_, i) => { const u = (t * 1.6 + i / 6) % 1; return [BX + Math.sin(i * 2) * 1.2, 2.2 + u * 1.8, 0.8, 0.12 + 0.25 * u, p * (1 - u)] as [number, number, number, number, number]; });
  return (<>
    <Cam t={t} keys={K13} impacts={[[46.39, 0.05]]} />
    <Lights warm="#e0c0ff" />
    <Plaza t={t} top="#2a1048" bot="#a0305a" glowO={0.6} lit={1} ground={["#6a5a6a", "#5a4a5a"]} skip={[3, 4]} />
    <Ball p={[-8, 14, -80]} r={4.5} color="#f0e8ff" ink={0} /><Glow p={[-8, 14, -79]} r={16} color="rgba(200,180,255,1)" o={0.4} />
    <Torch p={[-5.5, 0, -2]} t={t} on={1} /><Torch p={[11, 0, -3]} t={t} on={1} /><Barrel p={[-6.4, 0, 1]} /><Crate p={[-6.6, 0, 2]} s={0.9} /><Well p={[12, 0, -6]} /><Plant p={[-7, 0, -4]} s={1.2} pot="#b5603a" /><Bench p={[5, 0, -4.5]} rotY={0.1} />
    <group position={[BX, 0, 0]}>
      <Cyl p={[0, 1.4, 0]} rt={1.5} rb={1.8} h={2.8} color="#3a3a4a" line={4} />{[0.6, 2.2].map((y) => <Cyl key={y} p={[0, y, 0]} rt={1.62} rb={1.62} h={0.12} color="#5a5a6e" line={2} />)}
      {[-1, 0, 1].map((k) => <Ball key={k} p={[k * 0.9, 1.5, 1.7 - Math.abs(k) * 0.25]} r={0.09} color="#8a8a9a" ink={0.02} />)}
      <CanvasPlane p={[0, 1.4, 1.62]} s={[1.8, 0.9]} px={[360, 180]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#f3d9a0"; c.fillRect(10, 10, W - 20, H - 20); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(10, 10, W - 20, H - 20); c.fillStyle = "#b3122e"; c.font = "900 78px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("STRESS", W / 2, H / 2 + 4); }} />
      <Glow p={[0, 1.6, 2.0]} r={3.4} color="rgba(255,70,50,1)" o={0.5 * p * (boom ? 0 : 1)} />
      <group position={[0, lidY, 0]} rotation={[0, 0, lidRot]}><Cyl p={[0, 0, 0]} rt={1.3} rb={1.58} h={0.4} color="#4a4a5e" line={3} /><Ball p={[0, 0.3, 0]} r={0.2} color="#8a8a9a" /></group>
      {!boom ? <CanvasPlane p={[0, 3.9, 1.0]} s={[1.5, 1.5]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#f4f4ee"; c.strokeStyle = INK; c.lineWidth = 9; c.beginPath(); c.arc(100, 100, 88, 0, 7); c.fill(); c.stroke(); c.fillStyle = "#e5233a"; c.beginPath(); c.moveTo(100, 100); c.arc(100, 100, 74, Math.PI * 0.85, Math.PI * 2.15); c.closePath(); c.globalAlpha = 0.25; c.fill(); c.globalAlpha = 1; c.strokeStyle = INK; c.lineWidth = 9; c.beginPath(); c.moveTo(100, 100); c.lineTo(100 + Math.sin(needle) * 70, 100 - Math.cos(needle) * 70); c.stroke(); }} /> : null}
    </group>
    {steam.map(([x, y, z, r, o], i) => o > 0.03 ? <Ball key={i} p={[x, y, z]} r={r} color="#f4f4f4" ink={0.03} /> : null)}
    <Person p={[BX - 2.8, 0, 0.6]} h={3.3} look={villagers[1]} f={f} pose={{ mood: "worry", sweat: 1, nerv: p, hunch: 0.4 + 0.3 * p, lookX: 0.8, tilt: 0.03 * Math.sin(t * 20) * p }} />
    {boom ? <><Glow p={[front, 2.6, 1.2]} r={4 + dt * 3} color="rgba(190,90,255,1)" o={0.55 * Math.max(0, 1 - dt * 0.45)} /><Glow p={[BX, 3.4, 1.0]} r={2 + dt * 8} color="rgba(255,255,230,1)" o={0.9 * Math.exp(-dt * 5)} /></> : null}
    {VX.map((x, i) => { const arrive = 46.39 + (x - BX) / 7.5, hit = boom && front > x, k = hit ? clamp((front - x) / 1.2) : 0, shock = hit && t < arrive + 0.42, b = danceBeat(t, i + 20, seg(t, arrive + 0.4, arrive + 0.9));
      return <React.Fragment key={i}><Person p={[x, hit && !shock ? b.y : 0, FZ[i]]} sy={0} h={3.0} look={villagers[(i + 4) % 8]} f={f + i * 4} pose={{ mood: !hit ? "deadpan" : shock ? "shock" : "worry", sweat: hit ? 1 : 0, nerv: hit ? 0.6 : 0, ...(hit && !shock ? b.pose : {}), squash: shock ? -0.15 : 0, arms: shock ? "head" : undefined, armK: 1 }} />
        {hit ? <Glow p={[x, 1.8, FZ[i] + 0.3]} r={1.6 * k + 0.001} color="rgba(190,90,255,1)" o={0.4 * (shock ? 1 : 0.5)} /> : null}</React.Fragment>; })}
  </>);
};

/* ============ S14 48.6 – 52.2  "They called it a plague. It was a mind catching fire." ============ */
const K14: Key[] = [
  { t: 48.4, pos: [0, 3.6, 14.5], look: [0, 2.6, 0], fov: 56 },
  { t: 50.2, pos: [0, 3.3, 11.2], look: [0, 2.8, 0], fov: 54 },
  { t: 51.6, pos: [0, 2.2, 7.4], look: [0, 3.3, 0], fov: 52 },
  { t: 53.0, pos: [0, 2.0, 6.4], look: [0, 3.5, 0], fov: 50 },
];
export const S14 = ({ t, f }: Ctx) => {
  const burn = seg(t, 50.19, 50.95, Easing.in(Easing.quad)), fire = seg(t, 50.99, 51.7, Easing.out(Easing.cubic)), h = 3.4;
  const sw = Math.sin(t * 2.0) * 0.02 * (1 - burn);
  return (<>
    <Cam t={t} keys={K14} />
    <Lights warm="#ffb080" />
    <Surface p={[0, 0, -10]} s={[90, 60]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#1a1030" b="#14102a" unit={2.2} />
    <Sky p={[0, 26, -40]} s={[200, 120]} top="#05030f" bottom="#2a0a30" stars={0.9} t={t} glowAt={[0.5 + 0.3 * fire, "rgba(255,80,30,1)"]} />
    <CrowdField n={46} t={t} rate={5.6} at={(i) => { const a = i * 2.399, r = 5 + (i % 9) * 1.3; return [Math.cos(a) * r * 1.1, 0, -4 - Math.abs(Math.sin(a)) * r * 0.9] as V3; }} size={1.3} mood={1} />
    <Shaft p={[0, 11, -0.5]} s={[4.4, 12]} color="255,170,110" o={0.18 + 0.2 * fire} /><Glow p={[0, 2.8, -1]} r={7} color="rgba(255,90,40,1)" o={0.3 + 0.35 * fire} /><Dust t={t} area={[5, 6, 4]} color="rgba(255,170,110,.9)" />
    {[-6, 6].map((x) => <Torch key={x} p={[x, 0, 1]} t={t} on={1} />)}<Box p={[-4, 0.25, 3]} s={[0.4, 0.5, 0.4]} color="#2a2236" line={2} /><Barrel p={[5.6, 0, -2]} /><Crate p={[-5.4, 0, -2]} />
    <Person p={[0, 0, 0]} h={h} look={troffeaBleed} f={f} pose={{ mood: t < 50.9 ? "worry" : "shock", sweat: 1, nerv: t > 50.99 ? 0.6 : 0.2, hunch: 0.4, arms: t > 50.99 ? "head" : "down", armK: seg(t, 50.99, 51.3), lookX: 0, squash: t > 50.99 ? -0.05 * Math.exp(-(t - 51) * 6) : 0 }} />
    <Flame p={[0, h * 0.78 + 0.5 * fire, 0.15]} t={t} s={1.9 * fire} hot="#ffd23a" />
    {fire > 0.1 ? <Glow p={[0, h * 0.95, 0.5]} r={4.0 * fire} color="rgba(255,150,40,1)" o={0.65} /> : null}
    <group position={[0, 0, 1.6]} rotation={[0, sw, 0]}>
      {[-2.3, 2.3].map((x) => <Cyl key={x} p={[x, 2.8, 0]} rt={0.09} h={5.6} color="#5a3a22" line={2} />)}<Box p={[0, 5.6, 0]} s={[5, 0.2, 0.2]} color="#5a3a22" line={2} />
      <CanvasPlane p={[0, 2.4, 0.05]} s={[4.4, 4.4]} px={[440, 440]} draw={(c, W, H) => {
        c.clearRect(0, 0, W, H); c.fillStyle = "#6a4a2a"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 10; c.strokeRect(5, 5, W - 10, H - 10); c.fillStyle = "#e8dcc0"; c.beginPath(); c.arc(220, 140, 80, 0, 7); c.fill(); c.stroke(); c.fillRect(185, 205, 70, 40); c.strokeRect(185, 205, 70, 40); c.fillStyle = INK; c.beginPath(); c.arc(190, 136, 22, 0, 7); c.arc(250, 136, 22, 0, 7); c.fill(); c.beginPath(); c.moveTo(220, 160); c.lineTo(208, 184); c.lineTo(232, 184); c.fill();
        c.fillStyle = "#e8dcc0"; c.font = "900 112px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.strokeStyle = INK; c.lineWidth = 12; c.strokeText("PLAGUE", W / 2, 340); c.fillText("PLAGUE", W / 2, 340);
        if (burn > 0) { const y0 = H * (1 - burn * 1.15); c.globalCompositeOperation = "destination-out"; c.beginPath(); c.moveTo(0, H); c.lineTo(0, y0); for (let x = 0; x <= W; x += 20) c.lineTo(x, y0 + Math.sin(x * 0.07 + t * 9) * 18 + (x % 40 ? 8 : -8)); c.lineTo(W, H); c.closePath(); c.fill(); c.globalCompositeOperation = "source-over"; }
      }} />
      {burn > 0 && burn < 1 ? [-1.8, -0.9, 0, 0.9, 1.8].map((x, i) => <Flame key={i} p={[x, 0.2 + 4.4 * Math.min(1, burn * 1.15), 0.2]} t={t + i} s={0.95} />) : null}
    </group>
  </>);
};

export const SCENES: Record<string, any> = { S8, S9, S10, S11, S12, S13, S14 };
export const tintFor = (i: number): ((t: number) => string) | undefined => i === 11 ? () => "#e4e2c4" : i === 12 ? () => "#c8b0e8" : i === 13 ? () => "#b49494" : i === 7 ? () => "#ffd8c0" : undefined;
