import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Park";
import { Captions } from "../Main";
export const PCUTS = [0, 4.4, 9.4, 16.7, 20.4, 26.0, 33.0, 38.9, 42.9, 45.7, 48.7];
const BG = ["#5aa8ff", "#2fb8c8", "#5aa8ff", "#5aa8ff", "#5aa8ff", "#5aa8ff", "#2a3a50", "#5aa8ff", "#1a2a4a", "#ff9a3a"];
const TR: Trans[] = ["ghost", "whip", "zoom", "ghost", "whip", "ghost", "flash", "zoom", "flash", "ghost"];
export const ParkMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={PCUTS[i]} end={PCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
