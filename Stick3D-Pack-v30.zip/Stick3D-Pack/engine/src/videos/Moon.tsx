// WHAT IF THE MOON CAME CLOSER — 10 scenes. Moon, laser ranging, tides, Roche ring, fingernail ruler.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Dust } from "../style/props";
import { Cam, Globe, Stars, Building } from "../style/extra";
import { Sky } from "../style/medieval";
import { Water } from "../style/nature";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const sci = (i: number): Look => mk(["#f3d3b2", "#8d5a3a"][i], "#f4f4f4", "shirt", i ? "short" : "bob", "#3b2a1a", { glasses: true, badge: "#2f8cff" });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = "#ffffff" }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.2, h * k * 1.2]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Moon: React.FC<{ p: V3; r: number; rot?: number }> = ({ p, r, rot = 0 }) => (
  <group position={p} rotation={[0, rot, 0]}>
    <Ball p={[0, 0, 0]} r={r} color="#d8d4c8" ink={0.04} />
    {[[0.35, 0.3, 0.22], [-0.4, -0.1, 0.28], [0.1, -0.45, 0.18], [-0.15, 0.5, 0.14], [0.55, -0.2, 0.12]].map(([x, y, s], i) => { const z = Math.sqrt(Math.max(0, 1 - x * x - y * y)); return <Ball key={i} p={[x * r, y * r, z * r * 0.93]} r={s * r} s={[1, 1, 0.3]} color="#b8b2a4" ink={0.02} />; })}
  </group>
);
const Night: React.FC<{ t: number }> = ({ t }) => <Stars p={[0, 12, -30]} s={[110, 70]} t={t} top="#05061a" bottom="#1a2050" n={180} />;

/* ============ S1 0 – 4.14  hook: the Moon is getting closer ============ */
export const S1 = ({ t, f }: Ctx) => {
  const r = lerp(1.6, 2.6, seg(t, 0, 4.2, ease)), q = seg(t, 3.58, 3.85, back);
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 3.0, 14], look: [0, 4.2, 0], fov: 58 }, { t: 4.3, pos: [0, 2.6, 12], look: [0, 4.6, 0], fov: 56 }])} />
    <Lights warm="#b8c4ff" />
    <Night t={t} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a2a3a" b="#1a2a3a" />
    <Moon p={[0.8, 7.6, -8]} r={r} rot={t * 0.1} /><Glow p={[0.8, 7.6, -7.4]} r={r * 2.2} color="rgba(220,230,255,1)" o={0.35} />
    {[-2.2, 0, 2.2].map((x, i) => <Person key={i} p={[x, 0, 1.4 + (i % 2) * 0.6]} h={3.2} look={i === 1 ? you : sci(i ? 1 : 0)} f={f + i * 4} pose={{ mood: "worry", lookX: 0.2, armR: [0.3, 0.78], armRK: i === 1 ? seg(t, 1.0, 1.5) : 0 }} />)}
    <Sign p={[0, 6.0, 1.4]} w={1.3} h={1.3} text="?" k={q} size={100} bg="#000" fg="#ff5a8a" />
  </>);
};

/* ============ S2 4.14 – 9.25  lasers at the Apollo mirrors ============ */
export const S2 = ({ t, f }: Ctx) => {
  const fire = seg(t, 4.98, 5.5), mir = seg(t, 6.55, 6.9, back), cut = seg(t, 7.8, 8.6, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 4.0, pos: [0, 3.4, 14], look: [0, 4.0, 0], fov: 58 }, { t: 7.6, pos: [0, 4.0, 14], look: [0, 5.0, -2], fov: 58 }, { t: 9.4, pos: [0, 6.0, 12], look: [0, 6.6, -4], fov: 56 }])} />
    <Lights warm="#b8c4ff" />
    <Night t={t} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2a3040" b="#2a3040" />
    {/* observatory dome */}
    <group position={[-1.6, 0, 0]}><Cyl p={[0, 1.2, 0]} rt={1.8} h={2.4} color="#e8e8f0" line={4} /><Ball p={[0, 2.4, 0]} r={1.8} s={[1, 0.8, 1]} color="#f4f4fa" /><Box p={[0.3, 3.4, 0.6]} s={[0.5, 1.6, 0.6]} rot={[0, 0, -0.35]} color="#2b3350" line={2} /></group>
    {fire > 0 ? <><Box p={[lerp(-1.3, 1.6, 0.5), lerp(4.0, 10, 0.5), lerp(0.6, -6, 0.5)]} s={[0.08, 13.5 * fire, 0.08]} rot={[-0.47, 0, -0.4]} color="#3aff6a" line={0} /><Glow p={[-1.2, 4.1, 0.8]} r={1.2} color="rgba(80,255,120,1)" o={0.8 * fire} /></> : null}
    <Moon p={[2.6, 10.5, -7]} r={2.2} rot={t * 0.1} />
    {/* mirror panel on the moon */}
    <group position={[1.7, 9.4, -4.9]} scale={[mir + 0.001, mir + 0.001, mir + 0.001]}><Box p={[0, 0, 0]} s={[0.8, 0.5, 0.06]} color="#9fd4ff" line={2} /><Glow p={[0, 0, 0.2]} r={0.8} color="rgba(120,255,160,1)" o={0.7 * fire} /></group>
    <Sign p={[1.6, 7.6, -3]} w={3.4} h={0.8} text="APOLLO MIRRORS" k={mir} size={34} bg="#14141c" fg="#9fd4ff" />
    <Person p={[1.4, 0, 1.8]} h={3.2} look={sci(0)} f={f} pose={{ mood: "smile", lookX: -0.3, armR: [0.3, 0.78], armRK: fire * (1 - cut) }} />
  </>);
};

/* ============ S3 9.25 – 16.39  the round trip gets faster ============ */
export const S3 = ({ t, f }: Ctx) => {
  const should = seg(t, 11.07, 11.4, back), faster = seg(t, 13.17, 13.5, Easing.out(Easing.back(3))), cm = t < 15.54 ? seg(t, 14.2, 14.9) * 3 : 3 + seg(t, 15.54, 16.3) * 27;
  const ph = ((t - 9.3) / 1.6) % 1, up = ph < 0.5, py = up ? lerp(2.8, 9.0, ph * 2) : lerp(9.0, 2.8, ph * 2 - 1);
  return (<>
    <Cam t={t} keys={[{ t: 9.1, pos: [0, 4.6, 15.5], look: [0, 4.8, 0], fov: 58 }, { t: 16.5, pos: [0, 4.8, 14.5], look: [0, 5.0, 0], fov: 58 }]} />
    <Lights warm="#b8c4ff" />
    <Night t={t} />
    <Globe p={[-1.6, 1.6, 0]} r={1.2} rotY={t * 0.3} />
    <Moon p={[-1.6, 9.8, -0.5]} r={0.9} />
    <Box p={[-1.6, 5.6, 0]} s={[0.04, 7.2, 0.04]} color="#2a6a3a" line={0} />
    <Ball p={[-1.6, py, 0.1]} r={0.22} color="#3aff6a" ink={0.02} /><Glow p={[-1.6, py, 0.4]} r={0.9} color="rgba(80,255,120,1)" o={0.8} />
    {/* round-trip timer panel */}
    <CanvasPlane p={[1.6, 7.6, 0.4]} s={[3.4, 2.2]} px={[340, 220]} draw={(c, W, H) => { c.fillStyle = "#0c1020"; c.strokeStyle = "#fff"; c.lineWidth = 6; c.beginPath(); c.roundRect(4, 4, W - 8, H - 8, 16); c.fill(); c.stroke(); c.fillStyle = "#9fd4ff"; c.font = "900 28px Inter, Arial"; c.textAlign = "center"; c.fillText("ROUND TRIP", W / 2, 46); c.fillStyle = faster > 0.5 ? "#ff5a6a" : "#3aff6a"; c.font = "900 56px Inter, Arial"; c.fillText(faster > 0.5 ? "2.56s ↓" : "2.56s", W / 2, 120); c.fillStyle = "#fff"; c.font = "900 26px Inter, Arial"; c.fillText(cm > 0 ? `CLOSER: ${Math.round(cm)} cm` : " ", W / 2, 180); }} />
    <Sign p={[1.6, 4.8, 0.6]} w={3.2} h={0.75} text="SHOULD: LONGER" k={should * (1 - faster)} size={34} bg="#2fa86a" fg="#fff" />
    <Sign p={[1.6, 4.8, 0.8]} w={3.2} h={0.8} text="FASTER?!" k={faster} size={50} bg="#e5233a" fg="#fff" />
  </>);
};

/* ============ S4 16.39 – 18.17  scientists check the math twice ============ */
export const S4 = ({ t, f }: Ctx) => {
  const x2 = seg(t, 17.53, 17.8, back);
  return (<>
    <Cam t={t} keys={low([{ t: 16.2, pos: [0, 3.0, 11.5], look: [0, 2.6, 0], fov: 56 }, { t: 18.3, pos: [0, 3.0, 10.5], look: [0, 2.8, 0], fov: 54 }])} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, 0, 0]} s={[40, 30]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#cfd8e8" b="#bcc8dc" unit={1.6} />
    <Box p={[0, 6, -4]} s={[30, 12, 0.3]} color="#2a3a5a" line={3} />
    <CanvasPlane p={[0, 5.2, -3.7]} s={[5.2, 2.6]} px={[520, 260]} frame="#8a6a3a" draw={(c, W, H) => { c.fillStyle = "#1e4a3a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "700 34px Inter, Arial"; c.textAlign = "left"; c.fillText("d = c · t / 2", 30, 60); c.fillText("t ↓  →  d ↓ ???", 30, 120); c.strokeStyle = "#ff5a6a"; c.lineWidth = 6; if (t > 17.2) { c.beginPath(); c.arc(330, 108, 70, 0, 7); c.stroke(); } c.fillStyle = "#ffe14a"; c.fillText(t > 16.9 ? "✓ ✓" : "✓", 30, 200); }} />
    {[0, 1].map((i) => <Person key={i} p={[-1.6 + i * 3.2, 0, 1.2]} h={3.4} look={sci(i)} f={f + i * 5} pose={{ mood: "worry", lookX: i ? -0.5 : 0.5, flip: i === 1, sweat: 1, armR: [0.3, 0.7], armRK: 0.6 + 0.4 * Math.sin(t * 6 + i) }} />)}
    <Sign p={[0, 7.8, -1]} w={3.6} h={0.9} text="CHECKED ×2" k={x2} size={52} bg="#ffe14a" fg="#14141c" edge="#14141c" />
  </>);
};

/* ============ S5 18.17 – 21.76  tides creep higher, Moon looks bigger ============ */
export const S5 = ({ t, f }: Ctx) => {
  const lvl = lerp(0.2, 1.5, seg(t, 18.4, 20.4, ease)), big = lerp(1.6, 2.8, seg(t, 20.45, 21.3, back));
  return (<>
    <Cam t={t} keys={[{ t: 18.0, pos: [0, 3.2, 14], look: [0, 3.0, 0], fov: 58 }, { t: 20.3, pos: [0, 3.6, 14.5], look: [0, 4.2, -2], fov: 58 }, { t: 21.9, pos: [0, 3.8, 15], look: [0, 5.0, -3], fov: 58 }]} />
    <Lights warm="#c8d0ff" />
    <Night t={t} />
    <Moon p={[1.2, 9.0, -10]} r={big} /><Glow p={[1.2, 9.0, -9.5]} r={big * 2} color="rgba(220,230,255,1)" o={0.3} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#d8c08a" b="#d8c08a" />
    {[-3.4, 0.4, 3.6].map((x, i) => <Building key={i} p={[x, 0, -3]} s={[2.6, 3 + i, 2.2]} color={["#e8b8a0", "#a8c8e8", "#f0d890"][i]} seed={i + 1} lit={0.6} />)}
    <Water p={[0, 0, 2]} w={30} d={14} level={lvl} o={0.7} />
    <Box p={[2.6, lvl + 0.4, 3.0]} s={[0.12, 2.4, 0.12]} color="#fff" line={2} />{[0, 1, 2, 3].map((i) => <Box key={i} p={[2.75, 0.4 + i * 0.6, 3.0]} s={[0.2, 0.04, 0.04]} color="#e5233a" line={0} />)}
    <Sign p={[-1.2, 6.4, 1.0]} w={3.6} h={0.8} text="TIDES RISING" k={seg(t, 18.17, 18.5, back)} size={40} bg="#1f6ad8" fg="#fff" />
  </>);
};

/* ============ S6 21.76 – 28.5  Roche limit: torn into a ring ============ */
export const S6 = ({ t, f }: Ctx) => {
  const d = lerp(6.5, 3.1, seg(t, 21.9, 24.2, Easing.in(Easing.quad))), tear = seg(t, 24.2, 25.4, Easing.out(Easing.quad)), ring = seg(t, 26.6, 28.0, ease), lim = seg(t, 25.49, 25.8, back);
  const N = 36;
  return (<>
    <Cam t={t} keys={[{ t: 21.6, pos: [0, 7.0, 18], look: [0, 3.0, 0], fov: 58 }, { t: 25.0, pos: [0, 8.0, 17], look: [0, 3.0, 0], fov: 58 }, { t: 28.6, pos: [0, 10.0, 15], look: [0, 3.0, 0], fov: 58 }]} />
    <Lights warm="#d8e0ff" />
    <Night t={t} />
    <Globe p={[0, 4.0, 0]} r={1.5} rotY={t * 0.5} tilt={0.3} />
    {/* the danger circle */}
    <group position={[0, 4.0, 0]} rotation={[-Math.PI / 2 + 0.25, 0, 0]}>{Array.from({ length: 40 }, (_, i) => { const a = (i / 40) * Math.PI * 2; return i % 2 ? null : <Box key={i} p={[Math.cos(a) * 3.1, Math.sin(a) * 3.1, 0]} s={[0.3, 0.06, 0.06]} rot={[0, 0, a + Math.PI / 2]} color="#ff5a6a" line={0} />; })}</group>
    {tear < 0.02 ? <Moon p={[d, 4.0 + d * 0.15, -d * 0.3]} r={0.8} /> :
      Array.from({ length: N }, (_, i) => { const a0 = Math.atan2(-0.3, 1) + (i - N / 2) * 0.03 * tear, a = lerp(a0, (i / N) * Math.PI * 2, ring), R = lerp(3.1, 3.1 + (i % 3) * 0.25, ring), sp = tear * 0.8 * (1 - ring);
        const x = Math.cos(a) * R + Math.sin(i * 7) * sp, z = Math.sin(a) * R * 0.97 + Math.cos(i * 3) * sp, y = 4.0 + Math.sin(i * 5) * sp * 0.5 - z * 0.25;
        return <Ball key={i} p={[x, y + 0.45 * (1 - ring) * 0.5, z]} r={0.22 - (i % 4) * 0.03} color={i % 3 ? "#d8d4c8" : "#b8b2a4"} ink={0.03} />; })}
    <Sign p={[0, 9.2, 0]} w={3.8} h={0.85} text="18,000 KM" k={lim} size={50} bg="#e5233a" fg="#fff" />
    <Sign p={[0, 7.4, 0.4]} w={3.6} h={0.85} text="TORN APART" k={seg(t, 24.2, 24.5, back) * (1 - ring)} size={44} bg="#14141c" fg="#ff5a6a" />
    <Sign p={[0, 7.4, 0.6]} w={3.2} h={0.85} text="A RING" k={seg(t, 27.9, 28.2, back)} size={50} bg="#ffe14a" fg="#14141c" edge="#14141c" />
  </>);
};

/* ============ S7 28.5 – 31.5  the strange part: the real Moon does the opposite ============ */
export const S7 = ({ t, f }: Ctx) => {
  const flip = seg(t, 30.2, 31.0, ease), opp = seg(t, 30.88, 31.15, back), mx = lerp(2.2, 3.6, flip);
  return (<>
    <Cam t={t} keys={[{ t: 28.3, pos: [0, 4.4, 13], look: [0, 4.0, 0], fov: 58 }, { t: 31.6, pos: [0.4, 4.4, 13.5], look: [0.4, 4.0, 0], fov: 58 }]} />
    <Lights warm="#d8e0ff" />
    <Night t={t} />
    <Globe p={[-1.8, 4.0, 0]} r={1.3} rotY={t * 0.5} />
    <Moon p={[mx, 4.0, 0]} r={0.7} />
    {/* arrow: toward Earth, then flips away */}
    <group position={[0.6, 5.6, 0.4]} rotation={[0, 0, flip * Math.PI]}><Box p={[0, 0, 0]} s={[1.6, 0.22, 0.1]} color={flip > 0.5 ? "#3aff6a" : "#ff5a6a"} line={2} /><Box p={[-0.9, 0, 0]} s={[0.5, 0.5, 0.1]} rot={[0, 0, Math.PI / 4]} color={flip > 0.5 ? "#3aff6a" : "#ff5a6a"} line={2} /></group>
    <Sign p={[0, 8.2, 0]} w={3.8} h={0.9} text="THE REAL MOON" k={seg(t, 29.95, 30.2, back)} size={40} bg="#14141c" fg="#ffe14a" />
    <Sign p={[0, 2.4, 1.4]} w={3.8} h={0.9} text="MOVING AWAY" k={opp} size={44} bg="#2fd46a" fg="#14141c" edge="#14141c" />
  </>);
};

/* ============ S8 31.5 – 37.37  3.8 cm a year = fingernails ============ */
export const S8 = ({ t, f }: Ctx) => {
  const rate = seg(t, 33.72, 34.0, back), nail = seg(t, 36.63, 37.2, ease), eq = seg(t, 36.72, 37.0, back), rule = seg(t, 33.4, 34.4, ease);
  return (<>
    <Cam t={t} keys={[{ t: 31.3, pos: [0, 4.4, 12.5], look: [0, 4.2, 0], fov: 56 }, { t: 35.5, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 56 }, { t: 37.5, pos: [0.6, 4.2, 10.5], look: [0.6, 4.0, 0], fov: 54 }]} />
    <Lights warm="#e8ecff" />
    <Night t={t} />
    {/* giant ruler */}
    <CanvasPlane p={[0, 6.8, 0]} s={[6.0 * rule + 0.001, 1.0]} px={[600, 100]} draw={(c, W, H) => { c.fillStyle = "#ffd36a"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6); for (let i = 0; i <= 40; i++) { const x = 20 + i * 14; c.lineWidth = i % 10 ? 2 : 4; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, i % 10 ? 30 : 55); c.stroke(); } c.fillStyle = "#e5233a"; c.globalAlpha = 0.5; c.fillRect(20, 60, 14 * 38 * rule, 30); c.globalAlpha = 1; c.fillStyle = INK; c.font = "900 24px Inter, Arial"; c.fillText("0", 14, 88); c.fillText("3.8 cm", 20 + 14 * 38 - 40, 88); }} />
    <Sign p={[0, 8.6, 0.2]} w={3.6} h={0.85} text="3.8 CM / YEAR" k={rate} size={44} bg="#14141c" fg="#ffe14a" />
    {/* a giant finger with a growing nail */}
    <group position={[1.6, 3.4, 0.6]} rotation={[0, 0, -0.25]}>
      <Cyl p={[0, -1.0, 0]} rt={0.55} h={2.6} color="#e8b88c" line={4} /><Ball p={[0, 0.3, 0]} r={0.55} color="#e8b88c" />
      <Box p={[0, 0.35 + 0.25 * nail, 0.42]} s={[0.7, 0.7 + 0.5 * nail, 0.1]} color="#ffd8e0" line={3} />
    </group>
    <Moon p={[-1.6, 3.2, -0.5]} r={0.8} />
    <Sign p={[0.1, 5.2, 1.6]} w={3.6} h={0.8} text="= FINGERNAILS" k={eq} size={36} bg="#ff7aa8" fg="#fff" />
  </>);
};

/* ============ S9 37.37 – 39.9  our closest neighbor is slowly leaving ============ */
export const S9 = ({ t, f }: Ctx) => {
  const away = seg(t, 37.4, 40.0, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 37.2, pos: [0, 3.0, 13], look: [0, 4.4, 0], fov: 58 }, { t: 40.0, pos: [0, 3.0, 13], look: [0, 4.6, -2], fov: 58 }])} />
    <Lights warm="#b8c4ff" />
    <Night t={t} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a2a3a" b="#1a2a3a" />
    <Moon p={[lerp(0.8, 2.0, away), lerp(7.0, 8.4, away), lerp(-6, -16, away)]} r={1.8} /><Glow p={[lerp(0.8, 2.0, away), lerp(7.0, 8.4, away), lerp(-5.5, -15.5, away)]} r={3.4} color="rgba(220,230,255,1)" o={0.3 * (1 - away * 0.5)} />
    <Person p={[0, 0, 1.6]} h={3.4} look={you} f={f} pose={{ mood: "worry", lookX: 0.2, armR: [0.42, 0.85], armRK: 0.5 + 0.5 * Math.sin(t * 8) }} />
    <Sign p={[-1.6, 5.4, 1.4]} w={2.2} h={0.8} text="BYE…?" k={seg(t, 38.97, 39.25, back)} size={44} bg="#fff" fg="#14141c" edge="#14141c" />
  </>);
};

/* ============ S10 39.9 – end  "what would you do if it ever turned around?" ============ */
export const S10 = ({ t, f }: Ctx) => {
  const turn = seg(t, 41.9, 42.9, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 39.7, pos: [0, 2.8, 12], look: [0, 4.2, 0], fov: 58 }, { t: 43.4, pos: [0, 2.6, 10.5], look: [0, 4.4, -1], fov: 56 }])} />
    <Lights warm="#b8c4ff" />
    <Night t={t} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a2a3a" b="#1a2a3a" />
    <Moon p={[1.0, 7.4, lerp(-12, -8, turn)]} r={1.8} rot={turn * Math.PI} /><Glow p={[1.0, 7.4, lerp(-11.5, -7.5, turn)]} r={3.6} color="rgba(220,230,255,1)" o={0.35} />
    {/* U-turn arrow */}
    <group position={[-1.6, 7.4, -4]} scale={[turn + 0.001, turn + 0.001, turn + 0.001]}><Box p={[0, 0.6, 0]} s={[1.4, 0.2, 0.1]} color="#ffe14a" line={2} /><Box p={[0.7, 0.3, 0]} s={[0.2, 0.8, 0.1]} color="#ffe14a" line={2} /><Box p={[0.1, 0, 0]} s={[1.2, 0.2, 0.1]} color="#ffe14a" line={2} /><Box p={[-0.5, 0, 0]} s={[0.45, 0.45, 0.1]} rot={[0, 0, Math.PI / 4]} color="#ffe14a" line={2} /></group>
    <Person p={[0, 0, 1.6]} h={3.4} look={you} f={f} pose={{ mood: turn > 0.5 ? "worry" : "smile", lookX: 0.2, sweat: turn > 0.5 ? 1 : 0 }} />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
