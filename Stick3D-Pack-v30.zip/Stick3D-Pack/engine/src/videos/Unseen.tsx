// THE UNSEEN UNIVERSE — 9 scenes. Space props: Galaxy (canvas spiral), Telescope, Bubble (observable-universe sphere), Afterglow shell.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Dust } from "../style/props";
import { Cam, Key, Globe, Stars } from "../style/extra";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const gazer = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const futureAstro = mk("#cfd8f0", "#5ac8e8", "blazer", "grey", "#aaa", { shirt: "#fff", glasses: true });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k * 1.3 + 0.001, h * k * 1.3 + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = "#ffffff"; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
/** spiral galaxy billboard; o = brightness 0..1 */
const Galaxy: React.FC<{ p: V3; r: number; t: number; o?: number; hue?: number; seed?: number }> = ({ p, r, t, o = 1, hue = 270, seed = 1 }) => (
  o <= 0.01 ? null : <CanvasPlane p={p} s={[r * 2, r * 2]} px={[160, 160]} face draw={(c, W, H) => {
    c.clearRect(0, 0, W, H); const cx = W / 2, cy = H / 2;
    const g = c.createRadialGradient(cx, cy, 2, cx, cy, W / 2); g.addColorStop(0, `hsla(${hue + 40},100%,90%,${o})`); g.addColorStop(0.25, `hsla(${hue},90%,65%,${0.7 * o})`); g.addColorStop(1, `hsla(${hue},90%,40%,0)`); c.fillStyle = g; c.fillRect(0, 0, W, H);
    for (let arm = 0; arm < 2; arm++) for (let i = 0; i < 40; i++) { const a = i * 0.22 + arm * Math.PI + t * 0.3 + seed, rr = i * 1.7; c.fillStyle = `hsla(${hue + i},100%,85%,${o * (1 - i / 45)})`; c.beginPath(); c.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.6, 2.4 - i * 0.03, 0, 7); c.fill(); }
  }} />
);
const Telescope: React.FC<{ p: V3; aim?: number; flip?: boolean }> = ({ p, aim = 0.7, flip }) => (
  <group position={p} scale={[flip ? -1 : 1, 1, 1]}>
    {[-0.5, 0.5, 0].map((x, i) => <Box key={i} p={[x * 0.6, 0.9, i === 2 ? -0.4 : 0.2]} s={[0.08, 1.9, 0.08]} rot={[i === 2 ? 0.25 : 0, 0, x * 0.5]} color="#3a3a46" line={2} />)}
    <group position={[0, 1.9, 0]} rotation={[0, 0, aim]}><Cyl p={[0, 0.9, 0]} rt={0.24} rb={0.18} h={2.2} color="#e8e8f0" line={3} /><Cyl p={[0, 2.05, 0]} rt={0.28} h={0.18} color="#2f8cff" line={2} /></group>
  </group>
);
const Hill: React.FC<{ color?: string }> = ({ color = "#1a2a3a" }) => (<>
  <Surface p={[0, 0, 0]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={color} b={color} />
  <Ball p={[-6, -6, -10]} r={9} color="#16222e" ink={0.02} /><Ball p={[7, -7, -12]} r={10} color="#16222e" ink={0.02} />
</>);
const Space: React.FC<{ t: number; top?: string; bottom?: string }> = ({ t, top = "#05030f", bottom = "#1a0e3a" }) => <Stars p={[0, 10, -30]} s={[110, 70]} t={t} top={top} bottom={bottom} n={220} />;

/* ============ S1 0 – 3.46  hook: stargazer, dark "unknown" regions ============ */
export const S1 = ({ t, f }: Ctx) => {
  const q = seg(t, 2.84, 3.1, back);
  return (<>
    <Cam t={t} keys={[{ t: 0, pos: [0, 3.4, 15], look: [0, 3.0, 0], fov: 58 }, { t: 3.6, pos: [0.6, 3.2, 13], look: [0.4, 3.4, -2], fov: 56 }]} />
    <Lights warm="#8a9ad8" />
    <Space t={t} /><Hill />
    {[[-3.2, 9.5, -8, 1.8, 290], [3.0, 11.5, -10, 2.2, 200], [0.2, 13.5, -14, 1.6, 330]].map(([x, y, z, r, h], i) => <Galaxy key={i} p={[x, y, z]} r={r} t={t} hue={h} seed={i} />)}
    <Box p={[3.6, 8.2, -6]} s={[3.2, 2.4, 0.1]} color="#000000" line={0} /><Sign p={[3.6, 8.2, -5.8]} w={1.4 * q + 0.001} h={1.4 * q + 0.001} text="?" size={110} bg="#000" fg="#ff5a8a" />
    <Telescope p={[-1.0, 0, 1.2]} aim={0.7} />
    <Person p={[0.6, 0, 1.6]} h={3.4} look={gazer} f={f} pose={{ mood: "smile", lookX: -0.3, armR: [-0.35, 0.6], armRK: 1 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(200,210,255,.7)" />
  </>);
};

/* ============ S2 3.46 – 8.37  entire galaxies beyond the veil ============ */
export const S2 = ({ t, f }: Ctx) => {
  const veil = seg(t, 5.13, 5.6), no = seg(t, 7.66, 7.95, back);
  return (<>
    <Cam t={t} keys={[{ t: 3.3, pos: [0, 4, 16], look: [0, 4, -6], fov: 58 }, { t: 8.5, pos: [0, 4.2, 12], look: [0, 4.4, -8], fov: 56 }]} />
    <Lights warm="#a8b8ff" />
    <Space t={t} top="#020108" bottom="#120a28" />
    {Array.from({ length: 9 }, (_, i) => <Galaxy key={i} p={[-5 + (i % 3) * 5, 1.5 + Math.floor(i / 3) * 3.4, -14 - (i % 2) * 3]} r={1.3 + (i % 3) * 0.4} t={t} hue={200 + i * 25} seed={i} o={seg(t, 3.9 + i * 0.12, 4.4 + i * 0.12)} />)}
    {/* the veil: what we can never observe */}
    <mesh position={[0, 5, -9]}><planeGeometry args={[30, 20]} /><meshBasicMaterial color="#000000" transparent opacity={0.82 * veil} depthWrite={false} /></mesh>
    <Sign p={[0, 8.6, -6]} w={5.4 * no + 0.001} h={1.2 * no + 0.001} text="NO HUMAN WILL SEE" size={48} bg="#14141c" fg="#ff5a8a" />
    <Globe p={[0, 4.2, 2]} r={1.3} rotY={t * 0.4} />
    <Dust t={t} area={[10, 7, 5]} color="rgba(200,210,255,.6)" />
  </>);
};

/* ============ S3 8.37 – 15.54  13.8 billion years: light hasn't reached us ============ */
export const S3 = ({ t, f }: Ctx) => {
  const age = seg(t, 9.38, 9.7, back), lx = lerp(-2.4, 0.5, seg(t, 11.99, 14.6, Easing.out(Easing.quad))), notyet = seg(t, 13.77, 14.1, back);
  return (<>
    <Cam t={t} keys={[{ t: 8.2, pos: [0, 4.6, 12], look: [0, 4.4, -2], fov: 58 }, { t: 12.0, pos: [-0.3, 4.2, 11.5], look: [-0.3, 4.0, -2], fov: 58 }, { t: 15.7, pos: [0, 4.0, 11], look: [0, 3.8, -2], fov: 56 }]} />
    <Lights warm="#b8c8ff" />
    <Space t={t} />
    <Sign p={[0, 7.4, -3]} w={6.4 * age + 0.001} h={1.5 * age + 0.001} text="13.8 BILLION YRS" size={66} bg="#14141c" fg="#ffe14a" />
    <Globe p={[2.1, 3.0, 0]} r={0.9} rotY={t * 0.4} />
    <Galaxy p={[-2.6, 3.0, -0.5]} r={1.1} t={t} hue={300} seed={3} />
    {/* the light beam travelling toward Earth, not arrived */}
    {t > 11.9 ? <><Box p={[(lx - 2.4) / 2, 3.0, 0]} s={[Math.max(0.01, lx + 2.4), 0.14, 0.14]} color="#fff6b0" line={0} /><Ball p={[lx, 3.0, 0]} r={0.3} color="#fff6b0" ink={0.02} /><Glow p={[lx, 3.0, 0.3]} r={1.2} color="rgba(255,240,160,1)" o={0.7} /></> : null}
    <Box p={[1.0, 3.0, 0]} s={[0.06, 2.2, 0.06]} color="#ff5a8a" line={0} />
    <Sign p={[0, 5.2, 0.4]} w={3.6 * notyet + 0.001} h={0.9 * notyet + 0.001} text="NOT HERE YET" size={38} bg="#fff" fg="#e5233a" />
    <Sign p={[2.1, 4.15, 0.6]} w={1.2} h={0.5} text="US" size={40} bg="#2f8cff" fg="#fff" />
  </>);
};

/* ============ S4 15.54 – 24.59  edge of the observable universe, 46 billion ly ============ */
export const S4 = ({ t, f }: Ctx) => {
  const bub = seg(t, 16.0, 17.4, ease), stretch = seg(t, 22.38, 23.8, ease), r = 3.2 + 1.2 * stretch, dist = seg(t, 19.07, 19.4, back), dirs = seg(t, 21.41, 22.0, back), edge = seg(t, 16.64, 17.0, back);
  return (<>
    <Cam t={t} keys={[{ t: 15.3, pos: [0, 3.0, 13], look: [0, 3.4, 0], fov: 58 }, { t: 20.0, pos: [0, 4.0, 17], look: [0, 3.6, 0], fov: 58 }, { t: 24.8, pos: [0, 4.6, 20], look: [0, 3.8, 0], fov: 60 }]} />
    <Lights warm="#b8c8ff" />
    <Space t={t} />
    {Array.from({ length: 10 }, (_, i) => { const a = i * 0.63; return <Galaxy key={i} p={[Math.cos(a) * 9, 3.6 + Math.sin(a) * 6, -6 - (i % 3)]} r={0.9} t={t} hue={180 + i * 30} seed={i} o={0.6} />; })}
    <group position={[0, 3.6, 0]} scale={[bub * r / 3.2 + 0.001, bub * r / 3.2 + 0.001, bub * r / 3.2 + 0.001]}>
      <mesh><sphereGeometry args={[3.2, 40, 24]} /><meshBasicMaterial color="#5ab0ff" transparent opacity={0.16} depthWrite={false} /></mesh>
      <mesh><sphereGeometry args={[3.22, 40, 24]} /><meshBasicMaterial color="#9fd4ff" wireframe transparent opacity={0.25} /></mesh>
    </group>
    <Globe p={[0, 3.6, 0]} r={0.5} rotY={t * 0.6} />
    {Array.from({ length: 8 }, (_, i) => { const a = i * Math.PI / 4, L = r * bub * dirs; return L > 0.05 ? <group key={i} position={[0, 3.6, 0.2]} rotation={[0, 0, a]}><Box p={[L / 2 + 0.55, 0, 0]} s={[Math.max(0.01, L - 0.6), 0.08, 0.08]} color="#ffe14a" line={0} /></group> : null; })}
    <Sign p={[0, 9.9, 0]} w={6.2 * edge + 0.001} h={1.1 * edge + 0.001} text="OBSERVABLE UNIVERSE" size={42} bg="#14141c" fg="#9fd4ff" />
    <Sign p={[0, 7.9, 1.5]} w={6.4 * dist + 0.001} h={1.2 * dist + 0.001} text="46 BILLION LIGHT-YRS" size={44} bg="#ffe14a" fg="#14141c" />
  </>);
};

/* ============ S5 24.59 – 30.16  Big Bang afterglow; beyond it? ============ */
export const S5 = ({ t, f }: Ctx) => {
  const glow = seg(t, 26.4, 27.4, ease), lab = seg(t, 27.17, 27.5, back), beyond = seg(t, 28.03, 28.6, ease), q = seg(t, 28.67, 29.0, back);
  return (<>
    <Cam t={t} keys={[{ t: 24.4, pos: [0, 3.6, 15], look: [0, 3.6, 0], fov: 58 }, { t: 28.0, pos: [0, 3.8, 18], look: [0, 3.8, 0], fov: 60 }, { t: 30.3, pos: [0, 4.4, 24], look: [0, 4.0, 0], fov: 62 }]} />
    <Lights warm="#ffd8b8" />
    <Space t={t} top="#05030f" bottom="#0a0618" />
    {/* afterglow shell drawn as a mottled disc behind */}
    <CanvasPlane p={[0, 3.8, -4]} s={[11 * (0.6 + 0.4 * glow), 11 * (0.6 + 0.4 * glow)]} px={[300, 300]} face draw={(c, W, H) => {
      c.clearRect(0, 0, W, H); const cx = W / 2; c.save(); c.beginPath(); c.arc(cx, cx, cx - 6, 0, 7); c.clip();
      for (let i = 0; i < 260; i++) { const x = ((i * 7919) % 300), y = ((i * 104729) % 300), hue = (i * 37) % 3 === 0 ? 200 : 25; c.fillStyle = `hsla(${hue},90%,${55 + (i % 4) * 6}%,${0.55 * glow})`; c.beginPath(); c.arc(x, y, 14 + (i % 5) * 3, 0, 7); c.fill(); }
      c.restore(); c.fillStyle = "#05030f"; c.beginPath(); c.arc(cx, cx, cx * 0.62, 0, 7); c.fill(); c.strokeStyle = `rgba(255,190,110,${glow})`; c.lineWidth = 8; c.beginPath(); c.arc(cx, cx, cx - 6, 0, 7); c.stroke();
    }} />
    <Globe p={[0, 3.8, -3.8]} r={0.45} rotY={t * 0.6} />
    <Sign p={[0, 8.8, -2]} w={5.8 * lab + 0.001} h={1.1 * lab + 0.001} text="BIG BANG AFTERGLOW" size={44} bg="#c0602e" fg="#fff" />
    {[[-7.5, 7], [7.5, 6], [-6.5, -0.5], [6.8, 0.2]].map(([x, y], i) => <Sign key={i} p={[x, y, -3]} w={1.4 * q + 0.001} h={1.4 * q + 0.001} text="?" size={100} bg="#000" fg="#ff5a8a" />)}
    <Sign p={[0, -1.8, -1]} w={5.6 * beyond + 0.001} h={1.1 * beyond + 0.001} text="SPACE KEEPS GOING?" size={46} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S6 30.16 – 37.81  expansion speeding up; light stops reaching us ============ */
export const S6 = ({ t, f }: Ctx) => {
  const str = seg(t, 30.6, 30.9, back), acc = seg(t, 31.4, 37.8, Easing.in(Easing.cubic)), gauge = seg(t, 32.36, 33.2, ease), stop = seg(t, 36.57, 36.9, back), cut = seg(t, 36.3, 37.0);
  const off = (i: number) => (1 + acc * 2.2) * (1 + (i % 3) * 0.15);
  return (<>
    <Cam t={t} keys={[{ t: 30.0, pos: [0, 3.6, 14], look: [0, 3.6, 0], fov: 58 }, { t: 37.9, pos: [0, 4.0, 17], look: [0, 3.8, 0], fov: 60 }]} />
    <Lights warm="#b8c8ff" />
    <Space t={t} />
    <Globe p={[0, 3.6, 0]} r={0.6} rotY={t * 0.6} />
    {Array.from({ length: 8 }, (_, i) => { const a = i * Math.PI / 4 + 0.3, R = 2.6 * off(i), x = Math.cos(a) * R, y = 3.6 + Math.sin(a) * R * 0.9; return <React.Fragment key={i}><Galaxy p={[x, y, -1]} r={0.8} t={t} hue={190 + i * 22} seed={i} />
      {i % 2 === 0 ? <Box p={[x / 2, (y + 3.6) / 2, -0.9]} s={[Math.hypot(x, y - 3.6) * (1 - cut) * 0.8 + 0.01, 0.05, 0.05]} rot={[0, 0, Math.atan2(y - 3.6, x)]} color="#fff6b0" line={0} /> : null}</React.Fragment>; })}
    <Sign p={[0, 9.8, 0]} w={3.8 * str + 0.001} h={1.2 * str + 0.001} text="STRANGER" size={56} bg="#ff5a8a" fg="#fff" />
    {/* speed gauge */}
    <CanvasPlane p={[0, 7.4, 1.5]} s={[3.0 * gauge + 0.001, 1.7 * gauge + 0.001]} px={[300, 170]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(4, 4, W - 8, H - 8, 18); c.fill(); c.stroke(); c.strokeStyle = "#444"; c.lineWidth = 16; c.beginPath(); c.arc(W / 2, H - 30, 100, Math.PI, 0); c.stroke(); c.strokeStyle = "#e5233a"; c.beginPath(); c.arc(W / 2, H - 30, 100, Math.PI, Math.PI + Math.PI * (0.15 + 0.85 * acc)); c.stroke(); const a = Math.PI + Math.PI * (0.15 + 0.85 * acc); c.strokeStyle = "#fff"; c.lineWidth = 6; c.beginPath(); c.moveTo(W / 2, H - 30); c.lineTo(W / 2 + Math.cos(a) * 85, H - 30 + Math.sin(a) * 85); c.stroke(); c.fillStyle = "#fff"; c.font = "900 24px Inter, Arial"; c.textAlign = "center"; c.fillText("EXPANSION", W / 2, 36); }} />
    <Sign p={[0, 5.6, 2.2]} w={5.4 * stop + 0.001} h={1.0 * stop + 0.001} text="LIGHT STOPS COMING" size={42} bg="#fff" fg="#e5233a" />
  </>);
};

/* ============ S7 37.81 – 40.95  galaxies fade from the sky ============ */
export const S7 = ({ t, f }: Ctx) => {
  const yrs = seg(t, 38.04, 38.4, back);
  return (<>
    <Cam t={t} keys={[{ t: 37.6, pos: [0, 2.8, 13], look: [0, 5.2, 0], fov: 58 }, { t: 41.1, pos: [0, 2.6, 11.5], look: [0, 5.6, -2], fov: 56 }]} />
    <Lights warm="#8a9ad8" />
    <Space t={t} /><Hill />
    {Array.from({ length: 10 }, (_, i) => <Galaxy key={i} p={[-5 + (i % 5) * 2.5, 6.5 + Math.floor(i / 5) * 3 + (i % 2) * 0.8, -9]} r={0.9 + (i % 3) * 0.25} t={t} hue={190 + i * 20} seed={i} o={1 - seg(t, 39.4 + i * 0.12, 39.9 + i * 0.12)} />)}
    <Sign p={[0, 3.2, 0]} w={5.4 * yrs + 0.001} h={1.1 * yrs + 0.001} text="+ BILLIONS OF YEARS" size={42} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S8 40.95 – 45.93  future astronomers see nothing ============ */
export const S8 = ({ t, f }: Ctx) => {
  const empty = seg(t, 43.11, 43.6, back), never = seg(t, 44.73, 45.0, back);
  return (<>
    <Cam t={t} keys={[{ t: 40.8, pos: [0, 3.4, 14], look: [0, 3.0, 0], fov: 58 }, { t: 46.1, pos: [0.4, 3.2, 12.5], look: [0.2, 3.2, -1], fov: 56 }]} />
    <Lights warm="#8a9ad8" />
    <Stars p={[0, 10, -30]} s={[110, 70]} t={t} top="#020104" bottom="#06040c" n={6} />
    <Hill color="#14202a" />
    <Telescope p={[-1.2, 0, 1.0]} aim={0.75} />
    <Person p={[0.6, 0, 1.6]} h={3.5} look={futureAstro} f={f} pose={{ mood: t > 43.1 ? "worry" : "deadpan", lookX: -0.3, armR: [-0.35, 0.6], armRK: 1, nerv: t > 43.1 ? 0.15 : 0 }} />
    <Sign p={[0, 8.6, -3]} w={4.6 * empty + 0.001} h={1.1 * empty + 0.001} text="ALMOST NOTHING" size={40} bg="#14141c" fg="#9fd4ff" />
    <Sign p={[0, 6.8, -2]} w={4.6 * never + 0.001} h={1.0 * never + 0.001} text="AND NEVER KNOW" size={40} bg="#fff" fg="#e5233a" />
  </>);
};

/* ============ S9 45.93 – end  "what are we missing right now?" ============ */
export const S9 = ({ t, f }: Ctx) => {
  const reveal = seg(t, 46.3, 47.4, ease);
  return (<>
    <Cam t={t} keys={[{ t: 45.7, pos: [0, 3.2, 13], look: [0, 3.0, -2], fov: 58 }, { t: 49.2, pos: [0, 3.0, 12], look: [0, 3.2, -3], fov: 56 }]} />
    <Lights warm="#9aa8e8" />
    <Space t={t} /><Hill />
    {Array.from({ length: 12 }, (_, i) => <Galaxy key={i} p={[-5 + (i % 4) * 3.3, 6 + Math.floor(i / 4) * 2.6 + (i % 2) * 0.6, -10]} r={0.8 + (i % 3) * 0.3} t={t} hue={190 + i * 18} seed={i} o={reveal * (i % 3 === 0 ? 0.25 : 1)} />)}
    <Person p={[0, 0, 1.6]} h={3.5} look={gazer} f={f} pose={{ mood: "smile", lookX: 0, armR: [0.3, 0.75], armRK: seg(t, 47.35, 47.8) }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(200,210,255,.7)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
