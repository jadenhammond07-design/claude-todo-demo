import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Unseen";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const UCUTS = [0, 3.46, 8.37, 15.54, 24.59, 30.16, 37.81, 40.95, 45.93, 49.0];
const BG = ["#05030f", "#020108", "#05030f", "#05030f", "#05030f", "#05030f", "#05030f", "#020104", "#05030f"];
const TR: Trans[] = ["ghost", "zoom", "ghost", "whip", "dip", "flash", "ghost", "dip", "ghost"];
export const UnseenMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={UCUTS[i]} end={UCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"THERE ARE GALAXIES WE'LL NEVER SEE"} until={2.8} />
    <EndQuestion text={"Do you think there's life in the part we can't see?"} from={46.0} end={48.92} />
  </AbsoluteFill>
);
