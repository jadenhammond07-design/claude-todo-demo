// MEETING YOUR TEN-YEARS-AGO SELF — 10 scenes. Generic stick figures.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Calendar } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Mug, HangLamp } from "../style/extra";
import { Sky, Flame } from "../style/medieval";
import { Heart } from "../style/studio2";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const wide = (ks: Key[], k: number): Key[] => ks.map((q) => ({ ...q, pos: [q.look[0] + (q.pos[0] - q.look[0]) * k, q.look[1] + (q.pos[1] - q.look[1]) * 1 + 0.4, q.look[2] + (q.pos[2] - q.look[2]) * k] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const now = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true, badge: "#ffc23a" });
const young = mk("#e8b88c", "#2fd4a0", "hoodie", "swept", "#3a2410", { shoe: "#c9402e" });
const future = mk("#cfd8f0", "#9ab8e0", "blazer", "grey", "#aaa", { shirt: "#fff", glasses: true });
const pastGhost = mk("#cfd8f0", "#a8d8c8", "hoodie", "swept", "#7a8aa0");
const sci = (i: number): Look => mk(["#f3d3b2", "#8d5a3a"][i], "#f4f4f4", "shirt", i ? "short" : "bob", "#3b2a1a", { glasses: true, badge: "#2f8cff" });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Cloud: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; col?: string; size?: number }> = ({ p, w, h, text, k = 1, col = "#6a5aa8", size = 44 }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); for (const [x, y, r] of [[W * 0.22, H * 0.5, H * 0.34], [W * 0.5, H * 0.38, H * 0.4], [W * 0.78, H * 0.5, H * 0.34], [W * 0.5, H * 0.62, H * 0.34]] as number[][]) { c.moveTo(x + r, y); c.arc(x, y, r, 0, 7); } c.fill(); c.stroke(); c.fillStyle = "#fff"; for (const [x, y, r] of [[W * 0.22, H * 0.5, H * 0.32], [W * 0.5, H * 0.38, H * 0.38], [W * 0.78, H * 0.5, H * 0.32], [W * 0.5, H * 0.62, H * 0.32]] as number[][]) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } c.fillStyle = col; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2); }} />
);
/* a warm cafe: table for two */
const Cafe: React.FC<{ t: number; warm?: number; tableL?: number }> = ({ t, warm = 1, tableL = 3.4 }) => (<>
  <Floor kind="plank" a="#7a5a3a" b="#6a4c30" unit={1.8} w={34} d={24} />
  <WallDoor z={-5} W={34} kind="wood" a={warm > 0.5 ? "#b8804a" : "#5a6a88"} b={warm > 0.5 ? "#a8723e" : "#4e5e7c"} base="#3a2412" /><SideWall x={-9} kind="wood" a={warm > 0.5 ? "#a8723e" : "#4e5e7c"} b={warm > 0.5 ? "#a8723e" : "#4e5e7c"} /><SideWall x={9} kind="wood" a={warm > 0.5 ? "#a8723e" : "#4e5e7c"} b={warm > 0.5 ? "#a8723e" : "#4e5e7c"} />
  <CanvasPlane p={[-5.4, 4.6, -4.9]} s={[3.2, 3.6]} px={[320, 360]} frame="#3a2412" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, warm > 0.5 ? "#ffd8a0" : "#9ab0d0"); g.addColorStop(1, warm > 0.5 ? "#ffb070" : "#6a82a8"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "rgba(0,0,0,.25)"; c.fillRect(W / 2 - 3, 0, 6, H); c.fillRect(0, H / 2 - 3, W, 6); }} />
  <Frame p={[5.2, 4.8, -4.9]} s={[1.8, 1.3]} art={2} /><Plant p={[7, 0, -3]} s={1.4} pot="#c0643a" /><Plant p={[-7.4, 0, 1]} s={1.3} pot="#c0643a" />
  <HangLamp p={[-2.0, 9.6, -0.4]} color={warm > 0.5 ? "#c9402e" : "#3a5a8a"} o={warm} /><HangLamp p={[2.0, 9.6, -0.4]} color={warm > 0.5 ? "#c9402e" : "#3a5a8a"} o={warm} />
  <Cyl p={[0, 1.0, -0.2]} rt={tableL * 0.5} h={0.2} color="#8a5a32" line={4} rot={[0, 0, 0]} /><Cyl p={[0, 0.5, -0.2]} rt={0.18} h={1.0} color="#5a3a22" line={3} />
  <Mug p={[-0.9, 1.25, -0.2]} s={1.2} /><Mug p={[0.9, 1.25, -0.2]} s={1.2} />
  {warm > 0.5 ? <><Glow p={[0, 4, 0]} r={9} color="rgba(255,190,110,1)" o={0.3} /></> : <Glow p={[0, 4, 0]} r={9} color="rgba(120,160,255,1)" o={0.25} />}
</>);

/* ============ S1 0 – 2.5  "What if you could meet yourself from ten years ago?" ============ */
const K1: Key[] = [
  { t: 0, pos: [-2.0, 3.4, 11.0], look: [0, 3.2, -1], fov: 58 },
  { t: 2.7, pos: [0.4, 3.4, 8.6], look: [0.6, 3.4, -2], fov: 52 },
];
export const S1 = ({ t, f }: Ctx) => {
  const day = Math.round(lerp(0, 10, seg(t, 0.6, 2.0, Easing.linear))), open = seg(t, 1.3, 2.2, ease), pop = seg(t, 0.6, 0.9, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K1, 1.35)} />
    <Lights warm="#e8e0ff" />
    <Floor kind="marble" a="#1c1a3a" b="#16142e" unit={2} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#24204a" b="#24204a" base="#100e24" /><SideWall x={-9} kind="plain" a="#1e1a40" b="#1e1a40" /><SideWall x={9} kind="plain" a="#1e1a40" b="#1e1a40" />
    <Box p={[2.0, 2.8, -4.7]} s={[3.2, 5.6, 0.3]} color="#3a3466" line={4} /><Box p={[2.0, 2.6, -4.5]} s={[2.6, 5.0, 0.1]} color="#ffd36a" line={2} /><Glow p={[2.0, 2.8, -4.0]} r={5} color="rgba(255,210,110,1)" o={0.55 * open + 0.2} />
    <Sign p={[2.0, 6.6, -4.2]} w={3.8} h={0.9} text="10 YEARS AGO" size={46} bg="#c0182e" fg="#fff" face={false} />
    <Calendar p={[-3.2, 5.2, -4.8]} month="YEAR" day={String(2026 - day).slice(2)} s={2.4 * pop + 0.001} />
    <Person p={[-1.6, 0, 1.4]} h={3.9} look={now} f={f} pose={{ mood: "smile", walk: t > 1.0 ? (t - 1.0) * 3 : undefined, speed: t > 1.0 ? 0.5 : 0, lookX: 0.6 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(220,210,255,.8)" />
  </>);
};

/* ============ S2 2.5 – 6.0  "Would the younger version of you even recognize the person you've become?" ============ */
const K2: Key[] = [
  { t: 2.3, pos: [-1.0, 3.6, 12.0], look: [0, 3.0, 0], fov: 58 },
  { t: 5.0, pos: [0.0, 3.4, 10.0], look: [0.6, 3.2, 0], fov: 54 },
  { t: 6.2, pos: [0.4, 3.4, 9.2], look: [0.6, 3.2, 0], fov: 50 },
];
export const S2 = ({ t, f }: Ctx) => {
  const squint = seg(t, 3.81, 4.2), q = seg(t, 5.39, 5.7, Easing.out(Easing.back(2.6))), tag = seg(t, 2.86, 3.2, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K2, 1.5)} />
    <Lights warm="#fff0d8" />
    <Cafe t={t} />
    <Chair p={[-2.4, 0, -0.2]} rotY={0.5} color="#6a3a22" /><Chair p={[2.4, 0, -0.2]} rotY={-0.5} color="#6a3a22" />
    <Person p={[-2.6, 0, 1.6]} h={3.0} look={young} f={f} pose={{ mood: squint > 0.5 ? "worry" : "smile", lookX: 0.6, tilt: 0.1 * squint, armR: [0.3, 0.45], armRK: squint }} />
    <Sign p={[-2.6, 4.2, 1.6]} w={2.4 * tag + 0.001} h={0.7} text="10 YRS AGO" size={32} bg="#2fa86a" fg="#fff" />
    <Person p={[2.6, 0, 1.6]} h={3.9} look={now} f={f + 4} pose={{ mood: "smile", flip: true, lookX: -0.4 }} />
    <FaceGroup p={[-2.6, 0, 1.6]}><Cyl p={hand(3.0, [0.3, 0.46], 0, false, 0.14)} rt={0.2} h={0.05} color="#bfe8ff" line={2} rot={[Math.PI / 2, 0, 0]} /></FaceGroup>
    <Cloud p={[0, 6.4, 1.6]} w={2.6} h={1.6} text="?" k={q} size={90} col="#e5233a" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S3 6.0 – 8.4  "You'd expect to sit across from an old friend." ============ */
const K3: Key[] = [
  { t: 5.8, pos: [0, 3.4, 11.0], look: [0, 3.0, 0], fov: 56 },
  { t: 8.6, pos: [0, 3.4, 9.2], look: [0, 3.2, 0], fov: 50 },
];
export const S3 = ({ t, f }: Ctx) => {
  const hug = seg(t, 7.48, 8.0), fr = seg(t, 7.75, 8.05, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K3, 1.45)} />
    <Lights warm="#ffe8c8" />
    <Cafe t={t} />
    <Person p={[-1.8 + 0.7 * hug, 0, 1.6]} h={3.0} look={young} f={f} pose={{ mood: "grin", arms: "up", armK: hug, lookX: 0.4, squash: -0.03 }} />
    <Person p={[1.8 - 0.7 * hug, 0, 1.6]} h={3.9} look={now} f={f + 4} pose={{ mood: "grin", arms: "up", armK: hug, flip: true, lookX: -0.4 }} />
    {Array.from({ length: 8 }, (_, i) => { const u = ((t * 0.6 + i / 8) % 1); return hug > 0.2 ? <Heart key={i} p={[Math.sin(i * 2.1) * 1.8, 4.6 + u * 3, 1.6]} s={0.5 + 0.2 * (i % 2)} /> : null; })}
    <Sign p={[0, 7.6, 1.2]} w={4.4 * fr + 0.001} h={1.1 * fr + 0.001} text="OLD FRIEND" size={58} bg="#1fa850" fg="#fff" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S4 8.4 – 12.7  "Psychologists say it might actually feel more like meeting a total stranger." ============ */
const K4: Key[] = [
  { t: 8.2, pos: [0, 3.6, 11.5], look: [0, 3.2, 0], fov: 56 },
  { t: 11.0, pos: [0, 3.8, 13.0], look: [0, 3.2, 0], fov: 58 },
  { t: 12.9, pos: [0, 3.8, 11.5], look: [0, 3.2, 0], fov: 54 },
];
export const S4 = ({ t, f }: Ctx) => {
  const cold = seg(t, 9.62, 10.4), apart = seg(t, 11.07, 11.9, ease), strg = seg(t, 11.88, 12.2, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K4, 1.4)} />
    <Lights warm={cold > 0.5 ? "#c8d8ff" : "#ffe8c8"} />
    <Cafe t={t} warm={cold > 0.5 ? 0 : 1} tableL={3.4 + 3 * apart} />
    <Person p={[-1.8 - 2.2 * apart, 0, 1.6]} h={3.0} look={young} f={f} pose={{ mood: "worry", arms: "chest", armK: cold, lookX: 0.6, nerv: 0.2 * cold }} />
    <Person p={[1.8 + 2.2 * apart, 0, 1.6]} h={3.9} look={now} f={f + 4} pose={{ mood: "worry", arms: "chest", armK: cold, flip: true, lookX: -0.6 }} />
    <Sign p={[0, 7.8, 1.4]} w={5.6 * strg + 0.001} h={1.2 * strg + 0.001} text="TOTAL STRANGER" size={48} bg="#2a3a6a" fg="#fff" />
    <Sign p={[-4.0, 4.8, 1.6]} w={2.2 * seg(t, 11.5, 11.8, Easing.out(Easing.back(2.6))) + 0.001} h={0.9} text="WHO?" size={50} bg="#fff" fg="#c0182e" /><Sign p={[4.0, 5.8, 1.6]} w={2.2 * seg(t, 11.7, 12.0, Easing.out(Easing.back(2.6))) + 0.001} h={0.9} text="WHO?" size={50} bg="#fff" fg="#c0182e" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(200,215,255,.8)" />
  </>);
};

/* ============ S5 12.7 – 17.6  "Researchers Anne Wilson and Michael Ross found that people tend to judge their past selves harshly," ============ */
const K5: Key[] = [
  { t: 12.5, pos: [-3.0, 3.8, 12.5], look: [-1.0, 3.2, 0], fov: 58 },
  { t: 15.0, pos: [0.0, 3.8, 11.5], look: [0.2, 3.2, 0], fov: 54 },
  { t: 17.8, pos: [0.6, 3.8, 10.5], look: [0.6, 3.2, 0], fov: 52 },
];
export const S5 = ({ t, f }: Ctx) => {
  const a = seg(t, 13.38, 13.7, Easing.out(Easing.back(2.6))), b = seg(t, 14.24, 14.55, Easing.out(Easing.back(2.6))), grade = seg(t, 16.18, 16.6, Easing.out(Easing.back(2.8))), harsh = seg(t, 17.41, 17.7);
  return (<>
    <Cam t={t} keys={wide(K5, 1.75)} />
    <Lights warm="#f0f4ff" />
    <Floor kind="tile" a="#dfe6ef" b="#cdd6e4" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#2a3a5a" b="#2a3a5a" base="#141e30" />
    <Box p={[2.8, 0.5, -0.4]} s={[2.4, 1.0, 2.4]} color="#8a8aa0" line={3} />
    <Person p={[2.8, 1.0, -0.4]} sy={1.0} h={3.0} look={young} f={f} pose={{ mood: harsh > 0.5 ? "worry" : "smile", hunch: 0.4 * harsh, lookX: -0.4, sweat: harsh > 0.5 ? 1 : 0 }} />
    <Sign p={[2.8, 5.2, -0.4]} w={2.4} h={0.7} text="PAST SELF" size={34} bg="#2fa86a" fg="#fff" />
    <Person p={[-0.8, 0, 2.2]} h={3.9} look={now} f={f + 3} pose={{ mood: harsh > 0.5 ? "angry" : "deadpan", armR: [0.3, 0.7], armRK: grade, lookX: 0.6, hunch: 0.1 }} />
    <Sign p={[-0.8, 5.4, 2.2]} w={3.0} h={0.8} text="PRESENT YOU" size={34} bg="#ff7a29" fg="#fff" />
    <Sign p={[0.9, 5.0, 1.8]} w={2.0 * grade + 0.001} h={1.4 * grade + 0.001} text="D-" size={110} bg="#fff" fg="#e5233a" />
    {[-4.4, -2.6].map((x, i) => <React.Fragment key={i}><Person p={[x, 0, -1.0]} h={3.8} look={sci(i)} f={f + i * 5} pose={{ mood: "deadpan", armR: [0.3, 0.55], armRK: 1, lookX: 0.5 }} /><FaceGroup p={[x, 0, -1.0]}><Box p={hand(3.8, [0.3, 0.55], 0, false, 0.1)} s={[0.5, 0.7, 0.05]} color="#c9a870" line={2} /></FaceGroup></React.Fragment>)}
    <Sign p={[-4.4, 5.2, -1.0]} w={2.8 * a + 0.001} h={0.7} text="ANNE WILSON" size={26} bg="#fff" fg="#14141c" /><Sign p={[-2.4, 6.2, -1.0]} w={3.0 * b + 0.001} h={0.7} text="MICHAEL ROSS" size={26} bg="#fff" fg="#14141c" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(230,240,255,.8)" />
  </>);
};

/* ============ S6 17.6 – 23.7  "quietly rewriting the old version of us as the chump so the current version can feel like the champion." ============ */
const K6: Key[] = [
  { t: 17.4, pos: [-1.5, 3.8, 12.0], look: [0, 3.2, 0], fov: 58 },
  { t: 20.6, pos: [0.0, 3.8, 11.0], look: [0, 3.2, 0], fov: 54 },
  { t: 22.9, pos: [1.0, 4.0, 11.5], look: [0.4, 3.6, 0], fov: 56 },
  { t: 23.9, pos: [1.0, 4.0, 11.0], look: [0.4, 3.8, 0], fov: 54 },
];
export const S6 = ({ t, f }: Ctx) => {
  const draw = seg(t, 18.65, 20.7, Easing.linear), chump = seg(t, 20.71, 21.0, Easing.out(Easing.back(2.6))), champ = seg(t, 22.97, 23.3, Easing.out(Easing.back(2.6))), erase = seg(t, 19.43, 19.9);
  return (<>
    <Cam t={t} keys={wide(K6.map((q) => ({ ...q, pos: [q.pos[0] + 2.2, q.pos[1], q.pos[2]] as V3, look: [q.look[0] + 2.2, q.look[1], q.look[2]] as V3 })), 1.75)} />
    <Lights warm="#fff4e0" />
    <Floor kind="marble" a="#e8e0f0" b="#d8d0e4" unit={2} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#6a4a8a" b="#6a4a8a" base="#3a2650" />
    {/* the rewritten storybook page */}
    <CanvasPlane p={[-3.0, 4.6, -4.8]} s={[4.6, 5.4]} px={[460, 540]} frame="#5a4228" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#6a6a7a"; c.font = "800 30px Inter, Arial"; c.textAlign = "center"; c.fillText(erase > 0.5 ? "THE NEW STORY" : "THE OLD STORY", W / 2, 50);
      c.strokeStyle = INK; c.lineWidth = 8; c.lineCap = "round"; c.fillStyle = "#e8b88c"; c.beginPath(); c.arc(W / 2, 220, 80, 0, 7); c.fill(); c.stroke(); c.fillStyle = INK; c.beginPath(); c.arc(W / 2 - 28, 205, 9, 0, 7); c.arc(W / 2 + 28, 205, 9, 0, 7); c.fill();
      if (draw > 0.2) { c.fillStyle = "#e5233a"; c.beginPath(); c.arc(W / 2, 235, 20 * Math.min(1, draw * 2), 0, 7); c.fill(); }
      if (draw > 0.5) { c.fillStyle = "#e5233a"; c.beginPath(); c.moveTo(W / 2 - 70, 160); c.lineTo(W / 2, 40 + 30 * (1 - draw)); c.lineTo(W / 2 + 70, 160); c.closePath(); c.fill(); c.stroke(); }
      c.strokeStyle = "#e5233a"; c.lineWidth = 6; c.beginPath(); c.moveTo(W / 2 - 40, 270); c.quadraticCurveTo(W / 2, 300, W / 2 + 40, 270); c.stroke();
      c.fillStyle = "#14141c"; c.font = "900 56px Inter, Arial"; c.fillText(chump > 0.5 ? "CHUMP" : "", W / 2, 440); }} />
    <group position={[-3.0 + Math.sin(t * 12) * 0.3 * (draw > 0 && draw < 1 ? 1 : 0), 3.4 + draw * 0.4, -3.9]} rotation={[0, 0, -0.6]}><Box p={[0, 0, 0]} s={[0.3, 2.6, 0.3]} color="#ffc23a" line={3} /><Cyl p={[0, -1.5, 0]} rt={0} rb={0.15} h={0.4} color="#c9a870" line={2} /><Box p={[0, 1.4, 0]} s={[0.34, 0.4, 0.34]} color="#e5233a" line={2} /></group>
    {/* the podium */}
    <Box p={[3.4, 0.6, 0]} s={[2.2, 1.2, 2.0]} color="#d8b84a" line={4} /><Box p={[5.8, 0.3, 0]} s={[2.2, 0.6, 2.0]} color="#a8a8b8" line={4} />
    <Person p={[3.4, 1.2, 0]} sy={1.2} h={3.7} look={now} f={f} pose={{ mood: champ > 0.5 ? "grin" : "smile", arms: champ > 0.3 ? "up" : undefined, armK: champ }} />
    <Person p={[5.8, 0.6, 0]} sy={0.6} h={2.8} look={young} f={f + 3} pose={{ mood: chump > 0.5 ? "worry" : "smile", hunch: 0.5 * chump, lookX: -0.4 }} />
    <Sign p={[3.4, 6.6, 0.6]} w={4.4 * champ + 0.001} h={1.2 * champ + 0.001} text="CHAMPION" size={60} fg="#14141c" bg="#ffd36a" />
    <Sign p={[5.8, 4.8, 0.6]} w={2.6 * chump + 0.001} h={0.8} text="CHUMP" size={44} bg="#6a6a7a" fg="#fff" />
    {champ > 0 ? Array.from({ length: 16 }, (_, i) => { const u = (t - 22.97) * 1.0 + i * 0.05; return <Box key={i} p={[2.0 + (i % 8) * 0.5, 8 - u * 2.2 - (i % 3) * 0.3, 0.6]} s={[0.14, 0.05, 0.1]} rot={[0, 0, t * 6 + i]} color={["#e5233a", "#2f8cff", "#ffc23a", "#2fd46a"][i % 4]} line={0} />; }) : null}
    <Dust t={t} area={[8, 6, 4]} color="rgba(240,230,255,.8)" />
  </>);
};

/* ============ S7 23.7 – 31.8  brain scan ============ */
const K7: Key[] = [
  { t: 23.5, pos: [-3.0, 3.8, 12.5], look: [-1.0, 3.2, 0], fov: 58 },
  { t: 26.0, pos: [0.0, 4.2, 12.0], look: [0, 4.0, 0], fov: 56 },
  { t: 29.0, pos: [0.0, 4.4, 11.5], look: [0, 4.4, 0], fov: 54 },
  { t: 32.0, pos: [0.0, 4.4, 11.0], look: [0, 4.4, 0], fov: 52 },
];
export const S7 = ({ t, f }: Ctx) => {
  const fut = seg(t, 26.63, 27.2), oth = seg(t, 30.18, 30.8), hal = seg(t, 23.92, 24.3, Easing.out(Easing.back(2.6))), scan = seg(t, 25.11, 25.9);
  const brain = (c: CanvasRenderingContext2D, W: number, H: number, mode: "self" | "other", act: number) => { c.fillStyle = "#06101a"; c.fillRect(0, 0, W, H); c.fillStyle = "#2a3a50"; c.strokeStyle = "#8fd0ff"; c.lineWidth = 5; c.beginPath(); c.ellipse(W / 2, H / 2, W * 0.4, H * 0.34, 0, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.moveTo(W / 2, H * 0.18); c.bezierCurveTo(W * 0.4, H * 0.4, W * 0.6, H * 0.6, W / 2, H * 0.82); c.stroke();
    const reg = mode === "self" ? [W * 0.38, H * 0.42] : [W * 0.64, H * 0.58]; const col = mode === "self" ? "255,150,60" : "80,170,255"; const g = c.createRadialGradient(reg[0], reg[1], 4, reg[0], reg[1], 70); g.addColorStop(0, `rgba(${col},${0.95 * act})`); g.addColorStop(1, `rgba(${col},0)`); c.fillStyle = g; c.fillRect(0, 0, W, H); };
  return (<>
    <Cam t={t} keys={wide(K7, 1.8)} />
    <Lights warm="#e0f0ff" />
    <Floor kind="tile" a="#cfd8e8" b="#bcc8dc" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#12203a" b="#12203a" base="#080f20" />
    <CanvasPlane p={[-2.2, 5.6, -4.9]} s={[3.8, 3.6]} px={[380, 360]} frame="#8a8aa0" draw={(c, W, H) => { brain(c, W, H, "self", 0.9); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.fillText("ABOUT ME NOW", W / 2, 34); }} />
    <CanvasPlane p={[2.2, 5.6, -4.9]} s={[3.8, 3.6]} px={[380, 360]} frame="#8a8aa0" draw={(c, W, H) => { const mode = fut > 0.5 ? "other" : "self"; brain(c, W, H, mode, 0.9); c.fillStyle = "#fff"; c.font = "900 28px Inter, Arial"; c.textAlign = "center"; c.fillText(fut > 0.5 ? "FUTURE ME" : "…", W / 2, 34); }} />
    <CanvasPlane p={[0, 1.6, -4.9]} s={[4.4, 1.2]} px={[440, 120]} frame="#8a8aa0" draw={(c, W, H) => { c.fillStyle = "#06101a"; c.fillRect(0, 0, W, H); c.fillStyle = "#4aa8ff"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.fillText(oth > 0.5 ? "FUTURE ME  ≈  OTHER PEOPLE" : "SCANNING…", W / 2, 70); }} />
    {/* scanner ring */}
    <Cyl p={[-3.0, 2.4, 1.0]} rt={2.4} h={1.4} color="#e8eef8" line={4} rot={[Math.PI / 2, 0, 0]} /><Cyl p={[-3.0, 2.4, 1.0]} rt={1.5} h={1.5} color="#14181f" line={3} rot={[Math.PI / 2, 0, 0]} /><Box p={[-3.0, 0.9, 1.0]} s={[1.4, 0.2, 5.0]} color="#bcc8dc" line={3} />
    <Glow p={[-3.0, 2.4, 2.0]} r={2.6} color="rgba(120,190,255,1)" o={0.3 * scan} />
    <Person p={[-3.0, 0.6, 2.8]} sy={0.6} h={3.0} look={now} f={f} pose={{ mood: "deadpan", lookX: 0.4, nerv: 0.1 }} />
    <Person p={[3.4, 0, 1.6]} h={3.9} look={sci(0)} f={f + 4} pose={{ mood: "smile", arms: "point", armK: seg(t, 24.8, 25.2), flip: true, lookX: -0.6 }} />
    <Sign p={[3.4, 5.4, 1.6]} w={3.4 * hal + 0.001} h={0.8} text="HAL HERSHFIELD" size={28} bg="#fff" fg="#14141c" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(200,230,255,.8)" />
  </>);
};

/* ============ S8 31.8 – 35.6  "Your past self and your future self may both feel like strangers." ============ */
const K8: Key[] = [
  { t: 31.6, pos: [0, 3.8, 14.0], look: [0, 3.0, 0], fov: 60 },
  { t: 35.8, pos: [0, 4.0, 12.0], look: [0, 3.2, 0], fov: 56 },
];
export const S8 = ({ t, f }: Ctx) => {
  const q1 = seg(t, 32.0, 32.4, Easing.out(Easing.back(2.6))), q2 = seg(t, 33.0, 33.4, Easing.out(Easing.back(2.6))), st = seg(t, 34.86, 35.2, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K8, 2.2)} />
    <Lights warm="#d8e0ff" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#2a3a6a" bottom="#8aa0d0" />
    <Surface p={[0, -0.05, -10]} s={[140, 70]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#4a5a7a" b="#4a5a7a" />
    <Surface p={[0, 0.01, 0.4]} s={[30, 3]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#8a8aa0" b="#7a7a90" unit={1.2} />
    <Person p={[-5.6, 0, 0.8]} h={3.0} look={pastGhost} f={f} pose={{ mood: "deadpan", flip: false, lookX: -0.6, hunch: 0.2 }} />
    <Person p={[0, 0, 0.8]} h={3.9} look={now} f={f + 4} pose={{ mood: "worry", lookX: 0, armR: [0.3, 0.5], armRK: 1 }} />
    <Person p={[5.6, 0, 0.8]} h={3.9} look={future} f={f + 8} pose={{ mood: "deadpan", flip: true, lookX: 0.6 }} />
    <Sign p={[-5.6, 4.6, 0.8]} w={2.4} h={0.7} text="PAST YOU" size={34} bg="#6a7a9a" fg="#fff" /><Sign p={[5.6, 5.4, 0.8]} w={2.8} h={0.7} text="FUTURE YOU" size={34} bg="#6a7a9a" fg="#fff" />
    <Sign p={[-5.6, 6.2, 0.8]} w={1.6 * q1 + 0.001} h={1.6 * q1 + 0.001} text="?" size={110} fg="#ff5a8a" bg="#14081e" /><Sign p={[5.6, 7.0, 0.8]} w={1.6 * q2 + 0.001} h={1.6 * q2 + 0.001} text="?" size={110} fg="#ff5a8a" bg="#14081e" />
    <Sign p={[0, 8.4, 0.4]} w={5.4 * st + 0.001} h={1.2 * st + 0.001} text="STRANGERS" size={60} bg="#2a3a6a" fg="#fff" />
    <Dust t={t} area={[14, 6, 5]} color="rgba(200,215,255,.8)" />
  </>);
};

/* ============ S9 35.6 – 37.9  "But you're the only link between them." ============ */
const K9: Key[] = [
  { t: 35.4, pos: [0, 3.8, 12.5], look: [0, 3.2, 0], fov: 58 },
  { t: 38.1, pos: [0, 3.8, 10.5], look: [0, 3.4, 0], fov: 52 },
];
export const S9 = ({ t, f }: Ctx) => {
  const link = seg(t, 36.43, 37.2, ease), pop = seg(t, 36.83, 37.15, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={wide(K9, 2.0)} />
    <Lights warm="#ffe8c8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#ff9a50" bottom="#ffe8b0" glowAt={[0.9, "rgba(255,220,130,1)"]} />
    <Surface p={[0, -0.05, -10]} s={[140, 70]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#5a8a4a" b="#5a8a4a" />
    <Surface p={[0, 0.01, 0.4]} s={[30, 3]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#c8b898" b="#b8a888" unit={1.2} />
    <Person p={[-4.4, 0, 0.8]} h={3.0} look={pastGhost} f={f} pose={{ mood: "smile", armR: [0.4, 0.55], armRK: link, lookX: 0.6 }} />
    <Person p={[0, 0, 0.8]} h={3.9} look={now} f={f + 4} pose={{ mood: "grin", armR: [0.42, 0.55], armRK: link, armL: [-0.42, 0.55], armLK: link, lookX: 0 }} />
    <Person p={[4.4, 0, 0.8]} h={3.9} look={future} f={f + 8} pose={{ mood: "smile", flip: true, armR: [0.42, 0.55], armRK: link, lookX: -0.6 }} />
    {Array.from({ length: 16 }, (_, i) => { const u = (i + 0.5) / 16, k = clamp(link * 1.2 - Math.abs(u - 0.5)); return k > 0 ? <Ball key={i} p={[lerp(-4.0, 4.0, u), 2.2 + Math.sin(u * Math.PI) * -0.3, 1.0]} r={0.16 * k} color="#ffd36a" ink={0.03} /> : null; })}
    <Glow p={[0, 2.4, 1.4]} r={7} color="rgba(255,210,110,1)" o={0.5 * link} />
    <Sign p={[0, 7.0, 0.8]} w={5.6 * pop + 0.001} h={1.3 * pop + 0.001} text="THE ONLY LINK" size={52} fg="#14141c" bg="#ffd36a" />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,235,190,.8)" />
  </>);
};

/* ============ S10 37.9 – 41.9  the table ============ */
const K10: Key[] = [
  { t: 37.7, pos: [0, 3.8, 13.0], look: [0, 3.0, -0.2], fov: 58 },
  { t: 40.5, pos: [0.4, 3.0, 9.0], look: [0.6, 2.6, -0.2], fov: 52 },
  { t: 42.1, pos: [0.4, 2.8, 7.6], look: [0.6, 2.6, -0.2], fov: 48 },
];
export const S10 = ({ t, f }: Ctx) => {
  const q = seg(t, 39.37, 39.7, Easing.out(Easing.back(2.6))), say = seg(t, 40.67, 41.0, Easing.out(Easing.back(2.2)));
  return (<>
    <Cam t={t} keys={wide(K10, 1.65)} />
    <Lights warm="#ffe8c8" />
    <Cafe t={t} />
    <Chair p={[-2.4, 0, -0.2]} rotY={0.5} color="#6a3a22" /><Chair p={[2.4, 0, -0.2]} rotY={-0.5} color="#6a3a22" />
    <Person p={[-2.6, 0, 1.8]} h={3.9} look={now} f={f} pose={{ mood: "smile", armR: [0.3, 0.55], armRK: seg(t, 38.5, 38.9), lookX: 0.6 }} />
    <Cloud p={[2.4, 5.8, 0.4]} w={3.4 * q + 0.001} h={2.0 * q + 0.001} text="?" k={1} size={110} col="#e5233a" />
    <Cloud p={[-2.6, 6.6, 1.8]} w={4.6 * say + 0.001} h={2.0 * say + 0.001} text="I WANT TO SAY…" k={1} size={30} col="#1f6ad8" />
    <Mug p={[0.9, 1.4, -0.2]} s={1.3} />{[0, 1, 2].map((i) => { const u = ((t * 0.7 + i / 3) % 1); return <Ball key={i} p={[0.9 + Math.sin(i * 2 + t) * 0.1, 1.8 + u * 1.2, -0.1]} r={0.1 + 0.1 * u} color="#fff" ink={0.02} />; })}
    <Glow p={[2.4, 2.6, 0.4]} r={3} color="rgba(255,200,130,1)" o={0.5} /><Dust t={t} area={[8, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
