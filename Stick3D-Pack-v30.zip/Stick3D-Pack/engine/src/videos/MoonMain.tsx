import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Moon";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const MOCUTS = [0, 4.14, 9.25, 16.39, 18.17, 21.76, 28.56, 31.5, 37.91, 40.0, 43.3];
const BG = ["#05061a", "#05061a", "#05061a", "#2a3a5a", "#05061a", "#05061a", "#05061a", "#05061a", "#05061a", "#05061a"];
const TR: Trans[] = ["ghost", "zoom", "ghost", "whip", "ghost", "dip", "flash", "zoom", "ghost", "dip"];
export const MoonMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={MOCUTS[i]} end={MOCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"WHAT IF THE MOON STARTED COMING BACK?"} until={2.9} />
    <EndQuestion text={"Would you rather it come closer or keep leaving?"} from={40.3} end={43.22} />
  </AbsoluteFill>
);
