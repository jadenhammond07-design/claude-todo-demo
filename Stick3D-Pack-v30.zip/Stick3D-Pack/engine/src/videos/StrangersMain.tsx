import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Strangers";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const SCUTS = [0, 3.86, 9.43, 15.75, 19.02, 24.37, 30.75, 34.08, 39.57, 42.95];
const BG = ["#7ab0e8", "#7ab0e8", "#c8ccd8", "#c8ccd8", "#c8ccd8", "#c8ccd8", "#ffb070", "#4a3a6a", "#7ab0e8"];
const TR: Trans[] = ["ghost", "zoom", "whip", "ghost", "dip", "flash", "zoom", "ghost", "whip"];
export const StrangersMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={SCUTS[i]} end={SCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"EVERY STRANGER YOU PASS HAS A STORY"} until={2.9} />
    <EndQuestion text={"Would YOU talk to the stranger next to you? Yes or no?"} from={40.0} end={42.86} />
  </AbsoluteFill>
);
