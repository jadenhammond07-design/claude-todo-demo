// SMALL BUSINESS IDEAS — 11 scenes. Generic stick figures, no brands.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk, Calendar } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Monitor, Chair, Cooler, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Building, StreetLamp, Hydrant, Bin, Bench, ChipStack, Mug } from "../style/extra";
import { Sky, Banner, Barrel, Crate } from "../style/medieval";
import { Car, Palm } from "../style/studio";
import { Vending, Atm, Bill, Truck } from "../style/biz";
import { Heart } from "../style/studio2";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const hero = mk("#d9a77c", "#1fb98a", "hoodie", "short", "#1a1008", { glasses: false });
const ppl: Look[] = [mk("#f3d3b2", "#3a7fd6", "shirt", "short", "#3b2a1a"), mk("#8d5a3a", "#e5533a", "hoodie", "bob", "#111"), mk("#fbe3c8", "#8a4fb8", "shirt", "swept", "#b8742a"), mk("#c98e62", "#f0b429", "hoodie", "short", "#111", { glasses: true }), mk("#e0b48c", "#2fa86a", "shirt", "bob", "#5a3420")];
const owner = mk("#f6d6bd", "#c9402e", "shirt", "grey", "#999", { badge: "#fff", shoe: "#222" });
const suit = mk("#f3d3b2", "#2d3142", "suit", "short", "#222", { tie: "#e53e3e", shoe: "#111" });
const money = (n: number) => "$" + Math.round(n).toLocaleString("en-US");
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);

/* ============ S1 0 – 3.2  "Looking for a multi-million dollar business idea? Start small." ============ */
const K1: Key[] = [
  { t: 0, pos: [0, 2.2, 11], look: [0, 7, -10], fov: 62 },
  { t: 2.0, pos: [0.4, 2.8, 9.5], look: [0, 6, -10], fov: 60 },
  { t: 3.0, pos: [1.2, 1.5, 6.6], look: [0, 0.8, 3.6], fov: 52 },
  { t: 4.0, pos: [1.0, 1.3, 6.0], look: [0, 0.9, 3.6], fov: 46 },
];
export const S1 = ({ t, f }: Ctx) => {
  const sprout = seg(t, 3.0, 3.7, Easing.out(Easing.back(2)));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#ffe8b0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#2a7ad8" bottom="#ffe8b0" glowAt={[0.8, "rgba(255,220,130,1)"]} />
    <Surface p={[0, 0, -10]} s={[80, 60]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8c890" b="#c8b880" unit={2.2} />
    {Array.from({ length: 9 }, (_, i) => <React.Fragment key={i}><Box p={[0, 0.2 + i * 0.5, 3 - i * 2.4]} s={[5 + i * 0.3, 0.4 + i * 1.0, 2.4]} color={i % 2 ? "#ffc928" : "#e0a818"} line={3} />
      <ChipStack p={[-1.6 + (i % 3) * 1.6, 0.4 + i * 1.0, 3 - i * 2.4]} n={Math.min(2 + i, 9)} color={["#e5233a", "#2f8cff", "#2fd46a"][i % 3]} r={0.45} /></React.Fragment>)}
    <Box p={[0, 11, -26]} s={[10, 12, 6]} color="#f4e8c0" line={4} /><Box p={[0, 17.5, -26]} s={[12, 1, 7]} color="#c9a032" line={3} />
    <Sign p={[0, 14, -22]} w={9} h={3} text="$$$" size={190} fg="#ffe14a" bg="#0b1a2a" />
    {[-14, -9, 9, 14].map((x, i) => <Building key={x} p={[x, 0, -20 - i]} s={[5, 12 + i * 3, 5]} color={["#4a6a9a", "#5a7aaa", "#4a6a9a", "#6a8aba"][i]} lit={0.5} trim="#2b3350" />)}
    <Glow p={[0, 12, -22]} r={14} color="rgba(255,230,120,1)" o={0.5} />
    <Person p={[-1.4, 0, 5.8]} h={3.6} look={hero} f={f} pose={{ mood: t < 2.9 ? "smile" : "grin", lookX: 0.2, armR: t < 2.9 ? [0.3, 0.85] : undefined, armRK: t < 2.9 ? 1 : 0, squash: t > 2.9 ? -0.04 : 0 }} />
    <group position={[0.6, 0.8, 3.6]} scale={Math.max(0.001, sprout)}><Cyl p={[0, 0.3, 0]} rt={0.05} h={0.6} color="#3fb84a" line={2} /><Ball p={[-0.2, 0.6, 0]} r={0.2} color="#4fd85a" s={[1.4, 0.6, 1]} ink={0.04} /><Ball p={[0.2, 0.7, 0]} r={0.2} color="#4fd85a" s={[1.4, 0.6, 1]} ink={0.04} /></group>
    <Dust t={t} area={[8, 9, 6]} color="rgba(255,240,180,.9)" />
  </>);
};

/* ============ S2 3.2 – 10.2  "A vending machine costs $1,500 to $10,000 and brings in about $300 a month." ============ */
const K2: Key[] = [
  { t: 3.0, pos: [-3.0, 3.4, 10.5], look: [0, 2.6, 0], fov: 56 },
  { t: 6.0, pos: [0.4, 3.4, 9.5], look: [0.6, 2.8, 0], fov: 54 },
  { t: 8.6, pos: [1.2, 3.2, 8.4], look: [1.2, 2.5, 0], fov: 50 },
  { t: 10.4, pos: [1.2, 3.2, 8.0], look: [1.2, 2.4, 0], fov: 48 },
];
export const S2 = ({ t, f }: Ctx) => {
  const buy = seg(t, 4.6, 5.9, Easing.linear), cx = lerp(-4.5, -1.8, seg(t, 3.6, 4.6, ease)), drop = t > 5.4 ? (t - 5.4) / 0.6 : -1, k1 = seg(t, 5.33, 5.6, Easing.out(Easing.back(2.6))), k2 = seg(t, 6.83, 7.1, Easing.out(Easing.back(2.6))), k3 = seg(t, 8.86, 9.15, Easing.out(Easing.back(2.6)));
  const coins = Array.from({ length: 10 }, (_, i) => { const t0 = 8.9 + i * 0.1, u = t - t0; return u > 0 && u < 0.6 ? [2.2 + Math.sin(i) * 0.1, 3.4 - 9 * u * u - u * 2, 1.0] as V3 : null; });
  const jar = Math.min(10, Math.max(0, Math.floor((t - 9.4) / 0.1)));
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff0e0" />
    <Floor kind="marble" a="#f0e4d8" b="#e0d0c0" unit={2} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#2fb8c8" b="#2fb8c8" base="#1a7a88" /><SideWall x={-9} kind="plain" a="#28a8b8" b="#28a8b8" /><SideWall x={9} kind="plain" a="#28a8b8" b="#28a8b8" />
    <Vending p={[1.2, 0, -1.4]} s={1.15} t={t} drop={drop} color="#e5233a" seed={2} />
    <Sign p={[-0.2, 7.3, -0.4]} w={3.3} h={1.1} text="$1,500" k={k1} size={74} /><Sign p={[2.8, 7.3, -0.4]} w={3.3} h={1.1} text="$10,000" k={k2} size={74} />
    <Sign p={[1.2, 8.7, -0.4]} w={3.4} h={1.1} text="$300/MO" k={k3} size={72} fg="#2fff9a" />
    {coins.map((c, i) => c ? <Cyl key={i} p={c} rt={0.16} h={0.04} color="#ffc928" line={2} rot={[Math.PI / 2, 0, 0]} /> : null)}
    <Cyl p={[4.6, 0.6, -0.4]} rt={0.7} rb={0.6} h={1.2} color="#bfe8ff" line={3} />{Array.from({ length: jar }, (_, i) => <Cyl key={i} p={[4.6, 0.15 + i * 0.1, -0.4]} rt={0.5} h={0.08} color="#ffc928" line={1} />)}
    <Plant p={[-6.4, 0, -2]} s={1.3} pot="#e58ab0" /><Lamp p={[6.8, 0, -3]} h={3.4} color="#fff0d0" /><Bench p={[-5.2, 0, -3.6]} /><Frame p={[-3.6, 4.8, -4.9]} s={[1.6, 1.2]} art={1} /><Frame p={[6, 4.4, -4.9]} s={[1.2, 1.6]} art={2} />
    <Person p={[-3.4, 0, 0.8]} h={3.7} look={hero} f={f} pose={{ mood: "smile", armR: [0.3, 0.7], armRK: seg(t, 3.5, 3.9) * (1 - seg(t, 4.2, 4.5)), lookX: 0.6 }} />
    <Person p={[cx, 0, 1.4]} h={3.5} look={ppl[1]} f={f + 5} pose={{ mood: "smile", walk: t > 3.6 && t < 4.6 ? (cx + 4.5) * WALK : undefined, speed: t > 3.6 && t < 4.6 ? 0.6 : 0, armR: t > 4.6 && t < 6.2 ? [0.3, 0.6] : undefined, armRK: seg(t, 4.6, 4.9) * (1 - seg(t, 6.2, 6.5)), lookX: 0.5, flip: false }} />
    {t > 4.7 && t < 5.2 ? <Cyl p={[lerp(-1.4, 0.4, (t - 4.7) / 0.5), 2.8 + 0.5 * Math.sin(((t - 4.7) / 0.5) * Math.PI), 1.2]} rt={0.14} h={0.04} color="#ffc928" line={2} rot={[Math.PI / 2, 0, 0]} /> : null}
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S3 10.2 – 15.8  "Land a spot by paying the owner 5% to 25% of sales, then stack twenty." ============ */
const K3: Key[] = [
  { t: 10.0, pos: [-1.0, 3.4, 10.0], look: [0, 2.8, 0], fov: 56 },
  { t: 13.6, pos: [0.0, 3.6, 9.0], look: [0, 3.0, 0], fov: 54 },
  { t: 14.9, pos: [0, 5.0, 13.5], look: [0, 2.6, -4], fov: 58 },
  { t: 16.0, pos: [0, 11.0, 17.5], look: [0, 1.0, -8], fov: 60 },
];
export const S3 = ({ t, f }: Ctx) => {
  const pie = seg(t, 11.85, 13.2, Easing.inOut(Easing.cubic)), pct = lerp(5, 25, pie), shake = seg(t, 11.0, 11.4), cnt = Math.min(20, Math.floor(Math.max(0, t - 14.95) / 0.05) + (t > 14.95 ? 1 : 0));
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Surface p={[0, 0, -8]} s={[80, 50]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a7a86" b="#7a7a86" />
    <WallDoor z={-2.5} W={12} kind="brick" a="#c9724a" b="#b9623a" door={{ x: 0, w: 3, h: 4.4 }} base="#5a2a1a" /><Box p={[0, 6.2, -2.4]} s={[12, 0.5, 0.4]} color="#2a1a14" line={2} />
    <Sign p={[0, 7.6, -2.2]} w={5} h={1.2} text="CORNER STORE" size={62} bg="#1f4a8a" fg="#fff" face={false} />
    <CanvasPlane p={[3.6, 4.0, 1.4]} s={[3.0, 3.4]} px={[300, 340]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#e5233a"; c.fillRect(0, 0, W, 60); c.fillStyle = "#fff"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("OWNER'S CUT", W / 2, 32); c.fillStyle = "#d8dce8"; c.beginPath(); c.arc(150, 190, 90, 0, 7); c.fill(); c.fillStyle = "#ff7a29"; c.beginPath(); c.moveTo(150, 190); c.arc(150, 190, 90, -Math.PI / 2, -Math.PI / 2 + (pct / 100) * Math.PI * 2); c.closePath(); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.beginPath(); c.arc(150, 190, 90, 0, 7); c.stroke(); c.fillStyle = INK; c.font = "900 54px Inter, Arial"; c.fillText(Math.round(pct) + "%", 150, 310); }} />
    {Array.from({ length: 20 }, (_, i) => { const born = 14.95 + i * 0.05, u = clamp((t - born) / 0.25), sc = u <= 0 ? 0.001 : (1 + 0.15 * Math.sin(u * Math.PI)) * 0.55; return u > 0 ? <Vending key={i} p={[-6.4 + (i % 5) * 3.2, 0, -5.5 - Math.floor(i / 5) * 3.4]} s={sc} color={["#e5233a", "#2f8cff", "#2fd46a", "#ffc23a", "#c24fff"][i % 5]} seed={i} /> : null; })}
    <Sign p={[0, 8.6, -3]} w={3.6} h={1.5} text={"x" + cnt} k={t > 14.9 ? 1 : 0} size={110} fg="#2fff9a" />
    <Person p={[-1.6, 0, 1.4]} h={3.8} look={hero} f={f} pose={{ mood: "grin", armR: [0.3, 0.5], armRK: shake * (1 - seg(t, 11.7, 12.0)), lookX: 0.5 }} />
    <Person p={[0.8, 0, 1.4]} h={3.7} look={owner} f={f + 4} pose={{ mood: "smile", flip: true, armR: [0.3, 0.5], armRK: shake * (1 - seg(t, 11.7, 12.0)), lookX: -0.5 }} />
    <StreetLamp p={[-5.6, 0, 1]} h={5.2} /><Bin p={[5.8, 0, 1]} /><Plant p={[5.6, 0, -1.2]} s={1.2} pot="#c0643a" /><Dust t={t} area={[8, 6, 5]} color="rgba(255,255,255,.7)" />
  </>);
};

/* ============ S4 15.8 – 25.0  "An ATM costs about the same, needs a background check, and 25 withdrawals a day at three dollars a fee is roughly $2,250 a month." ============ */
const K4: Key[] = [
  { t: 15.6, pos: [-4.0, 3.4, 10.5], look: [0.4, 3.0, 0], fov: 56 },
  { t: 18.2, pos: [-1.0, 3.6, 10.5], look: [0.6, 3.0, 0], fov: 54 },
  { t: 20.4, pos: [1.4, 3.4, 9.0], look: [1.4, 2.8, 0], fov: 52 },
  { t: 23.0, pos: [0.6, 3.6, 10.0], look: [0.8, 3.0, 0], fov: 54 },
  { t: 25.2, pos: [0.6, 3.6, 9.4], look: [0.8, 3.0, 0], fov: 52 },
];
export const S4 = ({ t, f }: Ctx) => {
  const chk = seg(t, 18.25, 19.1, Easing.linear), n = Math.min(25, Math.max(0, Math.floor((t - 19.38) / 0.105))), tot = lerp(0, 2250, seg(t, 22.71, 24.5, Easing.out(Easing.cubic)));
  const bills = Array.from({ length: 6 }, (_, i) => { const idx = n - i, t0 = 19.38 + idx * 0.105, u = t - t0; return idx > 0 && u >= 0 && u < 0.5 ? [1.4 + (idx % 3) * 0.5 - 0.5, 1.45 - 2 * u * u * 3 + 0.3 * u, 1.1 + u * 1.2] as V3 : null; });
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#e0fff0" />
    <Floor kind="tile" a="#cfd8e0" b="#bcc8d4" unit={1.8} w={34} d={24} />
    <WallDoor z={-4} W={34} kind="brick" a="#8a98b0" b="#7a88a0" base="#3a4660" /><SideWall x={-9} kind="plain" a="#7a88a0" b="#7a88a0" /><SideWall x={9} kind="plain" a="#7a88a0" b="#7a88a0" />
    <Atm p={[1.4, 0, -1.6]} s={1.15} draw={(c, W, H) => { c.fillStyle = "#052a14"; c.fillRect(0, 0, W, H); c.fillStyle = "#3dff7a"; c.textAlign = "center"; c.font = "900 26px Inter, Arial"; c.fillText(t < 19.3 ? "WELCOME" : "WITHDRAW", W / 2, 40); c.font = "900 52px Inter, Arial"; c.fillText(t < 19.3 ? "ATM" : "$" + 20 * Math.max(1, n), W / 2, 100); }} />
    <CanvasPlane p={[-3.8, 4.4, -3.9]} s={[4.0, 3.2]} px={[400, 320]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#f6f8ff"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f4a8a"; c.fillRect(0, 0, W, 66); c.fillStyle = "#fff"; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("BACKGROUND CHECK", W / 2, 34); c.textAlign = "left"; c.fillStyle = INK; c.font = "800 38px Inter, Arial"; ["ID", "CREDIT", "RECORD"].forEach((s, i) => { c.fillText(s, 40, 120 + i * 62); if (chk > (i + 0.5) / 3) { c.strokeStyle = "#1fa850"; c.lineWidth = 12; c.lineCap = "round"; c.beginPath(); c.moveTo(280, 122 + i * 62); c.lineTo(310, 150 + i * 62); c.lineTo(360, 90 + i * 62); c.stroke(); } }); }} />
    <Sign p={[5.2, 6.6, -1.2]} w={3.6} h={1.1} text={n + " / 25"} k={t > 19.3 ? 1 : 0} size={70} fg="#2fff9a" />
    <Sign p={[-0.3, 7.4, -0.6]} w={3.4} h={1.1} text={"$3 FEE"} k={seg(t, 21.0, 21.25, Easing.out(Easing.back(2.5)))} size={72} />
    <Sign p={[1.0, 8.9, -0.6]} w={5.0} h={1.5} text={money(tot)} k={t > 22.7 ? 1 : 0} size={100} fg="#2fff9a" />
    {bills.map((b, i) => b ? <Bill key={i} p={b} rot={[0.5, 0, 0.2 * i]} s={1.2} /> : null)}
    <Person p={[-1.2, 0, 1.4]} h={3.8} look={hero} f={f} pose={{ mood: "grin", armR: t > 18.25 && t < 19.2 ? [0.3, 0.5] : undefined, armRK: seg(t, 18.2, 18.4) * (1 - seg(t, 19.1, 19.3)), lookX: 0.5 }} />
    {[4.4, 6.0, 7.5].map((x, i) => <Person key={i} p={[x, 0, 1.6 + (i % 2) * 0.5]} h={3.5} look={ppl[i + 2]} f={f + i * 5} pose={{ mood: "deadpan", lookX: -0.5, flip: true, armR: [0.15, 0.6], armRK: 1 }} />)}
    <Bin p={[-6, 0, 0.2]} /><Plant p={[-7, 0, -1.6]} s={1.2} pot="#2a6a4a" /><Lamp p={[8, 0, -2]} h={3.4} color="#e0fff0" /><Dust t={t} area={[6, 5, 4]} color="rgba(220,255,240,.8)" />
  </>);
};

/* ============ S5 25.0 – 31.8  "A self-serve car wash runs 24/7, and small ones average about $41,000 a year in profit." ============ */
const K5: Key[] = [
  { t: 24.8, pos: [-5.5, 3.4, 11.0], look: [0, 2.2, 0], fov: 58 },
  { t: 27.5, pos: [0.0, 3.8, 11.5], look: [0, 3.0, 0], fov: 56 },
  { t: 29.4, pos: [3.5, 3.6, 10.5], look: [1.8, 3.0, 0], fov: 54 },
  { t: 32.0, pos: [3.2, 3.8, 10.0], look: [1.6, 3.2, 0], fov: 52 },
];
export const S5 = ({ t, f }: Ctx) => {
  const day = (Math.sin(t * 5) + 1) / 2, profit = lerp(0, 41000, seg(t, 29.27, 30.7, Easing.out(Easing.cubic)));
  const spray = Array.from({ length: 14 }, (_, i) => { const u = ((t * 2.2 + i / 14) % 1); return [-1.8 + u * 2.6 + Math.sin(i) * 0.1, 2.6 - u * 1.8 + 0.5 * Math.sin(i * 2), 0.9] as V3; });
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#e8fbff" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#4aa8f0" bottom="#e0f6ff" />
    <Surface p={[0, 0, -4]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#b8c4d0" b="#a8b4c0" unit={2} />
    <Box p={[0, 6.6, -2]} s={[11, 0.6, 5.5]} color="#e8f4ff" line={4} /><Box p={[-5.2, 3.2, -3.2]} s={[0.6, 6.4, 3]} color="#2f8cff" line={3} /><Box p={[5.2, 3.2, -3.2]} s={[0.6, 6.4, 3]} color="#2f8cff" line={3} /><Box p={[0, 3.2, -4.8]} s={[11, 6.4, 0.4]} color="#d8ecff" line={3} />
    <Sign p={[0, 7.6, 0.6]} w={6.6} h={1.3} text="SELF-SERVE CAR WASH" size={52} bg="#1f6ad8" fg="#fff" face={false} />
    <CanvasPlane p={[3.4, 3.8, -4.55]} s={[3.2, 2.6]} px={[320, 260]} frame="#14141c" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, day > 0.5 ? "#4aa8f0" : "#0a1030"); g.addColorStop(1, day > 0.5 ? "#e0f6ff" : "#2a2a6a"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = day > 0.5 ? "#ffe14a" : "#f4f0d8"; c.beginPath(); c.arc(80 + day * 160, 100, 36, 0, 7); c.fill(); }} />
    <Sign p={[-2.8, 5.4, -4.5]} w={3.0} h={1.4} text="24/7" size={100} fg="#ff5ac8" face={false} /><Glow p={[-2.8, 5.4, -4.2]} r={3.4} color="rgba(255,90,200,1)" o={0.4} />
    <Car p={[0, 0, -2.2]} color="#2f8cff" />
    {[-1.8, 0.6, 1.8].map((x, i) => <Ball key={i} p={[x + 0.3 * Math.sin(t * 3 + i), 1.5 + 0.25 * Math.sin(t * 2 + i * 2), -1.3]} r={0.32 + 0.06 * Math.sin(t * 4 + i)} color="#fff" ink={0.04} />)}
    {spray.map((s, i) => <Ball key={i} p={s} r={0.07} color="#9fe0ff" ink={0.02} />)}
    <Cyl p={[-3.4, 1.8, -3.4]} rt={0.5} h={3.6} color="#ff3b6b" line={3} rot={[0, t * 6, 0]} /><Cyl p={[3.6, 1.8, -3.4]} rt={0.5} h={3.6} color="#ffc23a" line={3} rot={[0, -t * 6, 0]} />
    <Sign p={[3.6, 8.9, 0.6]} w={4.6} h={1.4} text={money(profit) + "/YR"} k={t > 29.2 ? 1 : 0} size={64} fg="#2fff9a" />
    <Person p={[-2.2, 0, 1.4]} h={3.8} look={hero} f={f} pose={{ mood: "grin", armR: [0.36, 0.55 + 0.05 * Math.sin(t * 8)], armRK: 1, lookX: 0.5, tilt: 0.04 * Math.sin(t * 8) }} />
    <FaceGroup p={[-2.2, 0, 1.4]}><Cyl p={hand(3.8, [0.4, 0.58], 0, false, 0.1)} rt={0.06} h={1.2} color="#2a2a38" line={2} rot={[0, 0, 1.2]} /></FaceGroup>
    <Dust t={t} area={[8, 6, 5]} color="rgba(210,245,255,.9)" />
  </>);
};

/* ============ S6 31.8 – 39.5  "A laundromat costs $200,000 to $1 million, but about 95% of new ones are still open after five years." ============ */
const K6: Key[] = [
  { t: 31.6, pos: [-3.5, 3.4, 11.0], look: [0, 3.0, 0], fov: 58 },
  { t: 34.6, pos: [0.5, 3.6, 10.5], look: [0.4, 3.2, 0], fov: 54 },
  { t: 36.0, pos: [0.4, 4.4, 11.5], look: [0.4, 4.0, 0], fov: 54 },
  { t: 39.7, pos: [0.4, 4.4, 10.8], look: [0.4, 4.0, 0], fov: 52 },
];
export const S6 = ({ t, f }: Ctx) => {
  const yr = Math.min(5, Math.max(0, Math.floor((t - 36.9) / 0.4) + 1)), shown = t > 35.89;
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#fff8e0" />
    <Floor kind="tile" a="#e8e4d8" b="#d8d4c8" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#6ac8d8" b="#6ac8d8" base="#3a98a8" /><SideWall x={-9} kind="plain" a="#5ab8c8" b="#5ab8c8" /><SideWall x={9} kind="plain" a="#5ab8c8" b="#5ab8c8" />
    {[-4.8, -1.6, 1.6, 4.8].map((x, i) => <group key={i} position={[x, 0, -3.6]}><Box p={[0, 1.6, 0]} s={[2.5, 3.2, 1.8]} color={["#f4f4f4", "#ffe14a", "#f4f4f4", "#ff7a9a"][i]} line={3} /><Cyl p={[0, 1.9, 0.95]} rt={0.8} h={0.1} color="#bfe8ff" line={3} rot={[Math.PI / 2, 0, 0]} />
      <CanvasPlane p={[0, 1.9, 1.03]} s={[1.5, 1.5]} px={[150, 150]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.save(); c.translate(W / 2, H / 2); c.rotate(t * 8 * (i % 2 ? 1 : -1)); ["#e5233a", "#2f8cff", "#ffc23a", "#2fd46a"].forEach((col, k) => { c.fillStyle = col; c.beginPath(); c.arc(Math.cos(k * 1.6) * 34, Math.sin(k * 1.6) * 34, 22, 0, 7); c.fill(); }); c.restore(); }} /><Box p={[0, 3.0, 0.95]} s={[2.2, 0.3, 0.05]} color="#14141c" line={1} /></group>)}
    <Sign p={[0, 7.4, -3.6]} w={6.4} h={1.3} text="LAUNDROMAT" size={72} bg="#1f6ad8" fg="#fff" face={false} />
    <Sign p={[-1.6, 8.9, 0.2]} w={3.8} h={1.0} text="$200,000" k={seg(t, 32.94, 33.2, Easing.out(Easing.back(2.6)))} size={70} /><Sign p={[2.4, 8.9, 0.2]} w={3.8} h={1.0} text="$1 MILLION" k={seg(t, 34.27, 34.55, Easing.out(Easing.back(2.6)))} size={64} />
    {shown ? <CanvasPlane p={[0.4, 4.6, 0.8]} s={[5.4, 3.4]} px={[540, 340]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#0b1a2a"; c.fillRect(0, 0, W, H); for (let i = 0; i < 20; i++) { const x = 40 + (i % 10) * 50, y = 80 + Math.floor(i / 10) * 90, dead = i === 13 && yr >= 5; c.fillStyle = dead ? "#3a3a44" : "#2fd46a"; c.strokeStyle = INK; c.lineWidth = 4; c.fillRect(x, y, 38, 40); c.strokeRect(x, y, 38, 40); c.fillStyle = dead ? "#555" : "#ffe14a"; c.fillRect(x + 12, y + 18, 14, 22); c.fillStyle = dead ? "#444" : "#e5233a"; c.beginPath(); c.moveTo(x - 4, y); c.lineTo(x + 19, y - 22); c.lineTo(x + 42, y); c.closePath(); c.fill(); c.stroke(); } c.fillStyle = "#2fff9a"; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.fillText("95% STILL OPEN", W / 2, 38); c.fillStyle = "#ffe14a"; c.font = "800 36px Inter, Arial"; c.fillText("YEAR " + Math.max(1, yr), W / 2, H - 22); }} /> : null}
    <Person p={[-5.6, 0, 1.6]} h={3.7} look={hero} f={f} pose={{ mood: "grin", armR: [0.3, 0.55 + 0.1 * Math.sin(t * 5)], armRK: 1, lookX: 0.5 }} />
    <Box p={[6, 0.7, 1.6]} s={[2.6, 1.4, 1.2]} color="#c9a870" line={3} /><Plant p={[7.4, 0, -2.4]} s={1.3} pot="#2a6a8a" /><Lamp p={[-8, 0, -2]} h={3.4} color="#fff0d0" /><Dust t={t} area={[6, 5, 4]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S7 39.5 – 44.4  "Self-storage? Buy land, build units, hire a manager, and add truck rentals." ============ */
const K7: Key[] = [
  { t: 39.3, pos: [-3.0, 3.6, 12.0], look: [0, 2.6, -2], fov: 58 },
  { t: 41.5, pos: [0.0, 4.6, 14.0], look: [1.0, 2.4, -3], fov: 58 },
  { t: 43.2, pos: [2.0, 4.2, 13.0], look: [1.6, 2.4, -2], fov: 58 },
  { t: 44.6, pos: [3.0, 4.2, 12.0], look: [2.0, 2.4, -2], fov: 56 },
];
export const S7 = ({ t, f }: Ctx) => {
  const sold = seg(t, 40.47, 40.8, Easing.out(Easing.back(2.6)));
  const truckX = lerp(-12, -1.5, seg(t, 43.26, 44.5, Easing.out(Easing.cubic)));
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#fff0d0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#fdf0d8" />
    <Surface p={[0, 0, -8]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7ab84a" b="#7ab84a" />
    <Surface p={[0, 0.02, 0.6]} s={[40, 4.4]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a7a86" b="#7a7a86" />
    <group position={[-3.0, 0, 1.6]}><Cyl p={[0, 1.6, 0]} rt={0.08} h={3.2} color="#6a4426" line={2} /><Sign p={[0, 3.4, 0.1]} w={2.4} h={1.1} text="SOLD" k={sold} size={80} bg="#e5233a" fg="#fff" /></group>
    {Array.from({ length: 8 }, (_, i) => { const born = 41.23 + i * 0.12, u = clamp((t - born) / 0.4), sc = u <= 0 ? 0.001 : Easing.out(Easing.back(2))(u); return <group key={i} position={[-5.4 + i * 1.9, 0, -3.4]} scale={[1, sc, 1]}><Box p={[0, 1.4, 0]} s={[1.8, 2.8, 2.4]} color="#e8e4dc" line={3} /><Box p={[0, 1.1, 1.22]} s={[1.3, 2.0, 0.06]} color={["#ff7a29", "#ff8a39"][i % 2]} line={2} />{[0, 1, 2, 3].map((k) => <Box key={k} p={[0, 0.4 + k * 0.45, 1.27]} s={[1.3, 0.04, 0.02]} color="#8a4a1a" line={0} />)}</group>; })}
    <Box p={[9.8, 1.6, -3.4]} s={[3.2, 3.2, 3]} color="#2f8cff" line={3} /><Sign p={[9.8, 3.8, -1.8]} w={3.0} h={0.8} text="OFFICE" size={56} face={false} />
    <Person p={[lerp(14, 8.2, seg(t, 42.16, 42.9, ease)), 0, -1.4]} h={3.6} look={owner} f={f} pose={{ mood: "grin", walk: t > 42.16 && t < 42.9 ? (14 - 8.2 * seg(t, 42.16, 42.9, ease)) * WALK : undefined, speed: t > 42.16 && t < 42.9 ? 0.7 : 0, arms: "chest", armK: t > 42.9 ? 1 : 0, flip: true }} />
    <Truck p={[truckX, 0, 0.8]} />
    <Person p={[-0.6, 0, 3.4]} h={3.7} look={hero} f={f} pose={{ mood: "grin", armR: [0.32, 0.6], armRK: seg(t, 41.0, 41.3), lookX: -0.3 }} />
    <StreetLamp p={[6.2, 0, 2.2]} h={5.2} /><Barrel p={[-8, 0, -1]} s={0.001} /><Dust t={t} area={[8, 6, 5]} color="rgba(255,245,210,.8)" />
  </>);
};

/* ============ S8 44.4 – 46.3  "Most can run beside a day job." ============ */
const K8: Key[] = [
  { t: 44.2, pos: [-1.5, 3.4, 9.0], look: [0, 2.8, 0], fov: 56 },
  { t: 46.6, pos: [0.5, 3.4, 7.4], look: [0.4, 2.8, 0], fov: 50 },
];
export const S8 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={K8} />
  <Lights warm="#fff4e0" />
  <Floor kind="carpet" a="#8aa0c0" b="#7a90b0" unit={1.8} w={30} d={24} />
  <WallDoor z={-5} W={30} kind="plain" a="#d8e4f4" b="#d8e4f4" base="#9ab0d0" /><SideWall x={-9} kind="plain" a="#c8d8ec" b="#c8d8ec" /><SideWall x={9} kind="plain" a="#c8d8ec" b="#c8d8ec" />
  <CanvasPlane p={[-2.4, 4.8, -4.9]} s={[4, 3]} px={[400, 300]} frame="#2a3a5a" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#5aa8ff"); g.addColorStop(1, "#dff0ff"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "#ffe14a"; c.beginPath(); c.arc(300 - (t - 44.4) * 30, 90, 40, 0, 7); c.fill(); c.fillStyle = "#6a7a9a"; for (let i = 0; i < 6; i++) c.fillRect(i * 70, 200 - (i % 3) * 30, 60, 120); }} />
  <Sign p={[2.0, 6.2, -4.8]} w={3.2} h={1.0} text="DAY JOB" size={64} face={false} />
  <Desk p={[0, 0, -1.4]} w={3.8} top="#f4f4f4" leg="#8a98a8" /><Monitor p={[-0.6, 1.25, -1.6]} rot={[0, 0.15, 0]} screen="#9ab8e8" />
  <Box p={[1.5, 1.28, -1.2]} s={[0.55, 0.06, 1.0]} color="#14141c" line={2} rot={[-0.1, 0, 0]} /><CanvasPlane p={[1.5, 1.32, -1.2]} rot={[-Math.PI / 2 - 0.1, 0, 0]} s={[0.45, 0.9]} px={[90, 180]} draw={(c, W, H) => { c.fillStyle = "#052a14"; c.fillRect(0, 0, W, H); c.fillStyle = "#3dff7a"; c.font = "900 40px Inter, Arial"; c.textAlign = "center"; c.fillText("+$", W / 2, H / 2); }} />
  {Array.from({ length: 5 }, (_, i) => { const u = ((t * 1.1 + i / 5) % 1); return <Sign key={i} p={[1.5 + Math.sin(i * 2) * 0.5, 2.0 + u * 2.6, -0.8]} w={1.0 * (1 - u * 0.3)} h={0.5 * (1 - u * 0.3)} text="+$" size={44} fg="#2fff9a" bg="#06301a" />; })}
  <Person p={[-0.4, 0, -0.2]} h={3.8} look={hero} f={f} pose={{ mood: "smile", armR: [0.22 + 0.04 * Math.sin(t * 14), 0.46], armRK: 1, armL: [-0.2 - 0.04 * Math.sin(t * 13), 0.46], armLK: 1, lookX: 0.3 }} />
  <Plant p={[-6, 0, -2]} s={1.3} pot="#2a6a4a" /><Cooler p={[6.6, 0, -3]} /><Dust t={t} area={[6, 5, 4]} color="rgba(255,255,255,.8)" />
</>);

/* ============ S9 46.3 – 52.6  "These are estimates, and every one has a catch: location, upkeep, seasons, and thin margins." ============ */
const K9: Key[] = [
  { t: 46.1, pos: [-2.0, 3.6, 11.5], look: [0, 2.6, 0], fov: 58 },
  { t: 48.4, pos: [0.0, 3.4, 9.8], look: [0, 2.2, 0], fov: 54 },
  { t: 50.5, pos: [0.0, 4.2, 12.5], look: [0, 3.0, 0], fov: 60 },
  { t: 52.8, pos: [0.0, 4.2, 12.0], look: [0, 3.0, 0], fov: 58 },
];
export const S9 = ({ t, f }: Ctx) => {
  const snap = seg(t, 48.44, 48.56, Easing.in(Easing.quad)), est = seg(t, 46.62, 46.9, Easing.out(Easing.back(2.6)));
  const p = (a: number) => seg(t, a, a + 0.25, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K9} impacts={[[48.5, 0.04]]} />
    <Lights warm="#ffd8c0" />
    <Floor kind="plank" a="#4a2a2a" b="#3e2222" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#5a1620" b="#5a1620" base="#2a0a10" /><SideWall x={-9} kind="plain" a="#4a1018" b="#4a1018" /><SideWall x={9} kind="plain" a="#4a1018" b="#4a1018" />
    <Sign p={[0, 6.8, -0.5]} w={4.6} h={1.1} text="≈ ESTIMATES" k={est} size={70} fg="#ffc23a" />
    {/* mousetrap with a bill as bait */}
    <Box p={[0, 0.3, 0.4]} s={[4.2, 0.4, 2.4]} color="#c9985a" line={4} /><Bill p={[1.0, 0.65, 0.4]} rot={[-Math.PI / 2, 0, 0.2]} s={1.2} />
    <group position={[-1.7, 0.55, 0.4]} rotation={[0, 0, (1 - snap) * 1.1 - 0.05]}><Box p={[1.8, 0.1, 0]} s={[3.6, 0.1, 0.2]} color="#c0c8d8" line={3} /><Box p={[0.1, 0.1, 0]} s={[0.2, 0.2, 2.0]} color="#c0c8d8" line={3} /></group>
    <Cyl p={[-1.7, 0.75, 0.4]} rt={0.3} h={0.3} color="#8a96a8" line={2} rot={[Math.PI / 2, 0, 0]} />
    <Sign p={[-3.6, 4.4, -0.4]} w={2.8} h={0.9} text="LOCATION" k={p(49.06)} size={44} bg="#ffd23a" fg="#14141c" /><Sign p={[3.6, 4.4, -0.4]} w={2.4} h={0.9} text="UPKEEP" k={p(49.95)} size={48} bg="#ffd23a" fg="#14141c" />
    <Sign p={[-3.2, 2.8, -0.2]} w={2.6} h={0.9} text="SEASONS" k={p(50.59)} size={46} bg="#ffd23a" fg="#14141c" /><Sign p={[3.4, 2.8, -0.2]} w={3.2} h={0.9} text="THIN MARGINS" k={p(51.56)} size={38} bg="#ffd23a" fg="#14141c" />
    {[-1, 1].map((d) => <Box key={d} p={[d * 6.4, 0.3, -2]} s={[1.4, 0.1, 0.6]} color="#ffd23a" line={2} rot={[0, 0, 0]} />)}
    <Person p={[-3.4, 0, 2.2]} h={3.8} look={hero} f={f} pose={{ mood: t < 48.5 ? "worry" : "shock", sweat: 1, nerv: 0.3, armR: t < 48.44 ? [0.3, 0.4] : undefined, armRK: t < 48.44 ? 1 : 0, arms: t > 48.5 ? "head" : undefined, armK: seg(t, 48.5, 48.8), squash: t > 48.5 ? -0.12 * Math.exp(-(t - 48.5) * 6) : 0, air: t > 48.5 && t < 48.7 ? 1 : 0, lookX: -0.4 }} />
    <Glow p={[0, 3, 1]} r={8} color="rgba(255,90,60,1)" o={0.25} /><Dust t={t} area={[6, 5, 4]} color="rgba(255,190,150,.8)" />
  </>);
};

/* ============ S10 52.6 – 56.2  "One machine will never make you rich. Owning many might." ============ */
const K10: Key[] = [
  { t: 52.4, pos: [0.0, 2.8, 8.5], look: [0, 2.2, 0], fov: 54 },
  { t: 54.6, pos: [0.0, 3.0, 8.0], look: [0, 2.2, 0], fov: 54 },
  { t: 55.6, pos: [0, 7.0, 17.0], look: [0, 3.0, -4], fov: 60 },
  { t: 56.4, pos: [0, 8.0, 18.5], look: [0, 3.2, -4], fov: 60 },
];
export const S10 = ({ t, f }: Ctx) => {
  const many = seg(t, 54.93, 55.0), meter = t < 54.93 ? 0.08 : lerp(0.08, 1, seg(t, 54.93, 56.0, Easing.out(Easing.cubic)));
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#fff4d0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#ff9a3a" bottom="#ffe8a8" glowAt={[0.8, "rgba(255,230,130,1)"]} />
    <Surface p={[0, 0, -10]} s={[80, 50]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#e8d8a8" b="#d8c898" unit={2.2} />
    <Vending p={[1.4, 0, -1.6]} s={1.1} color="#e5233a" seed={3} />
    <ChipStack p={[-1.4, 0, -0.4]} n={2} color="#e5a02a" r={0.45} />
    {Array.from({ length: 28 }, (_, i) => { const born = 54.93 + (i % 14) * 0.04 + Math.floor(i / 14) * 0.2, u = clamp((t - born) / 0.3), sc = u <= 0 ? 0.001 : (1 + 0.2 * Math.sin(u * Math.PI)) * 0.5; return many > 0 && i > 0 ? <Vending key={i} p={[-9 + (i % 7) * 3.0, 0, -6 - Math.floor(i / 7) * 3.2]} s={sc} color={["#e5233a", "#2f8cff", "#2fd46a", "#ffc23a", "#c24fff", "#ff7a29"][i % 6]} seed={i} /> : null; })}
    {Array.from({ length: 18 }, (_, i) => <ChipStack key={i} p={[-2.6 + (i % 6) * 0.9 - 0.2 * Math.floor(i / 6), Math.floor(i / 6) * 0.1, 2 + Math.floor(i / 6) * 0.6]} n={many > 0 ? 3 + (i % 5) * 2 : 0} color={["#e5a02a", "#ffc928"][i % 2]} r={0.4} />)}
    <CanvasPlane p={[-3.6, 5.4, 1.0]} s={[1.0, 4.0]} px={[100, 400]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#2a2a3a"; c.fillRect(0, 0, W, H); c.fillStyle = meter > 0.7 ? "#2fd46a" : "#e5233a"; c.fillRect(8, H - 8 - (H - 16) * meter, W - 16, (H - 16) * meter); c.fillStyle = "#fff"; c.font = "900 20px Inter, Arial"; c.textAlign = "center"; c.fillText("$", W / 2, 28); }} />
    <Person p={[-0.4, 0, 1.6]} h={3.8} look={hero} f={f} pose={{ mood: t < 54.93 ? "worry" : "grin", arms: t < 54.93 ? "shrug" : "up", armK: t < 54.93 ? seg(t, 52.9, 53.3) : seg(t, 55.0, 55.3), sweat: t < 54.9 ? 1 : 0, squash: t > 55.0 ? -0.05 * Math.exp(-(t - 55) * 5) : 0 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,240,180,.9)" />
  </>);
};

/* ============ S11 56.2 – 59.0  "So how many could you own a year from now?" ============ */
const K11: Key[] = [
  { t: 56.0, pos: [0, 3.8, 14.0], look: [0, 3.2, 0], fov: 58 },
  { t: 59.2, pos: [0, 3.6, 11.5], look: [0, 3.2, 0], fov: 52 },
];
export const S11 = ({ t, f }: Ctx) => {
  const filled = Math.floor(clamp((t - 57.0) / 1.6) * 8), q = seg(t, 56.3, 56.7, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#ffe8c8" />
    <Floor kind="marble" a="#14203a" b="#101a30" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e1630" b="#0e1630" base="#060a18" /><SideWall x={-9} kind="plain" a="#0b1228" b="#0b1228" /><SideWall x={9} kind="plain" a="#0b1228" b="#0b1228" />
    <SpotCone p={[0, 10, 0]} h={10} r={2.6} color="#fff2c0" o={0.15} />
    <Sign p={[0, 8.4, -3]} w={5.6} h={1.5} text="A YEAR FROM NOW" size={56} face={false} /><Sign p={[0, 6.0, -2.6]} w={3.2 * q + 0.001} h={3.2 * q + 0.001} text="?" size={240} fg="#ff5a8a" bg="#14081e" />
    {Array.from({ length: 8 }, (_, i) => <React.Fragment key={i}>{i < filled ? <Vending p={[-6.3 + i * 1.8, 0, -3.6]} s={0.55} color={["#e5233a", "#2f8cff", "#2fd46a", "#ffc23a", "#c24fff", "#ff7a29", "#e5233a", "#2f8cff"][i]} seed={i} /> : <Box p={[-6.3 + i * 1.8, 1.3, -3.6]} s={[1.3, 2.4, 0.8]} color="#1c2a4a" line={2} />}</React.Fragment>)}
    <Person p={[0, 0, 1.0]} h={3.9} look={hero} f={f} pose={{ mood: "smile", arms: "point", armK: seg(t, 56.6, 56.9), lookX: 0 }} />
    <Dust t={t} area={[6, 6, 4]} color="rgba(255,240,200,.9)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11 };
