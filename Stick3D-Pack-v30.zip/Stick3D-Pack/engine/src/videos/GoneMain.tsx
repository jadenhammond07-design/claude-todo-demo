import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Gone";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const GCUTS = [0, 4.19, 7.89, 9.88, 16.2, 20.72, 24.84, 31.18, 34.93, 41.26, 50.65, 52.9];
const BG = ["#5aa0e8", "#ffb070", "#3a4050", "#32323e", "#0a0e24", "#6a5a7a", "#7ab0e8", "#6ab0e0", "#8aa0b8", "#3a2a5a", "#2a1a40"];
const TR: Trans[] = ["ghost", "zoom", "whip", "dip", "ghost", "dip", "flash", "zoom", "ghost", "whip", "ghost"];
export const GoneMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 11 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={GCUTS[i]} end={GCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"EVERY HUMAN GONE. WHAT'S LEFT?"} until={2.6} />
    <EndQuestion text={"What do YOU think would be the last thing left of us?"} from={50.0} end={52.82} />
  </AbsoluteFill>
);
