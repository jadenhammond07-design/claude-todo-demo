// A RIVALRY THAT ENDED IN A COURTROOM — 13 scenes. Generic stick-figure stand-ins, no weapons shown, no gore.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Building, StreetLamp, Barrier, Curtain } from "../style/extra";
import { Sky, Flame, Note, danceBeat } from "../style/medieval";
import { Car, Palm } from "../style/studio";
import { Truck } from "../style/biz";
import { MicStand } from "../style/studio";
import { Phone, Heart } from "../style/studio2";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const mo3 = mk("#a86b45", "#2a2a38", "hoodie", "short", "#111", { badge: "#c9a032", shoe: "#f4f4f4" });
const beezy = mk("#8d5a3a", "#6a2a2a", "hoodie", "swept", "#111", { glasses: true, shoe: "#222" });
const police = mk("#f0cfae", "#1f3a6a", "leather", "short", "#222", { hat: "#1f3a6a", badge: "#ffc23a", shoe: "#111" });
const police2 = mk("#c98e62", "#1f3a6a", "leather", "short", "#111", { hat: "#1f3a6a", badge: "#ffc23a", shoe: "#111" });
const suit = mk("#f3d3b2", "#2d3142", "suit", "short", "#222", { tie: "#8a1a2e", shoe: "#111" });
const suit2 = mk("#e0b48c", "#3a3a4a", "suit", "bob", "#3b2a1a", { tie: "#1f4a8a", shoe: "#111" });
const judge = mk("#f6d6bd", "#14141c", "leather", "grey", "#aaa", { glasses: true, shoe: "#111" });
const shadow = mk("#0c0c12", "#0c0c12", "hoodie", "none", "#000", { shoe: "#000" });
const jurors: Look[] = [mk("#f3d3b2", "#7a5a3a", "shirt", "short", "#3b2a1a"), mk("#8d5a3a", "#3a7fd6", "shirt", "bob", "#111"), mk("#fbe3c8", "#8a4fb8", "shirt", "grey", "#999"), mk("#c98e62", "#2fa86a", "hoodie", "short", "#111"), mk("#e0b48c", "#c0402e", "shirt", "swept", "#5a3420"), mk("#f3d3b2", "#d6a43a", "shirt", "bob", "#7a4a1c")];
const TAG = (txt: string, p: V3, k = 1, col = "#ffe14a") => (
  <CanvasPlane p={p} s={[1.7 * k + 0.001, 0.6 * k + 0.001]} px={[170, 60]} face draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(4, 4, W - 8, H - 8, 12); c.fill(); c.stroke(); c.fillStyle = col; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(txt, W / 2, H / 2 + 2); }} />
);
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const YearCal: React.FC<{ p: V3; s?: number; top: string; big: string; sub?: string; rot?: V3; face?: boolean }> = ({ p, s = 2, top, big, sub, rot, face }) => (
  <CanvasPlane p={p} s={[s, s * 1.15]} rot={rot} face={face} px={[400, 460]} frame={INK} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#c0182e"; c.fillRect(0, 0, W, 110); c.fillStyle = "#fff"; c.font = "900 72px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(top, W / 2, 58); c.fillStyle = INK; c.font = `900 ${big.length > 3 ? 150 : 230}px Inter, Arial`; c.fillText(big, W / 2, 255); if (sub) { c.fillStyle = "#6a6a7a"; c.font = "800 52px Inter, Arial"; c.fillText(sub, W / 2, 400); } }} />
);
export const tintFor = (_i: number): ((t: number) => string) | undefined => () => "#dfe4ee";

const Highway: React.FC<{ t: number; len?: number }> = ({ t, len = 120 }) => (<>
  <Surface p={[0, 0, -30]} s={[22, len]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" />
  <Surface p={[-17, -0.01, -30]} s={[12, len]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8a9a6a" b="#8a9a6a" /><Surface p={[17, -0.01, -30]} s={[12, len]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8a9a6a" b="#8a9a6a" />
  {Array.from({ length: 30 }, (_, i) => [-4, 0, 4].map((x) => <Box key={i + "_" + x} p={[x, 0.02, 20 - i * 4]} s={[0.2, 0.03, 2]} color="#f4e8a0" line={0} />))}
  <Box p={[0, 0.5, -30]} s={[0.8, 1.0, len]} color="#b8b8c0" line={2} />
  <Box p={[-9.2, 0.02, -30]} s={[0.2, 0.03, len]} color="#fff" line={0} /><Box p={[9.2, 0.02, -30]} s={[0.2, 0.03, len]} color="#fff" line={0} />
</>);

/* ============ S1 0 – 4.9  "November 11, 2020, around noon. Interstate 35 in Dallas." ============ */
const K1: Key[] = [
  { t: 0, pos: [9, 18, 22], look: [0, 0, -10], fov: 60 },
  { t: 2.6, pos: [6, 10, 16], look: [0, 3, -12], fov: 58 },
  { t: 5.2, pos: [1.5, 4.4, 11], look: [0, 3.4, -10], fov: 56 },
];
export const S1 = ({ t, f }: Ctx) => {
  const pop = seg(t, 0.4, 0.8, Easing.out(Easing.back(2.4))), sign = seg(t, 2.85, 3.2, Easing.out(Easing.back(2.4)));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff8e8" />
    <Sky p={[0, 30, -90]} s={[300, 150]} top="#6aa0e0" bottom="#e8f0ff" />
    <Ball p={[6, 40, -70]} r={5} color="#fffbe0" ink={0} /><Glow p={[6, 40, -69]} r={20} color="rgba(255,250,210,1)" o={0.5} />
    <Highway t={t} />
    {/* cars on the interstate */}
    {Array.from({ length: 10 }, (_, i) => { const lane = [-6, -2, 2, 6][i % 4], dir = lane < 0 ? 1 : -1, z = ((t * (6 + (i % 3)) * dir + i * 13) % 70) - 40; return <group key={i} position={[lane, 0, z]} rotation={[0, dir > 0 ? -Math.PI / 2 : Math.PI / 2, 0]} scale={1.1}><Car p={[0, 0, 0]} color={["#e5233a", "#2f8cff", "#f4f4f4", "#2a2a38", "#ffc23a"][i % 5]} /></group>; })}
    {/* overhead gantry with the I-35 shield */}
    {[-10, 10].map((x) => <Box key={x} p={[x, 3.6, -12]} s={[0.6, 7.2, 0.6]} color="#8a8a96" line={3} />)}<Box p={[0, 7.0, -12]} s={[21, 0.6, 0.8]} color="#8a8a96" line={3} />
    <CanvasPlane p={[0, 6.0, -11.5]} s={[7, 2.4]} px={[700, 240]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#0d6a3a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 90px Inter, Arial"; c.textAlign = "left"; c.textBaseline = "middle"; c.fillText("DALLAS", 40, H / 2 + 4); c.fillStyle = "#1f4a8a"; c.strokeStyle = "#fff"; c.lineWidth = 8; c.beginPath(); c.roundRect(470, 28, 190, 180, 40); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 70px Inter, Arial"; c.textAlign = "center"; c.fillText("I-35", 565, 120); }} />
    {/* skyline */}
    {[-16, -11, -6, 5, 10, 16].map((x, i) => <Building key={x} p={[x, 0, -40 - (i % 3) * 3]} s={[5, 10 + (i % 4) * 5, 5]} color={["#7a8aaa", "#8a9ab8", "#6a7a9a"][i % 3]} lit={0.2} trim="#2b3350" />)}
    <Cyl p={[0, 12, -46]} rt={0.4} h={24} color="#9aa8c0" line={2} /><Ball p={[0, 25, -46]} r={2.4} color="#bfe0ff" />
    <YearCal p={[-8.6, 5.2, 3]} s={2.8 * pop + 0.001} top="NOV" big="11" sub="2020" /><Sign p={[8.6, 5.4, 3]} w={3.2} h={1.1} text="NOON" k={sign} size={74} face={false} />
    <Sign p={[8.6, 3.6, 3]} w={0.2} h={0.2} text="" k={0.001} />
    <Cyl p={[-8.6, 2.4, 3]} rt={0.1} h={4.8} color="#5a5a6a" line={2} /><Cyl p={[8.6, 2.4, 3]} rt={0.1} h={4.8} color="#5a5a6a" line={2} />
    <Dust t={t} area={[10, 8, 6]} color="rgba(255,255,240,.7)" />
  </>);
};

/* ============ S2 4.9 – 9.0  "MO3's car stops near the zoo, and a man steps out with a rifle." ============ */
const K2: Key[] = [
  { t: 4.7, pos: [-1.0, 3.0, 10.0], look: [0.4, 1.8, 0], fov: 54 },
  { t: 7.0, pos: [1.0, 2.8, 9.4], look: [1.4, 1.8, 0], fov: 52 },
  { t: 8.4, pos: [2.2, 2.6, 7.6], look: [2.6, 2.0, 0], fov: 46 },
  { t: 9.2, pos: [2.4, 2.6, 7.4], look: [2.6, 2.0, 0], fov: 46 },
];
export const S2 = ({ t, f }: Ctx) => {
  const x = (t0: number, stop: number, x0: number, x1: number) => t < t0 ? x0 : t < stop ? lerp(x0, x1, Easing.out(Easing.quad)(clamp((t - t0) / (stop - t0)))) : x1;
  const carX = x(4.7, 6.0, -10, 3.0), suvX = x(4.9, 6.5, -14, -2.0), brake = t > 5.4 && t < 6.2, out = seg(t, 7.2, 7.8, ease), fig = seg(t, 7.35, 8.2, ease), freeze = t > 8.4;
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff8e8" />
    <Sky p={[carX, 26, -50]} s={[300, 150]} top="#6aa0e0" bottom="#e8f0ff" />
    <Surface p={[0, 0, -4]} s={[120, 22]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" /><Surface p={[0, 0.01, 8]} s={[120, 3]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8a8a96" b="#8a8a96" />
    {Array.from({ length: 26 }, (_, i) => <Box key={i} p={[-30 + i * 3.5, 0.02, 2.2]} s={[1.6, 0.03, 0.2]} color="#f4e8a0" line={0} />)}
    <Box p={[0, 0.5, -6.4]} s={[120, 1.0, 0.7]} color="#b8b8c0" line={2} />
    {/* the zoo exit sign + giraffe */}
    <Cyl p={[6.0, 3.0, -5.6]} rt={0.12} h={6} color="#5a5a6a" line={2} /><CanvasPlane p={[6.0, 6.4, -5.4]} s={[4.4, 2.4]} px={[440, 240]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#0d6a3a"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 92px Inter, Arial"; c.textAlign = "left"; c.textBaseline = "middle"; c.fillText("ZOO", 30, 90); c.fillText("→", 280, 90); c.fillStyle = "#ffc23a"; c.fillRect(30, 150, 24, 70); c.fillRect(70, 150, 24, 70); c.fillRect(24, 120, 80, 44); c.fillRect(96, 70, 18, 80); c.beginPath(); c.arc(114, 66, 20, 0, 7); c.fill(); }} />
    {[-9, -4.2, 8.6].map((px, i) => <Palm key={i} p={[px, 0, -8]} h={6 + i} sway={Math.sin(t + i)} />)}
    <Building p={[-4, 0, -16]} s={[6, 9, 4]} color="#8a9ab8" lit={0.2} trim="#2b3350" /><Building p={[3, 0, -16]} s={[5, 12, 4]} color="#7a8aaa" lit={0.2} trim="#2b3350" />
    {/* MO3's car brakes to a stop */}
    <Car p={[carX, 0, 0]} color="#2f8cff" />
    <Person p={[carX - 0.2, 0.5, 0]} sy={0.5} h={2.7} look={mo3} f={f} pose={{ mood: freeze ? "shock" : "deadpan", armR: [0.3, 0.32], armRK: 1, armL: [0.3, 0.32], armLK: 1, tilt: t > 5.4 && t < 6.1 ? 0.12 : 0, lookX: 0.3 }} />
    {brake ? <Glow p={[carX - 1.7, 0.8, 0.5]} r={1.6} color="rgba(255,40,40,1)" o={0.9} /> : null}
    {TAG("MO3", [carX, 4.0, 0.4], seg(t, 5.08, 5.3, Easing.out(Easing.back(2.4))))}
    {/* a dark SUV pulls up behind */}
    <group position={[suvX, 0, 0.2]}><Box p={[0, 0.9, 0]} s={[3.8, 1.2, 1.7]} color="#14141c" line={3} /><Box p={[-0.2, 1.8, 0]} s={[2.4, 0.8, 1.6]} color="#1c1c26" line={3} /><Box p={[0.6, 1.8, 0.82]} s={[0.9, 0.55, 0.04]} color="#5a7a9a" line={1} />
      {[-1.2, 1.2].map((px) => <Cyl key={px} p={[px, 0.4, 0.8]} rt={0.42} h={0.25} color="#0a0a10" line={2} rot={[Math.PI / 2, 0, 0]} />)}
      <group position={[0.2, 1.3, 0.86]} rotation={[0, -out * 1.2, 0]}><Box p={[0.4, 0, 0]} s={[0.8, 1.0, 0.05]} color="#1c1c26" line={1} /></group></group>
    {t > 7.35 ? <Person p={[lerp(suvX + 0.6, suvX + 2.2, fig), 0, 1.6]} h={3.5} look={shadow} f={f} pose={{ mood: "deadpan", walk: fig < 1 ? fig * 3.2 * WALK : undefined, speed: fig < 1 ? 0.6 : 0, lookX: 0.5 }} /> : null}
    {freeze ? [0, 1, 2, 3, 4, 5].map((i) => { const u = (t - 8.4) * 1.2; return <Box key={i} p={[1 + i * 0.9 + u * 3, 6 + u * 2.4 + (i % 2) * 0.6, -2]} s={[0.35, 0.05, 0.12]} rot={[0, 0, Math.sin(t * 20 + i) * 0.5]} color="#14141c" line={0} />; }) : null}
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,255,240,.7)" />
  </>);
};

/* ============ S3 9.0 – 12.4  "The rapper runs across the highway on foot. He doesn't make it." ============ */
const RX3 = (t: number) => lerp(-9, 2.0, seg(t, 9.0, 11.7, Easing.in(Easing.sin)));
const K3: Key[] = [8.8, 9.8, 10.6, 11.3, 12.0, 12.8].map((tt) => ({ t: tt, pos: [Math.min(RX3(tt) + 1.6, 3.6), 3.2, 11.0] as V3, look: [Math.min(RX3(tt) + 2.0, 4.0), 2.2, 0] as V3, fov: 56 }));
export const S3 = ({ t, f }: Ctx) => {
  const rx = RX3(t), run = t < 11.5, truck = seg(t, 11.3, 12.4, Easing.linear);
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff8e8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#6aa0e0" bottom="#e8f0ff" />
    <Highway t={t} />
    {[-6, -2, 2, 6].map((lx, i) => <group key={i} position={[lx, 0, ((t * 9 * (i % 2 ? 1 : -1) + i * 17) % 60) - 20]} rotation={[0, i % 2 ? -Math.PI / 2 : Math.PI / 2, 0]}><Car p={[0, 0, 0]} color={["#e5233a", "#f4f4f4", "#ffc23a", "#2a2a38"][i]} /></group>)}
    <group position={[2, 0, lerp(-30, 16, truck)]} rotation={[0, -Math.PI / 2, 0]} scale={1.3}><Truck p={[0, 0, 0]} label="FREIGHT" color="#e5533a" /></group>
    {t < 12.08 ? <Person p={[rx, 0, 1.2]} h={3.6} look={mo3} f={f} pose={{ mood: "worry", walk: run ? rx * WALK * 0.8 : undefined, speed: run ? 1 : 0, sweat: 1, tilt: 0.1, arms: "up", armK: 0.5 }} /> : null}
    {t < 12.08 ? TAG("MO3", [rx, 4.5, 1.2], 1) : null}
    {t > 11.9 ? <Box p={[2.6, 0.1, 2]} s={[0.5, 0.18, 0.25]} color="#f4f4f4" line={2} rot={[0, 0.4, 0]} /> : null}
    {t > 11.9 ? <Glow p={[2.6, 0.4, 2]} r={1.6} color="rgba(255,255,255,1)" o={0.4} /> : null}
    <Barrier p={[-9.6, 0, 3]} w={2.4} /><StreetLamp p={[9.6, 0, -4]} h={5.6} flip /><Dust t={t} area={[10, 6, 6]} color="rgba(255,255,240,.7)" />
  </>);
};

/* ============ S4 12.4 – 14.7  "Another driver is hit but survives." ============ */
const K4: Key[] = [
  { t: 12.2, pos: [-3.0, 3.0, 10.0], look: [0.0, 2.0, 0], fov: 56 },
  { t: 14.9, pos: [0.4, 3.2, 9.0], look: [0.8, 2.2, 0], fov: 52 },
];
export const S4 = ({ t, f }: Ctx) => {
  const amb = lerp(14, 4.8, seg(t, 12.7, 13.8, Easing.out(Easing.cubic))), blink = Math.sin(t * 16) > 0, up = seg(t, 13.89, 14.2, Easing.out(Easing.back(2)));
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff0e0" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#7a9ac0" bottom="#e8eef8" />
    <Surface p={[0, 0, -4]} s={[60, 22]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" /><Surface p={[0, 0.01, 7.6]} s={[60, 3.4]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8a8a96" b="#8a8a96" />
    <Box p={[0, 0.5, -6.4]} s={[60, 1.0, 0.7]} color="#b8b8c0" line={2} />
    <group position={[-0.5, 0, 1.0]} rotation={[0, 0.2, 0]}><Car p={[0, 0, 0]} color="#ffc23a" crumple={1} rotZ={0.04} /></group>
    {[-2.2, 0.9].map((x, i) => <Glow key={i} p={[x, 1.2, 1.9]} r={1.2} color="rgba(255,170,40,1)" o={(blink ? 0.9 : 0.1)} />)}
    <group position={[amb, 0, 3.2]}><Box p={[0, 1.4, 0]} s={[5.4, 2.4, 1.9]} color="#f4f4f4" line={3} /><Box p={[2.0, 1.2, 0]} s={[1.5, 1.8, 1.9]} color="#e8e8f0" line={3} /><Box p={[0, 1.5, 0.97]} s={[3.0, 0.28, 0.04]} color="#e5233a" line={0} />
      {[-1.7, 1.7].map((x) => <Cyl key={x} p={[x, 0.45, 0.9]} rt={0.45} h={0.25} color="#14141c" line={2} rot={[Math.PI / 2, 0, 0]} />)}
      <Glow p={[-1, 2.8, 0]} r={2.2} color="rgba(255,40,40,1)" o={blink ? 0.9 : 0.1} /><Glow p={[1, 2.8, 0]} r={2.2} color="rgba(40,80,255,1)" o={blink ? 0.1 : 0.9} /></group>
    <Person p={[2.4, 0, 3.6]} h={3.6} look={mk("#f3d3b2", "#3a7fd6", "shirt", "short", "#3b2a1a")} f={f} pose={{ mood: up > 0.5 ? "smile" : "worry", sweat: up > 0.5 ? 0 : 1, nerv: up > 0.5 ? 0 : 0.5, hunch: 0.4 * (1 - up), armR: [0.2, 0.75], armRK: 1 - up, arms: up > 0.5 ? "up" : undefined, armK: up > 0.5 ? seg(t, 14.0, 14.3) * 0.6 : 0, lookX: -0.4 }} />
    <Dust t={t} area={[8, 5, 4]} color="rgba(240,240,250,.7)" />
  </>);
};

/* ============ S5 14.7 – 17.7  "For years, no one is convicted of ordering it." ============ */
const K5: Key[] = [
  { t: 14.5, pos: [-2.5, 3.6, 12.5], look: [0, 3.2, -1], fov: 58 },
  { t: 17.9, pos: [1.5, 3.6, 10.5], look: [0.4, 3.0, -1], fov: 54 },
];
export const S5 = ({ t, f }: Ctx) => {
  const yr = 2020 + Math.min(4, Math.floor((t - 15.0) / 0.5)), q = seg(t, 15.6, 15.9, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#f0e8d8" />
    <Floor kind="plank" a="#5a4630" b="#4e3c28" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="wood" a="#6a5238" b="#5e4630" base="#2a1e12" /><SideWall x={-9} kind="wood" a="#5a4630" b="#5a4630" /><SideWall x={9} kind="wood" a="#5a4630" b="#5a4630" />
    <Box p={[0, 1.0, -4.2]} s={[7, 2.0, 1.6]} color="#7a5a38" line={4} /><Box p={[0, 2.2, -4.2]} s={[7.6, 0.3, 2.0]} color="#5a3e22" line={3} /><Chair p={[0, 0, -5.2]} rotY={0} color="#3a2a1a" />
    <Box p={[-4.4, 0.6, -2.0]} s={[2.4, 1.2, 1.2]} color="#7a5a38" line={3} /><Box p={[4.4, 0.6, -2.0]} s={[2.4, 1.2, 1.2]} color="#7a5a38" line={3} />
    {[-2.6, 2.6].map((x) => <Box key={x} p={[x, 0.5, 1.0]} s={[2.0, 1.0, 1.2]} color="#6a4a2a" line={3} />)}
    <Cyl p={[0, 3.4, -4.4]} rt={0.05} h={1.6} color="#c9a032" line={2} /><Box p={[0, 4.2, -4.4]} s={[2.4, 0.1, 0.1]} color="#c9a032" line={2} /><Ball p={[-1.1, 3.9, -4.4]} r={0.3} color="#c9a032" /><Ball p={[1.1, 3.9, -4.4]} r={0.3} color="#c9a032" />
    <YearCal p={[-5.4, 5.6, -5.9]} s={2.6} top="NOV 11" big={String(yr)} />
    {/* a cobweb in the corner + dust */}
    <CanvasPlane p={[-7.6, 6.4, -5.9]} s={[3, 3]} px={[200, 200]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.8)"; c.lineWidth = 2; for (let k = 0; k < 6; k++) { const a = k * 0.28; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 200, Math.sin(a) * 200); c.stroke(); } for (let r = 30; r < 190; r += 34) { c.beginPath(); c.arc(0, 0, r, 0, 1.6); c.stroke(); } }} />
    <Box p={[4.4, 1.35, -2.0]} s={[1.0, 0.3, 0.8]} color="#e8dcc0" line={2} /><CanvasPlane p={[4.4, 1.52, -1.6]} s={[0.9, 0.3]} px={[180, 60]} draw={(c, W, H) => { c.fillStyle = "#e8dcc0"; c.fillRect(0, 0, W, H); c.fillStyle = "#c0182e"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.fillText("UNSOLVED", W / 2, 42); }} />
    <Sign p={[0.4, 6.4 + Math.sin(t * 3) * 0.2, 0.5]} w={2.4 * q + 0.001} h={2.4 * q + 0.001} text="?" size={200} fg="#ff5a8a" bg="#14081e" />
    <Person p={[0.4, 0, 2.2]} h={3.9} look={mk("#f3d3b2", "#5a5a6a", "blazer", "grey", "#999", { shirt: "#fff", shoe: "#111" })} f={f} pose={{ mood: "deadpan", hunch: 0.4, lookX: -0.4, sweat: 0, armR: [0.18, 0.55], armRK: seg(t, 16.8, 17.1) }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(230,215,180,.8)" />
  </>);
};

/* ============ S6 17.7 – 24.9  "Dallas knows MO3 had a rival in Yella Beezy, another rising Dallas rapper, trading shots in songs and online," ============ */
const K6: Key[] = [
  { t: 17.5, pos: [-5.5, 3.6, 13.0], look: [-1, 3.0, 0], fov: 58 },
  { t: 20.5, pos: [0, 3.6, 12.5], look: [0, 3.0, 0], fov: 56 },
  { t: 23.0, pos: [4.5, 3.8, 12.5], look: [1, 3.2, 0], fov: 58 },
  { t: 25.1, pos: [1.5, 3.8, 11.5], look: [0, 3.2, 0], fov: 56 },
];
const BUBS = ["BARS", "♪ VERSE", "DISS?", "@ POST", "BARS", "♪ VERSE", "REPLY", "@ POST"];
export const S6 = ({ t, f }: Ctx) => {
  const online = seg(t, 24.24, 24.5);
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#ffe0f0" />
    <Floor kind="tile" a="#1a1630" b="#14102a" unit={1.8} w={34} d={24} />
    <Sky p={[0, 12, -14]} s={[80, 40]} top="#12082a" bottom="#5a2a7a" stars={0.6} t={t} />
    {[-12, -7, -2, 3, 8, 13].map((x, i) => <Building key={x} p={[x, 0, -10 - (i % 2)]} s={[4, 8 + (i % 3) * 4, 3]} color={["#2a2a4a", "#34345a", "#2a3a5a"][i % 3]} lit={0.5} trim="#14142a" />)}
    <Cyl p={[7, 10, -12]} rt={0.3} h={20} color="#7a8ab0" line={2} /><Ball p={[7, 20, -12]} r={2} color="#9fc0ff" />
    <Box p={[0, 0.3, -1]} s={[10, 0.6, 3.6]} color="#2a2a3a" line={3} />
    <SpotCone p={[-2.8, 10, -1]} h={9.6} r={2.0} color="#ff6a8a" o={0.15} /><SpotCone p={[2.8, 10, -1]} h={9.6} r={2.0} color="#6a8aff" o={0.15} />
    <MicStand p={[-1.4, 0.6, -0.4]} h={2.2} /><MicStand p={[1.4, 0.6, -0.4]} h={2.2} />
    <Person p={[-2.8, 0.6, -1]} sy={0.6} h={3.6} look={mo3} f={f} pose={{ mood: Math.sin(t * 6) > 0 ? "grin" : "angry", armR: [0.34, 0.6 + 0.12 * Math.sin(t * 5)], armRK: 1, tilt: 0.05 * Math.sin(t * 5), lookX: 0.6 }} />
    <Person p={[2.8, 0.6, -1]} sy={0.6} h={3.6} look={beezy} f={f + 4} pose={{ mood: Math.sin(t * 6 + 3) > 0 ? "grin" : "angry", flip: true, armR: [0.34, 0.6 + 0.12 * Math.sin(t * 5 + 3)], armRK: 1, tilt: -0.05 * Math.sin(t * 5), lookX: -0.6 }} />
    {TAG("MO3", [-2.8, 5.4, -1], seg(t, 18.65, 18.9, Easing.out(Easing.back(2.4))), "#8fd0ff")}{TAG("BEEZY", [2.8, 5.4, -1], seg(t, 20.2, 20.5, Easing.out(Easing.back(2.4))), "#ff8aa8")}
    {BUBS.map((txt, i) => { const born = 21.2 + i * 0.42, u = clamp((t - born) / 1.2), dir = i % 2 ? -1 : 1; return u > 0 && u < 1 ? <Sign key={i} p={[lerp(dir > 0 ? -2.4 : 2.4, dir > 0 ? 2.4 : -2.4, u), 5.0 + Math.sin(u * Math.PI) * 1.4, 0.8]} w={1.9} h={0.7} text={txt} k={Math.sin(u * Math.PI) ** 0.4} size={38} bg="#fff" fg={dir > 0 ? "#1f6ad8" : "#e5233a"} /> : null; })}
    {[-3.6, 3.6].map((x, i) => <group key={i}><Phone p={[x, 7.4, 0.4]} s={1.6} rot={[0, i ? -0.3 : 0.3, 0]} glow="rgba(160,200,255,1)" o={0.3 * online} />{online > 0 ? [0, 1, 2].map((k) => { const u = ((t * 0.8 + k / 3 + i * 0.2) % 1); return <Heart key={k} p={[x + (k - 1) * 0.6, 8.2 + u * 2, 0.6]} s={0.5} />; }) : null}</group>)}
    <Dust t={t} area={[8, 6, 4]} color="rgba(240,200,255,.8)" />
  </>);
};

/* ============ S7 24.9 – 29.5  "though in 2019 MO3 shrugged the feud off. It was nothing, he said." ============ */
const K7: Key[] = [
  { t: 24.7, pos: [-3.0, 3.4, 10.0], look: [0, 2.8, 0], fov: 56 },
  { t: 27.6, pos: [0.6, 3.4, 8.4], look: [0.3, 2.8, 0], fov: 52 },
  { t: 29.8, pos: [0.4, 3.4, 8.0], look: [0.3, 2.8, 0], fov: 50 },
];
export const S7 = ({ t, f }: Ctx) => {
  const cloud = seg(t, 26.0, 26.4, Easing.out(Easing.back(2.4))), swat = seg(t, 27.4, 27.8, Easing.in(Easing.quad)), shrug = seg(t, 26.49, 26.8) * (1 - seg(t, 28.3, 28.5)), bub = seg(t, 28.55, 28.85, Easing.out(Easing.back(2.4)));
  const cx = lerp(1.2, 8, swat), cy = lerp(5.6, 8.5, swat);
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#fff0d0" />
    <Floor kind="carpet" a="#8a5a3a" b="#7a4e32" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#d8a860" b="#d8a860" base="#9a7038" /><SideWall x={-9} kind="plain" a="#c89850" b="#c89850" /><SideWall x={9} kind="plain" a="#c89850" b="#c89850" />
    <YearCal p={[-3.8, 5.4, -4.9]} s={2.4} top="YEAR" big="2019" /><Frame p={[3.6, 5.2, -4.9]} s={[1.8, 1.2]} art={1} /><Shelf p={[6.4, 0, -4.4]} w={2.6} rows={3} seed={4} wood="#6a4426" />
    <Chair p={[-2.8, 0, -1.4]} rotY={0.5} color="#2a2a38" /><Box p={[-3.6, 0.6, 0.4]} s={[1.2, 1.2, 1.2]} color="#2a2a38" line={3} /><MicStand p={[2.4, 0, 0.2]} h={2.0} />
    {/* tripod camera filming the interview */}
    <Box p={[6.0, 2.0, 1.4]} s={[0.9, 0.7, 0.7]} color="#14141c" line={3} /><Cyl p={[6.0, 1.0, 1.4]} rt={0.05} h={1.8} color="#5a5a6a" line={2} /><Ball p={[5.5, 2.0, 1.4]} r={0.25} color="#8fd0ff" /><Glow p={[6.0, 2.4, 1.4]} r={0.5} color="rgba(255,40,40,1)" o={0.7} />
    <Person p={[0.6, 0, 0.6]} h={4.0} look={mo3} f={f} pose={{ mood: t < 28.3 ? "smile" : "grin", arms: shrug > 0.01 ? "shrug" : undefined, armK: shrug, armR: swat > 0 && t < 27.9 ? [0.4, 0.75] : undefined, armRK: t > 27.3 && t < 27.9 ? seg(t, 27.3, 27.5) : 0, tilt: 0.04 * Math.sin(t * 3), lookX: 0.3 }} />
    {TAG("MO3", [0.6, 5.2, 0.6], 1, "#8fd0ff")}
    {cloud > 0.01 ? <CanvasPlane p={[cx, cy, 0.6]} s={[2.8 * cloud + 0.001, 1.9 * cloud + 0.001]} rot={[0, 0, swat * 3]} px={[280, 190]} face draw={(c, W, H) => { c.fillStyle = "#c8c8d4"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); for (const [x, y, r] of [[70, 100, 52], [140, 70, 62], [210, 100, 52], [140, 130, 56]] as number[][]) { c.moveTo(x + r, y); c.arc(x, y, r, 0, 7); } c.fill(); c.stroke(); c.fillStyle = "#c8c8d4"; for (const [x, y, r] of [[70, 100, 50], [140, 70, 60], [210, 100, 50], [140, 130, 54]] as number[][]) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } c.fillStyle = "#8a1a2e"; c.font = "900 52px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("FEUD", 140, 100); }} /> : null}
    <Sign p={[0.6, 6.6, 0.8]} w={4.0 * bub + 0.001} h={1.3 * bub + 0.001} text={"“IT WAS NOTHING”"} size={44} bg="#fff" fg="#14141c" />
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,235,190,.8)" />
  </>);
};

/* ============ S8 29.5 – 33.0  "Then in March 2025, Beezy is arrested." ============ */
const K8: Key[] = [
  { t: 29.3, pos: [-1.0, 3.4, 10.0], look: [0.6, 2.8, 0], fov: 56 },
  { t: 31.6, pos: [2.0, 3.2, 10.5], look: [2.4, 2.6, 0], fov: 54 },
  { t: 33.2, pos: [3.0, 3.2, 9.5], look: [3.0, 2.6, 0], fov: 52 },
];
export const S8 = ({ t, f }: Ctx) => {
  const cal = seg(t, 30.28, 30.6, Easing.out(Easing.back(2.4))), walk = seg(t, 31.7, 33.0, ease), px = lerp(1.0, 4.2, walk), blink = Math.sin(t * 14) > 0, arrest = seg(t, 32.0, 32.5);
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#e0e8ff" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#7a8aa8" bottom="#d8e0ee" />
    <Surface p={[0, 0, -4]} s={[60, 24]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" /><Box p={[0, 0.12, -6]} s={[60, 0.24, 2]} color="#9a9aa6" line={2} />
    {[-10, -3, 4, 11].map((x, i) => <Building key={x} p={[x, 0, -12]} s={[5, 7 + (i % 3) * 3, 4]} color={["#8a7a6a", "#7a8a9a", "#9a8a7a", "#6a7a8a"][i]} lit={0.2} trim="#2b3350" />)}
    <YearCal p={[-3.4, 5.2, 1.2]} s={2.4 * cal + 0.001} top="MARCH" big="2025" />
    <Car p={[6.4, 0, -1.4]} color="#f4f4f4" /><Box p={[6.4, 2.0, -1.4]} s={[1.8, 0.2, 0.5]} color="#14141c" line={2} /><Glow p={[5.8, 2.4, -1.2]} r={2.4} color="rgba(255,40,40,1)" o={blink ? 0.9 : 0.1} /><Glow p={[7.0, 2.4, -1.2]} r={2.4} color="rgba(40,90,255,1)" o={blink ? 0.1 : 0.9} />
    <Person p={[px - 1.4, 0, 1.2]} h={3.8} look={police} f={f} pose={{ mood: "deadpan", walk: walk > 0 && walk < 1 ? px * WALK : undefined, speed: walk > 0 && walk < 1 ? 0.5 : 0, arms: "hold", armK: 0.6 }} />
    <Person p={[px, 0, 1.4]} h={3.7} look={beezy} f={f + 4} pose={{ mood: "worry", walk: walk > 0 && walk < 1 ? px * WALK : undefined, speed: walk > 0 && walk < 1 ? 0.5 : 0, hunch: 0.4, armR: [-0.04, 0.42], armRK: arrest, armL: [0.04, 0.42], armLK: arrest, lookX: 0.3 }} />
    {arrest > 0.5 ? <FaceGroup p={[px, 0, 1.4]}>{[-0.12, 0.12].map((x) => <Cyl key={x} p={[x, 3.7 * 0.42, 0.2]} rt={0.12} h={0.05} color="#c9d3e0" line={2} rot={[Math.PI / 2, 0, 0]} />)}</FaceGroup> : null}
    {TAG("BEEZY", [px, 5.0, 1.4], seg(t, 31.75, 32.0, Easing.out(Easing.back(2.4))), "#ff8aa8")}
    <Person p={[px + 1.5, 0, 1.0]} h={3.8} look={police2} f={f + 7} pose={{ mood: "deadpan", walk: walk > 0 && walk < 1 ? px * WALK : undefined, speed: walk > 0 && walk < 1 ? 0.5 : 0, arms: "hold", armK: 0.6, flip: true }} />
    <Dust t={t} area={[8, 5, 4]} color="rgba(230,235,250,.8)" />
  </>);
};

/* ============ S9 33.0 – 39.0  "Prosecutors say he paid a hitman, pointing to a $40,000 cash withdrawal days after the shooting." ============ */
const K9: Key[] = [
  { t: 32.8, pos: [-2.5, 3.6, 12.0], look: [0, 3.4, -1], fov: 58 },
  { t: 35.0, pos: [0.0, 3.6, 11.0], look: [0.4, 3.4, -1], fov: 54 },
  { t: 37.5, pos: [1.0, 3.8, 10.0], look: [1.4, 3.4, -1], fov: 52 },
  { t: 39.2, pos: [0.8, 3.8, 10.0], look: [1.2, 3.4, -1], fov: 52 },
];
export const S9 = ({ t, f }: Ctx) => {
  const a = seg(t, 34.16, 34.5, Easing.out(Easing.back(2.2))), h = seg(t, 34.53, 34.9, Easing.out(Easing.back(2.2))), b = seg(t, 35.72, 36.1, Easing.out(Easing.back(2.2))), w = seg(t, 37.14, 37.5), d = seg(t, 37.69, 38.0, Easing.out(Easing.back(2.2)));
  const point = seg(t, 33.2, 33.6);
  return (<>
    <Cam t={t} keys={K9} />
    <Lights warm="#f0f0f8" />
    <Floor kind="plank" a="#5a4630" b="#4e3c28" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#2a3a50" b="#2a3a50" base="#141e30" /><SideWall x={-9} kind="plain" a="#24344a" b="#24344a" /><SideWall x={9} kind="plain" a="#24344a" b="#24344a" />
    <CanvasPlane p={[1.2, 4.6, -5.8]} s={[8.4, 5.2]} px={[840, 520]} frame="#4a3220" draw={(c, W2, H2) => {
      c.fillStyle = "#b8895a"; c.fillRect(0, 0, W2, H2); for (let i = 0; i < 300; i++) { c.fillStyle = `rgba(90,60,30,${0.1 + (i % 3) * 0.05})`; c.fillRect((i * 97) % W2, (i * 53) % H2, 3, 3); }
      const card = (x: number, y: number, w2: number, h2: number, rot: number, k: number, draw: () => void) => { if (k <= 0.01) return; c.save(); c.translate(x + w2 / 2, y + h2 / 2); c.rotate(rot); c.scale(k, k); c.translate(-w2 / 2, -h2 / 2); c.fillStyle = "#fffaf0"; c.strokeStyle = INK; c.lineWidth = 5; c.fillRect(0, 0, w2, h2); c.strokeRect(0, 0, w2, h2); draw(); c.restore(); };
      card(60, 70, 220, 160, -0.05, a, () => { c.fillStyle = "#c0182e"; c.font = "900 40px Inter, Arial"; c.textAlign = "center"; c.fillText("PAID A", 110, 70); c.fillText("HITMAN", 110, 120); });
      card(60, 290, 200, 190, 0.04, h, () => { c.fillStyle = "#14141c"; c.beginPath(); c.arc(100, 78, 38, 0, 7); c.fill(); c.fillRect(48, 110, 104, 70); c.fillStyle = "#ffe14a"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.fillText("?", 100, 94); });
      card(330, 120, 260, 190, 0.03, b, () => { c.fillStyle = "#1f4a8a"; c.fillRect(0, 0, 260, 44); c.fillStyle = "#fff"; c.font = "800 22px Inter, Arial"; c.textAlign = "center"; c.fillText("CASH WITHDRAWAL", 130, 30); c.fillStyle = "#14141c"; c.font = "900 56px Inter, Arial"; c.fillText("$40,000", 130, 120); c.font = "800 20px Inter, Arial"; c.fillText("DAYS AFTER", 130, 160); });
      card(640, 80, 170, 200, -0.04, d, () => { c.fillStyle = "#c0182e"; c.fillRect(0, 0, 170, 50); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.fillText("DAY +3", 85, 36); c.fillStyle = "#14141c"; c.font = "900 90px Inter, Arial"; c.fillText("3", 85, 140); });
      c.strokeStyle = "#e5233a"; c.lineWidth = 6; c.lineCap = "round"; const line = (x1: number, y1: number, x2: number, y2: number, k: number) => { if (k <= 0) return; c.beginPath(); c.moveTo(x1, y1); c.lineTo(x1 + (x2 - x1) * k, y1 + (y2 - y1) * k); c.stroke(); };
      line(170, 150, 460, 215, h); line(460, 215, 725, 180, d); line(160, 380, 460, 215, w);
      for (const [x, y, k] of [[170, 150, a], [160, 380, h], [460, 215, b], [725, 180, d]] as number[][]) if (k > 0.5) { c.fillStyle = "#e5233a"; c.beginPath(); c.arc(x, y, 10, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 3; c.stroke(); }
    }} />
    {b > 0.1 ? [0, 1, 2].map((i) => <Box key={i} p={[4.6 + i * 0.1, 1.2 + i * 0.28, 1.4]} s={[1.5, 0.26, 0.9]} color="#6fd08a" line={2} rot={[0, 0.1 * i, 0]} />) : null}
    <Box p={[4.6, 0.55, 1.4]} s={[2.0, 1.1, 1.3]} color="#6a4a2a" line={3} />
    <Person p={[-3.6, 0, 1.6]} h={4.0} look={suit} f={f} pose={{ mood: "deadpan", armR: [0.5, 0.7], armRK: point, flip: false, lookX: 0.6 }} />
    <FaceGroup p={[-3.6, 0, 1.6]}><Cyl p={hand(4.0, [0.5, 0.74], 0, false, 0.1).map((v, i) => i === 0 ? v + 0.9 : v) as V3} rt={0.04} h={2.2} color="#c9a032" line={2} rot={[0, 0, 1.2]} /></FaceGroup>
    <Lamp p={[7.2, 0, -3]} h={3.4} color="#ffe0a0" /><Chair p={[-7, 0, 2]} rotY={0.6} color="#3a2a1a" /><Dust t={t} area={[6, 5, 4]} color="rgba(240,230,200,.8)" />
  </>);
};

/* ============ S10 39.0 – 43.1  "He pleads not guilty. The trial is delayed again and again." ============ */
const K10: Key[] = [
  { t: 38.8, pos: [-1.5, 3.8, 11.5], look: [0, 3.2, -1], fov: 58 },
  { t: 41.0, pos: [0.5, 3.8, 10.5], look: [0.4, 3.4, -1], fov: 54 },
  { t: 43.3, pos: [0.4, 3.8, 10.0], look: [0.4, 3.6, -1], fov: 52 },
];
export const S10 = ({ t, f }: Ctx) => {
  const ng = seg(t, 39.88, 40.2, Easing.out(Easing.back(2.6))), st = (a: number) => seg(t, a, a + 0.1, Easing.in(Easing.quad)), dates = ["MAR 3", "JUN 12", "SEP 8", "DEC 1"], di = t < 41.2 ? 0 : t < 41.88 ? 1 : t < 42.62 ? 2 : 3;
  return (<>
    <Cam t={t} keys={K10} impacts={[[41.3, 0.03], [41.95, 0.03], [42.7, 0.04]]} />
    <Lights warm="#f0e8d8" />
    <Floor kind="plank" a="#5a4630" b="#4e3c28" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="wood" a="#6a5238" b="#5e4630" base="#2a1e12" /><SideWall x={-9} kind="wood" a="#5a4630" b="#5a4630" /><SideWall x={9} kind="wood" a="#5a4630" b="#5a4630" />
    <Box p={[0, 1.0, -4.4]} s={[6, 2.0, 1.4]} color="#7a5a38" line={4} /><Person p={[0, 2.0, -4.8]} sy={2.0} h={3.2} look={judge} f={f} pose={{ mood: "deadpan", armR: [0.3, 0.55], armRK: 1 }} />
    <Box p={[-4.4, 0.5, 0.2]} s={[3.2, 1.0, 1.4]} color="#6a4a2a" line={3} /><Box p={[4.4, 0.5, 0.2]} s={[3.2, 1.0, 1.4]} color="#6a4a2a" line={3} />
    <Person p={[-4.8, 0, -0.8]} h={3.9} look={beezy} f={f} pose={{ mood: "deadpan", hunch: 0.2, lookX: 0.4, arms: "chest", armK: 1 }} />{TAG("BEEZY", [-4.8, 5.1, -0.8], seg(t, 39.0, 39.3, Easing.out(Easing.back(2.4))), "#ff8aa8")}
    <Person p={[-3.0, 0, -0.8]} h={3.9} look={suit2} f={f + 3} pose={{ mood: "deadpan", lookX: 0.2, armR: [0.3, 0.6], armRK: seg(t, 39.2, 39.6) * (1 - seg(t, 40.4, 40.7)) }} />
    <Sign p={[-4.0, 6.2, 0.3]} w={4.2 * ng + 0.001} h={1.2 * ng + 0.001} text="NOT GUILTY" size={62} bg="#1fa850" fg="#fff" />
    <CanvasPlane p={[3.6, 5.2, -5.9]} s={[4.2, 4.6]} px={[420, 460]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f4a8a"; c.fillRect(0, 0, W, 90); c.fillStyle = "#fff"; c.font = "900 50px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("TRIAL DATE", W / 2, 48); c.fillStyle = INK; c.font = "900 96px Inter, Arial"; c.fillText(dates[di], W / 2, 220); [0, 1, 2].forEach((k) => { if (di > k) { c.strokeStyle = "#e5233a"; c.lineWidth = 14; c.beginPath(); c.moveTo(40, 160 + (k % 2) * 4); c.lineTo(W - 40, 280); c.stroke(); } }); const s = [41.2, 41.88, 42.62].findIndex((a) => t >= a && t < a + 0.8); if (s >= 0) { c.save(); c.translate(W / 2, 360); c.rotate(-0.15); c.strokeStyle = "#e5233a"; c.fillStyle = "#e5233a"; c.lineWidth = 8; c.strokeRect(-150, -42, 300, 84); c.font = "900 56px Inter, Arial"; c.fillText("DELAYED", 0, 4); c.restore(); } }} />
    <Dust t={t} area={[6, 5, 4]} color="rgba(240,230,200,.8)" />
    {void st}
  </>);
};

/* ============ S11 43.1 – 46.0  "Then on November 11, 2026," ============ */
const K11: Key[] = [
  { t: 42.9, pos: [0, 3.6, 12.5], look: [0, 3.2, -2], fov: 58 },
  { t: 46.2, pos: [0, 3.4, 10.0], look: [0, 3.2, -2], fov: 52 },
];
export const S11 = ({ t, f }: Ctx) => {
  const yr = 2020 + Math.min(6, Math.floor(Math.max(0, t - 43.9) / 0.4)), lit = yr - 2020;
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#ffd8b0" />
    <Floor kind="marble" a="#1a1a28" b="#14141f" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e1020" b="#0e1020" base="#060812" /><SideWall x={-9} kind="plain" a="#0b0d1a" b="#0b0d1a" /><SideWall x={9} kind="plain" a="#0b0d1a" b="#0b0d1a" />
    <YearCal p={[0, 5.6, -3]} s={4.2} top="NOV 11" big={String(yr)} sub={lit > 0 ? lit + (lit === 1 ? " YEAR" : " YEARS") : ""} />
    <Box p={[0, 0.5, -1.6]} s={[9.4, 1.0, 1.6]} color="#2a2a3a" line={3} />
    {Array.from({ length: 6 }, (_, i) => <group key={i} position={[-3.8 + i * 1.52, 1.0, -1.6]}><Cyl p={[0, 0.5, 0]} rt={0.22} h={1.0} color="#f4efe0" line={2} />{lit > i ? <><Flame p={[0, 1.1, 0]} t={t + i} s={0.5} /><Glow p={[0, 1.4, 0.3]} r={1.6} color="rgba(255,190,90,1)" o={0.5} /></> : null}</group>)}
    <SpotCone p={[0, 10, -3]} h={10} r={3.0} color="#ffe8c0" o={0.12} /><Dust t={t} area={[6, 6, 4]} color="rgba(255,225,170,.8)" />
  </>);
};

/* ============ S12 46.0 – 50.9  "the sixth anniversary of the shooting, a jury finds Beezy guilty of hiring the gunman." ============ */
const K12: Key[] = [
  { t: 45.8, pos: [-2.5, 3.8, 13.0], look: [0, 3.2, -1], fov: 58 },
  { t: 48.6, pos: [0.4, 3.8, 11.5], look: [0.4, 3.4, -1], fov: 54 },
  { t: 49.6, pos: [0.4, 4.0, 9.4], look: [0.4, 3.4, -1], fov: 48 },
  { t: 51.2, pos: [0.4, 4.0, 9.0], look: [0.4, 3.4, -1], fov: 46 },
];
export const S12 = ({ t, f }: Ctx) => {
  const stamp = seg(t, 49.0, 49.07, Easing.in(Easing.quad)), slip = seg(t, 47.9, 48.5, ease), pressed = t > 49.07, gav = t > 49.66 ? seg(t, 49.66, 49.75, Easing.in(Easing.quad)) * (1 - seg(t, 49.8, 50.1)) : 0;
  return (<>
    <Cam t={t} keys={K12} impacts={[[49.07, 0.05], [49.75, 0.04]]} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#5a4630" b="#4e3c28" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="wood" a="#6a5238" b="#5e4630" base="#2a1e12" /><SideWall x={-9} kind="wood" a="#5a4630" b="#5a4630" /><SideWall x={9} kind="wood" a="#5a4630" b="#5a4630" />
    <Box p={[0, 1.2, -4.6]} s={[6.4, 2.4, 1.5]} color="#7a5a38" line={4} /><Person p={[0, 2.4, -5.0]} sy={2.4} h={3.2} look={judge} f={f} pose={{ mood: "deadpan", armR: t > 49.6 ? [0.3, 0.7 + 0.1 * gav] : [0.3, 0.55], armRK: 1 }} />
    <Box p={[2.4, 2.5, -4.2]} s={[1.0, 0.16, 0.7]} color="#4a2a14" line={2} /><group position={[2.4, 2.64 + 0.8 * (1 - gav), -4.2]}><Cyl p={[0, 0.3, 0]} rt={0.06} h={0.8} color="#5a3a22" line={2} rot={[0, 0, 0.3]} /><Box p={[0.15, 0.7, 0]} s={[0.6, 0.3, 0.3]} color="#6a4426" line={2} /></group>
    {/* jury box: two rows behind a rail */}
    <Box p={[-5.2, 0.5, -1.4]} s={[4.2, 1.0, 0.3]} color="#6a4a2a" line={3} />
    {jurors.map((l, i) => <Person key={i} p={[-6.6 + (i % 3) * 1.5, (i < 3 ? 0 : 0.6), i < 3 ? -0.6 : -2.4]} sy={0} h={3.0} look={l} f={f + i * 4} pose={{ mood: t > 49.07 ? "deadpan" : "worry", lookX: 0.5, armR: [0.15, 0.6], armRK: 0.6 }} />)}
    <Box p={[3.6, 0.5, 0.4]} s={[4.0, 1.0, 1.4]} color="#6a4a2a" line={3} />
    <Person p={[3.4, 0, -0.6]} h={3.9} look={beezy} f={f} pose={{ mood: t > 49.07 ? "shock" : "worry", hunch: 0.3 + 0.4 * seg(t, 49.07, 49.7), sweat: 1, nerv: 0.3, lookX: -0.5, arms: t > 49.5 ? "head" : "chest", armK: t > 49.5 ? seg(t, 49.5, 49.9) : 1 }} />{TAG("BEEZY", [3.4, 5.2, -0.6], 1, "#ff8aa8")}
    <Person p={[-1.2, 0, 1.4]} h={3.9} look={mk("#f3d3b2", "#6a6a7a", "blazer", "bob", "#3b2a1a", { shirt: "#fff" })} f={f + 6} pose={{ mood: "deadpan", armR: [0.3, 0.7], armRK: slip * (1 - seg(t, 49.3, 49.6)), lookX: 0.3 }} />
    <CanvasPlane p={[lerp(-2.4, -0.2, slip), 3.2 + 0.4 * slip, 1.6]} s={[1.7, 2.1]} px={[170, 210]} face frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "800 18px Inter, Arial"; c.textAlign = "center"; c.fillText("VERDICT", W / 2, 28); c.fillText("FORM", W / 2, 50); c.fillStyle = "#6a6a7a"; for (let k = 0; k < 4; k++) c.fillRect(24, 70 + k * 16, W - 48, 6); if (pressed) { c.save(); c.translate(W / 2, 150); c.rotate(-0.2); c.strokeStyle = "#e5233a"; c.fillStyle = "#e5233a"; c.lineWidth = 6; c.strokeRect(-70, -26, 140, 52); c.font = "900 34px Inter, Arial"; c.textBaseline = "middle"; c.fillText("GUILTY", 0, 2); c.restore(); } }} />
    <group position={[-0.2, 3.2 + 0.4 * slip + lerp(2.0, 0, stamp), 1.7]}><Box p={[0, 0, 0]} s={[0.7, 0.16, 0.5]} color="#c0182e" line={3} /><Cyl p={[0, 0.5, 0]} rt={0.14} h={0.8} color="#3a2a22" line={2} /></group>
    {[-3.9, -3.2, -2.5].map((x, i) => <group key={i} position={[x + 8.6, 1.0, -2.4]}><Cyl p={[0, 0.3, 0]} rt={0.16} h={0.6} color="#f4efe0" line={2} /><Flame p={[0, 0.7, 0]} t={t + i} s={0.34} /></group>)}
    <Dust t={t} area={[6, 5, 4]} color="rgba(240,230,200,.8)" />
  </>);
};

/* ============ S13 50.9 – 54.6  "A rivalry that lived in verses ended in a courtroom." ============ */
const K13: Key[] = [
  { t: 50.7, pos: [-3.5, 3.8, 11.5], look: [-3.5, 3.0, 0], fov: 56 },
  { t: 52.6, pos: [-2.5, 3.8, 11.5], look: [-2.5, 3.0, 0], fov: 56 },
  { t: 53.2, pos: [3.0, 3.8, 12.5], look: [3.8, 3.0, 0], fov: 56 },
  { t: 54.9, pos: [3.6, 3.6, 10.5], look: [3.8, 3.0, 0], fov: 52 },
];
export const S13 = ({ t, f }: Ctx) => {
  const ended = seg(t, 52.94, 53.1, Easing.in(Easing.quad)), gav = t > 52.94 ? seg(t, 52.94, 53.1, Easing.in(Easing.quad)) * (1 - seg(t, 53.2, 53.6)) : 0, fall = (i: number) => t < 52.94 ? 0 : clamp((t - 52.94 - i * 0.05) / 0.8);
  return (<>
    <Cam t={t} keys={K13} impacts={[[53.1, 0.06]]} />
    <Lights warm="#ffe8d8" />
    <Floor kind="plank" a="#4a3a2a" b="#3e3024" unit={1.8} w={50} d={24} />
    <WallDoor z={-6} W={50} kind="plain" a="#1c1630" b="#1c1630" base="#0c0818" />
    {/* left: the stage of verses */}
    <Box p={[-3.0, 0.3, -1]} s={[7, 0.6, 3]} color="#2a2a3a" line={3} /><MicStand p={[-4.2, 0.6, -0.4]} h={2.2} /><MicStand p={[-1.8, 0.6, -0.4]} h={2.2} />
    <SpotCone p={[-3, 10, -1]} h={9.6} r={2.8} color="#c8a0ff" o={0.14} />
    {Array.from({ length: 8 }, (_, i) => { const u = fall(i), x0 = -5.4 + i * 0.85, y0 = 5.4 + (i % 3) * 0.6; return <CanvasPlane key={i} p={[x0 + Math.sin(t * 2 + i) * 0.15, lerp(y0 + Math.sin(t * 1.5 + i) * 0.2, 0.7, u * u), -0.2 + (i % 2) * 0.4]} rot={[-u * 1.2, 0, Math.sin(t + i) * 0.3]} s={[0.9, 1.2]} px={[90, 120]} draw={(c, W, H) => { c.fillStyle = "#f6edc8"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(2, 2, W - 4, H - 4); c.fillStyle = "#6a5a4a"; for (let k = 0; k < 7; k++) c.fillRect(10, 18 + k * 14, 40 + ((i * 17 + k * 13) % 36), 5); c.fillStyle = "#8a1a2e"; c.font = "900 16px Inter, Arial"; c.fillText("VERSE", 10, 14); }} />; })}
    {t > 51.5 ? [0, 1, 2, 3].map((i) => <Note key={i} p={[-5 + i * 1.8, 6.6 - fall(i) * 2 + 0.3 * Math.sin(t * 2 + i), 0.2]} s={0.6} o={1 - ended} color="#ffe08a" />) : null}
    {/* right: the courtroom bench and the gavel */}
    <Box p={[5.0, 1.2, -2.6]} s={[6, 2.4, 1.6]} color="#7a5a38" line={4} /><Box p={[5.0, 2.55, -2.6]} s={[6.4, 0.2, 1.9]} color="#5a3e22" line={3} />
    <Box p={[5.0, 2.8, -2.0]} s={[1.0, 0.2, 0.7]} color="#4a2a14" line={2} />
    <group position={[5.0, 3.0 + 1.4 * (1 - gav), -2.0]} rotation={[0, 0, 0.4 - gav * 0.6]}><Cyl p={[0, 0.3, 0]} rt={0.07} h={1.0} color="#5a3a22" line={2} rot={[0, 0, 0.3]} /><Box p={[0.2, 0.85, 0]} s={[0.8, 0.4, 0.4]} color="#6a4426" line={2} /></group>
    <Cyl p={[7.4, 3.8, -3.0]} rt={0.05} h={2.4} color="#c9a032" line={2} /><Box p={[7.4, 5.0, -3.0]} s={[1.8, 0.1, 0.1]} color="#c9a032" line={2} /><Ball p={[6.6, 4.4, -3.0]} r={0.35} color="#c9a032" /><Ball p={[8.2, 4.4, -3.0]} r={0.35} color="#c9a032" />
    <Sign p={[5.0, 6.8, -2]} w={5.0} h={1.2} text="COURT IN SESSION" k={seg(t, 53.4, 53.8, Easing.out(Easing.back(2.4)))} size={52} face={false} />
    <Glow p={[5, 4, 0]} r={7} color="rgba(255,210,150,1)" o={0.2 + 0.3 * seg(t, 53.1, 53.6)} /><Dust t={t} area={[10, 6, 4]} color="rgba(240,225,190,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13 };
