import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Dejavu";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const DCUTS = [0, 3.78, 7.59, 9.33, 12.46, 18.0, 25.48, 30.65, 35.49, 41.01, 42.6];
const BG = ["#1a1438", "#c8865a", "#c8865a", "#3a2a6a", "#0a1028", "#1a1438", "#2a1a40", "#0e1a30", "#1a1438", "#3a2a7a"];
const TR: Trans[] = ["ghost", "zoom", "ghost", "whip", "zoom", "ghost", "flash", "ghost", "dip", "whip"];
export const DejavuMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={DCUTS[i]} end={DCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"DÉJÀ VU MIGHT BE ANOTHER LIFE"} until={2.9} />
    <EndQuestion text={"Other life or brain glitch? Comment 1 or 2"} from={41.0} end={42.52} />
  </AbsoluteFill>
);
