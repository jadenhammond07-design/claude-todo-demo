import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Senses";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const SECUTS = [0, 4.85, 9.13, 15.26, 18.22, 20.69, 27.57, 30.51, 34.9, 39.41, 42.8];
const BG = ["#4a2a8a", "#5a5a5a", "#5a5a5a", "#4a2a8a", "#120e2a", "#4a2a8a", "#0a1428", "#4a2a8a", "#1a1438", "#1a1438"];
const TR: Trans[] = ["ghost", "dip", "zoom", "flash", "ghost", "whip", "zoom", "ghost", "dip", "ghost"];
export const SensesMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={SECUTS[i]} end={SECUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"YOU MIGHT ALREADY HAVE A 6TH SENSE"} until={2.1} />
    <EndQuestion text={"Which new sense would YOU want? 👇"} from={39.9} end={42.72} />
  </AbsoluteFill>
);
