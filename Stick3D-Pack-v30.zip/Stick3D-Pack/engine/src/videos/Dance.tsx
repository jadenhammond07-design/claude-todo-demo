// DANCING PLAGUE 1518 — scenes 1-7. Real physics, one idea per scene (see 02-videos/dance/_ledger.md).
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, camAt, FaceGroup, hand, Extrude, Curtain, Bench, Barrier } from "../style/extra";
import { Sky, Timber, Minster, Barrel, Crate, Well, Cart, Torch, Banner, Flame, Note, CrowdField, danceBeat, mixHex } from "../style/medieval";
import { Ctx, WALK, toWorld, troffea, troffeaBleed, villagers, doctor, doctor2, councilor, councilor2, carpenter, drummer, piper } from "./dancecommon";

const WALLS = ["#f1dfb8", "#e8c9a0", "#f6e8c8", "#d9b98a", "#efd5a8"], ROOFS = ["#a8442c", "#8a3a2a", "#b5603a", "#9c3a30"];
const ease = Easing.inOut(Easing.sin);

/* ----- reusable plaza shell: sky, cobbles, ring of houses, minster ----- */
export const Plaza: React.FC<{ t: number; top: string; bot: string; glowO?: number; lit?: number; stars?: number; ground?: [string, string]; skip?: number[] }> = ({ t, top, bot, glowO = 0.5, lit = 0, stars = 0, ground = ["#8e8a7e", "#7e7a6e"], skip = [] }) => (<>
  <Sky p={[0, 26, -90]} s={[300, 150]} top={top} bottom={bot} stars={stars} t={t} glowAt={[glowO, "rgba(255,210,140,1)"]} />
  <Surface p={[0, 0, -20]} s={[90, 90]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a={ground[0]} b={ground[1]} unit={1.6} />
  {[-24, -17, -10, -3, 4, 11, 18, 25].map((x, i) => skip.includes(i) ? null : <Timber key={"b" + i} p={[x, 0, -19 - (i % 3) * 2.2]} s={[6.2, 6 + (i % 3) * 1.8, 5]} wall={WALLS[i % 5]} roof={ROOFS[i % 4]} lit={lit} seed={i + 1} />)}
  {[-9, -15, -21].map((z, i) => <React.Fragment key={"s" + i}><Timber p={[-17, 0, z + 4]} s={[6, 6.5 + i, 5]} yaw={Math.PI / 2} wall={WALLS[(i + 2) % 5]} roof={ROOFS[(i + 1) % 4]} lit={lit} seed={i + 4} /><Timber p={[17, 0, z + 4]} s={[6, 7 - i * 0.4, 5]} yaw={-Math.PI / 2} wall={WALLS[(i + 4) % 5]} roof={ROOFS[(i + 3) % 4]} lit={lit} seed={i + 7} /></React.Fragment>)}
  <Minster p={[-5, 0, -42]} s={1.3} lit={lit} />
</>);

/* ============ S1 0 – 2.65  "Strasbourg, July 1518." ============ */
const K1: Key[] = [
  { t: 0, pos: [0.5, 17, 24], look: [0, 4, -22], fov: 60 },
  { t: 1.4, pos: [0.8, 8.5, 18], look: [0, 4.5, -22], fov: 58 },
  { t: 2.9, pos: [1.4, 3.4, 12], look: [0, 4.4, -14], fov: 56 },
];
export const S1 = ({ t, f }: Ctx) => {
  const walkX = lerp(-3.8, 3.8, seg(t, 0.4, 2.9, Easing.linear));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#ffe2b0" />
    <Sky p={[0, 26, -90]} s={[300, 150]} top="#ff9d5c" bottom="#ffe3a8" glowAt={[0.9, "rgba(255,190,110,1)"]} />
    <Ball p={[-8, 4.5, -85]} r={6} color="#fff0b0" ink={0} /><Glow p={[-8, 4.5, -84]} r={30} color="rgba(255,200,120,1)" o={0.55} />
    <Surface p={[0, 0, -20]} s={[60, 100]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#8e8a7e" b="#7e7a6e" unit={1.5} />
    {Array.from({ length: 9 }, (_, k) => <React.Fragment key={k}>
      <Timber p={[-7.6, 0, 9 - k * 6.4]} s={[5.8, 5.4 + (k % 3) * 1.7, 4]} yaw={Math.PI / 2} wall={WALLS[k % 5]} roof={ROOFS[k % 4]} seed={k} />
      <Timber p={[7.6, 0, 6 - k * 6.4]} s={[5.8, 6.2 - (k % 3) * 0.7, 4]} yaw={-Math.PI / 2} wall={WALLS[(k + 2) % 5]} roof={ROOFS[(k + 1) % 4]} seed={k + 3} />
    </React.Fragment>)}
    <Minster p={[0, 0, -52]} s={1.5} />
    <Cyl p={[0, 8.9, -2]} rt={0.05} h={11} color="#5a3a22" line={1} rot={[0, 0, Math.PI / 2]} />
    <Banner p={[0, 7.0, -2]} s={[4.6, 2.3]} text="STRASBOURG" sub="JULY 1518" size={58} />
    <Banner p={[-3.6, 6.6, 7]} s={[1.6, 2.6]} text="†" bg="#2a5a9a" size={110} /><Banner p={[3.6, 6.4, -8]} s={[1.6, 2.6]} text="★" bg="#c9a032" fg="#6a1a1a" size={110} />
    <Barrel p={[-4.3, 0, 3]} /><Barrel p={[-4.6, 0, 3.8]} s={0.9} /><Crate p={[4.4, 0, 1]} rotY={0.3} /><Crate p={[4.5, 0.8, 1]} s={0.8} rotY={0.8} /><Well p={[3.2, 0, -9]} /><Cart p={[-3.2, 0, -12]} rotY={0.2} />
    <Torch p={[-4.4, 0, -4]} t={t} on={0.0} /><Torch p={[4.4, 0, -5]} t={t} on={0.0} /><Plant p={[-4.2, 0, 7]} s={1.1} pot="#b5603a" /><Plant p={[4.2, 0, 6]} s={1.0} pot="#b5603a" />
    <Barrel p={[4.2, 0, -16]} /><Crate p={[-4.4, 0, -18]} /><Barrel p={[-4.3, 0, -24]} /><Plant p={[4.2, 0, -26]} s={1.2} pot="#c0643a" />
    <Shaft p={[-1.5, 9, -2]} s={[2.8, 14]} rot={[0, 0, 0.5]} color="255,200,120" o={0.18} /><Dust t={t} area={[8, 9, 6]} color="rgba(255,225,170,.9)" />
    {[[-2.2, 2, 0.6], [2.4, -3, 0.5], [-1.2, -9, 0.4]].map(([x, z, s], i) => <Person key={i} p={[x, 0, z]} h={3.1} look={villagers[i + 1]} f={f + i * 9} pose={{ mood: "deadpan", lookX: i % 2 ? -0.6 : 0.6, nerv: 0.1 }} />)}
    <Person p={[walkX, 0, -6]} h={2.8} look={villagers[3]} f={f} pose={{ mood: "smile", walk: (walkX + 3.8) * WALK, speed: 0.8 }} />
  </>);
};

/* ============ S2 2.65 – 5.8  "Frau Troffea steps into the street and starts dancing." ============ */
const K2: Key[] = [
  { t: 2.5, pos: [0.4, 3.0, 6.0], look: [0, 2.4, -3.5], fov: 56 },
  { t: 3.9, pos: [0, 3.1, 8.2], look: [0, 2.2, -1.5], fov: 56 },
  { t: 5.4, pos: [0, 3.5, 10.8], look: [0, 1.9, 0.6], fov: 56 },
  { t: 6.0, pos: [0, 3.6, 11.5], look: [0, 1.9, 0.8], fov: 56 },
];
const WZ = -3;
const tz = (t: number) => t < 2.65 ? -5.5 : t < 3.05 ? lerp(-5.5, -3.9, seg(t, 2.65, 3.05, ease)) : t < 3.35 ? -3.9 : lerp(-3.9, 0.9, seg(t, 3.35, 5.15, Easing.inOut(Easing.quad)));
export const S2 = ({ t, f }: Ctx) => {
  const z = tz(t), walking = (t > 2.65 && t < 3.05) || t > 3.35 && t < 5.15, open = seg(t, 3.08, 3.55, ease);
  const reach = seg(t, 3.0, 3.1) * (1 - seg(t, 3.5, 3.62)), dk = seg(t, 5.0, 5.4), db = danceBeat(t, 0, dk);
  const dist = t < 5.15 ? z + 5.5 : 0;
  const dancing = t >= 5.0;
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#ffe2b0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#7aa2e0" bottom="#ffd7a0" />
    <Surface p={[0, 0, 4]} s={[44, 26]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#8e8a7e" b="#7e7a6e" unit={1.5} />
    <WallDoor z={WZ} W={18} kind="wood" a="#dcc48e" b="#d0b680" door={{ x: 0, w: 2.4, h: 4.2 }} base="#6a4a30" />
    {[-7.5, -4.4, -2.4, 2.4, 4.4, 7.5].map((x) => <Box key={x} p={[x, 4.5, WZ + 0.06]} s={[0.28, 9, 0.12]} color="#4a2a18" line={2} />)}
    {[4.6, 8.8].map((y) => <Box key={y} p={[0, y, WZ + 0.06]} s={[18, 0.3, 0.12]} color="#4a2a18" line={2} />)}
    <Box p={[0, 4.2 + 0.1, WZ + 0.06]} s={[2.9, 0.26, 0.12]} color="#4a2a18" line={2} />
    {[-5.9, 5.9].map((x) => [2.5, 6.6].map((y) => <group key={x + "_" + y} position={[x, y, WZ + 0.1]}><Box p={[0, 0, 0]} s={[1.5, 1.4, 0.12]} color="#4a2a18" line={2} /><Box p={[0, 0, 0.04]} s={[1.2, 1.1, 0.06]} color={y > 4 ? "#ffd36a" : "#6f93b8"} line={1} /><Box p={[-1.0, 0, 0.06]} s={[0.55, 1.2, 0.08]} color="#2f6a4a" line={2} /><Box p={[1.0, 0, 0.06]} s={[0.55, 1.2, 0.08]} color="#2f6a4a" line={2} /></group>))}
    <Extrude p={[0, 9, WZ - 1.8]} pts={[[-9.6, 0], [9.6, 0], [0, 3.6]]} depth={4} color="#a8442c" line={4} /><Box p={[4.2, 11.5, WZ - 2.5]} s={[0.8, 2.2, 0.8]} color="#7a5a48" line={3} />
    <Box p={[0, 3.2, WZ - 6.2]} s={[10, 6.4, 0.2]} color="#4a3020" /><Box p={[-5, 3.2, WZ - 3.2]} s={[0.2, 6.4, 6.2]} color="#4a3020" /><Box p={[5, 3.2, WZ - 3.2]} s={[0.2, 6.4, 6.2]} color="#4a3020" /><Box p={[0, 6.4, WZ - 3.2]} s={[10.2, 0.2, 6.4]} color="#3a2418" />
    <Surface p={[0, 0.02, WZ - 3.2]} s={[10, 6.2]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#8a5a34" b="#7a4c2a" unit={1.4} />
    <Box p={[-3.2, 0.5, WZ - 4.6]} s={[2.4, 1.0, 1.7]} color="#8f4a3a" /><Box p={[-3.2, 1.05, WZ - 4.6]} s={[2.4, 0.2, 1.7]} color="#f3e8d0" line={2} /><Box p={[3.2, 0.9, WZ - 4.4]} s={[2.0, 0.18, 1.2]} color="#7a4a26" /><Box p={[3.2, 0.45, WZ - 4.4]} s={[1.8, 0.9, 1.0]} color="#5a3a22" line={2} />
    <Cyl p={[3.0, 1.15, WZ - 4.4]} rt={0.09} h={0.34} color="#f3e8d0" line={2} /><Flame p={[3.0, 1.32, WZ - 4.4]} t={t} s={0.22} />
    <Box p={[0, 1.4, WZ - 6.0]} s={[2.6, 2.8, 0.3]} color="#2a1a14" /><Flame p={[0, 0.2, WZ - 5.6]} t={t} s={0.9} /><Glow p={[0, 2.4, WZ - 3.6]} r={6} color="rgba(255,170,70,1)" o={0.45} />
    <Shelf p={[-4.4, 0, WZ - 5.7]} w={2} rows={3} seed={2} wood="#6a4426" />
    {/* door leaf (hinged on the left, opens AWAY) */}
    <group position={[-1.2, 0, WZ + 0.02]} rotation={[0, open * 1.4, 0]}><Box p={[1.2, 2.1, 0]} s={[2.4, 4.2, 0.14]} color="#7a4a26" /><Box p={[1.2, 3.2, 0.08]} s={[2.2, 0.16, 0.04]} color="#2b2a35" line={1} /><Box p={[1.2, 1.0, 0.08]} s={[2.2, 0.16, 0.04]} color="#2b2a35" line={1} /><Box p={[2.0, 2.0, 0.12]} s={[0.3, 0.12, 0.1]} color="#d8b24a" line={2} /></group>
    {/* street dressing */}
    <Barrel p={[-5.2, 0, 1.4]} /><Barrel p={[-5.7, 0, 2.2]} s={0.9} /><Crate p={[5.4, 0, 1.0]} rotY={0.4} /><Cart p={[7.6, 0, 3.4]} rotY={-0.5} /><Well p={[-8.6, 0, 3]} />
    <Torch p={[-1.9, 0, -2.4]} t={t} on={0} /><Torch p={[1.9, 0, -2.4]} t={t} on={0} /><Plant p={[-3.4, 0, -2.4]} s={1.1} pot="#b5603a" /><Plant p={[3.4, 0, -2.4]} s={1.1} pot="#b5603a" />
    <Timber p={[-14, 0, 2]} s={[6, 8, 5]} yaw={Math.PI / 2} seed={3} /><Timber p={[14, 0, 0]} s={[6, 7, 5]} yaw={-Math.PI / 2} seed={5} wall="#e8c9a0" />
    <Shaft p={[2.5, 10, 3]} s={[3, 14]} rot={[0, 0, 0.3]} color="255,215,150" o={0.16} /><Dust t={t} area={[7, 7, 5]} color="rgba(255,225,170,.9)" />
    <Person p={[0, dancing ? db.y : 0, z]} sy={0} h={3.4} look={troffea} f={f} pose={{ mood: dancing ? "deadpan" : "smile", walk: walking ? dist * WALK : undefined, speed: walking ? 0.7 : 0, nerv: 0,
      arms: dancing ? undefined : "down", armR: dancing ? db.pose.armR : reach > 0 ? [0.33, 0.47] : undefined, armRK: dancing ? db.pose.armRK : reach, armL: dancing ? db.pose.armL : undefined, armLK: db.pose.armLK,
      squash: dancing ? db.pose.squash : 0, air: dancing ? db.pose.air : 0, tilt: dancing ? db.pose.tilt : 0, lookX: dancing ? db.pose.lookX : 0 }} />
  </>);
};

/* ============ S3 5.8 – 10.45  "No music. No joy. She's still dancing the next morning, feet bleeding." ============ */
const SKY: [number, string, string][] = [[5.8, "#4da3ff", "#bfe6ff"], [6.5, "#7a58a8", "#ff9a5a"], [7.2, "#0a0e2e", "#2a2a6a"], [8.3, "#070a24", "#1a2150"], [8.8, "#6a7ad0", "#ffb27a"], [9.4, "#8ab8ff", "#ffe2b0"]];
const skyAt = (t: number): [string, string] => { let i = 0; while (i < SKY.length - 2 && t > SKY[i + 1][0]) i++; const k = clamp((t - SKY[i][0]) / (SKY[i + 1][0] - SKY[i][0])); return [mixHex(SKY[i][1], SKY[i + 1][1], k), mixHex(SKY[i][2], SKY[i + 1][2], k)]; };
const nightK = (t: number) => seg(t, 6.6, 7.3, Easing.linear) * (1 - seg(t, 8.35, 9.0, Easing.linear));
export const tint3 = (t: number) => { const dusk = Math.max(0, 1 - Math.abs(t - 6.7) / 0.7); const n = nightK(t); return mixHex(mixHex("#ffffff", "#ffc890", dusk * 0.7), "#4c5aa8", n * 0.85); };
const K3: Key[] = [
  { t: 5.7, pos: [-6.0, 2.3, 8.5], look: [0, 2.2, 0], fov: 58 },
  { t: 7.2, pos: [-1.5, 1.7, 9.5], look: [0, 2.4, 0], fov: 58 },
  { t: 8.8, pos: [4.6, 1.9, 8.0], look: [0, 2.0, 0], fov: 56 },
  { t: 9.35, pos: [1.3, 0.95, 4.2], look: [0.1, 0.5, 0], fov: 52 },
  { t: 10.7, pos: [0.5, 0.8, 3.4], look: [0.1, 0.45, 0], fov: 50 },
];
const NoSign: React.FC<{ p: V3; k: number; kind: "note" | "smile" }> = ({ p, k, kind }) => (
  <CanvasPlane p={p} s={[1.9 * k + 0.001, 1.9 * k + 0.001]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#fff6dc"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.arc(100, 100, 86, 0, 7); c.fill(); c.stroke(); c.fillStyle = INK;
    if (kind === "note") { c.beginPath(); c.ellipse(80, 130, 24, 17, -0.4, 0, 7); c.fill(); c.lineWidth = 10; c.beginPath(); c.moveTo(98, 124); c.lineTo(98, 52); c.lineTo(132, 68); c.stroke(); } else { c.beginPath(); c.arc(70, 82, 10, 0, 7); c.arc(130, 82, 10, 0, 7); c.fill(); c.lineWidth = 9; c.beginPath(); c.arc(100, 106, 40, 0.15 * Math.PI, 0.85 * Math.PI); c.stroke(); }
    c.strokeStyle = "#e5233a"; c.lineWidth = 16; c.beginPath(); c.arc(100, 100, 84, 0, 7); c.moveTo(40, 40); c.lineTo(160, 160); c.stroke(); }} />
);
export const S3 = ({ t, f }: Ctx) => {
  const [top, bot] = skyAt(t), n = nightK(t), db = danceBeat(t, 0, 0.8 + 0.1 * Math.sin(t)), bleed = t > 9.0;
  const sunU = seg(t, 5.8, 7.2, ease), sunV = seg(t, 8.3, 9.7, ease), moonU = seg(t, 6.9, 8.0, ease), moonD = seg(t, 8.3, 9.2, ease);
  const sunY = t < 8 ? lerp(10, -8, sunU) : lerp(-8, 7, sunV), sunX = t < 8 ? lerp(6, -4, sunU) : lerp(8, 3, sunV);
  const moonY = lerp(-8, 11, moonU) - moonD * 19, moonX = lerp(-8, 5, seg(t, 6.9, 9.2, Easing.linear));
  const spots = Math.floor(lerp(0, 26, seg(t, 9.1, 10.3, Easing.linear)));
  const specs: [number, number][] = [[-5.4, -4], [-3.2, -6.5], [4.2, -5], [6.1, -8], [-7.5, -9]];
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff0d0" />
    <Plaza t={t} top={top} bot={bot} glowO={0.35 * (1 - n)} lit={n > 0.4 ? 1 : 0} stars={n} />
    <Ball p={[sunX, sunY, -80]} r={5} color="#fff0b0" ink={0} /><Glow p={[sunX, sunY, -79]} r={22} color="rgba(255,210,130,1)" o={0.5} />
    <Ball p={[moonX, moonY, -80]} r={4} color="#eef0ff" ink={0} /><Glow p={[moonX, moonY, -79]} r={14} color="rgba(190,200,255,1)" o={0.4 * n} />
    <Well p={[6.5, 0, -2]} /><Cart p={[-7, 0, -5]} rotY={0.5} /><Barrel p={[-6.2, 0, -3]} /><Crate p={[7.4, 0, 2]} /><Torch p={[-3.2, 0, -3]} t={t} on={n} /><Torch p={[3.4, 0, -3.4]} t={t} on={n} /><Plant p={[8.5, 0, -6]} s={1.3} pot="#b5603a" /><Bench p={[-4.6, 0, -8]} rotY={0.3} />
    <Cyl p={[0, 0.2, -12]} rt={2.2} h={0.4} color="#9a9aa8" /><Cyl p={[0, 1.0, -12]} rt={0.4} h={1.8} color="#aeb0be" /><Cyl p={[0, 2.0, -12]} rt={1.2} rb={0.2} h={0.4} color="#9a9aa8" />
    {/* the silent crowd */}
    {specs.map(([x, z], i) => <Person key={i} p={[x, 0, z]} h={3.1} look={villagers[(i + 2) % 8]} f={f + i * 7} pose={{ mood: i % 2 ? "worry" : "deadpan", lookX: x < 0 ? 0.7 : -0.7, flip: x > 0, nerv: 0.1, sweat: 0 }} />)}
    <NoSign p={[-1.6, 5.9, -1]} k={seg(t, 6.04, 6.25, Easing.out(Easing.back(2.4))) * (1 - seg(t, 7.8, 8.0))} kind="note" />
    <NoSign p={[1.6, 5.9, -1]} k={seg(t, 6.95, 7.15, Easing.out(Easing.back(2.4))) * (1 - seg(t, 7.9, 8.1))} kind="smile" />
    <CanvasPlane p={[0.1, 0.03, 0]} rot={[-Math.PI / 2, 0, 0]} s={[3.4, 3.4]} px={[256, 256]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); for (let i = 0; i < spots; i++) { const a = i * 2.4, r = 24 + ((i * 53) % 90), x = W / 2 + Math.cos(a) * r, y = H / 2 + Math.sin(a) * r * 0.7, k = 0.6 + ((i * 7) % 5) / 6; c.fillStyle = "#c8102e"; c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); c.ellipse(x, y, 13 * k, 9 * k, a, 0, 7); c.fill(); c.stroke(); } }} />
    <Person p={[0, db.y, 0]} sy={0} h={3.4} look={bleed ? troffeaBleed : troffea} f={f} pose={{ mood: bleed ? "worry" : "deadpan", nerv: bleed ? 0.3 : 0, sweat: t > 8.4 ? 1 : 0, ...db.pose, hunch: bleed ? 0.5 : 0 }} />
  </>);
};

/* ============ S4 10.45 – 15.0  "Within a week, thirty-four people have joined her. Within a month, hundreds." ============ */
const K4: Key[] = [
  { t: 10.3, pos: [-3.6, 2.5, 6.4], look: [0.4, 2.0, 0], fov: 58 },
  { t: 12.4, pos: [-2.2, 3.4, 8.6], look: [0.3, 1.8, -0.5], fov: 58 },
  { t: 13.3, pos: [0.0, 4.2, 11.0], look: [0, 1.8, -1], fov: 58 },
  { t: 14.4, pos: [0, 15.5, 14.5], look: [0, 0, -5], fov: 60 },
  { t: 15.6, pos: [0, 19, 16], look: [0, 0, -6], fov: 60 },
];
const SP = (i: number) => { const r = 1.7 + 0.42 * i, a = i * 0.95 + 0.6; return [Math.cos(a) * r, Math.min(3.5, Math.sin(a) * r * 0.8 - 1.2)] as [number, number]; };
export const S4 = ({ t, f }: Ctx) => {
  const count = Math.round(lerp(1, 34, seg(t, 10.55, 12.9, Easing.linear))), month = t > 13.33;
  const R = lerp(0, 26, seg(t, 13.45, 14.7, Easing.inOut(Easing.quad)));
  const crowd = (i: number): V3 => { const r = 5 + Math.sqrt((i + 0.5) / 150) * 20, a = i * 2.399 + 0.3; return r < R ? [Math.cos(a) * r, 0, Math.min(8, Math.sin(a) * r * 0.8 - 2)] : [0, -99, 0]; };
  const pop = seg(t, 13.33, 13.6, Easing.out(Easing.back(2.5)));
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#ffd890" />
    <Plaza t={t} top="#ee9a40" bot="#ffe6a0" glowO={0.8} ground={["#a89a7e", "#988a6e"]} lit={0} />
    <Ball p={[10, 24, -80]} r={5} color="#fff4c0" ink={0} /><Glow p={[10, 24, -79]} r={26} color="rgba(255,190,90,1)" o={0.6} />
    <Cyl p={[0, 0.2, -9]} rt={2.4} h={0.4} color="#9a9aa8" /><Cyl p={[0, 1.2, -9]} rt={0.45} h={2} color="#aeb0be" /><Ball p={[0, 2.4, -9]} r={0.7} color="#78b8e8" />
    <Cart p={[7.6, 0, -3]} rotY={-0.4} load="#e8d070" /><Barrel p={[-7.4, 0, -3]} /><Crate p={[-7.8, 0, -2]} /><Well p={[8, 0, -8]} /><Torch p={[-5, 0, -6]} t={t} on={0} />
    <group position={[-2.9, 0, -5.5]}><Cyl p={[0, 1.4, 0]} rt={0.12} h={2.8} color="#5a3a22" line={2} />
      <CanvasPlane p={[0, 3.5, 0.1]} s={[3.4 + 0.001, 2.0]} px={[340, 200]} frame="#4a2a18" draw={(c, W, H) => { c.fillStyle = "#e9d3a0"; c.fillRect(0, 0, W, H); c.fillStyle = "#6a1a1a"; c.textAlign = "center"; c.textBaseline = "middle"; c.font = "900 46px Inter, Arial"; c.fillText(month ? "MONTH 1" : "WEEK 1", W / 2, 44); const s = month ? 0.8 + 0.2 * pop : 1; c.save(); c.translate(W / 2, 128); c.scale(s, s); c.fillStyle = month ? "#c8102e" : "#1a1a1a"; c.font = `900 ${month ? 62 : 108}px Inter, Arial`; c.fillText(month ? "HUNDREDS" : String(count), 0, 0); c.restore(); }} /></group>
    <CrowdField n={150} t={t} at={crowd} size={1.25} />
    <Person p={[0, danceBeat(t, 0).y, 0]} sy={0} h={3.4} look={troffeaBleed} f={f} pose={{ mood: "worry", sweat: 1, nerv: 0.3, ...danceBeat(t, 0).pose }} />
    {Array.from({ length: 14 }, (_, i) => { const [tx, tz2] = SP(i), st = 10.5 + i * 0.16, k = seg(t, st, st + 2.3, Easing.inOut(Easing.quad)), sgn = i % 2 ? 1 : -1, sx = tx + sgn * (10 - Math.abs(tx) * 0.2), x = lerp(sx, tx, k), d = danceBeat(t, i + 1);
      return <Person key={i} p={[x, d.y, tz2]} sy={0} h={3.0 + (i % 3) * 0.15} look={villagers[i % 8]} f={f + i * 3} pose={{ mood: i % 3 ? "deadpan" : "worry", sweat: i % 4 === 0 ? 1 : 0, ...d.pose }} />; })}
  </>);
};

/* ============ S5 15.0 – 18.7  "The doctors blame hot blood. Their cure? More dancing." ============ */
const K5: Key[] = [
  { t: 14.8, pos: [-2.0, 4.0, 15.0], look: [0, 2.8, 0], fov: 58 },
  { t: 15.9, pos: [-1.0, 3.8, 13.2], look: [-0.4, 2.8, 0], fov: 56 },
  { t: 16.7, pos: [-1.2, 3.6, 11.4], look: [-1.0, 2.7, 0.2], fov: 52 },
  { t: 17.6, pos: [0.8, 4.0, 13.8], look: [0.4, 3.4, -0.5], fov: 56 },
  { t: 19.0, pos: [0.8, 4.0, 13.0], look: [0.4, 3.4, -0.5], fov: 54 },
];
export const S5 = ({ t, f }: Ctx) => {
  const heat = seg(t, 15.7, 16.6, Easing.inOut(Easing.cubic)), unroll = seg(t, 17.83, 18.2, Easing.out(Easing.back(1.6))), lift = seg(t, 17.04, 17.3, ease);
  const jig = danceBeat(t, 3, seg(t, 18.1, 18.4) * 0.9);
  const puffs = [0, 1, 2, 3, 4, 5].map((i) => { const u = ((t * 0.9 + i / 6) % 1); return [-1.4 + Math.sin(i * 2.1 + t) * 0.18, 3.55 + u * 1.7, 0.2, 0.15 + u * 0.28, 0.9 * (1 - u) * heat] as [number, number, number, number, number]; });
  const ph = hand(3.6, [0.12, 0.7 + 0.12 * lift], 0, false, 0.12);
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#ffd2a0" />
    <Floor kind="plank" a="#6a4228" b="#5e3a22" unit={1.8} w={30} d={24} />
    <WallDoor z={-6} W={30} kind="wood" a="#7a5234" b="#6a4528" base="#3a2412" /><SideWall x={-9} kind="wood" a="#7a5234" b="#6a4528" /><SideWall x={9} kind="wood" a="#7a5234" b="#6a4528" />
    <CanvasPlane p={[3.3, 4.9, -5.9]} s={[3.2, 3.4]} px={[256, 272]} frame="#3a2412" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#8fb8e8"); g.addColorStop(1, "#ffe3b0"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "#6a4a30"; c.fillRect(0, H * 0.78, W, H); for (let i = 0; i < 6; i++) { const x = 30 + i * 40, b = Math.abs(Math.sin(t * 5.2 + i)) * 12; c.strokeStyle = INK; c.lineWidth = 5; c.fillStyle = INK; c.beginPath(); c.arc(x, H * 0.7 - b, 8, 0, 7); c.fill(); c.beginPath(); c.moveTo(x, H * 0.7 - b + 8); c.lineTo(x, H * 0.78 - b); c.moveTo(x - 12, H * 0.72 - b - 14 * Math.sin(t * 5.2 + i)); c.lineTo(x, H * 0.72 - b + 3); c.lineTo(x + 12, H * 0.72 - b + 14 * Math.sin(t * 5.2 + i)); c.stroke(); } }} />
    <Box p={[3.3, 3.1, -5.85]} s={[3.6, 0.2, 0.3]} color="#3a2412" line={2} />
    <Shelf p={[-5.6, 0, -5.5]} w={3.2} rows={4} seed={5} wood="#4a2a18" /><Shelf p={[-1.6, 0, -5.5]} w={3} rows={4} seed={8} wood="#4a2a18" />
    <Box p={[0, 1.7, 0]} s={[6.6, 0.22, 2.2]} color="#9a6a3a" /><Box p={[-2.8, 0.85, 0.8]} s={[0.3, 1.7, 0.3]} color="#6a4426" line={2} /><Box p={[2.8, 0.85, 0.8]} s={[0.3, 1.7, 0.3]} color="#6a4426" line={2} /><Box p={[-2.8, 0.85, -0.8]} s={[0.3, 1.7, 0.3]} color="#6a4426" line={2} /><Box p={[2.8, 0.85, -0.8]} s={[0.3, 1.7, 0.3]} color="#6a4426" line={2} />
    {/* the flask of hot blood */}
    <Cyl p={[-1.4, 2.95, 0.2]} rt={0.16} h={0.8} color="#bfe0ea" /><Cyl p={[-1.4, 3.45, 0.2]} rt={0.2} h={0.16} color="#8a5a32" line={2} /><Ball p={[-1.4, 2.4, 0.2]} r={0.72} color={mixHex("#8a1022", "#ff2a2a", heat)} /><Glow p={[-1.4, 2.5, 0.8]} r={1.7} color="rgba(255,60,40,1)" o={0.5 * heat} />
    {puffs.map(([x, y, z, r, o], i) => o > 0.02 ? <Ball key={i} p={[x, y, z]} r={r} color="#f4f4f4" ink={0.03} /> : null)}
    <group position={[1.4, 1.8, 0.4]}><Cyl p={[0, 1.5, 0]} rt={0.14} h={3.0} color="#f0f0f0" line={2} /><Box p={[0, 0.2 + heat * 1.35, 0.05]} s={[0.1, 0.4 + heat * 2.7, 0.1]} color="#e5233a" line={0} /><Ball p={[0, 0.02, 0]} r={0.27} color="#e5233a" /></group>
    <Box p={[2.4, 1.92, 0.2]} s={[0.9, 0.16, 0.7]} color="#e9d9b0" line={2} /><Cyl p={[3.0, 1.9, -0.2]} rt={0.13} h={0.3} color="#f3e8d0" line={2} /><Flame p={[3.0, 2.05, -0.2]} t={t} s={0.2} />
    <Cyl p={[-3.3, 2.0, 0.1]} rt={0.24} h={0.5} color="#2a6a8a" line={2} /><Ball p={[-2.7, 1.95, 0.5]} r={0.26} color="#5aa05a" /><Chair p={[-5.6, 0, 2.6]} rotY={0.6} color="#6a4426" /><Rug p={[0, 0.01, 3]} s={[8, 4]} a="#5a1a2a" b="#c9a032" /><Lamp p={[6.4, 0, -4.4]} h={3.4} color="#ffe0a0" />
    <Glow p={[0, 5.5, -1]} r={7} color="rgba(255,190,100,1)" o={0.25} /><Shaft p={[3.3, 8.5, -4]} s={[2.4, 8]} rot={[0, 0, -0.4]} color="255,235,170" o={0.2} /><Dust t={t} area={[6, 5, 3]} color="rgba(255,230,170,.9)" />
    <Person p={[-2.7, 0, -1.7]} h={3.6} look={doctor} f={f} pose={{ mood: t < 15.6 ? "deadpan" : "worry", arms: t > 15.1 && t < 15.9 ? "point" : undefined, armK: 1, tilt: heat * 0.08, lookX: 0.6 }} />
    <Person p={[0.3, 0, -1.7]} h={3.6} look={doctor2} f={f + 5} pose={{ mood: t > 17.0 ? "grin" : "worry", armR: t > 17.04 ? [0.12, 0.7 + 0.12 * lift] : undefined, armRK: lift * (1 - seg(t, 18.4, 18.6)), arms: t > 18.5 ? "up" : "down", armK: seg(t, 18.5, 18.7) }} />
    <Person p={[3.0, jig.y, -1.7]} sy={0} h={3.6} look={doctor} f={f + 9} pose={{ mood: t > 18.1 ? "gulp" : "deadpan", lookX: -0.5, ...(t > 18.1 ? jig.pose : {}) }} />
    <FaceGroup p={[0.3, 0, -1.7]}><group position={ph}>
      {unroll < 0.05 ? <Cyl p={[0, 0, 0]} rt={0.1} h={0.8} color="#f1e2b8" line={2} rot={[0, 0, Math.PI / 2]} /> : <CanvasPlane p={[0, -0.9 * unroll - 0.1, 0.02]} s={[1.9, 1.8 * unroll + 0.01]} px={[190, 180]} frame="#6a4426" draw={(c, W, H) => { c.fillStyle = "#f6e8c0"; c.fillRect(0, 0, W, H); c.fillStyle = "#3a2412"; c.textAlign = "center"; c.textBaseline = "middle"; c.font = "800 18px Inter, Arial"; c.fillText("PRESCRIPTION", W / 2, 22); c.fillStyle = "#b3122e"; c.font = "900 48px Inter, Arial"; c.fillText("MORE", W / 2, 80); c.fillText("DANCING", W / 2, 128); c.beginPath(); c.arc(W - 26, H - 22, 14, 0, 7); c.fill(); }} />}
    </group></FaceGroup>
  </>);
};

/* ============ S6 18.7 – 22.4  "So the council builds a wooden stage, hires drummers and pipers," ============ */
const K6: Key[] = [
  { t: 18.5, pos: [-7.0, 2.8, 12.0], look: [-1.5, 2.4, -2], fov: 62 },
  { t: 20.0, pos: [-1.0, 3.6, 13.5], look: [-0.5, 2.0, -3], fov: 62 },
  { t: 21.1, pos: [3.0, 3.6, 10.5], look: [-0.5, 2.0, -3.2], fov: 58 },
  { t: 22.6, pos: [0.8, 3.2, 8.2], look: [-0.5, 2.4, -3.2], fov: 54 },
];
const plankT = (i: number) => 19.3 + i * 0.22;
export const S6 = ({ t, f }: Ctx) => {
  const planks = [0, 1, 2, 3, 4, 5, 6, 7];
  const px = (i: number) => -3.5 + i, py = (i: number) => { const u = clamp((t - plankT(i)) / 0.5); return u <= 0 ? 12 : u >= 1 ? 0.8 + 0.1 * Math.exp(-(t - plankT(i) - 0.5) * 12) * Math.abs(Math.sin((t - plankT(i) - 0.5) * 30)) : lerp(12, 0.8, u * u); };
  const hit = (k: number) => Math.max(0, Math.sin((t * 7.0 + k) * Math.PI)) ;
  const buy = seg(t, 20.85, 21.35, Easing.linear), dm = seg(t, 20.9, 21.7, ease), pp = seg(t, 21.6, 22.3, ease);
  const purseP: V3 = t < 20.85 ? [-5.6, 3.1, 0.5] : [lerp(-5.6, -2.2, buy), lerp(3.1, 2.4, buy) + Math.sin(buy * Math.PI) * 1.3, lerp(0.5, -3.0, buy)];
  return (<>
    <Cam t={t} keys={K6} impacts={[[plankT(7) + 0.5, 0.025]]} />
    <Lights warm="#ffc890" />
    <Plaza t={t} top="#ff9a50" bot="#ffe0a0" glowO={0.9} ground={["#a89a7e", "#988a6e"]} />
    <Ball p={[-14, 8, -80]} r={5} color="#fff0b0" ink={0} /><Glow p={[-14, 8, -79]} r={24} color="rgba(255,170,80,1)" o={0.6} />
    {/* stage frame + falling planks */}
    {[-4, 4].map((x) => [-5, -1.6].map((z) => <Box key={x + "_" + z} p={[x, 0.4, z]} s={[0.4, 0.8, 0.4]} color="#6a4426" line={3} />))}
    <Box p={[0, 0.6, -5]} s={[8.6, 0.3, 0.3]} color="#6a4426" line={3} /><Box p={[0, 0.6, -1.6]} s={[8.6, 0.3, 0.3]} color="#6a4426" line={3} />
    {planks.map((i) => <Box key={i} p={[px(i), py(i), -3.3]} s={[0.96, 0.18, 3.8]} color={i % 2 ? "#c9985a" : "#d4a566"} rot={[0, 0, t < plankT(i) + 0.5 ? (1 - clamp((t - plankT(i)) / 0.5)) * 0.4 : 0]} line={3} />)}
    {[-3.8, 3.8].map((x) => <Box key={x} p={[x, 1.5, -5.2]} s={[0.2, 1.4, 0.2]} color="#6a4426" line={2} />)}<Banner p={[0, 3.4, -5.4]} s={[4.2, 1.5]} text="STRASBOURG" size={52} bg="#9c1f2e" />
    <Barrel p={[-7, 0, -4]} /><Barrel p={[-7.6, 0, -3.2]} s={0.9} /><Crate p={[7.2, 0, -3]} /><Crate p={[7.6, 0, -2]} s={0.8} rotY={0.5} /><Cart p={[7.8, 0, 2]} rotY={-0.3} load="#8a5a32" /><Torch p={[-5, 0, -1]} t={t} on={0} /><Plant p={[6.2, 0, 3]} s={1.1} pot="#b5603a" /><Bench p={[-6.8, 0, 3]} rotY={0.4} />
    <Dust t={t} area={[7, 6, 4]} color="rgba(255,215,150,.9)" />
    {/* carpenters hammering */}
    {[-3.6, 3.7].map((x, k) => { const sw = Math.sin((t * 9.5) + k * 2), up = 0.52 + 0.3 * Math.max(0, sw); const on = t > plankT(0) - 0.1 && t < plankT(7) + 0.7;
      return <React.Fragment key={x}><Person p={[x, 0, -0.6]} h={3.0} look={carpenter} f={f + k * 4} pose={{ mood: "deadpan", armR: on ? [0.26, up] : undefined, armRK: on ? 1 : 0, tilt: on ? 0.05 * sw : 0, lookX: 0.5 }} />
        {on ? <FaceGroup p={[x, 0, -0.6]}><Box p={hand(3.0, [0.26, up + 0.08], 0, false, 0.1)} s={[0.34, 0.16, 0.16]} color="#5a5a66" line={2} /></FaceGroup> : null}</React.Fragment>; })}
    {/* council: points, pays */}
    {[[-6.6, 0.2], [-5.2, 1.4], [-4.8, -0.9]].map(([x, z], i) => <Person key={i} p={[x, 0, z]} h={3.4} look={i === 1 ? councilor2 : councilor} f={f + i * 6} pose={{ mood: i === 0 && t > 20.7 ? "grin" : "deadpan", arms: i === 0 && t > 19.2 && t < 20.7 ? "point" : undefined, armK: 1, armR: i === 1 && t > 20.6 && t < 20.9 ? [0.3, 0.72] : undefined, armRK: seg(t, 20.5, 20.65) * (1 - seg(t, 20.8, 20.9)), lookX: 0.6 }} />)}
    {t > 20.85 ? <Ball p={purseP} r={0.2} color="#8a5a32" /> : <FaceGroup p={[-5.2, 0, 1.4]}><Ball p={hand(3.4, [0.3, 0.72], 0, false, 0.12)} r={0.2} color="#8a5a32" /></FaceGroup>}
    {/* hired: drummer and piper climb on */}
    <Person p={[lerp(-8.5 + 0, -2.2, dm), 0.9 * seg(t, 21.2, 21.6, ease), lerp(1.8, -3.0, dm)]} sy={0} h={3.2} look={drummer} f={f} pose={{ mood: "grin", walk: dm < 1 ? dm * 6.5 * WALK * 1.1 : undefined, speed: dm < 1 ? 0.7 : 0, armR: dm >= 1 ? [0.25, 0.55 + 0.2 * Math.max(0, Math.sin(t * 8))] : undefined, armRK: dm >= 1 ? 1 : 0 }} />
    <Person p={[lerp(8.5, 1.8, pp), 0.9 * seg(t, 22.0, 22.35, ease), lerp(1.6, -3.0, pp)]} sy={0} h={3.2} look={piper} f={f + 3} pose={{ mood: "smile", flip: true, walk: pp < 1 ? pp * 6.7 * WALK * 1.1 : undefined, speed: pp < 1 ? 0.7 : 0, armR: pp >= 1 ? [0.14, 0.62] : undefined, armRK: pp >= 1 ? 1 : 0 }} />
    <Cyl p={[lerp(-8.5, -2.2, dm) + 0.65, 1.2 + 0.9 * seg(t, 21.2, 21.6), lerp(1.8, -3.0, dm) + 0.1]} rt={0.5} h={0.7} color="#c9402e" line={3} rot={[0.3, 0, 0]} />
  </>);
};

/* ============ S7 22.4 – 25.2  "and clears the guildhalls so nobody has to stop." ============ */
const K7: Key[] = [
  { t: 22.2, pos: [0, 2.0, 15], look: [0, 3.0, -4], fov: 58 },
  { t: 23.7, pos: [0, 2.6, 10.5], look: [0, 2.9, -4], fov: 56 },
  { t: 25.4, pos: [0, 2.9, 7.6], look: [0, 2.8, -6], fov: 54 },
];
const HZ = -4;
export const S7 = ({ t, f }: Ctx) => {
  const open = seg(t, 22.54, 22.95, Easing.out(Easing.cubic)), sl = (t0: number, v0: number) => { const d = Math.max(0, t - t0), tt = Math.min(d, v0 / 6); return v0 * tt - 3 * tt * tt; };
  const dancers = [0, 1, 2, 3, 4].map((i) => { const st = 23.4 + i * 0.28, k = seg(t, st, st + 1.7, Easing.linear); return { i, z: lerp(3.5 - i * 0.8, -6.2, k), x: (i - 2) * 1.15 * (1 - k * 0.5), d: danceBeat(t, i + 2, 0.7), k }; });
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#ffd8a0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#9ab8f0" bottom="#ffe6b8" />
    <Surface p={[0, 0, 4]} s={[50, 30]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#9a9488" b="#8a8478" unit={1.5} />
    <WallDoor z={HZ} W={22} kind="brick" a="#a8683e" b="#9a5c34" door={{ x: 0, w: 6, h: 5.6 }} base="#5a3a22" />
    <Extrude p={[0, 9, HZ - 1.6]} pts={[[-11.5, 0], [11.5, 0], [0, 4.6]]} depth={4} color="#7a2a2a" line={4} />
    {[-9, -6, 6, 9].map((x) => <Box key={x} p={[x, 4.5, HZ + 0.1]} s={[0.3, 9, 0.15]} color="#3a2412" line={2} />)}<Box p={[0, 6.2, HZ + 0.1]} s={[7, 0.4, 0.2]} color="#3a2412" line={2} />
    <Banner p={[0, 7.6, HZ + 0.3]} s={[4.2, 1.6]} text="GUILDHALL" size={60} bg="#1f4a8a" />
    {[-8, 8].map((x) => <Banner key={x} p={[x, 6.2, HZ + 0.2]} s={[1.5, 3]} text="⚒" bg="#9c1f2e" size={100} />)}
    <Box p={[0, 0, HZ - 5]} s={[0.01, 0.01, 0.01]} color="#000" line={0} />
    <Box p={[0, 4.5, HZ - 9.6]} s={[14, 9, 0.2]} color="#3a2418" /><Box p={[-7, 4.5, HZ - 4.8]} s={[0.2, 9, 10]} color="#4a3020" /><Box p={[7, 4.5, HZ - 4.8]} s={[0.2, 9, 10]} color="#4a3020" /><Box p={[0, 9, HZ - 4.8]} s={[14, 0.2, 10]} color="#3a2418" />
    <Surface p={[0, 0.02, HZ - 4.8]} s={[14, 10]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#a8703a" b="#986430" unit={1.6} />
    {[-4, 4].map((x) => <React.Fragment key={x}><Cyl p={[x, 6, HZ - 5.5]} rt={0.1} h={6} color="#3a2412" line={1} /><Cyl p={[x, 3.0, HZ - 5.5]} rt={0.5} rb={0.9} h={0.5} color="#c9a032" line={3} /><Glow p={[x, 2.8, HZ - 5.4]} r={3.4} color="rgba(255,200,110,1)" o={0.6} /></React.Fragment>)}
    <Glow p={[0, 3, HZ - 3]} r={9} color="rgba(255,190,90,1)" o={0.4} />
    <group position={[-3, 0, HZ + 0.02]} rotation={[0, open * 1.45, 0]}><Box p={[1.5, 2.8, 0]} s={[3, 5.6, 0.18]} color="#7a4a26" /><Box p={[1.5, 4.5, 0.1]} s={[2.8, 0.2, 0.05]} color="#2b2a35" line={1} /><Box p={[1.5, 1.2, 0.1]} s={[2.8, 0.2, 0.05]} color="#2b2a35" line={1} /></group>
    <group position={[3, 0, HZ + 0.02]} rotation={[0, -open * 1.45, 0]}><Box p={[-1.5, 2.8, 0]} s={[3, 5.6, 0.18]} color="#7a4a26" /><Box p={[-1.5, 4.5, 0.1]} s={[2.8, 0.2, 0.05]} color="#2b2a35" line={1} /><Box p={[-1.5, 1.2, 0.1]} s={[2.8, 0.2, 0.05]} color="#2b2a35" line={1} /></group>
    {/* furniture cleared out: benches slide, barrels roll (friction), stools tumble */}
    {[[-1.6, 22.9, 9.5], [1.5, 23.0, 8.5], [0.0, 23.1, 11]].map(([x, t0, v], i) => <group key={i} position={[x, 0, HZ - 1.5 + sl(t0, v)]} rotation={[0, i * 0.15, 0]}><Bench p={[0, 0, 0]} /></group>)}
    {[[-2.4, 22.95, 8], [2.6, 23.05, 7]].map(([x, t0, v], i) => { const d = sl(t0, v); return <group key={i} position={[x, 0.45, HZ - 2 + d]} rotation={[d / 0.45 * (i ? -1 : 1), 0, Math.PI / 2]}><Cyl p={[0, 0, 0]} rt={0.42} rb={0.38} h={1.0} color="#8a5a32" /><Cyl p={[0, 0.3, 0]} rt={0.43} h={0.07} color="#2b2a35" line={2} /></group>; })}
    <Crate p={[-4.6, 0, 1.4]} rotY={0.5} /><Barrel p={[4.6, 0, 1.0]} /><Plant p={[-6.5, 0, 1]} s={1.2} pot="#b5603a" /><Torch p={[-3.6, 0, 0.6]} t={t} on={0} /><Torch p={[3.6, 0, 0.6]} t={t} on={0} /><Dust t={t} area={[7, 7, 5]} color="rgba(255,225,170,.9)" />
    {/* two clerks shove them out */}
    {[-4.2, 4.2].map((x, k) => <Person key={x} p={[x, 0, HZ + 0.9]} h={3.2} look={k ? councilor2 : councilor} f={f + k * 5} pose={{ mood: "worry", arms: t > 22.5 ? "point" : undefined, armK: seg(t, 22.5, 22.7), flip: k === 0, lookX: 0.4 }} />)}
    {dancers.map(({ i, z, x, d, k }) => <Person key={i} p={[x, d.y, z]} sy={0} h={3.1} look={i ? villagers[i + 1] : troffeaBleed} f={f + i * 5} pose={{ mood: "deadpan", sweat: i % 2, ...d.pose }} />)}
  </>);
};
