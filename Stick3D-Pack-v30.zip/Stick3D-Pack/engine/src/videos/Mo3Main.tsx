import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES, tintFor } from "./Mo3";
import { Captions } from "../Main";
export const MCUTS = [0, 4.9, 9.0, 12.4, 14.7, 17.7, 24.9, 29.5, 33.0, 39.0, 43.1, 46.0, 50.9, 54.6];
const BG = ["#6aa0e0", "#6aa0e0", "#6aa0e0", "#7a9ac0", "#5a4630", "#1a1630", "#d8a860", "#7a8aa8", "#2a3a50", "#5a4630", "#1a1a28", "#5a4630", "#1c1630"];
const TR: Trans[] = ["ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost", "ghost"];
export const Mo3Main: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 13 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={MCUTS[i]} end={MCUTS[i + 1]} bg={BG[i]} trans={TR[i]} tint={tintFor(i)}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
