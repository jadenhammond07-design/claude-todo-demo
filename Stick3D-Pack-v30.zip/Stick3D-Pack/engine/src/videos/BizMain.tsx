import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Biz";
import { Captions } from "../Main";
export const BCUTS = [0, 3.2, 10.2, 15.8, 25.0, 31.8, 39.5, 44.4, 46.3, 52.6, 56.2, 59.0];
const BG = ["#2a7ad8", "#2fb8c8", "#dff0ff", "#cfd8e0", "#e0f6ff", "#6ac8d8", "#5aa8ff", "#d8e4f4", "#5a1620", "#ffe8a8", "#0e1630"];
const TR: Trans[] = ["ghost", "whip", "zoom", "ghost", "whip", "zoom", "ghost", "flash", "flash", "ghost", "zoom"];
export const BizMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 11 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={BCUTS[i]} end={BCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
