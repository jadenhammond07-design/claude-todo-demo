import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Eoh";
import { Captions } from "../Main";
export const ECUTS = [0, 3.9, 9.0, 15.2, 19.6, 22.6, 27.4, 30.4, 35.0, 41.5, 43.6, 46.8];
const BG = ["#bcd0e8", "#e8d8b8", "#5aa8ff", "#7a98c0", "#4a68a0", "#8aa8d0", "#ff9a50", "#2a3a5a", "#1a1630", "#1a1630", "#2a1a5a"];
const TR: Trans[] = ["ghost", "ghost", "zoom", "whip", "ghost", "flash", "ghost", "zoom", "flash", "ghost", "ghost"];
export const EohMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 11 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={ECUTS[i]} end={ECUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
