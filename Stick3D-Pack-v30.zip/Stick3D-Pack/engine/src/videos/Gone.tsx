// EARTH WITHOUT HUMANS — 11 scenes. Generic stick figures, no gore; nuclear beat shown only as warning lights.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Dust } from "../style/props";
import { Cam, Key, Building, StreetLamp, Taxi, Globe } from "../style/extra";
import { Sky } from "../style/medieval";
import { Mug } from "../style/extra";
import { Tree, Bush, Weed, Water, Animal, Cap } from "../style/nature";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const PEOPLE: Look[] = [
  mk("#d9a77c", "#ff7a29", "hoodie", "short"), mk("#8d5a3a", "#2f8cff", "shirt", "bob", "#2a1a10"), mk("#f3d3b2", "#e5233a", "blazer", "swept", "#7a4a20", { shirt: "#fff" }),
  mk("#c68e62", "#2fd4a0", "hoodie", "short", "#111"), mk("#e8b88c", "#9a5ad8", "shirt", "bob", "#c08a3a"),
];
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
/** person that vanishes: squashes to nothing with a little poof */
const Vanish: React.FC<{ p: V3; look: Look; f: number; t: number; at: number; walk?: boolean; h?: number; flip?: boolean }> = ({ p, look, f, t, at, walk, h = 3.4, flip }) => {
  const k = 1 - seg(t, at, at + 0.28, Easing.in(Easing.quad)), poof = seg(t, at + 0.1, at + 0.6);
  return (<>
    {k > 0.01 ? <group position={p} scale={[1 + 0.4 * (1 - k), Math.max(0.001, k), 1]}><Person p={[0, 0, 0]} h={h} look={look} f={f} pose={{ mood: "smile", walk: walk ? t * 3 : undefined, speed: walk ? 0.5 : 0, flip }} /></group> : null}
    {poof > 0 && poof < 1 ? Array.from({ length: 6 }, (_, i) => <Ball key={i} p={[p[0] + Math.cos(i) * poof * 0.9, p[1] + 1.2 + Math.sin(i * 2) * poof * 0.7, p[2]]} r={0.32 * (1 - poof) + 0.01} color="#ffffff" ink={0.02} />) : null}
  </>);
};
const Street: React.FC<{ dark?: number; crack?: number }> = ({ dark = 0, crack = 0 }) => (<>
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={dark > 0.5 ? "#2a2c38" : "#4a4c58"} b="#4a4c58" />
  <Surface p={[0, 0.01, -4.2]} s={[60, 2.4]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#9a9aa8" b="#8a8a98" unit={1.2} />
  {Array.from({ length: 8 }, (_, i) => <Box key={i} p={[-14 + i * 4, 0.02, 1.0]} s={[1.6, 0.02, 0.2]} color="#ffd23a" line={0} />)}
  {crack > 0 ? Array.from({ length: 7 }, (_, i) => <Box key={"c" + i} p={[-4 + i * 1.3, 0.03, 2.4 - (i % 3) * 1.1]} s={[1.2 * crack, 0.02, 0.06]} rot={[0, (i * 1.7) % 1.2 - 0.6, 0]} color="#14141c" line={0} />) : null}
</>);
const Skyline: React.FC<{ lit?: (i: number) => number; z?: number; grow?: number; sink?: number }> = ({ lit = () => 0.35, z = -7, grow = 0, sink = 0 }) => (<>
  {[[-6.4, 9, "#6a7aa8"], [-3.4, 13, "#8a6aa8"], [-0.4, 11, "#5a8aa0"], [2.6, 15, "#a87a6a"], [5.6, 10, "#6aa08a"]].map(([x, h, col], i) => {
    const hh = (h as number) * (1 - sink); return hh > 0.2 ? <React.Fragment key={i}><Building p={[x as number, 0, z]} s={[2.6, hh, 2.4]} color={col as string} seed={i + 3} lit={lit(i)} />
      {grow > 0 ? <><Box p={[(x as number) - 1.0, hh * 0.5 * grow, z + 1.25]} s={[0.25, hh * grow, 0.05]} color="#3fae4a" line={2} /><Box p={[(x as number) + 0.7, hh * 0.35 * grow, z + 1.25]} s={[0.22, hh * 0.7 * grow, 0.05]} color="#4cc25a" line={2} /></> : null}</React.Fragment> : null;
  })}
</>);

/* ============ S1 0 – 4.19  hook: people vanish ============ */
export const S1 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={[{ t: 0, pos: [0, 4.6, 16], look: [0, 3.2, 0], fov: 56 }, { t: 2.9, pos: [0, 5.6, 17.5], look: [0, 4.0, 0], fov: 58 }, { t: 4.4, pos: [0, 7.0, 18.5], look: [0, 5.0, -2], fov: 60 }]} />
  <Lights warm="#fff0d8" />
  <Sky p={[0, 26, -40]} s={[200, 90]} top="#5aa0e8" bottom="#cfe8ff" />
  <Street /><Skyline />
  {PEOPLE.map((lk, i) => <Vanish key={i} p={[-3.6 + i * 1.8, 0, 1.4 + (i % 2) * 1.2]} look={lk} f={f + i * 3} t={t} at={1.3 + i * 0.16} walk flip={i % 2 === 1} />)}
  <Taxi p={[3.4, 0, -1.6]} /><StreetLamp p={[-4.6, 0, -3.4]} />
  <Dust t={t} area={[10, 6, 5]} color="rgba(255,255,255,.8)" />
</>);

/* ============ S2 4.19 – 7.89  "Tomorrow, 8 a.m. Every human on Earth is gone." ============ */
export const S2 = ({ t, f }: Ctx) => {
  const clk = seg(t, 4.87, 5.15, back), zero = seg(t, 7.23, 7.5, back);
  return (<>
    <Cam t={t} keys={[{ t: 4.0, pos: [-0.6, 4.6, 16], look: [0, 3.8, 0], fov: 56 }, { t: 8.1, pos: [0.2, 4.4, 14], look: [0, 3.6, 0], fov: 56 }]} />
    <Lights warm="#fff4e0" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#ffb070" bottom="#ffe8c0" glowAt={[0.8, "rgba(255,220,140,1)"]} />
    <Street /><Skyline />
    <Sign p={[0, 7.8, -4.0]} w={4.2 * clk + 0.001} h={1.6 * clk + 0.001} text="8:00 AM" size={84} bg="#14141c" fg="#ff3a3a" face={false} />
    {/* things left behind */}
    <Taxi p={[-2.4, 0, -1.2]} /><Mug p={[1.4, 0.05, 2.2]} s={1.4} /><Box p={[2.6, 0.1, 2.6]} s={[0.9, 0.2, 0.6]} color="#2f8cff" line={3} rot={[0, 0.4, 0]} />
    <Cyl p={[-0.6, 0.12, 3.0]} rt={0.45} rb={0.5} h={0.24} color="#14141c" line={3} />
    <Sign p={[0, 4.0, 2.4]} w={4.4 * zero + 0.001} h={1.3 * zero + 0.001} text="0 HUMANS" size={62} bg="#e5233a" fg="#fff" />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,240,210,.8)" />
  </>);
};

/* ============ S3 7.89 – 9.88  "Nobody is left to run the pumps." ============ */
export const S3 = ({ t, f }: Ctx) => {
  const stop = seg(t, 8.6, 9.5), spin = t * 8 * (1 - stop) + stop * 2, off = seg(t, 9.18, 9.4, back), alarm = 0.5 + 0.5 * Math.sin(t * 14);
  return (<>
    <Cam t={t} keys={[{ t: 7.7, pos: [0, 4.0, 13], look: [0, 2.8, 0], fov: 56 }, { t: 10.1, pos: [0, 3.6, 10.5], look: [0, 2.8, 0], fov: 52 }]} />
    <Lights warm="#d8e0ff" />
    <Surface p={[0, 0, 0]} s={[40, 30]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#5a6070" b="#4e5464" unit={1.6} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.4]} color="#3a4050" line={3} />
    {[-2.6, 0, 2.6].map((x, i) => <group key={i}>
      <Cyl p={[x, 1.4, -1]} rt={0.9} h={2.8} color="#2f8cff" line={4} />
      <group position={[x, 3.2, -1]} rotation={[0, spin + i, 0]}><Box p={[0, 0, 0]} s={[2.0, 0.18, 0.3]} color="#ffd23a" line={2} /></group>
      <Cyl p={[x, 4.4, -1]} rt={0.25} h={2.4} color="#8a8a98" line={2} />
    </group>)}
    <Box p={[0, 4.6, -1]} s={[7.2, 0.4, 0.4]} color="#8a8a98" line={3} />
    <Glow p={[0, 6.4, -3]} r={8} color="rgba(255,40,40,1)" o={0.55 * alarm * stop} />
    <Sign p={[0, 7.0, 0.5]} w={5.0 * off + 0.001} h={1.3 * off + 0.001} text="PUMPS: OFF" size={78} bg="#14141c" fg="#ff3a3a" />
  </>);
};

/* ============ S4 9.88 – 16.2  subway floods ============ */
export const S4 = ({ t, f }: Ctx) => {
  const lvl = lerp(0, 2.6, seg(t, 11.0, 16.0, Easing.inOut(Easing.quad))), gw = seg(t, 12.96, 13.3, back), nyc = seg(t, 10.86, 11.2, back);
  return (<>
    <Cam t={t} keys={[{ t: 9.7, pos: [0, 3.6, 14], look: [0, 2.6, -4], fov: 58 }, { t: 13.0, pos: [0, 3.2, 11], look: [0, 2.2, -6], fov: 56 }, { t: 16.4, pos: [0, 3.8, 9.5], look: [0, 2.0, -6], fov: 54 }]} />
    <Lights warm="#cfe0ff" />
    {/* tunnel */}
    <Surface p={[0, 0, -10]} s={[10, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#3a3a46" b="#32323e" unit={1.4} />
    <Box p={[-4.6, 3, -10]} s={[0.4, 6, 40]} color="#5a5a6a" line={3} /><Box p={[4.6, 3, -10]} s={[0.4, 6, 40]} color="#5a5a6a" line={3} /><Box p={[0, 6.1, -10]} s={[9.6, 0.4, 40]} color="#4a4a5a" line={3} />
    {[-0.8, 0.8].map((x, i) => <Box key={i} p={[x, 0.08, -10]} s={[0.14, 0.16, 40]} color="#9a9aa8" line={1} />)}
    {Array.from({ length: 8 }, (_, i) => <Glow key={i} p={[0, 5.6, 4 - i * 4]} r={1.4} color="rgba(255,230,160,1)" o={0.5 * (1 - seg(t, 13.5 + i * 0.1, 14.0 + i * 0.1)) + 0.08} />)}
    <Sign p={[0, 3.2, -1]} w={3.6 * nyc + 0.001} h={0.9} text="NYC SUBWAY" size={46} bg="#14141c" fg="#fff" face={false} />
    <Water p={[0, 0, -10]} w={9} d={40} level={lvl} />
    {Array.from({ length: 10 }, (_, i) => { const u = (t * 1.4 + i * 0.13) % 1; return t > 10.2 ? <Ball key={i} p={[-4.2 + (i % 2) * 8.4, 5.6 - u * 5.4, -1 - i * 1.6]} r={0.08} color="#7ac0ff" ink={0.02} /> : null; })}
    <Sign p={[0, 4.6, 1.0]} w={4.4 * gw + 0.001} h={1.1 * gw + 0.001} text="GROUNDWATER ↑" size={50} bg="#1f6ad8" fg="#fff" />
  </>);
};

/* ============ S5 16.2 – 20.72  power grid fails ============ */
export const S5 = ({ t, f }: Ctx) => {
  const out = (i: number) => 0.55 * (1 - seg(t, 16.95 + i * 0.45, 17.15 + i * 0.45)), globe = seg(t, 19.0, 20.0, ease), sg = seg(t, 16.61, 16.9, back);
  return (<>
    <Cam t={t} keys={[{ t: 16.0, pos: [0, 4.6, 16], look: [0, 5.0, -4], fov: 58 }, { t: 19.0, pos: [0, 5.2, 17], look: [0, 5.4, -4], fov: 58 }, { t: 20.9, pos: [0, 6.0, 18.5], look: [0, 6.4, -4], fov: 60 }]} />
    <Lights warm="#8a9ad8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#0a0e24" bottom="#2a3060" stars={60} t={t} />
    <Street dark={1} /><Skyline lit={out} />
    {[-4.4, 0, 4.4].map((x, i) => <StreetLamp key={i} p={[x, 0, -3.0]} on={1 - seg(t, 17.3 + i * 0.5, 17.4 + i * 0.5)} />)}
    <Sign p={[0, 9.6, -3]} w={5.2 * sg + 0.001} h={1.2 * sg + 0.001} text="GRID FAILURE" size={70} bg="#14141c" fg="#ffd23a" />
    {globe > 0 ? <group position={[0, 12.5, -4]} scale={[globe, globe, globe]}><Globe p={[0, 0, 0]} r={2.0} rotY={t * 0.6} /><Glow p={[0, 0, 0.5]} r={2.6} color="rgba(20,20,60,1)" o={0.6} /></group> : null}
  </>);
};

/* ============ S6 20.72 – 24.84  nuclear plants (warning lights only) ============ */
export const S6 = ({ t, f }: Ctx) => {
  const cool = 1 - seg(t, 22.86, 24.0), warn = seg(t, 24.06, 24.4, back), blink = 0.5 + 0.5 * Math.sin(t * 12);
  return (<>
    <Cam t={t} keys={[{ t: 20.5, pos: [0, 6.0, 26], look: [0, 5.0, -4], fov: 58 }, { t: 25.0, pos: [0, 5.4, 22.5], look: [0, 4.8, -4], fov: 56 }]} />
    <Lights warm="#ffe0c8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#6a5a7a" bottom="#e8b090" />
    <Surface p={[0, 0, -6]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6a7a5a" b="#6a7a5a" />
    {[-2.6, 2.6].map((x, i) => <group key={i}>
      <Cyl p={[x, 3.5, -5]} rt={1.6} rb={2.4} h={7} color="#d8d4cc" line={4} />
      {Array.from({ length: 5 }, (_, j) => { const u = (t * 0.4 + j / 5) % 1; return <Ball key={j} p={[x + Math.sin(j * 2 + t) * 0.4, 7.4 + u * 3.6, -5]} r={(0.8 + u * 0.8) * (0.3 + 0.7 * cool)} color="#ffffff" ink={0.02} />; })}
    </group>)}
    <Box p={[0, 1.4, -1.6]} s={[3.2, 2.8, 2.4]} color="#8a8aa0" line={4} />
    <Glow p={[0, 3.4, -0.2]} r={6} color="rgba(255,40,40,1)" o={0.6 * blink * seg(t, 22.86, 23.2)} />
    <CanvasPlane p={[0, 6.6, 0.6]} s={[4.4, 1.3]} px={[440, 130]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(4, 4, W - 8, H - 8, 16); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 38px Inter, Arial"; c.textAlign = "left"; c.textBaseline = "middle"; c.fillText("COOLING", 20, H / 2); c.fillStyle = "#333"; c.fillRect(200, 40, 210, 50); c.fillStyle = cool > 0.5 ? "#2fd46a" : cool > 0.2 ? "#ffd23a" : "#e5233a"; c.fillRect(200, 40, 210 * cool, 50); c.strokeStyle = "#fff"; c.lineWidth = 3; c.strokeRect(200, 40, 210, 50); }} />
    <Sign p={[0, 4.6, 1.4]} w={4.0 * warn + 0.001} h={1.3 * warn + 0.001} text="⚠ RISK" size={80} bg="#ffd23a" fg="#14141c" />
  </>);
};

/* ============ S7 24.84 – 31.18  time-lapse decay ============ */
export const S7 = ({ t, f }: Ctx) => {
  const weeds = seg(t, 25.98, 27.0, back), crack = seg(t, 26.62, 27.0), roof = seg(t, 29.2, 29.8, Easing.in(Easing.quad)), rust = seg(t, 30.3, 31.0);
  const year = t < 25.4 ? 1 : t < 27.77 ? Math.round(lerp(1, 5, seg(t, 25.4, 26.2))) : Math.round(lerp(5, 50, seg(t, 27.77, 28.8)));
  const steel = `rgb(${Math.round(lerp(120, 170, rust))},${Math.round(lerp(130, 80, rust))},${Math.round(lerp(150, 40, rust))})`;
  return (<>
    <Cam t={t} keys={[{ t: 24.6, pos: [-1.0, 4.0, 13], look: [0, 2.8, -2], fov: 56 }, { t: 28.0, pos: [0.0, 4.2, 13.5], look: [0, 3.0, -2], fov: 56 }, { t: 31.4, pos: [0.6, 4.6, 14.5], look: [0.4, 3.4, -2], fov: 58 }]} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#7ab0e8" bottom="#e8f4ff" />
    <Street crack={crack} />
    {/* house that collapses */}
    <group position={[-2.6, 0, -3]}>
      <Box p={[0, 1.4, 0]} s={[3.2, 2.8, 2.6]} color="#e8c890" line={4} /><Box p={[0, 1.0, 1.31]} s={[0.8, 1.6, 0.04]} color="#6a4426" line={2} />
      <group position={[-1.6, 2.8, 0]} rotation={[0, 0, -roof * 0.9]}><Box p={[1.7, 0.6, 0]} s={[3.8, 0.3, 3.0]} rot={[0, 0, 0.32]} color="#c0402e" line={4} /></group>
    </group>
    {/* bridge that rusts */}
    <group position={[3.0, 0, -5]}>
      {[-1.8, 1.8].map((x, i) => <Box key={i} p={[x, 1.8, 0]} s={[0.4, 3.6, 0.4]} color={steel} line={3} />)}
      <Box p={[0, 3.7, 0]} s={[5.4, 0.35, 1.6]} color={steel} line={3} />
      {[-1.2, 0, 1.2].map((x, i) => <Box key={i} p={[x, 4.4, 0]} s={[0.12, 1.4, 0.12]} rot={[0, 0, 0.5 * (i - 1)]} color={steel} line={2} />)}
    </group>
    {Array.from({ length: 9 }, (_, i) => <Weed key={i} p={[-4 + i * 1.0, 0, 2.4 - (i % 3) * 1.0]} k={weeds * (0.7 + 0.4 * ((i * 7) % 3) / 2)} />)}
    <Sign p={[0, 8.4, -2]} w={4.0} h={1.4} text={`YEAR ${year}`} size={90} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S8 31.18 – 34.93  cities become forests ============ */
export const S8 = ({ t, f }: Ctx) => {
  const g = seg(t, 31.6, 33.4, ease), sg = seg(t, 33.49, 33.8, back);
  return (<>
    <Cam t={t} keys={[{ t: 31.0, pos: [0, 4.6, 17], look: [0, 4.4, -3], fov: 58 }, { t: 35.1, pos: [0, 3.6, 13.5], look: [0, 3.6, -3], fov: 56 }]} />
    <Lights warm="#f0ffe0" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#6ab0e0" bottom="#e0f4d0" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#4a4c58" b="#4a4c58" />
    <Surface p={[0, 0.02, 0]} s={[60 * g + 0.01, 40 * g + 0.01]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#5aa04a" b="#5aa04a" />
    <Skyline lit={() => 0} grow={g} />
    {[[-5.0, -3.2, 6], [-2.0, -2.6, 5], [1.2, -3.0, 6.5], [4.4, -2.8, 5.5], [-3.6, 1.0, 4], [3.0, 1.4, 4.5], [0, -0.4, 3.5]].map(([x, z, h], i) => <Tree key={i} p={[x, 0, z]} h={h} k={seg(t, 31.6 + i * 0.18, 32.4 + i * 0.18, back)} sway={Math.sin(t * 1.5 + i) * 0.03} />)}
    {Array.from({ length: 8 }, (_, i) => <Bush key={i} p={[-4.2 + i * 1.2, 0, 2.8 - (i % 2) * 0.8]} s={g} />)}
    <Taxi p={[1.6, 0, 1.4]} color="#b89a3a" /><Bush p={[1.6, 0.6, 1.4]} s={seg(t, 32.6, 33.4)} />
    <Sign p={[0, 9.4, -2]} w={6.4 * sg + 0.001} h={1.3 * sg + 0.001} text="NATURE TAKES BACK" size={56} bg="#1fa850" fg="#fff" />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,255,220,.8)" />
  </>);
};

/* ============ S9 34.93 – 41.26  Chernobyl exclusion zone: wolves, boar, deer ============ */
export const S9 = ({ t, f }: Ctx) => {
  const zs = seg(t, 34.93, 35.3, back), wx = lerp(-9, -2.6, seg(t, 37.6, 39.2, Easing.out(Easing.quad))), bx = lerp(9, 2.4, seg(t, 38.3, 39.8, Easing.out(Easing.quad))), dx = lerp(-9, 0.2, seg(t, 39.0, 40.6, Easing.out(Easing.quad)));
  return (<>
    <Cam t={t} keys={[{ t: 34.7, pos: [0, 4.6, 16], look: [0, 3.6, -2], fov: 58 }, { t: 37.6, pos: [0, 3.6, 14], look: [0, 2.4, -1], fov: 56 }, { t: 41.5, pos: [0, 3.2, 12.5], look: [0, 2.0, 0], fov: 54 }]} />
    <Lights warm="#f4ecd8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#8aa0b8" bottom="#e8e4d0" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6a8a4a" b="#6a8a4a" />
    {/* abandoned block, overgrown */}
    <Building p={[-1.8, 0, -8]} s={[5.0, 9, 2.6]} color="#b8b0a0" seed={9} lit={0} />
    <Building p={[4.2, 0, -9]} s={[3.0, 7, 2.4]} color="#a8a090" seed={4} lit={0} />
    {[[-5.2, -4.2, 6], [5.6, -4.0, 5.5], [-3.6, -5.6, 5], [2.0, -5.2, 4.6]].map(([x, z, h], i) => <Tree key={i} p={[x, 0, z]} h={h} color="#5a9a3a" sway={Math.sin(t + i) * 0.03} />)}
    {/* the zone sign */}
    <group position={[-2.6, 0, -1.6]}>
      <Cyl p={[-1.1, 1.3, 0]} rt={0.08} h={2.6} color="#5a5a62" line={2} /><Cyl p={[1.1, 1.3, 0]} rt={0.08} h={2.6} color="#5a5a62" line={2} />
      <CanvasPlane p={[0, 2.6, 0.05]} s={[2.8 * zs + 0.001, 1.6 * zs + 0.001]} px={[280, 160]} draw={(c, W, H) => { c.fillStyle = "#ffd23a"; c.strokeStyle = INK; c.lineWidth = 8; c.fillRect(4, 4, W - 8, H - 8); c.strokeRect(4, 4, W - 8, H - 8); c.fillStyle = "#14141c"; c.font = "900 60px Inter, Arial"; c.textAlign = "center"; c.fillText("☢", W / 2, 70); c.font = "900 26px Inter, Arial"; c.fillText("EXCLUSION ZONE", W / 2, 128); }} />
    </group>
    <Sign p={[2.4, 6.6, -2]} w={3.8 * zs + 0.001} h={1.0 * zs + 0.001} text="CHERNOBYL" size={50} bg="#14141c" fg="#fff" />
    <Animal p={[wx, 0, 1.0]} kind="wolf" t={t} walk={wx < -2.7 ? 1 : 0} s={1.2} />
    <Animal p={[bx, 0, 2.4]} kind="boar" t={t} walk={bx > 2.5 ? 1 : 0} flip s={1.1} />
    <Animal p={[dx, 0, -0.8]} kind="deer" t={t} walk={dx < 0.1 ? 1 : 0} s={1.2} />
    {[["WOLVES", 37.74, -1.8, 3.4], ["BOAR", 38.4, 2.4, 3.0], ["DEER", 39.15, 0.2, 4.4]].map(([txt, at, x, y], i) => { const k = seg(t, at as number, (at as number) + 0.3, back); return <Sign key={i} p={[x as number, y as number, 1.4]} w={2.2 * k + 0.001} h={0.8 * k + 0.001} text={txt as string} size={44} bg="#fff" fg="#14141c" />; })}
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,250,220,.8)" />
  </>);
};

/* ============ S10 41.26 – 50.65  plastic outlasts everything ============ */
export const S10 = ({ t, f }: Ctx) => {
  const q = seg(t, 41.9, 42.2, back), bottle = seg(t, 42.22, 42.6, back), sink = seg(t, 45.6, 46.5, Easing.in(Easing.quad)), proof = seg(t, 47.83, 48.2, back), push = seg(t, 48.6, 50.4, ease);
  return (<>
    <Cam t={t} keys={[{ t: 41.0, pos: [0, 5.4, 17], look: [0, 5.0, -3], fov: 58 }, { t: 45.0, pos: [0, 5.0, 16], look: [0, 4.6, -3], fov: 58 }, { t: 48.4, pos: [0, 3.4, 11], look: [0, 1.6, 0], fov: 54 }, { t: 50.9, pos: [0, 2.0, 6.0], look: [0, 0.4, 1.0], fov: 48 }]} />
    <Lights warm="#ffe8c8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#3a2a5a" bottom="#e89060" glowAt={[0.8, "rgba(255,190,110,1)"]} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a5a3a" b="#7a5a3a" />
    <Skyline lit={() => 0} sink={sink} z={-8} />
    {[[-5.0, -4.0, 5], [5.0, -4.2, 5.5]].map(([x, z, h], i) => <Tree key={i} p={[x, 0, z]} h={h} />)}
    <Sign p={[0, 9.2, -2]} w={1.8 * q * (1 - seg(t, 42.2, 42.4)) + 0.001} h={1.8 * q * (1 - seg(t, 42.2, 42.4)) + 0.001} text="?" size={140} bg="#14141c" fg="#ffe14a" />
    {/* the bottle and its cap */}
    <group position={[0, 0, 1.0]} scale={[bottle + 0.001, bottle + 0.001, bottle + 0.001]}>
      <group rotation={[0, 0, Math.PI / 2 * 0.92]} position={[0.9, 0.3, 0]}><Cyl p={[0, 0, 0]} rt={0.3} h={1.5} color="#a8d8f0" line={3} /><Cyl p={[0, 0.95, 0]} rt={0.14} rb={0.3} h={0.4} color="#a8d8f0" line={2} /></group>
      <Cap p={[-0.3, 0, 0.6]} r={0.28} />
    </group>
    <Glow p={[0, 0.6, 1.4]} r={2.2} color="rgba(255,220,140,1)" o={0.5 * bottle} />
    <Sign p={[0, 7.0, -1]} w={4.4 * bottle * (1 - push) + 0.001} h={1.2 * bottle * (1 - push) + 0.001} text="PLASTIC OUTLASTS" size={44} bg="#1f6ad8" fg="#fff" />
    <Sign p={[0, 2.3, 0.2]} w={4.2 * proof + 0.001} h={0.8 * proof + 0.001} text="LAST PROOF WE EXISTED" size={30} bg="#fff" fg="#e5233a" />
    <Dust t={t} area={[8, 5, 5]} color="rgba(255,230,190,.8)" />
  </>);
};

/* ============ S11 50.65 – end  "Not what we built. What we threw away." ============ */
export const S11 = ({ t, f }: Ctx) => {
  const ghost = 1 - seg(t, 51.0, 51.6), glow = seg(t, 51.77, 52.4);
  return (<>
    <Cam t={t} keys={[{ t: 50.4, pos: [0, 2.2, 7.0], look: [0, 1.2, 0], fov: 50 }, { t: 53.0, pos: [0, 1.6, 5.4], look: [0, 0.8, 0.4], fov: 46 }]} />
    <Lights warm="#ffe0b8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#2a1a40" bottom="#c87050" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6a4a2e" b="#6a4a2e" />
    {ghost > 0.02 ? <group position={[0, 0, -6]}><mesh position={[0, 5, 0]}><boxGeometry args={[3, 10, 2]} /><meshBasicMaterial color="#c8d8ff" transparent opacity={0.35 * ghost} depthWrite={false} /></mesh></group> : null}
    {[[-1.4, 0.2, 0.3], [1.3, -0.4, 0.4], [-0.7, 1.4, 0.25], [0.9, 1.2, 0.3]].map(([x, z, r], i) => <Ball key={i} p={[x, 0.05, z]} r={r} color="#5a3e26" />)}
    <Weed p={[-0.9, 0, -0.2]} k={0.6} /><Weed p={[1.1, 0, 0.1]} k={0.5} />
    <Cap p={[0, 0, 0.6]} r={0.42} />
    <Glow p={[0, 0.4, 0.9]} r={1.6 + glow} color="rgba(255,210,130,1)" o={0.3 + 0.4 * glow} />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11 };
