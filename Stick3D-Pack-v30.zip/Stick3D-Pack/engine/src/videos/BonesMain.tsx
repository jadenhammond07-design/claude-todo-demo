import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Bones";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const BOCUTS = [0, 2.6, 5.63, 12.84, 14.93, 22.16, 28.71, 34.8, 41.21, 44.5];
const BG = ["#0c1a30", "#c8865a", "#3a6ab0", "#0c1a30", "#05061a", "#2a1420", "#6a4a3a", "#3a2a6a", "#0c1a30"];
const TR: Trans[] = ["ghost", "zoom", "whip", "flash", "ghost", "zoom", "ghost", "whip", "dip"];
export const BonesMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={BOCUTS[i]} end={BOCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"YOUR BONES ARE CHANGING SHAPE RIGHT NOW"} until={2.5} />
    <EndQuestion text={"Be honest: do you sit more or move more? 👇"} from={41.4} end={44.41} />
  </AbsoluteFill>
);
