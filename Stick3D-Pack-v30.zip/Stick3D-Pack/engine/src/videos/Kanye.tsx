// THROUGH THE WIRE — 11 scenes. Generic stick-figure stand-ins (no real faces/logos).
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk, Clock, Calendar, ChartScreen } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Monitor, Chair, Cooler, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, Curtain, SpotCone, Building, StreetLamp, Hydrant, Bin, Mug, Stars } from "../style/extra";
import { Sky, Banner, Barrel, Crate, danceBeat } from "../style/medieval";
import { Console, Speaker, MicStand, GoldDisc, Palm, Car, Vinyl } from "../style/studio";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const prod: Look = { skin: "#b9835a", body: "#e58ab0", outfit: "shirt", hair: "short", hairColor: "#1a1008", shoe: "#f4f4f4" };
const prodWire: Look = { ...prod, wire: true };
const rapper: Look = { skin: "#a86b45", body: "#222230", outfit: "leather", hair: "none", glasses: true, shoe: "#c9a032" };
const boss: Look = { skin: "#f3d3b2", body: "#2a3a5a", outfit: "suit", tie: "#c9a032", hair: "grey", shoe: "#111" };
const suits: Look[] = [
  { skin: "#f3d3b2", body: "#2d3142", outfit: "suit", tie: "#e53e3e", hair: "short", hairColor: "#3b2a1a", shoe: "#111" }, { skin: "#8d5a3a", body: "#3a3a4a", outfit: "suit", tie: "#2f8cff", hair: "swept", hairColor: "#111", glasses: true, shoe: "#111" },
  { skin: "#fbe3c8", body: "#4a2a4a", outfit: "suit", tie: "#ffc23a", hair: "grey", shoe: "#111" }, { skin: "#c98e62", body: "#26404a", outfit: "suit", tie: "#2fd46a", hair: "bob", hairColor: "#222", shoe: "#111" },
  { skin: "#e0b48c", body: "#4a3a2a", outfit: "suit", tie: "#fff", hair: "short", hairColor: "#5a3420", shoe: "#111" }, { skin: "#fbe3c8", body: "#1f2f4a", outfit: "suit", tie: "#c9402e", hair: "swept", hairColor: "#b8742a", shoe: "#111" },
];
const surgeon: Look = { skin: "#f0cfae", body: "#3fb8a0", outfit: "shirt", hair: "none", hat: "#3fb8a0", shoe: "#e8e8f0" };

const NoX: React.FC<{ p: V3; k: number }> = ({ p, k }) => (
  <CanvasPlane p={p} s={[1.6 * k + 0.001, 1.6 * k + 0.001]} px={[160, 160]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#fff6dc"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.arc(80, 80, 68, 0, 7); c.fill(); c.stroke(); c.fillStyle = INK; c.beginPath(); c.ellipse(64, 104, 20, 14, -0.4, 0, 7); c.fill(); c.lineWidth = 9; c.strokeStyle = INK; c.beginPath(); c.moveTo(80, 98); c.lineTo(80, 48); c.lineTo(108, 60); c.stroke(); c.strokeStyle = "#e5233a"; c.lineWidth = 14; c.beginPath(); c.arc(80, 80, 66, 0, 7); c.moveTo(32, 32); c.lineTo(128, 128); c.stroke(); }} />
);
const Tag: React.FC<{ p: V3; h: number; k: number; hy?: number }> = ({ p, h, k, hy = 0.42 }) => (
  <FaceGroup p={p}><CanvasPlane p={[0.12 * h, hy * h, 0.1]} s={[1.5 * k + 0.001, 0.5 * k + 0.001]} px={[300, 100]} draw={(c, W, H) => { c.fillStyle = "#fff"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(4, 4, W - 8, H - 8); c.fillStyle = "#e5233a"; c.fillRect(8, 8, W - 16, 28); c.fillStyle = INK; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("PRODUCER", W / 2, 68); }} /></FaceGroup>
);

/* ============ S1 0 – 4.6  "October 2002. Kanye West has barely slept in days." ============ */
const K1: Key[] = [
  { t: 0, pos: [0, 6.0, 12.0], look: [0, 2.4, 0], fov: 60 },
  { t: 2.2, pos: [0.3, 3.8, 9.0], look: [0, 2.6, 0], fov: 56 },
  { t: 4.9, pos: [0.2, 3.4, 7.2], look: [0, 2.8, 0], fov: 50 },
];
export const S1 = ({ t, f }: Ctx) => {
  const mugs = Math.floor(lerp(2, 10, seg(t, 1.6, 4.2, Easing.linear))), day = 12 + Math.max(0, Math.min(5, Math.floor((t - 3.2) / 0.28))), pop = seg(t, 0.55, 0.85, Easing.out(Easing.back(2.2)));
  const micro = t > 2.9 && t < 3.4 ? Math.sin(clamp((t - 2.9) / 0.5) * Math.PI) * 0.16 : 0;
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#ffd2b0" />
    <Floor kind="carpet" a="#1b1f3a" b="#171a33" unit={1.8} w={30} d={24} />
    <WallDoor z={-6} W={30} kind="plain" a="#20264a" b="#20264a" base="#10142a" /><SideWall x={-9} kind="plain" a="#1b2142" b="#1b2142" /><SideWall x={9} kind="plain" a="#1b2142" b="#1b2142" />
    <CanvasPlane p={[0, 5.2, -5.92]} s={[7, 3.4]} px={[560, 272]} frame="#0b0d1a" draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#050818"); g.addColorStop(1, "#2a2a6a"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.fillStyle = "#f4f0d8"; c.beginPath(); c.arc(450, 70, 30, 0, 7); c.fill(); for (let i = 0; i < 40; i++) { c.fillStyle = "rgba(255,255,230,.7)"; c.fillRect((i * 97) % W, (i * 53) % 150, 2, 2); } for (let i = 0; i < 14; i++) { const x = i * 42, hh = 60 + ((i * 37) % 80); c.fillStyle = "#0b0d22"; c.fillRect(x, H - hh, 38, hh); c.fillStyle = "#ffd770"; for (let k = 0; k < 6; k++) if ((i * 7 + k * 3) % 4 < 2) c.fillRect(x + 6 + (k % 3) * 10, H - hh + 8 + Math.floor(k / 3) * 16, 6, 8); } }} />
    {[-7, -4.6, 4.6, 7].map((x, i) => <Box key={x} p={[x, 3 + (i % 2) * 2.4, -5.9]} s={[1.6, 1.6, 0.25]} color={["#3a2a5a", "#2a3a5a"][i % 2]} line={2} />)}
    <CanvasPlane p={[0, 7.6, -5.9]} s={[5.4 * pop + 0.001, 1.6 * pop + 0.001]} px={[540, 160]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#12142a"; c.fillRect(0, 0, W, H); c.fillStyle = "#ffc23a"; c.font = "900 74px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("OCTOBER 2002", W / 2, H / 2 + 4); }} />
    <Clock p={[-5.4, 6.2, -5.88]} r={0.9} t={t} speed={40} /><Calendar p={[5.4, 5.9, -5.88]} month="OCT" day={String(day)} s={1.7} />
    <Console p={[0, 0, 1.0]} w={5.4} t={t} /><Speaker p={[-5.2, 0, -1.2]} t={t} beat={1} /><Speaker p={[5.2, 0, -1.2]} t={t} beat={1} />
    <Monitor p={[-1.6, 3.4, 0.2]} rot={[0, 0.2, 0]} screen="#2fd46a" /><Monitor p={[1.6, 3.4, 0.2]} rot={[0, -0.2, 0]} screen="#2f8cff" />
    <Box p={[5.3, 1.5, 3.1]} s={[2.2, 0.12, 1.2]} color="#6a4a2a" line={2} />{[4.4, 6.2].map((x) => <Box key={x} p={[x, 0.75, 3.1]} s={[0.12, 1.5, 0.12]} color="#4a3220" line={2} />)}
    {Array.from({ length: mugs }, (_, i) => <Mug key={i} p={[4.5 + (i % 5) * 0.38, 1.7, 2.8 + Math.floor(i / 5) * 0.5]} s={0.85} color={["#ffffff", "#ffc23a", "#e5233a"][i % 3]} />)}
    {[0, 1, 2].map((i) => <Cyl key={i} p={[4.6 + i * 0.5, 1.82, 3.4]} rt={0.12} h={0.34} color={["#e5233a", "#2fd46a", "#2f8cff"][i]} line={2} />)}
    <Plant p={[-6.8, 0, 2]} s={1.3} pot="#6a3a8a" /><Lamp p={[7, 0, 1]} h={3.2} color="#ffb070" /><Chair p={[-3.2, 0, 3.4]} rotY={0.5} color="#5a2a8a" /><Rug p={[0, 0.01, 5]} s={[8, 4]} a="#2a1a4a" b="#e58ab0" />
    <Glow p={[0, 4.6, 1]} r={7} color="rgba(255,150,90,1)" o={0.25} /><Dust t={t} area={[6, 5, 4]} color="rgba(255,190,150,.9)" />
    <Person p={[0, 0, -0.7]} h={4.2} look={prod} f={f} pose={{ mood: "deadpan", sweat: t > 2.6 ? 1 : 0, hunch: 0.7, nerv: 0.1, tilt: 0.04 * Math.sin(t * 1.6) + micro, squash: -0.03, lookX: 0.2 * Math.sin(t),
      armR: [0.2 + 0.1 * Math.sin(t * 2), 0.4], armRK: 1, armL: [-0.2 - 0.1 * Math.sin(t * 1.4), 0.4], armLK: 1 }} />
  </>);
};

/* ============ S2 4.6 – 10.4  "He's produced hits for Jay-Z... but nobody wants to hear him rap." ============ */
const K2: Key[] = [
  { t: 4.4, pos: [-5.5, 3.4, 12.0], look: [-1.5, 2.6, -2], fov: 58 },
  { t: 6.6, pos: [0, 3.6, 12.0], look: [0, 2.6, -1], fov: 58 },
  { t: 9.0, pos: [2.0, 3.4, 11.0], look: [1.2, 2.4, 0], fov: 54 },
  { t: 10.7, pos: [2.2, 3.4, 10.4], look: [1.3, 2.4, 0], fov: 52 },
];
export const S2 = ({ t, f }: Ctx) => {
  const jay = seg(t, 5.62, 5.9, Easing.out(Easing.back(2.4))), nod = seg(t, 7.0, 7.3) * (1 - seg(t, 8.4, 8.6)), turn = seg(t, 8.67, 9.0), enter = seg(t, 8.3, 9.2, ease), rap = t > 9.3;
  const bx = lerp(6.5, 1.3, enter);
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#ffe2b0" />
    <Floor kind="marble" a="#2a2a38" b="#222230" unit={2} w={34} d={24} />
    <WallDoor z={-7} W={34} kind="plain" a="#161a3a" b="#161a3a" base="#0a0c1c" /><SideWall x={-10} kind="plain" a="#121634" b="#121634" /><SideWall x={10} kind="plain" a="#121634" b="#121634" />
    {Array.from({ length: 15 }, (_, i) => <GoldDisc key={i} p={[-4.2 + (i % 5) * 2.1, 2.8 + Math.floor(i / 5) * 2.0, -6.8]} s={0.95} text={i === 7 ? "HIT" : ""} />)}
    <Box p={[0, 0.3, -4]} s={[6, 0.6, 3]} color="#3a2a5a" line={3} /><SpotCone p={[0, 10, -3.6]} h={9.6} r={2.2} color="#fff2c0" o={0.14} /><Glow p={[0, 0.7, -3.6]} r={2.2} color="rgba(255,240,200,1)" o={0.4} />
    <MicStand p={[0.6, 0.6, -3.6]} h={2.2} />
    <Person p={[-0.6, 0.6, -4.0]} sy={0.6} h={3.0} look={rapper} f={f} pose={{ mood: "grin", ...danceBeat(t, 0, t < 8.5 ? 0.3 : 0).pose, armR: [0.3, 0.62], armRK: t < 8.5 ? 1 : 0 }} />
    {jay > 0.02 ? <CanvasPlane p={[-0.6, 4.9, -3.6]} s={[2.0 * jay + 0.001, 2.0 * jay + 0.001]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#ffc928"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 - Math.PI / 2, r = i % 2 ? 44 : 92; c.lineTo(100 + Math.cos(a) * r, 100 + Math.sin(a) * r); } c.closePath(); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("HIT", 100, 104); }} /> : null}
    {[[-3.2, 1.6], [-1.1, 2.4], [1.1, 1.0], [3.2, 2.0], [-2.2, 4.2], [2.4, 4.4]].map(([x, z], i) => { const b = danceBeat(t, i, 0.22 * nod), away = turn > 0.5 && i !== 2;
      return <Person key={i} p={[x, b.y * 0.5, z]} sy={0} h={3.7} look={suits[i]} f={f + i * 5} pose={{ mood: turn > 0.4 ? (i % 2 ? "angry" : "deadpan") : nod > 0.1 ? "grin" : "smile", squash: nod * b.pose.squash, tilt: nod * b.pose.tilt * 0.6, flip: i % 2 === 1, lookX: away ? (i % 2 ? 0.9 : -0.9) : 0, arms: turn > 0.4 ? (i === 1 ? "head" : "chest") : "down", armK: turn }} />; })}
    <MicStand p={[1.9, 0, 4.8]} h={2.0} />
    <Person p={[bx, 0, 4.8]} h={3.8} look={prod} f={f} pose={{ mood: rap ? (Math.sin(t * 10) > 0 ? "laugh" : "deadpan") : "worry", walk: enter < 1 && enter > 0 ? bx * WALK : undefined, speed: enter < 1 && enter > 0 ? 0.7 : 0, flip: enter < 1, nerv: 0.2, sweat: t > 9.3 ? 1 : 0, hunch: 0.2, armR: rap ? [0.3, 0.6 + 0.1 * Math.sin(t * 5)] : undefined, armRK: rap ? 1 : 0 }} />
    <NoX p={[1.3, 6.3, 4.6]} k={seg(t, 9.5, 9.75, Easing.out(Easing.back(2.4)))} />
    <Barrel p={[0, 0, 0]} s={0.001} /><Plant p={[-7, 0, 1]} s={1.4} pot="#6a3a8a" /><Plant p={[7, 0, 1]} s={1.4} pot="#6a3a8a" /><Lamp p={[-8, 0, -3]} h={3.4} color="#ffe0a0" /><Lamp p={[8, 0, -3]} h={3.4} color="#ffe0a0" />
    <Dust t={t} area={[7, 6, 4]} color="rgba(255,225,170,.9)" />
  </>);
};

/* ============ S3 10.4 – 14.1  "Producers make the beats, he's told. Someone else does the talking." ============ */
const K3: Key[] = [
  { t: 10.2, pos: [-0.8, 3.6, 9.6], look: [-0.2, 2.6, 0], fov: 56 },
  { t: 12.0, pos: [0.0, 3.6, 9.8], look: [0.2, 2.6, 0], fov: 56 },
  { t: 13.0, pos: [3.8, 3.6, 10.0], look: [4.8, 2.6, 0], fov: 54 },
  { t: 14.4, pos: [4.4, 3.5, 9.0], look: [5.4, 2.7, 0], fov: 50 },
];
export const S3 = ({ t, f }: Ctx) => {
  const tag = seg(t, 10.7, 11.0, Easing.out(Easing.back(2.6))), walk = seg(t, 11.7, 13.0, ease), px = lerp(1.7, -4.2, walk), enter = seg(t, 12.4, 13.3, ease), rx = lerp(9, 5.7, enter), talk = t > 13.4;
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#ffd0f0" />
    <Floor kind="tile" a="#3a1a5a" b="#2e1450" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#4a2272" b="#4a2272" base="#2a1248" /><SideWall x={-10} kind="plain" a="#3e1c62" b="#3e1c62" /><SideWall x={11} kind="plain" a="#3e1c62" b="#3e1c62" />
    <Desk p={[0.2, 0, -1.2]} w={3.6} top="#c9a870" leg="#6a4a2a" /><Monitor p={[-0.6, 1.2, -1.4]} rot={[0, 0.2, 0]} screen="#ffc23a" /><Frame p={[-3.6, 4.6, -5.9]} s={[1.6, 1.2]} art={1} /><Frame p={[1.6, 5.0, -5.9]} s={[1.4, 1.8]} art={2} />
    <Console p={[-4.4, 0, -2.2]} w={4} t={t} live={walk > 0.9 ? 1 : 0.3} /><Shelf p={[-8, 0, -5.4]} w={2.6} rows={4} seed={6} wood="#3a1a5a" /><Plant p={[-1.6, 0, -4.8]} s={1.3} pot="#e58ab0" />
    {/* glass booth */}
    <Box p={[5.7, 3.4, -3.2]} s={[5, 6.8, 0.2]} color="#2a1248" /><Box p={[8.2, 3.4, -0.5]} s={[0.2, 6.8, 5.4]} color="#2a1248" /><Box p={[3.2, 3.4, -0.5]} s={[0.2, 6.8, 5.4]} color="#2a1248" /><Box p={[5.7, 6.9, -0.5]} s={[5.2, 0.2, 5.6]} color="#2a1248" />
    {Array.from({ length: 6 }, (_, i) => <Box key={i} p={[3.6 + (i % 3) * 1.6 + 0.4, 5.6 - Math.floor(i / 3) * 1.5, -3.05]} s={[1.2, 1.2, 0.1]} color={i % 2 ? "#5a2a8a" : "#7a3aa8"} line={2} />)}
    <MicStand p={[5.9, 0, 0.2]} h={2.2} />
    <CanvasPlane p={[5.7, 3.0, 2.0]} s={[5.4, 5.6]} px={[200, 200]} draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, "rgba(160,220,255,.20)"); g.addColorStop(1, "rgba(160,220,255,.06)"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.55)"; c.lineWidth = 6; c.beginPath(); c.moveTo(30, 20); c.lineTo(90, 70); c.stroke(); }} />
    <Glow p={[0, 5.4, 0]} r={8} color="rgba(255,120,220,1)" o={0.22} /><Dust t={t} area={[7, 5, 4]} color="rgba(255,190,240,.9)" />
    <Person p={[0.2, 0, -2.6]} h={4.2} look={boss} f={f} pose={{ mood: t < 12.6 ? "angry" : "grin", arms: t > 10.6 && t < 12.5 ? "point" : "down", armK: seg(t, 10.5, 10.7), flip: true, tilt: t > 12.55 ? 0.05 * Math.sin(t * 6) : 0 }} />
    <Person p={[px, 0, 0.9]} h={3.9} look={prod} f={f} pose={{ mood: "worry", hunch: 0.5 + 0.4 * tag, sweat: t > 10.7 ? 1 : 0, nerv: 0.2, flip: walk > 0 && walk < 1, walk: walk > 0 && walk < 1 ? (px - 1.7) * WALK : undefined, speed: walk > 0 && walk < 1 ? 0.6 : 0, lookX: -0.5 }} />
    {tag > 0.02 ? <Tag p={[px, 0, 0.9]} h={3.9} k={tag} /> : null}
    <Person p={[rx, 0, -0.5]} h={3.8} look={rapper} f={f + 4} pose={{ mood: talk ? (Math.sin(t * 11) > 0 ? "laugh" : "grin") : "smile", flip: enter < 1, walk: enter > 0 && enter < 1 ? (9 - rx) * WALK : undefined, speed: enter > 0 && enter < 1 ? 0.8 : 0, armR: talk ? [0.3, 0.6 + 0.1 * Math.sin(t * 5)] : undefined, armRK: talk ? 1 : 0 }} />
    {talk ? <CanvasPlane p={[5.7, 6.0, 0.6]} s={[2.4, 1.3]} px={[240, 130]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 28, 22); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 40px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; const k = Math.floor(t * 4) % 3; c.fillText(["BLAH", "BLAH BLAH", "BLAH!"][k], W / 2, H / 2 - 8); }} /> : null}
  </>);
};

/* ============ S4 14.1 – 19.1  "So he works harder, chasing a record deal from a career stuck in the wrong role." ============ */
const K4: Key[] = [
  { t: 13.9, pos: [-6.5, 3.4, 10.5], look: [0, 2.8, 0], fov: 58 },
  { t: 16.0, pos: [0, 3.5, 12.5], look: [0, 2.9, 0], fov: 58 },
  { t: 18.4, pos: [3.0, 4.2, 15.0], look: [0, 3.2, 0], fov: 58 },
  { t: 19.5, pos: [3.4, 4.3, 15.5], look: [0, 3.2, 0], fov: 58 },
];
export const S4 = ({ t, f }: Ctx) => {
  const w = seg(t, 14.1, 15.0, Easing.in(Easing.quad)), ang = -(t - 14.1) * 1.1 * (0.15 + 0.85 * w) * 1.0, R = 3.4, drop = seg(t, 17.9, 18.4, Easing.out(Easing.bounce)), sw = Math.sin(t * 4.5) * 0.12;
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#c0fff0" />
    <Floor kind="tile" a="#14505a" b="#103f48" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0f3f4a" b="#0f3f4a" base="#082a32" /><SideWall x={-10} kind="plain" a="#0d3640" b="#0d3640" /><SideWall x={10} kind="plain" a="#0d3640" b="#0d3640" />
    <Frame p={[-5, 5, -5.9]} s={[1.6, 1.2]} art={0} /><Frame p={[5, 5.2, -5.9]} s={[1.4, 1.8]} art={3} /><Clock p={[-6.2, 3.4, -5.9]} r={0.9} t={t} speed={6} />
    <Shelf p={[6.6, 0, -5.4]} w={3} rows={4} seed={9} wood="#0a2a32" /><Cooler p={[-7.4, 0, -4]} /><Plant p={[7.6, 0, 1.6]} s={1.2} pot="#e58ab0" /><Plant p={[-7.2, 0, 2]} s={1.2} pot="#e58ab0" /><Lamp p={[-8.4, 0, -1]} h={3.2} color="#cdfff0" />
    <Cyl p={[-4.4, 0.35, 3.0]} rt={0.45} h={0.2} color="#2a2a38" line={2} /><Cyl p={[-3.4, 0.35, 3.2]} rt={0.45} h={0.2} color="#2a2a38" line={2} /><Rug p={[0, 0.01, 4]} s={[9, 3.4]} a="#0b3540" b="#e58ab0" />
    {/* the hamster wheel */}
    <group position={[0, 3.9, 0]}>
      <group rotation={[0, 0, ang]}>
        {Array.from({ length: 32 }, (_, i) => { const a = (i / 32) * Math.PI * 2; return <React.Fragment key={i}><Box p={[Math.cos(a) * R, Math.sin(a) * R, 0]} s={[0.9, 0.18, 1.3]} rot={[0, 0, a + Math.PI / 2]} color={i % 2 ? "#c9a032" : "#e0b84a"} line={2} /><Box p={[Math.cos(a) * R, Math.sin(a) * R, 0.7]} s={[0.9, 0.34, 0.1]} rot={[0, 0, a + Math.PI / 2]} color="#6a4a2a" line={2} /><Box p={[Math.cos(a) * R, Math.sin(a) * R, -0.7]} s={[0.9, 0.34, 0.1]} rot={[0, 0, a + Math.PI / 2]} color="#6a4a2a" line={2} /></React.Fragment>; })}
        {[0, 1, 2, 3].map((i) => <Box key={i} p={[0, 0, 0.7]} s={[R * 2, 0.14, 0.1]} rot={[0, 0, (i * Math.PI) / 4]} color="#6a4a2a" line={2} />)}
      </group>
      <Cyl p={[0, 0, 0.8]} rt={0.3} h={0.2} color="#2a2a38" line={2} rot={[Math.PI / 2, 0, 0]} />
    </group>
    {[-1.1, 1.1].map((z) => <Box key={z} p={[0, 1.9, z]} s={[0.25, 3.8, 0.25]} color="#2a2a38" rot={[0, 0, 0]} line={2} />)}<Box p={[0, 0.1, 0]} s={[6, 0.2, 2.6]} color="#2a2a38" line={2} />
    <Person p={[0, 0.6, 0]} sy={0.6} h={3.7} look={prod} f={f} pose={{ mood: "worry", sweat: 1, nerv: 0.2, walk: t * 13, speed: 0.9, hunch: 0.3, lookX: 0.5, tilt: 0.05 }} />
    {/* the carrot: a RECORD DEAL on a stick tied to his head */}
    <group position={[0, 0, 0]}><Box p={[1.2, 3.85, 0]} s={[2.6, 0.07, 0.07]} rot={[0, 0, 0.25]} color="#6a4a2a" line={1} />
      <group position={[2.4, 4.35, 0.2]} rotation={[0, 0, sw]}><Cyl p={[0, -0.3, 0]} rt={0.015} h={0.6} color="#c9d3e0" line={1} />
        <CanvasPlane p={[0, -1.0, 0]} s={[1.5, 1.0]} px={[300, 200]} frame="#6a4a2a" draw={(c, W, H) => { c.fillStyle = "#f6edc8"; c.fillRect(0, 0, W, H); c.fillStyle = "#b3122e"; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("RECORD", W / 2, 60); c.fillText("DEAL", W / 2, 118); c.fillStyle = "#ffc928"; c.beginPath(); c.arc(W - 34, H - 34, 20, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.stroke(); }} /></group></group>
    <Tag p={[0, 0.6, 0]} h={3.7} k={1} hy={0.38} />
    {drop > 0.01 ? <Banner p={[0, lerp(14, 8.7, drop), 1.6]} s={[4.4, 1.8]} text="WRONG ROLE" size={54} bg="#c0182e" /> : null}
    <Dust t={t} area={[7, 6, 4]} color="rgba(190,255,240,.9)" />
  </>);
};

/* ============ S5 19.1 – 23.7  "One night in Los Angeles, he leaves the studio around three in the morning, exhausted," ============ */
const K5: Key[] = [
  { t: 19.0, pos: [0, 14, 13], look: [0, 4, -20], fov: 62 },
  { t: 20.4, pos: [0.5, 3.6, 10.5], look: [-1, 3.2, -5], fov: 58 },
  { t: 22.2, pos: [1.8, 3.6, 11.5], look: [1.6, 2.6, -1], fov: 58 },
  { t: 24.0, pos: [3.4, 3.2, 10.5], look: [3.6, 2.4, 0.5], fov: 56 },
];
const WALK5 = (t: number): V3 => { const a = seg(t, 20.75, 21.35, Easing.linear), b = seg(t, 21.35, 23.6, ease); return [lerp(-2, 1.8, a) * (1 - b) + b * 4.2 + 0, 0, lerp(-4.3, -1.6, a) * (1 - b) + b * 1.4]; };
export const S5 = ({ t, f }: Ctx) => {
  const open = seg(t, 20.3, 20.8, ease), pos = WALK5(t), moving = t > 20.75 && t < 23.6, three = seg(t, 21.94, 22.2, Easing.out(Easing.back(2.4)));
  const dist = (t - 20.75) * 2.6;
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#b0b8ff" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#04061a" bottom="#2a2a6a" stars={1} t={t} />
    <Ball p={[-14, 22, -58]} r={3.2} color="#f4f0d8" ink={0} /><Glow p={[-14, 22, -57]} r={14} color="rgba(220,220,255,1)" o={0.35} />
    {[-22, -15, -9, 7, 14, 21].map((x, i) => <Building key={x} p={[x, 0, -34 - (i % 3) * 3]} s={[5, 12 + (i % 3) * 5, 5]} color={["#1b2142", "#241b42", "#1b2f42"][i % 3]} lit={0.5} trim="#0b0d22" />)}
    <Surface p={[0, 0, 0]} s={[70, 30]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2a2a36" b="#2a2a36" /><Box p={[0, 0.12, -3.0]} s={[40, 0.24, 2.2]} color="#5a5a6a" line={2} />
    <WallDoor z={-5} W={22} kind="brick" a="#8a3a2a" b="#7a3022" door={{ x: -2, w: 2.4, h: 4.2 }} base="#3a1a14" /><Box p={[0, 8.6, -5.0]} s={[22, 0.6, 0.4]} color="#2a1a14" line={2} />
    <Box p={[-2, 2.0, -9]} s={[8, 4.4, 0.2]} color="#1a1020" /><Surface p={[-2, 0.02, -7]} s={[8, 5]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#5a3a2a" b="#4e3022" unit={1.4} /><Glow p={[-2, 3, -6.4]} r={5} color="rgba(255,170,90,1)" o={0.5} /><Console p={[-2, 0, -7.6]} w={4} t={t} />
    <group position={[-2, 0, -4.9]} rotation={[0, open * 1.4, 0]}><Box p={[-0, 0, 0]} s={[0.001, 0.001, 0.001]} color="#000" line={0} /><group position={[-1.2, 0, 0]}><Box p={[1.2, 2.1, 0]} s={[2.4, 4.2, 0.14]} color="#4a2a5a" /></group></group>
    <CanvasPlane p={[-2, 5.4, -4.88]} s={[5.2, 1.5]} px={[520, 150]} draw={(c, W, H) => { c.fillStyle = "#14081e"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(4, 4, W - 8, H - 8); c.shadowColor = "#ff5ac8"; c.shadowBlur = 22; c.fillStyle = "#ff9ae0"; c.font = "900 92px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("STUDIO", W / 2, H / 2 + 4); }} />
    <Glow p={[-2, 5.4, -4.4]} r={5} color="rgba(255,90,200,1)" o={0.4} />
    <CanvasPlane p={[2.7, 7.2, -4.88]} s={[3.2 * three + 0.001, 1.5 * three + 0.001]} px={[320, 150]} draw={(c, W, H) => { c.fillStyle = "#14081e"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(4, 4, W - 8, H - 8); c.fillStyle = "#ff3b3b"; c.font = "900 78px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("3:00 AM", W / 2, H / 2 + 4); }} />
    {[-7.6, 8.4].map((x) => <Palm key={x} p={[x, 0, -2.2]} h={7} sway={Math.sin(t)} />)}
    <StreetLamp p={[8.6, 0, -1.2]} h={5.6} on={1} /><Glow p={[8.4, 5.4, -1]} r={4} color="rgba(255,190,110,1)" o={0.5} /><StreetLamp p={[-6.6, 0, 0.6]} h={5.6} on={1} flip /><Glow p={[-6.4, 5.4, 0.8]} r={4} color="rgba(255,190,110,1)" o={0.5} />
    <Hydrant p={[-4.8, 0, -1.9]} /><Bin p={[6.6, 0, -2.2]} /><Crate p={[-8.2, 0, -2]} /><Plant p={[3.0, 0, -4.3]} s={1.2} pot="#c0643a" />
    <Car p={[6.0, 0, 1.6]} color="#e5233a" />
    <Dust t={t} area={[8, 8, 5]} color="rgba(200,210,255,.9)" />
    <Person p={pos} h={3.9} look={prod} f={f} pose={{ mood: t > 22.89 ? "gulp" : "worry", walk: moving ? dist * WALK : undefined, speed: moving ? 0.5 : 0, hunch: 0.7 + 0.2 * seg(t, 22.89, 23.4), sweat: t > 21.5 ? 1 : 0, nerv: 0.1, tilt: moving ? 0.05 * Math.sin(t * 3) + 0.04 * seg(t, 22.89, 23.4) : 0, squash: t > 22.89 ? -0.04 : 0 }} />
  </>);
};

/* ============ S6 23.7 – 26.6  "and falls asleep at the wheel. The car crashes." ============ */
const TI = 25.85, XH = 3.9, V = 7;
const carX = (t: number) => t < TI ? XH - V * (TI - t) : XH - 0.28 * (1 - Math.exp(-(t - TI) * 14)) + 0.12 * Math.exp(-(t - TI) * 6) * Math.sin((t - TI) * 25) * 0;
const K6: Key[] = [
  { t: 23.6, pos: [carX(23.6) + 0.6, 2.4, 8.4], look: [carX(23.6) + 0.6, 1.5, 0], fov: 56 },
  { t: 24.8, pos: [carX(24.8) + 1.0, 2.6, 8.0], look: [carX(24.8) + 0.9, 1.5, 0], fov: 54 },
  { t: 25.7, pos: [carX(25.7) + 1.4, 2.5, 7.4], look: [carX(25.7) + 1.4, 1.5, 0], fov: 52 },
  { t: 26.8, pos: [4.5, 2.5, 7.0], look: [4.4, 1.5, 0], fov: 50 },
];
export const S6 = ({ t, f }: Ctx) => {
  const cx = carX(t), post = Math.max(0, t - TI), crash = t >= TI, nodK = seg(t, 24.0, 25.6, Easing.in(Easing.quad)), thrown = seg(t, TI, TI + 0.14, Easing.out(Easing.quad)), slump = seg(t, TI + 0.2, TI + 0.7, ease);
  const smoke = Array.from({ length: 6 }, (_, i) => { const u = ((post * 0.8 + i / 6) % 1); return [XH + 1.7 + Math.sin(i * 2.4) * 0.3, 1.0 + u * 2.2, 0.2, 0.16 + 0.3 * u, crash ? 1 - u : 0] as [number, number, number, number, number]; });
  const debris = [0, 1, 2, 3, 4].map((i) => { const vv: V3 = [2.2 + i * 0.5, 4.4 + i * 0.7, (i - 2) * 0.7], d = post, tl = (vv[1] + Math.sqrt(vv[1] ** 2 + 2 * 20 * 0.9)) / 20, q = Math.min(d, tl); return [XH + 1.9 + vv[0] * q * 0.55, Math.max(0.1, 0.9 + vv[1] * q - 10 * q * q), vv[2] * q * 0.4] as V3; });
  const hubX = XH + 1.7 + 3.0 * (1 - Math.exp(-post * 1.6));
  return (<>
    <Cam t={t} keys={K6} impacts={[[TI, 0.09]]} fovKick={[TI]} />
    <Lights warm="#b0b8ff" />
    <Sky p={[carX(t) + 0, 26, -50]} s={[300, 150]} top="#04061a" bottom="#2a2a6a" stars={1} t={t} />
    <Surface p={[0, 0, 0]} s={[120, 22]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#23232e" b="#23232e" /><Box p={[0, 0.1, -3.2]} s={[120, 0.2, 2.4]} color="#5a5a6a" line={2} />
    {Array.from({ length: 22 }, (_, i) => <Box key={i} p={[-30 + i * 3.5, 0.02, 3.2]} s={[1.6, 0.03, 0.2]} color="#e8e0a0" line={0} />)}
    {[-22, -14, -6, 10, 18, 26].map((x, i) => <Building key={x} p={[x, 0, -16 - (i % 2) * 3]} s={[5, 9 + (i % 3) * 3, 4]} color={["#1b2142", "#241b42", "#1b2f42"][i % 3]} lit={0.5} trim="#0b0d22" />)}
    {[-12, -3, 12, 20].map((x) => <Palm key={x} p={[x, 0, -5]} h={6.5} sway={Math.sin(t * 1.5)} />)}
    <StreetLamp p={[-8, 0, -3.5]} h={5.6} on={1} /><StreetLamp p={[16, 0, -3.5]} h={5.6} on={1} flip />
    {/* the pole it hits */}
    <Cyl p={[XH + 2.2, 2.8, 0]} rt={0.2} rb={0.26} h={5.6} color="#8a6a42" line={3} rot={[0, 0, crash ? 0.03 * Math.exp(-post * 4) * Math.sin(post * 30) : 0]} /><Box p={[XH + 2.2, 5.4, 0]} s={[1.6, 0.12, 0.12]} color="#5a3a22" line={2} />
    {!crash ? <SpotCone p={[cx + 1.7, 0.8, 0]} h={7} r={2.0} color="#fff2c0" o={0.16} rot={[0, 0, Math.PI / 2]} /> : null}
    <Car p={[cx, 0.0, 0]} crumple={crash ? seg(t, TI, TI + 0.1, Easing.out(Easing.quad)) : 0} rotZ={crash ? 0.05 * Math.exp(-post * 5) * Math.sin(post * 22) : 0} />
    {crash && post < 0.5 ? <Glow p={[XH + 1.9, 1.0, 0.6]} r={3.2} color="rgba(255,255,220,1)" o={0.9 * Math.exp(-post * 8)} /> : null}
    <Person p={[cx - 0.2, 0.5 + 0.35 * Math.sin(thrown * Math.PI), 0]} sy={0.5} h={2.7} look={prod} f={f} pose={{ mood: crash ? "shock" : "deadpan", sweat: 0, hunch: 0.3 + 0.5 * slump, tilt: crash ? lerp(0.75, 0.5, slump) * thrown + 0.0 : 0.04 + 0.34 * nodK * (0.7 + 0.3 * Math.sin(t * 6)), squash: crash ? -0.14 * Math.exp(-post * 6) : 0,
      armR: [0.3, 0.32], armRK: 1, armL: [0.3, 0.32], armLK: 1 }} />
    {t > 24.3 && !crash ? [0, 1, 2].map((i) => { const u = ((t * 0.9 + i / 3) % 1); return <CanvasPlane key={i} p={[cx - 0.2 + u * 0.8, 3.6 + u * 1.6, 0.6]} s={[0.5 + 0.3 * u, 0.5 + 0.3 * u]} px={[80, 80]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.globalAlpha = 1 - u * 0.8; c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.font = "900 64px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.strokeText("Z", 40, 44); c.fillText("Z", 40, 44); }} />; }) : null}
    {smoke.map(([x, y, z, r, o], i) => o > 0.05 ? <Ball key={i} p={[x, y, z]} r={r} color="#c8c8d0" ink={0.03} /> : null)}
    {crash ? debris.map((d, i) => <Box key={i} p={d} s={[0.22, 0.14, 0.2]} rot={[post * 7 + i, post * 5, i]} color="#e5233a" line={2} />) : null}
    {crash ? <Cyl p={[hubX, 0.4, 1.2]} rt={0.38} h={0.2} color="#14141c" line={2} rot={[Math.PI / 2, 0, 0]} /> : null}
  </>);
};

/* ============ S7 26.6 – 30.5  "His jaw breaks in three places, and surgeons wire it shut." ============ */
const K7: Key[] = [
  { t: 26.4, pos: [0, 4.8, 12.5], look: [0, 4.4, -3], fov: 56 },
  { t: 28.4, pos: [0, 4.6, 10.0], look: [0, 4.4, -3], fov: 52 },
  { t: 30.8, pos: [0, 4.5, 8.6], look: [0, 4.4, -3], fov: 50 },
];
export const S7 = ({ t, f }: Ctx) => {
  const cr = [27.25, 27.72, 28.08].map((a) => seg(t, a, a + 0.12, Easing.out(Easing.cubic))), wireP = seg(t, 29.5, 30.1, Easing.linear), jaw = 0.34 * (1 - seg(t, 29.9, 30.2, Easing.out(Easing.back(2)))) * (t > 27.2 ? 1 : 0.0) + 0.0;
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#d0f0ff" />
    <Floor kind="tile" a="#cfe8f0" b="#bcd8e4" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e3a4a" b="#0e3a4a" base="#082630" /><SideWall x={-9} kind="plain" a="#0c3442" b="#0c3442" /><SideWall x={9} kind="plain" a="#0c3442" b="#0c3442" />
    <Box p={[0, 4.4, -5.6]} s={[5.4, 6.0, 0.3]} color="#d8e8f0" line={4} />
    <CanvasPlane p={[0, 4.4, -5.42]} s={[4.9, 5.5]} px={[490, 550]} draw={(c, W, H) => {
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#0a2638"); g.addColorStop(1, "#06141e"); c.fillStyle = g; c.fillRect(0, 0, W, H);
      c.lineJoin = "round"; c.lineCap = "round"; c.strokeStyle = "#9fe6ff"; c.fillStyle = "rgba(150,225,255,.18)"; c.lineWidth = 7;
      c.beginPath(); c.ellipse(240, 210, 150, 130, 0, 0, 7); c.fill(); c.stroke();
      c.fillStyle = "#04121c"; c.beginPath(); c.arc(300, 190, 30, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.moveTo(350, 240); c.lineTo(372, 262); c.lineTo(344, 266); c.stroke();
      c.lineWidth = 6; for (let i = 0; i < 6; i++) { c.strokeRect(290 + i * 18, 300, 14, 24); } c.strokeStyle = "#6fc8e8"; c.lineWidth = 7; c.beginPath(); c.moveTo(190, 250); c.lineTo(200, 300); c.stroke();
      c.save(); c.translate(200, 296); c.rotate(jaw * 0.9); c.strokeStyle = "#9fe6ff"; c.fillStyle = "rgba(150,225,255,.14)"; c.lineWidth = 7; c.beginPath(); c.moveTo(0, -4); c.lineTo(-6, 90); c.quadraticCurveTo(80, 150, 195, 70); c.lineTo(150, 28); c.lineTo(0, -4); c.fill(); c.stroke(); c.lineWidth = 5; for (let i = 0; i < 6; i++) c.strokeRect(95 + i * 18, 24 - i * 2, 14, 26);
      c.strokeStyle = "#ff3b3b"; c.lineWidth = 8; const cracks: [number, number][] = [[24, 30], [86, 58], [160, 44]]; cracks.forEach(([x, y], i) => { const k = cr[i]; if (k > 0.01) { c.beginPath(); c.moveTo(x - 16 * k, y - 22 * k); c.lineTo(x + 2, y - 4); c.lineTo(x - 8, y + 10); c.lineTo(x + 14 * k, y + 28 * k); c.stroke(); } });
      c.restore();
      if (wireP > 0) { c.strokeStyle = "#e8eef8"; c.lineWidth = 7; c.beginPath(); const n = Math.floor(wireP * 40); for (let i = 0; i <= n; i++) { const x = 275 + i * 3.4, y = 312 + Math.sin(i * 1.3) * 7; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }
      c.fillStyle = "#9fe6ff"; c.font = "800 26px Inter, Arial"; c.textAlign = "left"; c.fillText("X-RAY", 20, 40);
    }} />
    <Glow p={[0, 4.4, -5.0]} r={6} color="rgba(120,220,255,1)" o={0.35} />
    {[-4.2, 4.2].map((x, i) => <Person key={x} p={[x, 0, -1.8]} h={3.4} look={surgeon} f={f + i * 4} pose={{ mood: t > 27.2 && t < 29.4 ? "shock" : "deadpan", arms: "point", armK: seg(t, 26.8, 27.1), flip: i === 1, lookX: i ? -0.6 : 0.6, nerv: 0.2 }} />)}
    <Cyl p={[-6.4, 3.0, -2]} rt={0.05} h={6} color="#c9d3e0" line={2} /><Ball p={[-6.4, 5.2, -2]} r={0.5} color="#bfe8ff" s={[0.8, 1.1, 0.5]} /><Box p={[6.2, 2.2, -2.6]} s={[1.6, 1.4, 0.3]} color="#2a2a38" line={2} /><Monitor p={[6.2, 2.8, -2.4]} rot={[0, -0.3, 0]} screen="#2fd46a" />
    <Cooler p={[7.4, 0, 1]} /><Plant p={[-7.2, 0, 1.4]} s={1.2} pot="#3fb8a0" /><Lamp p={[-8, 0, -3]} h={3.4} color="#cdf0ff" /><Rug p={[0, 0.01, 3.4]} s={[7, 3]} a="#a8d4e4" b="#3fb8a0" /><Dust t={t} area={[6, 6, 4]} color="rgba(200,240,255,.9)" />
  </>);
};

/* ============ S8 30.5 – 34.5  "Lying there, he could have been finished. Instead, two weeks later," ============ */
const K8: Key[] = [
  { t: 30.3, pos: [1.6, 3.4, 8.2], look: [0.8, 1.2, 0.2], fov: 50 },
  { t: 32.4, pos: [0.8, 3.0, 7.6], look: [0.6, 1.3, 0.2], fov: 50 },
  { t: 33.2, pos: [0.4, 5.4, 12.0], look: [0, 3.4, -3], fov: 54 },
  { t: 34.7, pos: [0.4, 4.4, 11.2], look: [0, 3.6, -3], fov: 52 },
];
export const S8 = ({ t, f }: Ctx) => {
  const flat = t > 31.95 && t < 32.85, up = seg(t, 33.7, 34.15, ease), hop = seg(t, 34.15, 34.5), days = Math.max(0, Math.min(14, Math.floor((t - 32.95) / 0.09)));
  const lie = (1 - up);
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#e8f4ff" />
    <Floor kind="tile" a="#dfeef2" b="#cde0e6" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#9ec4d2" b="#9ec4d2" base="#6a98a8" /><SideWall x={-9} kind="plain" a="#8ab4c4" b="#8ab4c4" /><SideWall x={9} kind="plain" a="#8ab4c4" b="#8ab4c4" />
    <Box p={[0, 0.45, 0]} s={[5.2, 0.5, 2.4]} color="#f2f6f8" line={3} /><Box p={[0, 0.15, 0]} s={[5.0, 0.3, 2.2]} color="#6a7a86" line={2} /><Box p={[-2.7, 1.1, 0]} s={[0.2, 1.4, 2.4]} color="#c9d3e0" line={3} /><Box p={[-1.2, 0.84, -0.3]} s={[1.0, 0.24, 1.1]} color="#fff" line={2} />
    <Box p={[1.4, 0.86, -0.35]} s={[2.8, 0.3, 1.3]} color="#9ec4e8" line={2} />
    <group position={[2.4, 0.98 + 0.2 * hop * (1 - hop), 0]} rotation={[0, 0, 1.5 * lie]}><Person p={[0, 0, 0]} h={3.6} look={prodWire} f={f} shadow={false} pose={{ mood: lie > 0.5 ? (flat ? "deadpan" : "worry") : "smile", sweat: 0, hunch: 0, squash: 0 }} /></group>
    
    <group position={[4.2, 0, -0.6]}><Cyl p={[0, 2.6, 0]} rt={0.05} h={5.2} color="#c9d3e0" line={2} /><Box p={[0, 4.3, 0.4]} s={[2.1, 1.5, 0.18]} color="#10182a" line={3} />
      <CanvasPlane p={[0, 4.3, 0.5]} s={[1.9, 1.3]} px={[190, 130]} draw={(c, W, H) => { c.fillStyle = "#04120c"; c.fillRect(0, 0, W, H); c.strokeStyle = flat ? "#ff4a4a" : "#3dff7a"; c.lineWidth = 4; c.beginPath(); for (let x = 0; x < W; x++) { const ph = ((x / 38) - t * 1.3) % 1, beat = flat ? 0 : ph > 0.4 && ph < 0.5 ? -(ph - 0.4) * 520 : ph > 0.5 && ph < 0.6 ? (ph - 0.5) * 360 - 52 : 0; const y = H / 2 + beat; x ? c.lineTo(x, y) : c.moveTo(x, y); } c.stroke(); }} /></group>
    <Ball p={[-3.5, 4.4, 0]} r={0.55} color="#bfe8ff" s={[0.8, 1.1, 0.5]} /><Cyl p={[-3.5, 2.4, 0]} rt={0.04} h={4.4} color="#c9d3e0" line={2} />
    <Box p={[-6, 2.2, -3]} s={[1.4, 4.4, 1]} color="#7aa6b8" line={2} /><Plant p={[6.4, 0, 3]} s={1.2} pot="#3fb8a0" />
    {/* calendar races through 14 days */}
    {t > 32.8 ? <Calendar p={[0, 4.4, -5.8]} month="DAY" day={String(days)} s={3.4} /> : null}
    {days > 0 && days < 14 ? <Box p={[Math.sin(days * 3) * 1.2, 4.4 - (t * 11 % 3) , -5.2]} s={[1.2, 1.4, 0.05]} rot={[0.3, 0.5, days]} color="#fffaf0" line={2} /> : null}
    <Dust t={t} area={[6, 6, 4]} color="rgba(220,240,255,.9)" />
  </>);
};

/* ============ S9 34.5 – 40.7  "he's back in the studio with the wire still in his mouth, rapping about the exact crash that almost ended him." ============ */
const K9: Key[] = [
  { t: 34.3, pos: [-4.0, 2.6, 11.5], look: [0, 3.0, 0], fov: 58 },
  { t: 37.0, pos: [0.4, 2.2, 9.2], look: [0.3, 3.1, 0], fov: 52 },
  { t: 40.8, pos: [0.3, 2.0, 7.8], look: [0.3, 3.3, 0], fov: 48 },
];
export const S9 = ({ t, f }: Ctx) => {
  const rap = t > 35.3 ? 1 : 0, m = Math.sin(t * 11) > 0, cs = clamp((t - 37.6) / 1.35), hit = t > 38.95, sh = hit ? Math.exp(-(t - 38.95) * 3) : 0;
  return (<>
    <Cam t={t} keys={K9} impacts={[[38.93, 0.04]]} />
    <Lights warm="#ffc0a0" />
    <Floor kind="plank" a="#6a3a22" b="#5e321c" unit={1.7} w={30} d={24} />
    <WallDoor z={-6} W={30} kind="plain" a="#5a1a24" b="#5a1a24" base="#2a0a10" /><SideWall x={-9} kind="plain" a="#4a141e" b="#4a141e" /><SideWall x={9} kind="plain" a="#4a141e" b="#4a141e" />
    {Array.from({ length: 16 }, (_, i) => <Box key={i} p={[-7.5 + i, 1.0 + 0.8 * Math.abs(Math.sin(t * 8 * rap + i * 1.4)), -5.8]} s={[0.8, 1.6 + 1.6 * Math.abs(Math.sin(t * 8 * rap + i * 1.4)), 0.3]} color={["#ff3b7a", "#ffc23a", "#2fd4ff", "#7c4dff"][i % 4]} line={2} />)}
    {Array.from({ length: 10 }, (_, i) => <Box key={"f" + i} p={[-7 + (i % 5) * 3.4, 4.6 + Math.floor(i / 5) * 2, -5.9]} s={[1.5, 1.5, 0.2]} color={i % 2 ? "#6a1a2a" : "#7a2432"} line={2} />)}
    <CanvasPlane p={[0, 7.6, -5.8]} s={[3.2, 1.2]} px={[320, 120]} draw={(c, W, H) => { c.fillStyle = "#1a0408"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 8; c.strokeRect(4, 4, W - 8, H - 8); c.shadowColor = "#ff2a2a"; c.shadowBlur = 20; c.fillStyle = "#ff5a5a"; c.font = "900 66px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("ON AIR", W / 2, H / 2 + 3); }} /><Glow p={[0, 7.6, -5.2]} r={4} color="rgba(255,50,50,1)" o={0.4} />
    <Speaker p={[-5.6, 0, -2]} t={t} beat={rap} /><Speaker p={[5.6, 0, -2]} t={t} beat={rap} /><Console p={[-3.6, 0, -3.4]} w={3.6} t={t} /><Plant p={[7.2, 0, 1]} s={1.3} pot="#e58ab0" /><Lamp p={[-7.6, 0, 1]} h={3.2} color="#ffb070" />
    <SpotCone p={[0, 10, 0.4]} h={10} r={2.6} color="#ffe2c0" o={0.14} />
    <MicStand p={[0.95, 0, 0.7]} h={1.5} />
    <Person p={[0, 0, 0]} h={3.5} look={prodWire} f={f} pose={{ mood: rap ? (m ? "laugh" : "grin") : "smile", lookX: 0.3, tilt: 0.05 * Math.sin(t * 5.5) * rap, squash: -0.02 * Math.abs(Math.sin(t * 5.5)) * rap, sweat: 0, nerv: 0.1,
      armR: [0.36 + 0.04 * Math.sin(t * 5.5), 0.62 + 0.12 * Math.sin(t * 5.5)], armRK: 1, armL: [-0.12, 0.7], armLK: 1 }} />
    <FaceGroup p={[0, 0, 0]}><Ball p={[-0.66, 2.12, 0]} r={0.26} color="#2a2a38" ink={0.05} s={[0.6, 1, 1]} /><Ball p={[0.66, 2.12, 0]} r={0.26} color="#2a2a38" ink={0.05} s={[0.6, 1, 1]} /></FaceGroup>
    {t > 37.4 ? <CanvasPlane p={[1.0, 5.7, 0.8]} s={[2.4, 1.75]} px={[290, 210]} face draw={(c, W, H) => {
      c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); for (const [x, y, r] of [[70, 80, 56], [150, 60, 62], [225, 90, 52], [110, 120, 56], [190, 120, 56]] as number[][]) { c.moveTo(x + r, y); c.arc(x, y, r, 0, 7); } c.fill(); c.stroke();
      c.fillStyle = "#fff"; for (const [x, y, r] of [[70, 80, 54], [150, 60, 60], [225, 90, 50], [110, 120, 54], [190, 120, 54]] as number[][]) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); }
      c.fillStyle = "#3a3a4a"; c.fillRect(30, 120, 230, 36); const cxx = 40 + cs * 130 - (hit ? 12 : 0); c.fillStyle = "#8a6a42"; c.fillRect(190, 60, 12, 62); c.fillStyle = "#e5233a"; c.fillRect(cxx, 94, hit ? 40 : 54, 26); c.fillStyle = "#2a2a38"; c.beginPath(); c.arc(cxx + 10, 122, 9, 0, 7); c.arc(cxx + (hit ? 32 : 44), 122, 9, 0, 7); c.fill();
      if (hit) { c.fillStyle = "#ffc928"; c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5, r = i % 2 ? 12 : 26; c.lineTo(180 + Math.cos(a) * r, 90 + Math.sin(a) * r); } c.closePath(); c.fill(); c.stroke(); }
      c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.arc(70, 180, 12, 0, 7); c.fill(); c.stroke(); c.beginPath(); c.arc(40, 200, 7, 0, 7); c.fill(); c.stroke();
    }} /> : null}
    <Dust t={t} area={[5, 6, 3]} color="rgba(255,190,150,.9)" />
    {void sh}
  </>);
};

/* ============ S10 40.7 – 44.6  "The song, Through the Wire, finally makes people take him seriously." ============ */
const K10: Key[] = [
  { t: 40.5, pos: [-4.0, 3.2, 10.0], look: [0, 2.4, -1], fov: 56 },
  { t: 42.5, pos: [0.0, 3.4, 9.6], look: [0, 2.6, -1], fov: 54 },
  { t: 44.9, pos: [1.6, 3.2, 8.8], look: [0.4, 2.6, -1], fov: 52 },
];
export const S10 = ({ t, f }: Ctx) => {
  const lean = seg(t, 42.43, 42.8, Easing.out(Easing.back(2))), cheer = seg(t, 43.8, 44.1);
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#fff0c0" />
    <Floor kind="marble" a="#1a1a24" b="#14141c" unit={2} w={34} d={24} />
    <WallDoor z={-7} W={34} kind="plain" a="#2a1a10" b="#2a1a10" base="#140a06" /><SideWall x={-10} kind="plain" a="#24160e" b="#24160e" /><SideWall x={10} kind="plain" a="#24160e" b="#24160e" />
    <Curtain p={[-7, 4.6, -6.6]} s={[3, 9.2]} color="#8a6a14" /><Curtain p={[7, 4.6, -6.6]} s={[3, 9.2]} color="#8a6a14" />
    <ChartScreen p={[0, 6.6, -6.7]} s={[5.6, 3]} prog={seg(t, 41.9, 43.7)} up label="BUZZ" />
    <Box p={[0, 0.5, -3.6]} s={[3.8, 1.0, 3.4]} color="#2a2a38" line={3} /><Vinyl p={[0, 1.08, -3.6]} r={1.5} spin={t * 3.5} label="THE WIRE" rot={[-Math.PI / 2, 0, 0]} />
    <Cyl p={[1.6, 1.4, -2.4]} rt={0.05} h={1.0} color="#c9d3e0" line={1} rot={[0, 0, 0.5]} />
    {Array.from({ length: 24 }, (_, i) => { const a = (i / 24) * Math.PI * 2; return <Cyl key={i} p={[Math.cos(a) * 1.9, 1.15, -3.6 + Math.sin(a) * 1.9]} rt={0.04} h={0.5} color="#e8eef8" line={1} rot={[Math.PI / 2, 0, -a]} />; })}
    <Banner p={[0, 4.6, -5.8]} s={[4.8, 1.4]} text="THROUGH THE WIRE" size={36} bg="#1a1a24" fg="#ffc928" />
    <SpotCone p={[0, 10, -3.6]} h={9.4} r={2.6} color="#fff2c0" o={0.16} /><Glow p={[0, 1.4, -3.6]} r={3} color="rgba(255,220,120,1)" o={0.4} />
    {suits.map((s, i) => { const x = -4.2 + i * 1.7, z = 1.2 + (i % 2) * 0.9, b = danceBeat(t, i, 0.35 * seg(t, 43.2, 43.5)), look: [number, number] = [0.2, 0.2];
      return <React.Fragment key={i}><Person p={[x, b.y * 0.6 + lean * 0.1 * (i % 2 ? 1 : 0), z]} sy={0} h={3.7} look={s} f={f + i * 5} pose={{ mood: t < 42.4 ? "deadpan" : t < 43.4 ? "shock" : "grin", squash: b.pose.squash, tilt: b.pose.tilt * 0.5 + (t < 42.4 ? 0 : 0.04), lookX: t < 42.4 ? (i < 3 ? 0.9 : -0.9) : 0, flip: i % 2 === 1, arms: t > 42.43 ? "up" : "chest", armK: t < 42.43 ? 1 : cheer > 0 ? cheer : 0.0 }} />
        {t > 42.43 + i * 0.07 && t < 43.2 ? <CanvasPlane p={[x, 4.7, z]} s={[0.8, 0.8]} px={[80, 80]} face draw={(c, W, H) => { c.fillStyle = "#e5233a"; c.strokeStyle = INK; c.lineWidth = 6; c.font = "900 80px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.strokeText("!", 40, 44); c.fillText("!", 40, 44); }} /> : null}
        {void look}</React.Fragment>; })}
    {[-6.5, 6.5].map((x) => <Speaker key={x} p={[x, 0, -2]} t={t} beat={seg(t, 41.3, 41.6)} />)}<Plant p={[-8, 0, 2]} s={1.3} pot="#c9a032" /><Plant p={[8, 0, 2]} s={1.3} pot="#c9a032" />
    <Dust t={t} area={[7, 6, 4]} color="rgba(255,225,150,.9)" />
  </>);
};

/* ============ S11 44.6 – 49.9  "He was told to stay behind the board. It took nearly dying to put him in front of the microphone." ============ */
const K11: Key[] = [
  { t: 44.4, pos: [-2.8, 3.4, 8.8], look: [-2.8, 2.6, -1], fov: 56 },
  { t: 46.5, pos: [-1.0, 3.6, 9.8], look: [-1.0, 2.6, -1], fov: 56 },
  { t: 48.2, pos: [1.5, 3.4, 10.0], look: [1.4, 2.6, 0], fov: 54 },
  { t: 49.3, pos: [3.0, 2.8, 8.0], look: [3.4, 3.2, 0.4], fov: 46 },
  { t: 50.6, pos: [3.2, 2.6, 6.8], look: [3.4, 3.4, 0.4], fov: 44 },
];
const WP = (t: number): V3 => { const a = seg(t, 47.5, 48.3, Easing.linear), b = seg(t, 48.3, 49.3, ease); return [lerp(-3.0, 0.4, a) + b * 2.7, 0, lerp(-1.7, -1.7, a) + b * 2.3]; };
export const tintFor = (i: number): ((t: number) => string) | undefined => i === 10 ? (t: number) => { const k = Math.max(0, 1 - Math.abs(t - 47.52) / 0.22); return k > 0.01 ? `rgb(${Math.round(255 - 215 * k)},${Math.round(255 - 225 * k)},${Math.round(255 - 215 * k)})` : ""; } : i === 5 ? () => "#c8d0ff" : undefined;
export const S11 = ({ t, f }: Ctx) => {
  const pos = WP(t), moving = t > 47.5 && t < 49.3, sign = seg(t, 44.71, 45.0, Easing.out(Easing.back(2.4))) * (1 - seg(t, 47.2, 47.4)), grab = seg(t, 49.0, 49.3), cheer = seg(t, 49.4, 49.7);
  const dist = pos[0] + 3;
  return (<>
    <Cam t={t} keys={K11} impacts={[[47.52, 0.05]]} />
    <Lights warm="#e0c8ff" />
    <Floor kind="plank" a="#2a1a3a" b="#241632" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#1c1030" b="#1c1030" base="#0e0818" /><SideWall x={-10} kind="plain" a="#180e2a" b="#180e2a" /><SideWall x={11} kind="plain" a="#180e2a" b="#180e2a" />
    <Curtain p={[-6.5, 4.6, -5.8]} s={[3, 9.2]} color="#5a1a8a" /><Curtain p={[9, 4.6, -5.8]} s={[3, 9.2]} color="#5a1a8a" />
    <Console p={[-3, 0, 0.1]} w={5.2} t={t} /><Speaker p={[-7, 0, -2.4]} t={t} beat={0} /><Speaker p={[8, 0, -2.4]} t={t} beat={0} /><Monitor p={[-4.4, 3.2, -1.2]} rot={[0, 0.2, 0]} screen="#2f8cff" /><Monitor p={[-1.6, 3.2, -1.2]} rot={[0, -0.2, 0]} screen="#2fd46a" />
    <Banner p={[-2.6, lerp(14, 6.8, sign), 0.6]} s={[4.6, 1.5]} text="STAY BEHIND THE BOARD" size={27} bg="#c0182e" />
    <MicStand p={[3.6, 0, 0.7]} h={1.5} />
    <SpotCone p={[3.6, 10, 0.5]} h={10} r={2.0} color="#fff2c0" o={t > 47.3 && t < 47.8 ? 0 : 0.2} /><Glow p={[3.6, 0.1, 0.8]} r={2.6} color="rgba(255,240,200,1)" o={t > 47.3 && t < 47.8 ? 0 : 0.5} />
    <Plant p={[7, 0, 2.4]} s={1.3} pot="#7c4dff" /><Lamp p={[-8, 0, 1]} h={3.2} color="#d0a0ff" /><Rug p={[3, 0.01, 2]} s={[5, 3]} a="#3a1a5a" b="#ffc23a" /><Chair p={[-6.6, 0, 3]} rotY={0.5} color="#5a2a8a" />
    <Glow p={[0, 5, 0]} r={8} color="rgba(190,120,255,1)" o={0.22} /><Dust t={t} area={[7, 6, 4]} color="rgba(220,190,255,.9)" />
    <Person p={pos} h={4.1} look={prodWire} f={f} pose={{ mood: cheer > 0.5 ? "grin" : t < 47.2 ? "deadpan" : "worry", sweat: 0, hunch: t < 47.5 ? 0.45 : 0, lookX: t < 47.5 ? 0 : 0.6, walk: moving ? dist * WALK * 1.1 : undefined, speed: moving ? 0.85 : 0, nerv: 0.1,
      armR: t < 47.5 ? [-0.2 + 0.12 * Math.sin(t * 2), 0.46] : grab > 0 ? [0.14, lerp(0.5, 0.62, grab)] : undefined, armRK: t < 47.5 ? 1 : grab, armL: t < 47.5 ? [-0.3, 0.46] : cheer > 0 ? [-0.3, 0.9] : undefined, armLK: t < 47.5 ? 1 : cheer,
      arms: undefined }} />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11 };
