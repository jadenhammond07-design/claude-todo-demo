// PARKING LOT BUSINESS — 10 scenes. Generic stick figures.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk, Calendar } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Building, StreetLamp, Hydrant, Bin, Bench, Barrier } from "../style/extra";
import { Sky, Banner, Flame } from "../style/medieval";
import { Car, Palm } from "../style/studio";
import { Bill } from "../style/biz";
import { LotLines, CarField, SpaceXY, PayStand, PSign } from "../style/lot";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const owner = mk("#e0b48c", "#e8a63a", "shirt", "grey", "#999", { shoe: "#6a4426" });
const hero = mk("#d9a77c", "#1fb98a", "hoodie", "short", "#1a1008");
const operator = mk("#c98e62", "#ff7a29", "shirt", "short", "#111", { hat: "#ff7a29", badge: "#fff" });
const suit = mk("#f3d3b2", "#2d3142", "suit", "short", "#222", { tie: "#e53e3e", shoe: "#111" });
const shopper = mk("#f3d3b2", "#e55a8a", "hoodie", "bob", "#7a4a1c");
const commuter = mk("#8d5a3a", "#3a5a8a", "suit", "short", "#111", { tie: "#ffc23a", shoe: "#111" });
const office = mk("#fbe3c8", "#6a6a7a", "blazer", "swept", "#b8742a", { shirt: "#fff", badge: "#2f8cff" });
const money = (n: number) => "$" + Math.round(n).toLocaleString("en-US");
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Ground: React.FC<{ color?: string }> = ({ color = "#8a9a6a" }) => <Surface p={[0, -0.05, -10]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={color} b={color} />;
const Cross: React.FC<{ p: V3; k: number; s?: number }> = ({ p, k, s = 2 }) => k > 0.01 ? (
  <CanvasPlane p={p} s={[s, s]} px={[160, 160]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#e5233a"; c.lineWidth = 20; c.lineCap = "round"; c.beginPath(); c.moveTo(20, 20); c.lineTo(20 + 120 * k, 20 + 120 * k); c.moveTo(140, 20); c.lineTo(140 - 120 * k, 20 + 120 * k); c.stroke(); }} />) : null;

/* ============ S1 0 – 4.4  "People are paying money every day just to park on somebody else's property." ============ */
const K1: Key[] = [
  { t: 0, pos: [8, 17, 12], look: [0, 0, -2], fov: 58 },
  { t: 2.4, pos: [5, 9, 11], look: [0, 1, -2], fov: 56 },
  { t: 4.6, pos: [3.4, 4.8, 10], look: [0.4, 1.6, 0], fov: 54 },
];
export const S1 = ({ t, f }: Ctx) => {
  const arrive = seg(t, 2.2, 3.4, Easing.out(Easing.cubic));
  const bills = Array.from({ length: 10 }, (_, i) => { const u = ((t * 0.55 + i / 10) % 1), c = i % 6, r = Math.floor(i / 6), [x, z] = SpaceXY(c, r, 6, 2, 2.8, 5.2); return [x + (4 - x) * u * 0.5, 1.6 + u * 3.2, z * (1 - u * 0.6)] as V3; });
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Ground />
    <LotLines p={[0, 0, -2]} cols={6} rows={2} />
    <CarField p={[0, 0, -2]} cols={6} rows={2} filled={(i) => (i === 5 ? 0 : [1, 1, 0.01, 1, 1, 0][i] || (i < 11 ? 1 : 0))} seed={2} />
    <group position={[SpaceXY(2, 1, 6, 2)[0], 0, -2 + SpaceXY(2, 1, 6, 2)[1] + lerp(-6, 0, arrive)]} rotation={[0, Math.PI / 2, 0]}><Car p={[0, 0, 0]} color="#ffc23a" /></group>
    {bills.map((b, i) => <Bill key={i} p={b} rot={[0.4, t * 2 + i, 0.2]} s={1.2} />)}
    <PSign p={[-8.6, 0, 2]} s={1.2} /><Palm p={[9.2, 0, -6]} h={6} sway={Math.sin(t)} />
    <Chair p={[4.8, 0, 4.2]} rotY={-0.5} color="#e8a63a" /><Person p={[4.8, 0.3, 4.2]} sy={0.3} h={3.6} look={owner} f={f} pose={{ mood: "grin", armR: [0.28, 0.62], armRK: 1, lookX: -0.4, flip: true }} />
    <Box p={[6.4, 0.6, 4.0]} s={[1.0, 1.2, 0.9]} color="#c9a870" line={3} /><Dust t={t} area={[8, 6, 5]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S2 4.4 – 9.4  "A lot has no walls to heat and no inventory to stock, just ground and a pay stand." ============ */
const K2: Key[] = [
  { t: 4.2, pos: [-2.5, 3.6, 13.0], look: [-0.5, 3.0, 0], fov: 58 },
  { t: 7.2, pos: [0.0, 3.6, 12.0], look: [0, 2.4, 0], fov: 56 },
  { t: 9.6, pos: [0.4, 3.2, 10.0], look: [0.4, 2.0, 0], fov: 52 },
];
export const S2 = ({ t, f }: Ctx) => {
  const wall = 1 - seg(t, 5.9, 6.3), x1 = seg(t, 5.23, 5.6, Easing.out(Easing.back(2))), inv = 1 - seg(t, 7.0, 7.4), x2 = seg(t, 6.46, 6.9, Easing.out(Easing.back(2))), slab = seg(t, 7.93, 8.4, Easing.out(Easing.back(1.6))), stand = seg(t, 8.81, 9.2, Easing.out(Easing.back(2.2)));
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff0d8" />
    <Floor kind="tile" a="#e8e4dc" b="#d8d4cc" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#2fb8c8" b="#2fb8c8" base="#1a7a88" /><SideWall x={-9} kind="plain" a="#28a8b8" b="#28a8b8" /><SideWall x={9} kind="plain" a="#28a8b8" b="#28a8b8" />
    <group position={[-3.4, 0, 0]} scale={[1, Math.max(0.001, wall), 1]}><Box p={[0, 2.2, 0]} s={[3.6, 4.4, 2.4]} color="#d8a870" line={4} /><Box p={[0, 4.6, 0]} s={[4, 0.5, 2.8]} color="#a8442c" line={3} /><Box p={[0, 1.6, 1.22]} s={[1.0, 2.2, 0.06]} color="#6a4426" line={2} /><Flame p={[1.3, 0.5, 1.4]} t={t} s={0.6} /><CanvasPlane p={[-0.9, 3.2, 1.22]} s={[1.0, 0.8]} px={[100, 80]} draw={(c, W, H) => { c.fillStyle = "#bfe8ff"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 4; c.strokeRect(2, 2, W - 4, H - 4); }} /></group>
    <Cross p={[-3.4, 3.0, 1.8]} k={x1} s={2.4} />
    <group position={[3.2, 0, 0.4]} scale={[1, Math.max(0.001, inv), 1]}><Shelf p={[0, 0, 0]} w={3} rows={3} seed={3} wood="#6a4426" /></group>
    <Cross p={[3.2, 2.4, 1.4]} k={x2} s={2.4} />
    {slab > 0.01 ? <group position={[0, 0, 2.2]} scale={[1, 1, Math.max(0.01, slab)]}><Box p={[0, 0.05, 0]} s={[8, 0.12, 3.6]} color="#3a3a44" line={3} />{[-3, -1, 1, 3].map((x) => <Box key={x} p={[x, 0.13, 0]} s={[0.1, 0.03, 3]} color="#f4f4f4" line={0} />)}</group> : null}
    <PayStand p={[0, 0, 0.6 + (1 - stand) * 0.0]} s={Math.max(0.001, stand) * 1.4} text="PAY" t={t} />
    <Person p={[-0.4, 0, 4.6]} h={3.8} look={hero} f={f} pose={{ mood: t < 7.9 ? "worry" : "grin", armR: [0.3, 0.55], armRK: seg(t, 8.8, 9.1), lookX: 0.2 }} />
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S3 9.4 – 16.7  "Charge ten dollars a space a day, and a full 20-space lot grosses about $73,000 a year if it stays full." ============ */
const K3: Key[] = [
  { t: 9.2, pos: [-3.0, 3.6, 8.0], look: [0, 1.6, 0], fov: 54 },
  { t: 11.3, pos: [0, 6.0, 12.0], look: [0, 1.0, -1], fov: 56 },
  { t: 12.8, pos: [0, 12.0, 13.0], look: [0, 0.5, -2.4], fov: 58 },
  { t: 16.9, pos: [0, 12.5, 12.0], look: [0, 0.5, -2.2], fov: 58 },
];
export const S3 = ({ t, f }: Ctx) => {
  const rate = seg(t, 9.71, 10.0, Easing.out(Easing.back(2.6))), full = (i: number) => t < 11.8 ? (i === 7 ? 1 : 0) : clamp((t - 11.8 - i * 0.045) / 0.25), total = lerp(0, 73000, seg(t, 13.54, 15.1, Easing.out(Easing.cubic))), day = Math.min(365, Math.floor(seg(t, 13.54, 15.1, Easing.linear) * 365));
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Ground />
    <LotLines p={[0, 0, -2.4]} cols={5} rows={4} />
    <CarField p={[0, 0, -2.4]} cols={5} rows={4} filled={full} seed={3} />
    <Sign p={[-1.4, 7.6, 1.0]} w={3.0} h={1.1} text="$10 / DAY" k={rate} size={62} />
    {t > 10.3 && t < 11.7 ? <Bill p={[SpaceXY(2, 1, 5, 4)[0] + 0.0, 2.6 + Math.sin(t * 4) * 0.2, -2.4 + SpaceXY(2, 1, 5, 4)[1]]} rot={[0.4, t * 3, 0.2]} s={1.8} /> : null}
    <Sign p={[1.6, 9.6, -2.0]} w={4.4} h={1.6} text={money(total)} k={t > 13.5 ? 1 : 0} size={78} fg="#2fff9a" />
    <Sign p={[1.6, 7.8, -2.0]} w={2.6} h={0.8} text={"DAY " + day} k={t > 13.5 && t < 15.3 ? 1 : 0} size={50} bg="#c0182e" fg="#fff" />
    <Sign p={[0, 11.2, -3.6]} w={3.0} h={1.1} text="FULL" k={seg(t, 16.22, 16.5, Easing.out(Easing.back(2.6)))} size={80} bg="#1fa850" fg="#fff" />
    <PSign p={[-7.6, 0, 3]} s={1.2} /><Person p={[-5.6, 0, 3.4]} h={3.8} look={hero} f={f} pose={{ mood: "grin", armR: [0.3, 0.7], armRK: t < 9.7 ? 1 : 0, lookX: 0.4 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S4 16.7 – 20.4  "A 200-space lot? Around $730,000." ============ */
const K4: Key[] = [
  { t: 16.5, pos: [0, 4.0, 14.0], look: [0, 2.0, 0], fov: 58 },
  { t: 18.0, pos: [0, 18.0, 26.0], look: [0, 0, -10], fov: 60 },
  { t: 20.6, pos: [0, 30.0, 34.0], look: [0, 0, -12], fov: 62 },
];
export const S4 = ({ t, f }: Ctx) => {
  const total = lerp(73000, 730000, seg(t, 18.41, 19.8, Easing.out(Easing.cubic))), pop = seg(t, 17.69, 18.1, Easing.out(Easing.back(2.4)));
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -80]} s={[400, 160]} top="#5aa8ff" bottom="#dff0ff" />
    <Ground />
    <LotLines p={[0, 0, -12]} cols={20} rows={10} />
    <CarField p={[0, 0, -12]} cols={20} rows={10} filled={(i) => (i % 13 === 5 ? 0 : clamp((t - 16.7 - (i % 20) * 0.01) / 0.3))} seed={5} />
    <Sign p={[0, 8.6, 4]} w={6.6} h={1.6} text={"200 SPACES"} k={pop} size={86} />
    <Sign p={[0, 15, 3]} w={9} h={2.6} text={money(total)} k={t > 18.4 ? 1 : 0} size={150} fg="#2fff9a" />
    <Person p={[-2.4, 0, 6]} h={3.8} look={hero} f={f} pose={{ mood: "shock", arms: "up", armK: seg(t, 17.2, 17.6), lookX: 0.2 }} />
    {Array.from({ length: 14 }, (_, i) => { const u = ((t * 0.6 + i / 14) % 1); return t > 18.4 ? <Bill key={i} p={[-10 + (i * 53) % 20, 22 - u * 20, 4 + (i % 4)]} rot={[0.3, t * 3 + i, 0.2]} s={2.4} /> : null; })}
    <Dust t={t} area={[10, 8, 6]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S5 20.4 – 26.0  "charge by the hour for shoppers, by the day for commuters, or by the month for office workers." ============ */
const K5: Key[] = [
  { t: 20.2, pos: [-5.5, 3.4, 10.5], look: [-5.0, 2.4, 0], fov: 56 },
  { t: 22.0, pos: [-1.5, 3.4, 10.5], look: [-0.5, 2.4, 0], fov: 56 },
  { t: 23.2, pos: [3.0, 3.4, 10.5], look: [4.4, 2.4, 0], fov: 56 },
  { t: 24.8, pos: [4.0, 3.4, 10.5], look: [4.6, 2.4, 0], fov: 56 },
  { t: 26.2, pos: [3.8, 3.4, 10.0], look: [4.6, 2.4, 0], fov: 54 },
];
export const S5 = ({ t, f }: Ctx) => {
  const a = seg(t, 21.43, 21.75, Easing.out(Easing.back(2.6))), b = seg(t, 22.86, 23.2, Easing.out(Easing.back(2.6))), c = seg(t, 24.56, 24.9, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -40]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Surface p={[0, 0, -2]} s={[80, 24]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" />
    {[-9, -4.5, 0, 4.5, 9].map((x) => <Box key={x} p={[x, 0.02, 0]} s={[0.12, 0.03, 4.6]} color="#f4f4f4" line={0} />)}
    {/* mall / station / office */}
    <Box p={[-4.6, 3.2, -4.6]} s={[6.6, 6.4, 2.6]} color="#e8a63a" line={4} /><Sign p={[-4.6, 5.8, -3.2]} w={4.4} h={0.9} text="SHOPPING" size={52} face={false} bg="#c0182e" fg="#fff" />
    <Box p={[0.6, 2.8, -4.6]} s={[6.0, 5.6, 2.6]} color="#7a8aaa" line={4} /><Sign p={[0.6, 5.2, -3.2]} w={4.4} h={0.9} text="STATION" size={52} face={false} bg="#1f4a8a" fg="#fff" />
    <Box p={[5.4, 4.6, -4.6]} s={[4.6, 9.2, 2.6]} color="#6a8aba" line={4} /><Sign p={[5.4, 8.4, -3.2]} w={3.8} h={0.9} text="OFFICES" size={52} face={false} bg="#2a2a38" fg="#fff" />
    <Car p={[-4.6, 0, 0.8]} color="#e5233a" /><Car p={[0.4, 0, 0.8]} color="#2f8cff" /><Car p={[5.2, 0, 0.8]} color="#f4f4f4" />
    <Person p={[-4.4, 0, 3.2]} h={3.7} look={shopper} f={f} pose={{ mood: "grin", armR: [0.3, 0.55], armRK: 1, armL: [-0.3, 0.55], armLK: 1 }} />
    {[-0.5, 0.5].map((dx) => <Box key={dx} p={[-4.4 + 0.9 + dx * 0.3, 1.1, 3.4]} s={[0.5, 0.8, 0.3]} color={dx < 0 ? "#ff7a9a" : "#ffc23a"} line={2} />)}
    <Person p={[0.6, 0, 3.2]} h={3.8} look={commuter} f={f + 3} pose={{ mood: "deadpan", armR: [0.3, 0.52], armRK: 1, lookX: -0.3 }} /><Box p={[1.5, 1.0, 3.4]} s={[0.9, 0.7, 0.3]} color="#6a4426" line={2} />
    <Person p={[5.4, 0, 3.2]} h={3.8} look={office} f={f + 6} pose={{ mood: "smile", armR: [0.3, 0.55], armRK: 1, lookX: 0.2 }} /><Box p={[6.3, 1.0, 3.4]} s={[0.9, 0.6, 0.2]} color="#14141c" line={2} />
    <Sign p={[-4.6, 6.2, 1.6]} w={3.0} h={1.0} text="BY THE HOUR" k={a} size={36} /><Sign p={[0.6, 6.2, 1.6]} w={3.0} h={1.0} text="BY THE DAY" k={b} size={36} /><Sign p={[5.4, 6.2, 1.6]} w={3.0} h={1.0} text="BY THE MONTH" k={c} size={32} />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S6 26.0 – 33.0  "you can lease your lot to an operator for a share of the profits, or invest in a few spaces through a developer." ============ */
const K6: Key[] = [
  { t: 25.8, pos: [-4.0, 3.6, 11.0], look: [-3.0, 2.8, 0], fov: 58 },
  { t: 28.4, pos: [-1.0, 3.6, 11.0], look: [0, 2.8, 0], fov: 56 },
  { t: 30.2, pos: [3.0, 3.8, 11.0], look: [4.4, 2.8, 0], fov: 56 },
  { t: 33.2, pos: [4.0, 4.2, 10.0], look: [4.6, 2.6, 0], fov: 54 },
];
export const S6 = ({ t, f }: Ctx) => {
  const shake = seg(t, 28.2, 28.6) * (1 - seg(t, 29.0, 29.3)), pie = seg(t, 29.3, 30.1, Easing.out(Easing.cubic)), gold = (i: number) => seg(t, 30.75 + i * 0.4, 31.0 + i * 0.4);
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -40]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Surface p={[0, 0, -2]} s={[80, 24]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a8a5a" b="#7a8a5a" />
    {/* the owner relaxing, the operator working the pay stand */}
    <Surface p={[-4.8, 0.02, 0.6]} s={[9, 5.6]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" />
    <Chair p={[-6.8, 0, 3.4]} rotY={0.4} color="#e8a63a" /><Person p={[-6.8, 0.3, 3.4]} sy={0.3} h={3.6} look={owner} f={f} pose={{ mood: "smile", armR: [0.28, 0.6], armRK: 1, lookX: 0.4 }} />
    <Cyl p={[-5.6, 1.0, 3.2]} rt={0.2} h={0.5} color="#ff7a9a" line={2} /><Cyl p={[-5.6, 0.2, 3.2]} rt={0.5} h={0.4} color="#c9a870" line={2} />
    <PayStand p={[-2.6, 0, 1.4]} s={1.3} text="OPEN" t={t} /><Person p={[-1.2, 0, 1.6]} h={3.8} look={operator} f={f + 3} pose={{ mood: "grin", armR: [0.28, 0.55 + 0.05 * Math.sin(t * 6)], armRK: 1, lookX: -0.3 }} />
    <Car p={[-6.0, 0, -0.2]} color="#e5233a" /><Car p={[-3.0, 0, -0.2]} color="#2f8cff" />
    {/* contract handshake + profit share */}
    <Sign p={[-3.4, 6.6, 1.2]} w={4.6} h={1.1} text="LEASE" k={seg(t, 27.56, 27.9, Easing.out(Easing.back(2.6)))} size={70} />
    <CanvasPlane p={[-3.4, 4.6, 1.6]} s={[2.4 * seg(t, 29.27, 29.6, Easing.out(Easing.back(2.2))) + 0.001, 2.6 * seg(t, 29.27, 29.6, Easing.out(Easing.back(2.2))) + 0.001]} px={[240, 260]} face frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f4a8a"; c.fillRect(0, 0, W, 50); c.fillStyle = "#fff"; c.font = "900 28px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("SHARE OF PROFITS", W / 2, 27); c.fillStyle = "#d8dce8"; c.beginPath(); c.arc(120, 150, 70, 0, 7); c.fill(); c.fillStyle = "#2fd46a"; c.beginPath(); c.moveTo(120, 150); c.arc(120, 150, 70, -Math.PI / 2, -Math.PI / 2 + pie * Math.PI * 1.1); c.closePath(); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.beginPath(); c.arc(120, 150, 70, 0, 7); c.stroke(); }} />
    {/* developer's table model: invest in a few spaces */}
    <Box p={[4.8, 1.0, 0.4]} s={[5.4, 0.2, 3.4]} color="#7a5a38" line={3} /><Box p={[4.8, 0.5, 0.4]} s={[5.0, 1.0, 3.0]} color="#5a3e22" line={2} />
    <Box p={[4.8, 1.14, 0.4]} s={[4.4, 0.1, 2.6]} color="#3a3a44" line={2} />
    {Array.from({ length: 8 }, (_, i) => { const c = i % 4, r = Math.floor(i / 4), g = i < 3 ? gold(i) : 0; return <Box key={i} p={[3.4 + c * 0.95, 1.3 + 0.1 * g, -0.4 + r * 1.2]} s={[0.7, 0.2 + 0.1 * g, 0.9]} color={g > 0.5 ? "#ffc928" : "#9aa4b8"} line={2} />; })}
    <Sign p={[4.8, 4.6, 0.6]} w={3.8} h={1.0} text="A FEW SPACES" k={seg(t, 31.31, 31.7, Easing.out(Easing.back(2.6)))} size={46} />
    <Person p={[6.8, 0, 1.4]} h={3.9} look={suit} f={f + 6} pose={{ mood: "grin", armR: [0.4, 0.6], armRK: seg(t, 30.5, 30.8), flip: true, lookX: -0.4 }} />
    <Person p={[2.2, 0, 1.6]} h={3.8} look={hero} f={f + 9} pose={{ mood: "smile", armR: [0.35, 0.5], armRK: shake, lookX: 0.5 }} />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S7 33.0 – 38.9  "Guides claim 30 to 40 percent margins, but nobody verifies that, and the catch is location." ============ */
const K7: Key[] = [
  { t: 32.8, pos: [-2.0, 3.6, 11.0], look: [0, 3.2, 0], fov: 58 },
  { t: 35.4, pos: [0.6, 3.6, 9.4], look: [0.6, 3.0, 0], fov: 54 },
  { t: 37.6, pos: [0.2, 4.0, 11.0], look: [0, 3.2, 0], fov: 56 },
  { t: 39.0, pos: [0.2, 4.0, 10.4], look: [0, 3.2, 0], fov: 54 },
];
export const S7 = ({ t, f }: Ctx) => {
  const guide = seg(t, 33.0, 33.4, Easing.out(Easing.back(2)));
  const bar = seg(t, 33.65, 34.9, Easing.out(Easing.cubic)), q = seg(t, 35.89, 36.2, Easing.out(Easing.back(2.6))), pin = seg(t, 37.9, 38.14, Easing.in(Easing.quad));
  return (<>
    <Cam t={t} keys={K7} impacts={[[38.14, 0.03]]} />
    <Lights warm="#ffe8c8" />
    <Floor kind="plank" a="#6a4a32" b="#5e402a" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#2a3a50" b="#2a3a50" base="#141e30" /><SideWall x={-9} kind="plain" a="#24344a" b="#24344a" /><SideWall x={9} kind="plain" a="#24344a" b="#24344a" />
    <group position={[-2.4, 1.6, 0.6]} scale={Math.max(0.001, guide) * 0.8}><Box p={[0, 1.2, 0]} s={[2.4, 3.0, 0.4]} color="#ffc23a" line={4} /><CanvasPlane p={[0, 1.4, 0.22]} s={[2.0, 2.2]} px={[200, 220]} draw={(c, W, H) => { c.fillStyle = "#ffc23a"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("PARKING", W / 2, 50); c.fillText("GUIDE", W / 2, 100); c.font = "900 90px Inter, Arial"; c.fillText("P", W / 2, 170); }} /></group>
    <CanvasPlane p={[1.4, 4.8, -0.4]} s={[3.8, 3.0]} px={[440, 340]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f4a8a"; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.fillText("MARGIN", W / 2, 46); c.fillStyle = "#d8dce8"; c.fillRect(30, 90, W - 60, 60); c.fillStyle = "#2fd46a"; c.fillRect(30, 90, (W - 60) * 0.3 * bar, 60); c.fillStyle = "#8be8a8"; c.fillRect(30 + (W - 60) * 0.3 * bar, 90, (W - 60) * 0.1 * bar, 60); c.strokeStyle = INK; c.lineWidth = 5; c.strokeRect(30, 90, W - 60, 60); c.fillStyle = INK; c.font = "900 80px Inter, Arial"; c.fillText("30–40%", W / 2, 240); c.fillStyle = "#c0182e"; c.font = "800 30px Inter, Arial"; c.fillText("(GUIDES CLAIM)", W / 2, 300); }} />
    <CanvasPlane p={[0.8, 2.2, 1.4]} s={[3.2 * q + 0.001, 1.5 * q + 0.001]} px={[320, 150]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 18); c.fill(); c.stroke(); c.fillStyle = "#14141c"; c.font = "900 40px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("VERIFIED?", W / 2, 52); c.strokeStyle = "#8a8a96"; c.lineWidth = 6; c.strokeRect(W / 2 - 30, 84, 60, 50); c.fillStyle = "#e5233a"; c.font = "900 50px Inter, Arial"; c.fillText("?", W / 2, 112); }} />
    <Sign p={[0.8, 7.6, 0]} w={3.2} h={1.0} text="LOCATION" k={seg(t, 38.14, 38.4, Easing.out(Easing.back(2.6)))} size={58} bg="#c0182e" fg="#fff" />
    <group position={[0.8, lerp(10.0, 6.6, pin), 0.4]}><Ball p={[0, 0.5, 0]} r={0.45} color="#e5233a" /><Cyl p={[0, -0.2, 0]} rt={0.03} h={1.0} color="#c9d3e0" line={1} /></group>
    <Person p={[0.6, 0, 3.0]} h={3.9} look={hero} f={f} pose={{ mood: t < 35.6 ? "smile" : t < 37.9 ? "worry" : "shock", sweat: t > 36 ? 1 : 0, armR: [0.34, 0.65], armRK: seg(t, 35.6, 35.9) * (1 - seg(t, 37.2, 37.5)), lookX: 0.4, arms: t > 38.14 ? "head" : undefined, armK: seg(t, 38.2, 38.5) }} />
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S8 38.9 – 42.9  "The same lot can print money downtown and sit empty in the suburbs." ============ */
const K8: Key[] = [
  { t: 38.7, pos: [-6.0, 3.8, 12.0], look: [-5.0, 2.6, 0], fov: 58 },
  { t: 40.6, pos: [-4.0, 4.0, 12.0], look: [-3.8, 2.8, 0], fov: 56 },
  { t: 41.6, pos: [4.6, 3.8, 12.0], look: [5.2, 2.6, 0], fov: 56 },
  { t: 43.1, pos: [5.4, 3.6, 10.6], look: [5.4, 2.4, 0], fov: 52 },
];
export const S8 = ({ t, f }: Ctx) => {
  const bills = Array.from({ length: 9 }, (_, i) => { const u = ((t * 0.9 + i / 9) % 1); return [-4.6 + Math.sin(i * 1.7) * 1.6 + u * 0.6, 1.8 + u * 4.2, 1.2] as V3; });
  const roll = seg(t, 41.8, 43.0, Easing.linear);
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#fff4d8" />
    <Sky p={[0, 26, -40]} s={[300, 150]} top="#5aa8ff" bottom="#dff0ff" />
    <Surface p={[-8, 0, -3]} s={[16, 18]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a44" b="#3a3a44" /><Surface p={[8, 0, -3]} s={[16, 18]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a8a5a" b="#7a8a5a" />
    {/* downtown: towers, full lot, money printer */}
    {[-12, -8.4, -4.8, -1.2].map((x, i) => <Box key={x} p={[x, 5 + (i % 3) * 2.5, -6]} s={[3.2, 10 + (i % 3) * 5, 3]} color={["#6a8aba", "#7a9aca", "#5a7aaa", "#6a8aba"][i]} line={4} />)}
    <CarField p={[-6.0, 0, -1.4]} cols={5} rows={2} filled={() => 1} seed={7} />
    <group position={[-4.6, 0, 3.4]}><Box p={[0, 0.9, 0]} s={[2.4, 1.8, 1.4]} color="#2fb85a" line={4} /><Box p={[0, 1.9, 0.2]} s={[1.6, 0.3, 0.9]} color="#14141c" line={2} /><Sign p={[0, 3.0, 0.4]} w={2.6} h={0.8} text="$$$" size={60} fg="#2fff9a" /></group>
    {bills.map((b, i) => <Bill key={i} p={b} rot={[0.4, t * 3 + i, 0.3]} s={1.6} />)}
    {/* suburbs: houses, empty lot, tumbleweed */}
    {[5.0, 9.4, 13.4].map((x, i) => <group key={x} position={[x, 0, -6]}><Box p={[0, 1.4, 0]} s={[3.0, 2.8, 2.6]} color={["#f0e0b8", "#d8c8a0", "#e8d8b0"][i]} line={3} /><Box p={[0, 3.2, 0]} s={[3.5, 0.9, 3]} color="#a8442c" line={3} /></group>)}
    <LotLines p={[8.0, 0, -1.4]} cols={5} rows={2} asphalt="#5a5a62" />
    <CarField p={[8.0, 0, -1.4]} cols={5} rows={2} filled={(i) => (i === 3 ? 1 : 0)} seed={4} />
    <Ball p={[lerp(11.5, 4.5, roll), 0.7, 3.0]} r={0.6} color="#a8884a" ink={0.05} />
    <CanvasPlane p={[6.0, 0.05, 2.4]} rot={[-Math.PI / 2, 0, 0]} s={[3, 3]} px={[100, 100]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.7)"; c.lineWidth = 2; for (let k = 0; k < 6; k++) { c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(k * 0.28) * 100, Math.sin(k * 0.28) * 100); c.stroke(); } }} />
    <Sign p={[-5.0, 8.6, 1.4]} w={3.2} h={1.0} text="DOWNTOWN" size={50} face={false} bg="#1fa850" fg="#fff" /><Sign p={[8.4, 6.0, 1.4]} w={3.2} h={1.0} text="SUBURBS" size={50} face={false} bg="#8a5a3a" fg="#fff" />
    <Person p={[-2.6, 0, 3.4]} h={3.8} look={hero} f={f} pose={{ mood: "grin", arms: "up", armK: seg(t, 39.88, 40.2), lookX: -0.4 }} />
    <Person p={[7.0, 0, 3.4]} h={3.8} look={owner} f={f + 4} pose={{ mood: "worry", sweat: t > 41.6 ? 1 : 0, arms: "shrug", armK: seg(t, 41.63, 42.0), lookX: -0.4 }} />
    <Dust t={t} area={[18, 6, 5]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S9 42.9 – 45.7  "So here's the question: what ground near you is sitting empty" ============ */
const K9: Key[] = [
  { t: 42.7, pos: [0, 15, 8], look: [0, 0, 0], fov: 56 },
  { t: 45.9, pos: [0, 11, 6.4], look: [0.4, 0, 0.2], fov: 50 },
];
export const S9 = ({ t, f }: Ctx) => {
  const pulse = 1 + 0.15 * Math.sin(t * 8), q = seg(t, 43.63, 43.95, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K9} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, -0.1, 0]} s={[60, 60]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a2a4a" b="#1a2a4a" />
    <CanvasPlane p={[0, 0.02, 0]} rot={[-Math.PI / 2, 0, 0]} s={[11, 15]} px={[660, 900]} draw={(c, W, H) => {
      c.fillStyle = "#dfe8d0"; c.fillRect(0, 0, W, H); c.fillStyle = "#b8c8d8"; for (let r = 0; r < 6; r++) c.fillRect(0, 60 + r * 150, W, 36); for (let k = 0; k < 4; k++) c.fillRect(80 + k * 160, 0, 36, H);
      for (let r = 0; r < 6; r++) for (let k = 0; k < 4; k++) { const x = 120 + k * 160 + 14, y = 100 + r * 150 + 6; if (r === 3 && k === 2) continue; c.fillStyle = ["#e8a63a", "#c9a870", "#9aa4b8", "#e58a8a"][(r + k) % 4]; c.strokeStyle = INK; c.lineWidth = 4; c.fillRect(x, y, 100, 90); c.strokeRect(x, y, 100, 90); }
      c.fillStyle = "#b8c0a0"; c.fillRect(120 + 2 * 160 + 14, 100 + 3 * 150 + 6, 100, 90); c.setLineDash([12, 8]); c.strokeStyle = "#e5233a"; c.lineWidth = 6; c.strokeRect(120 + 2 * 160 + 10, 100 + 3 * 150 + 2, 108, 98); c.setLineDash([]);
    }} />
    <group position={[0.7, 0.2, 2.6]} scale={pulse}><Cyl p={[0, 0.3, 0]} rt={0.02} h={0.6} color="#c9d3e0" line={1} /><Ball p={[0, 0.75, 0]} r={0.4} color="#e5233a" /><Glow p={[0, 0.8, 0.5]} r={1.8} color="rgba(255,60,60,1)" o={0.5} /></group>
    <Sign p={[0.7, 3.4, 2.6]} w={1.8 * q + 0.001} h={1.8 * q + 0.001} text="?" size={150} fg="#ff5a8a" bg="#14081e" />
    <Dust t={t} area={[8, 6, 6]} color="rgba(220,235,255,.8)" />
  </>);
};

/* ============ S10 45.7 – 48.7  "...that someone would pay to park on?" ============ */
const K10: Key[] = [
  { t: 45.5, pos: [-3.6, 3.6, 11.0], look: [0, 2.6, 0], fov: 58 },
  { t: 47.6, pos: [0.2, 3.6, 10.0], look: [0.6, 2.4, 0], fov: 54 },
  { t: 48.9, pos: [0.4, 3.6, 9.4], look: [0.6, 2.4, 0], fov: 52 },
];
export const S10 = ({ t, f }: Ctx) => {
  const car = seg(t, 46.9, 47.9, Easing.out(Easing.cubic)), pay = seg(t, 47.4, 47.7, Easing.out(Easing.back(2.6))), yours = seg(t, 47.9, 48.3, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#ffe8c8" />
    <Sky p={[0, 26, -40]} s={[300, 150]} top="#ff9a3a" bottom="#ffe8a8" glowAt={[0.8, "rgba(255,230,130,1)"]} />
    <Surface p={[0, 0, -2]} s={[80, 30]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#9aa070" b="#9aa070" />
    {[-7, -3.4, 4.6, 8.4].map((x, i) => <Box key={x} p={[x, 3 + (i % 2) * 1.5, -4.6]} s={[3.2, 6 + (i % 2) * 3, 2.8]} color={["#8a7a6a", "#7a8aaa", "#9a6a6a", "#6a8a7a"][i]} line={4} />)}
    <Box p={[0.6, 0.04, -1.4]} s={[7.6, 0.1, 5.4]} color="#b8b090" line={0} />
    {Array.from({ length: 12 }, (_, i) => <Cyl key={i} p={[-2.8 + (i % 6) * 1.1 + 0.2, 0.2, -3.6 + Math.floor(i / 6) * 3]} rt={0.14} h={0.4} color="#7a8a4a" line={0} />)}
    <group position={[-3.6, 0, 0.8]}><Cyl p={[0, 1.2, 0]} rt={0.07} h={2.4} color="#5a5a6a" line={2} /><Sign p={[0, 2.8, 0.1]} w={2.6} h={1.0} text="FOR RENT" size={50} bg="#fff" fg="#c0182e" face={false} /></group>
    <group position={[lerp(-4, 1.4, car), 0, -0.6]} rotation={[0, 0, 0]}><Car p={[0, 0, 0]} color="#2f8cff" /></group>
    {pay > 0.01 ? <Bill p={[1.6, 3.2 + 0.4 * Math.sin(t * 5), -0.6]} rot={[0.3, t * 3, 0.2]} s={2.2 * pay} /> : null}
    <Sign p={[0.6, 6.8, 0.6]} w={4.6 * yours + 0.001} h={1.4 * yours + 0.001} text="YOUR LOT?" size={66} fg="#2fff9a" />
    <Person p={[-1.8, 0, 3.2]} h={3.9} look={hero} f={f} pose={{ mood: t < 47.4 ? "worry" : "grin", armR: [0.34, 0.75], armRK: seg(t, 46.0, 46.3) * (1 - seg(t, 47.2, 47.5)), armL: [-0.3, 0.5], armLK: seg(t, 46.0, 46.3) * (1 - seg(t, 47.2, 47.5)), lookX: 0.5, arms: t > 47.6 ? "up" : undefined, armK: seg(t, 47.7, 48.0) }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,240,200,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
