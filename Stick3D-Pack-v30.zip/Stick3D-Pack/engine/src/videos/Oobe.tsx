// OUT-OF-BODY IN A LAB — 9 scenes (Ehrsson 2007 goggles + camera; Blanke brain stimulation). Generic figures.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Calendar } from "../style/kit";
import { Glow, Dust, Chair } from "../style/props";
import { Cam } from "../style/extra";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const vol = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008");
const ghost = mk("#e8f0ff", "#a8c8ff", "hoodie", "short", "#7a8ac8", { shoe: "#8aa0d8" });
const sci = mk("#f3d3b2", "#f4f4f4", "shirt", "swept", "#c8a060", { glasses: true, badge: "#2f8cff" });
const sci2 = mk("#e8b88c", "#f4f4f4", "shirt", "short", "#3a2410", { glasses: true, badge: "#2fd46a" });
const H = 3.4, EYE = H * 0.73;
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H2) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H2 - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H2 / 2 + 3); }} />
);
const Lab: React.FC = () => (<>
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8e0ee" b="#c8d0e0" unit={1.6} />
  <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#2a3a5a" line={3} />
  {[-4, 0, 4].map((x, i) => <Glow key={i} p={[x, 7.5, -4]} r={2} color="rgba(220,240,255,1)" o={0.4} />)}
</>);
const Goggles: React.FC<{ x: number; z: number; k?: number; flip?: boolean }> = ({ x, z, k = 1, flip }) => (k <= 0.01 ? null :
  <group position={[x, EYE + (1 - k) * 1.5, z + 0.32]} scale={[k, k, k]}><Box p={[0, 0, 0]} s={[0.95, 0.36, 0.32]} color="#14141c" line={2} /><Box p={[flip ? -0.2 : 0.2, 0, 0.17]} s={[0.4, 0.2, 0.02]} color="#3affd8" line={0} /></group>);
const Camera: React.FC<{ p: V3; flip?: boolean; rec?: number }> = ({ p, flip, rec = 1 }) => (
  <group position={p} scale={[flip ? -1 : 1, 1, 1]}>
    {[-0.4, 0.4, 0].map((x, i) => <Box key={i} p={[x * 0.6, 1.0, i === 2 ? -0.3 : 0.15]} s={[0.07, 2.0, 0.07]} rot={[i === 2 ? 0.2 : 0, 0, x * 0.4]} color="#3a3a46" line={2} />)}
    <Box p={[0, 2.25, 0]} s={[0.9, 0.6, 0.6]} color="#2b3350" line={3} /><Cyl p={[0.55, 2.25, 0]} rt={0.22} h={0.4} color="#14141c" line={2} rot={[0, 0, Math.PI / 2]} />
    <Ball p={[-0.25, 2.62, 0.2]} r={0.07} color={rec > 0.5 ? "#e5233a" : "#555"} ink={0.02} />
  </group>
);
/** what the goggles show: their own back from behind */
const Feed: React.FC<{ p: V3; s: [number, number]; t: number; hammer?: number; rod?: number }> = ({ p, s, t, hammer = 0, rod = 0 }) => (
  <CanvasPlane p={p} s={s} px={[360, 260]} draw={(c, W, Hh) => { c.fillStyle = "#c8d0e0"; c.fillRect(0, 0, W, Hh); c.fillStyle = "#2a3a5a"; c.fillRect(0, 0, W, Hh * 0.45);
    c.fillStyle = "#ff7a29"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(W / 2 - 60, 120, 120, 150, 30); c.fill(); c.stroke(); c.fillStyle = "#d9a77c"; c.beginPath(); c.arc(W / 2, 95, 50, 0, 7); c.fill(); c.stroke(); c.fillStyle = "#1a1008"; c.beginPath(); c.arc(W / 2, 85, 46, Math.PI, 0); c.fill();
    if (rod > 0) { c.strokeStyle = "#ffd23a"; c.lineWidth = 10; c.beginPath(); c.moveTo(W - 20, 150); c.lineTo(W - 20 - 80 * rod, 170); c.stroke(); }
    if (hammer > 0) { c.save(); c.translate(W - 40, 30); c.rotate(-1.2 + hammer * 1.4); c.fillStyle = "#8a5a32"; c.fillRect(-8, 0, 16, 140); c.fillStyle = "#555"; c.fillRect(-36, 130, 72, 40); c.restore(); }
    c.fillStyle = "#e5233a"; c.beginPath(); c.arc(24, 22, 9, 0, 7); c.fill(); c.fillStyle = "#14141c"; c.font = "900 20px Inter, Arial"; c.fillText("LIVE", 38, 29); }} />
);
const Brain: React.FC<{ p: V3; s?: number; t: number; spot?: number }> = ({ p, s = 1, t, spot = 0 }) => (
  <group position={p} scale={[s, s, s]}>
    {Array.from({ length: 14 }, (_, i) => { const a = (i / 14) * Math.PI * 2; return <Ball key={i} p={[Math.cos(a) * 1.1, Math.sin(a) * 0.75 + 0.1, ((i * 37) % 5) * 0.06]} r={0.55} color="#ff9ab8" ink={0.04} />; })}
    <Ball p={[0, 0.1, 0.1]} r={1.0} s={[1.3, 0.9, 0.7]} color="#ff9ab8" ink={0.04} />
    <Cyl p={[0.2, -1.05, -0.1]} rt={0.22} h={0.8} color="#e88aa8" line={2} />
    {spot > 0 ? <><Ball p={[0.6, 0.3, 0.75]} r={0.2} color="#ffe14a" ink={0.02} /><Glow p={[0.6, 0.3, 1.0]} r={1.0 + 0.25 * Math.sin(t * 8)} color="rgba(255,230,80,1)" o={0.8 * spot} /></> : null}
  </group>
);

/* ============ S1 0 – 4.2  hook: you float out of your body ============ */
export const S1 = ({ t, f }: Ctx) => {
  const out = seg(t, 0.8, 3.2, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 4.0, 12], look: [0, 4.2, 0], fov: 56 }, { t: 4.3, pos: [0, 4.6, 12.5], look: [0, 5.0, 0], fov: 56 }])} />
    <Lights warm="#d8e0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#1c2a4a" b="#16223e" unit={2} />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#121c34" line={3} />
    <Chair p={[0, 0, 0.2]} color="#3b4a8a" />
    <Person p={[0, 0, 0.9]} h={H} look={vol} f={f} pose={{ mood: "deadpan", lookX: 0 }} />
    <Glow p={[0.3, lerp(1.8, 5.0, out), 0.6]} r={3} color="rgba(160,200,255,1)" o={0.6 * out} />
    {out > 0.02 ? <Person p={[lerp(0, 0.6, out), lerp(0, 2.8, out), 0.6]} h={H} look={ghost} f={f + 9} pose={{ mood: "smile", lookX: -0.3, arms: "up", armK: out, tilt: 0.1 * out }} shadow={false} /> : null}
    <Dust t={t} area={[8, 7, 4]} color="rgba(190,210,255,.7)" />
  </>);
};

/* ============ S2 4.2 – 10.37  2007, Henrik Ehrsson, chair, goggles ============ */
export const S2 = ({ t, f }: Ctx) => {
  const yr = seg(t, 4.29, 4.6, back), nm = seg(t, 6.57, 6.9, back), gog = seg(t, 9.38, 9.8, back);
  return (<>
    <Cam t={t} keys={low([{ t: 4.0, pos: [0, 4.2, 12.5], look: [0, 3.8, 0], fov: 56 }, { t: 10.5, pos: [0, 4.0, 11.5], look: [0, 3.6, 0], fov: 55 }])} />
    <Lights warm="#f0f4ff" />
    <Lab />
    <Calendar p={[1.8, 6.6, -4.6]} month="YEAR" day="2007" s={1.5 * yr * (1 - nm) + 0.001} />
    <Chair p={[0.9, 0, 0.0]} color="#3b4a8a" />
    <Person p={[0.9, 0, 0.7]} h={H} look={vol} f={f} pose={{ mood: gog > 0.5 ? "smile" : "deadpan", lookX: -0.2 }} />
    <Goggles x={0.9} z={0.7} k={gog} />
    <Person p={[-1.6, 0, 1.4]} h={3.6} look={sci} f={f + 5} pose={{ mood: "smile", lookX: 0.5, armR: [0.35, 0.75], armRK: gog }} />
    <Sign p={[-0.5, 5.6, 1.6]} w={3.2} h={0.75} text="HENRIK EHRSSON" k={nm} size={33} bg="#fff" fg="#14141c" />
    <Sign p={[1.3, 4.4, 1.4]} w={2.8} h={0.75} text="VIDEO GOGGLES" k={gog} size={32} bg="#3affd8" fg="#14141c" />
  </>);
};

/* ============ S3 10.37 – 15.71  camera behind; they see their own back ============ */
export const S3 = ({ t, f }: Ctx) => {
  const cam = seg(t, 12.15, 12.5, back), feed = seg(t, 11.2, 11.6, back), own = seg(t, 14.29, 14.6, back);
  return (<>
    <Cam t={t} keys={low([{ t: 10.2, pos: [-4.0, 5.0, 10], look: [0, 3.6, -1], fov: 58 }, { t: 15.9, pos: [-3.0, 5.0, 10.5], look: [0, 3.6, -1], fov: 58 }])} />
    <Lights warm="#f0f4ff" />
    <Lab />
    <Chair p={[0, 0, 0]} color="#3b4a8a" rotY={Math.PI} />
    <Person p={[0, 0, -0.6]} h={H} look={vol} f={f} pose={{ mood: "smile", flip: true }} />
    <Goggles x={0} z={-0.95} k={1} />
    <Camera p={[0.2, 0, 2.6]} flip rec={cam} />
    {/* beam from camera to goggles */}
    <Box p={[0.1, 2.7, 1.0]} s={[0.05, 0.05, 3.2 * feed + 0.01]} color="#3affd8" line={0} />
    <Feed p={[1.6, 6.6, -1]} s={[3.0, 2.2]} t={t} />
    <Sign p={[1.6, 8.2, -0.8]} w={2.6} h={0.7} text="LIVE FEED" k={feed} size={34} bg="#e5233a" fg="#fff" />
    <Sign p={[-0.4, 7.4, 0.6]} w={3.4} h={0.8} text="THEIR OWN BACK" k={own} size={34} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S4 15.71 – 19.62  two rods move at the same time ============ */
export const S4 = ({ t, f }: Ctx) => {
  const r = seg(t, 15.9, 16.6, ease), r2 = seg(t, 17.7, 18.8, ease), sync = seg(t, 18.73, 19.0, back), tap = 0.15 * Math.sin(t * 8);
  return (<>
    <Cam t={t} keys={low([{ t: 15.5, pos: [0, 4.2, 12], look: [0, 3.6, 0], fov: 56 }, { t: 19.8, pos: [0, 4.2, 11], look: [0, 3.6, 0], fov: 54 }])} />
    <Lights warm="#f0f4ff" />
    <Lab />
    <Person p={[-1.2, 0, 0.6]} h={H} look={vol} f={f} pose={{ mood: "smile", lookX: 0.2 }} />
    <Goggles x={-1.2} z={0.6} />
    {/* rod 1 on chest */}
    <Box p={[lerp(0.6, -0.4, r) + tap * r, 1.9, 1.2]} s={[1.6, 0.1, 0.1]} color="#ffd23a" line={2} />
    <Person p={[1.4, 0, 1.0]} h={3.6} look={sci} f={f + 5} pose={{ mood: "smile", flip: true, armR: [-0.4, 0.5], armRK: r }} />
    {/* rod 2 toward the camera */}
    <Camera p={[2.8, 0, -2.0]} flip />
    <Box p={[lerp(1.2, 2.2, r2) + tap * r2, 2.25, -1.9]} s={[1.4, 0.1, 0.1]} color="#ffd23a" line={2} />
    <Sign p={[0, 6.6, 0.6]} w={3.2} h={0.85} text="SAME TIME" k={sync} size={46} bg="#ffd23a" fg="#14141c" />
    <Sign p={[-1.2, 5.0, 1.2]} w={1.9} h={0.7} text="CHEST" k={seg(t, 16.38, 16.7, back) * (1 - sync)} size={34} bg="#fff" fg="#14141c" />
  </>);
};

/* ============ S5 19.62 – 22.9  they feel outside their body ============ */
export const S5 = ({ t, f }: Ctx) => {
  const out = seg(t, 20.61, 22.0, ease), lab = seg(t, 21.79, 22.1, back);
  return (<>
    <Cam t={t} keys={low([{ t: 19.4, pos: [0, 4.4, 12.5], look: [0, 4.0, 0], fov: 56 }, { t: 23.0, pos: [0, 4.6, 12], look: [0, 4.2, 0], fov: 56 }])} />
    <Lights warm="#e0e8ff" />
    <Lab />
    <Chair p={[-0.8, 0, 0]} color="#3b4a8a" />
    <Person p={[-0.8, 0, 0.7]} h={H} look={vol} f={f} pose={{ mood: "worry", lookX: 0.2 }} />
    <Goggles x={-0.8} z={0.7} />
    <Glow p={[lerp(-0.8, 1.6, out), 2.2, -0.6]} r={2.6} color="rgba(160,200,255,1)" o={0.6 * out} />
    {out > 0.02 ? <Person p={[lerp(-0.8, 1.6, out), 0, lerp(0.7, -1.0, out)]} h={H} look={ghost} f={f + 9} pose={{ mood: "smile", lookX: -0.6, flip: true }} shadow={false} /> : null}
    <Camera p={[2.2, 0, -1.8]} flip />
    <Sign p={[0.4, 7.0, 0.6]} w={3.8} h={0.85} text="OUTSIDE MY BODY?!" k={lab} size={38} bg="#a8c8ff" fg="#14141c" />
  </>);
};

/* ============ S6 22.9 – 27.01  hammer swings; stress spikes ============ */
export const S6 = ({ t, f }: Ctx) => {
  const sw = seg(t, 23.4, 24.3, Easing.in(Easing.cubic)), stress = seg(t, 25.46, 26.6, Easing.out(Easing.quad)), sp = seg(t, 26.39, 26.65, Easing.out(Easing.back(3)));
  return (<>
    <Cam t={t} keys={low([{ t: 22.7, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 56 }, { t: 27.1, pos: [0.4, 4.2, 10.5], look: [0.3, 4.0, 0], fov: 54 }])} />
    <Lights warm="#ffe0e0" />
    <Lab />
    <Feed p={[0, 6.0, -1.5]} s={[4.0, 2.9]} t={t} hammer={sw} />
    <Person p={[-1.4, 0, 1.2]} h={H} look={vol} f={f} pose={{ mood: sw > 0.6 ? "worry" : "deadpan", sweat: sw > 0.6 ? 1 : 0, nerv: 0.4 * stress, arms: sw > 0.6 ? "chest" : undefined, armK: sw }} />
    <Goggles x={-1.4} z={1.2} />
    {/* stress meter */}
    <CanvasPlane p={[1.7, 2.6, 1.2]} s={[1.1, 2.6]} px={[110, 260]} draw={(c, W, Hh) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(3, 3, W - 6, Hh - 6, 14); c.fill(); c.stroke(); c.fillStyle = "#333"; c.fillRect(30, 40, 50, 200); const v = 0.15 + 0.85 * stress; c.fillStyle = v > 0.7 ? "#e5233a" : v > 0.4 ? "#ffd23a" : "#2fd46a"; c.fillRect(30, 240 - 200 * v, 50, 200 * v); c.fillStyle = "#fff"; c.font = "900 18px Inter, Arial"; c.textAlign = "center"; c.fillText("STRESS", W / 2, 28); }} />
    <Sign p={[1.7, 4.6, 1.4]} w={2.6} h={0.8} text="SPIKED!" k={sp} size={44} bg="#e5233a" fg="#fff" />
  </>);
};

/* ============ S7 27.01 – 33.49  Olaf Blanke: stimulating a spot in the brain ============ */
export const S7 = ({ t, f }: Ctx) => {
  const nm = seg(t, 28.83, 29.15, back), spot = seg(t, 32.34, 32.7, back), probe = seg(t, 31.57, 32.3, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 26.8, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 56 }, { t: 33.6, pos: [0, 4.4, 11], look: [0, 4.2, 0], fov: 54 }])} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0e1a30" b="#0e1a30" />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#0e1a30" line={0} />
    <Brain p={[0.9, 4.8, -1]} s={1.2} t={t} spot={spot} />
    <Box p={[lerp(4.2, 2.3, probe), lerp(6.8, 5.4, probe), 0.2]} s={[2.2, 0.08, 0.08]} rot={[0, 0, -0.5]} color="#c0c4d0" line={2} />
    <Person p={[-1.6, 0, 1.6]} h={3.4} look={sci2} f={f} pose={{ mood: "smile", lookX: 0.4 }} />
    <Sign p={[-1.1, 4.4, 2.0]} w={2.8} h={0.75} text="OLAF BLANKE" k={nm} size={36} bg="#fff" fg="#14141c" />
    <Sign p={[0.9, 7.8, 0]} w={2.8} h={0.8} text="ONE SPOT" k={spot} size={44} bg="#ffe14a" fg="#14141c" />
    <Sign p={[1.2, 2.2, 1.8]} w={2.6} h={0.7} text="= OUT OF BODY" k={seg(t, 32.9, 33.2, back)} size={28} bg="#a8c8ff" fg="#14141c" />
  </>);
};

/* ============ S8 33.49 – 39.32  made in a lab; comes from the brain ============ */
export const S8 = ({ t, f }: Ctx) => {
  const labk = seg(t, 35.41, 35.7, back), into = seg(t, 37.0, 38.3, ease), notk = seg(t, 38.36, 38.65, back);
  return (<>
    <Cam t={t} keys={low([{ t: 33.3, pos: [0, 4.6, 12.5], look: [0, 4.4, 0], fov: 56 }, { t: 39.4, pos: [0, 4.6, 12], look: [0, 4.4, 0], fov: 56 }])} />
    <Lights warm="#e0e8ff" />
    <Lab />
    <Person p={[-1.0, 0, 1.0]} h={H} look={vol} f={f} pose={{ mood: "smile", lookX: 0.3 }} />
    {into < 0.98 ? <Person p={[lerp(1.6, -1.0, into), lerp(1.4, 2.6, into), lerp(0.4, 1.0, into)]} h={H * (1 - 0.8 * into)} look={ghost} f={f + 9} pose={{ mood: "smile", flip: true }} shadow={false} /> : null}
    <Glow p={[-1.0, EYE, 1.3]} r={1.6} color="rgba(255,150,190,1)" o={0.7 * into} />
    <Sign p={[0, 7.4, 0.4]} w={3.4} h={0.85} text="MADE IN A LAB" k={labk * (1 - into)} size={42} bg="#2f8cff" fg="#fff" />
    <Sign p={[0, 7.4, 0.6]} w={3.6} h={0.85} text="FROM THE BRAIN" k={seg(t, 37.75, 38.05, back)} size={40} bg="#ff9ab8" fg="#14141c" />
    <Sign p={[1.6, 5.6, 1.0]} w={2.8} h={0.7} text="NOT LEAVING IT" k={notk} size={30} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S9 39.32 – end  "how sure are you that you're where you think you are?" ============ */
export const S9 = ({ t, f }: Ctx) => {
  const mv = seg(t, 41.28, 42.4, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 39.1, pos: [0, 4.4, 12], look: [0, 4.0, 0], fov: 56 }, { t: 45.1, pos: [0, 4.2, 11], look: [0, 3.8, 0], fov: 54 }])} />
    <Lights warm="#e0e8ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#1c2a4a" b="#16223e" unit={2} />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#121c34" line={3} />
    <Person p={[-1.4, 0, 1.0]} h={H} look={vol} f={f} pose={{ mood: mv > 0.5 ? "worry" : "smile", lookX: 0.4 }} />
    <Goggles x={-1.4} z={1.0} />
    <Camera p={[1.8, 0, 0.2]} flip />
    {/* "you are here" pin travels from you to the camera */}
    <group position={[lerp(-1.4, 1.8, mv), 4.6 + Math.sin(t * 3) * 0.1, 1.2]}>
      <Ball p={[0, 0.3, 0]} r={0.38} color="#e5233a" ink={0.05} /><Box p={[0, -0.25, 0]} s={[0.12, 0.6, 0.12]} rot={[0, 0, 0]} color="#e5233a" line={2} /><Ball p={[0, 0.3, 0.3]} r={0.14} color="#fff" ink={0.02} />
    </group>
    <Sign p={[0.2, 6.2, 1.0]} w={2.8} h={0.75} text="YOU ARE HERE?" k={seg(t, 40.59, 40.9, back)} size={34} bg="#fff" fg="#e5233a" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
