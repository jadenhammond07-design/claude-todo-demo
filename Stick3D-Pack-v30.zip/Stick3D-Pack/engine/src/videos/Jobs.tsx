// CONNECT THE DOTS — 12 scenes. Generic stick-figure stand-in, no logos.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Building, StreetLamp, Bench, Curtain, Lectern } from "../style/extra";
import { Sky, Banner, CrowdField, Flame } from "../style/medieval";
import { MicStand } from "../style/studio";
import { Compact } from "../style/computer";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#3a2a1a", ...extra });
const steveY = mk("#f3d3b2", "#5a7aaa", "shirt", "bob", "#5a3420", { glasses: true });
const steveO = mk("#f3d3b2", "#1a1a22", "hoodie", "short", "#3a3a3a", { glasses: true, shoe: "#8a8a96" });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008");
const teacher = mk("#e0b48c", "#6a4a8a", "blazer", "grey", "#aaa", { shirt: "#fff", glasses: true });
const eng = (i: number) => mk(["#e0b48c", "#8d5a3a", "#fbe3c8"][i % 3], ["#3a7fd6", "#2fa86a", "#e5533a"][i % 3], "shirt", (["short", "bob", "swept"] as const)[i % 3], "#3b2a1a", { glasses: i % 2 === 1 });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; font?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true, font = "900 {s}px Inter, Arial" }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = font.replace("{s}", String(size)); c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const TAG = (txt: string, p: V3, k = 1) => <Sign p={p} w={2.6} h={0.7} text={txt} k={k} size={40} />;

/* ============ S1 0 – 3.9  "What if one tiny decision changed your entire life?" ============ */
const K1: Key[] = [
  { t: 0, pos: [0.4, 2.4, 6.0], look: [0, 1.0, 0], fov: 54 },
  { t: 2.0, pos: [0.4, 5.0, 9.0], look: [0, 1.5, -4], fov: 58 },
  { t: 4.1, pos: [0.2, 12.0, 12.0], look: [0, 0, -10], fov: 60 },
];
export const S1 = ({ t, f }: Ctx) => {
  const grow = clamp((t - 1.2) / 2.4), pick = t > 1.94;
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#ffe0c0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#2a1a5a" bottom="#ffb070" glowAt={[0.8, "rgba(255,200,120,1)"]} stars={0.4} t={t} />
    <Surface p={[0, -0.05, -14]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a5a3a" b="#3a5a3a" />
    <CanvasPlane p={[0, 0.02, -14]} rot={[-Math.PI / 2, 0, 0]} s={[40, 30]} px={[1000, 750]} draw={(c, W, H) => {
      c.clearRect(0, 0, W, H); const branch = (x: number, y: number, a: number, len: number, d: number, lit: boolean) => { if (d > 6 || len < 8) return; const k = clamp(grow * 7 - d); if (k <= 0) return; const x2 = x + Math.sin(a) * len * k, y2 = y - Math.cos(a) * len * k; c.strokeStyle = lit ? "#ffd36a" : "rgba(230,230,255,.55)"; c.lineWidth = Math.max(3, 18 - d * 2.4); c.lineCap = "round"; c.beginPath(); c.moveTo(x, y); c.lineTo(x2, y2); c.stroke(); if (k >= 1) { branch(x2, y2, a - 0.42, len * 0.78, d + 1, lit && pick); branch(x2, y2, a + 0.42, len * 0.78, d + 1, false); } };
      branch(W / 2, H - 20, 0, 150, 0, true);
    }} />
    <Person p={[0, 0, 0.4]} h={3.3} look={you} f={f} pose={{ mood: pick ? "grin" : "worry", armR: [0.2, 0.55], armRK: 1, lookX: pick ? -0.3 : 0.3 }} />
    {!pick ? <Cyl p={[0.8, 2.4 + Math.abs(Math.sin(t * 9)) * 0.5, 0.8]} rt={0.12} h={0.03} color="#ffc928" line={1} rot={[t * 14, 0, 0]} /> : null}
    <Dust t={t} area={[8, 6, 6]} color="rgba(255,230,170,.8)" />
  </>);
};

/* ============ S2 3.9 – 9.4  "There's a version of your life that exists because you made one decision you probably don't even remember." ============ */
const K2: Key[] = [
  { t: 3.7, pos: [0, 3.6, 12.0], look: [0, 3.0, 0], fov: 58 },
  { t: 6.6, pos: [0.4, 3.4, 10.0], look: [0, 2.8, 0], fov: 54 },
  { t: 9.6, pos: [0.0, 3.4, 8.6], look: [0, 3.0, 0], fov: 50 },
];
export const S2 = ({ t, f }: Ctx) => {
  const v = (i: number) => seg(t, 4.15 + i * 0.25, 4.5 + i * 0.25, Easing.out(Easing.back(2.2))), door = seg(t, 6.6, 7.1, ease), fade = seg(t, 8.0, 9.0);
  const outfits = ["#2f8cff", "#2fa86a", "#c24fff"];
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#e8e0ff" />
    <Floor kind="marble" a="#1c1a3a" b="#16142e" unit={2} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#24204a" b="#24204a" base="#100e24" /><SideWall x={-9} kind="plain" a="#1e1a40" b="#1e1a40" /><SideWall x={9} kind="plain" a="#1e1a40" b="#1e1a40" />
    {[-4.4, 0, 4.4].map((x, i) => <React.Fragment key={i}><Box p={[x, 2.4, -4.8]} s={[2.6, 4.8, 0.3]} color="#3a3466" line={3} /><Box p={[x, 2.2, -4.6]} s={[2.0, 4.2, 0.1]} color={i === 1 ? "#ffd36a" : "#5a5490"} line={2} /><Glow p={[x, 2.4, -4.2]} r={2.6} color={i === 1 ? "rgba(255,210,110,1)" : "rgba(150,140,255,1)"} o={0.35} />
      <Sign p={[x, 5.4, -4.4]} w={2.4} h={0.7} text={"VERSION " + "ABC"[i]} size={34} k={v(i)} face={false} />
      <Person p={[x, 0, -2.6]} h={3.2} look={{ ...you, body: outfits[i] }} f={f + i * 7} pose={{ mood: i === 1 ? "grin" : "smile", lookX: 0 }} /></React.Fragment>)}
    <Person p={[0, 0, 1.8]} h={3.8} look={you} f={f} pose={{ mood: t > 8.4 ? "worry" : "smile", armR: [0.3, 0.55], armRK: door * (1 - seg(t, 7.4, 7.6)), lookX: 0 }} />
    <CanvasPlane p={[1.6, 6.2, 2.0]} s={[2.4, 1.7]} px={[240, 170]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.globalAlpha = 1 - fade * 0.85; c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); for (const [x, y, r] of [[70, 80, 50], [130, 60, 56], [185, 88, 46], [120, 112, 50]] as number[][]) { c.moveTo(x + r, y); c.arc(x, y, r, 0, 7); } c.fill(); c.stroke(); c.fillStyle = "#fff"; for (const [x, y, r] of [[70, 80, 48], [130, 60, 54], [185, 88, 44], [120, 112, 48]] as number[][]) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } c.fillStyle = "#6a5aa8"; c.font = "900 64px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(fade > 0.5 ? "?" : "A or B", 125, 88); }} />
    <Dust t={t} area={[8, 6, 4]} color="rgba(200,190,255,.8)" />
  </>);
};

/* ============ S3 9.4 – 12.0  "Steve Jobs did. Early 1970s, Reed College." ============ */
const K3: Key[] = [
  { t: 9.2, pos: [-3.0, 3.4, 11.0], look: [0, 2.8, 0], fov: 58 },
  { t: 12.2, pos: [0.4, 3.6, 10.0], look: [0, 3.2, -1], fov: 56 },
];
export const S3 = ({ t, f }: Ctx) => {
  const tag = seg(t, 9.42, 9.7, Easing.out(Easing.back(2.6))), yr = seg(t, 10.82, 11.1, Easing.out(Easing.back(2.6))), col = seg(t, 12.0, 12.2);
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#7ab0e8" bottom="#f8ecd0" />
    <Surface p={[0, -0.05, -10]} s={[100, 60]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6aa84a" b="#6aa84a" /><Surface p={[0, 0.0, 0]} s={[3, 30]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#b8a890" b="#a89880" unit={1.2} />
    <WallDoor z={-6} W={22} kind="brick" a="#a84a3a" b="#983e30" door={{ x: 0, w: 2.6, h: 4.2 }} base="#5a2418" /><Box p={[0, 9.2, -6.2]} s={[22.6, 0.6, 1]} color="#e8dcc0" line={3} />
    <Sign p={[0, 6.4, -5.8]} w={5.4} h={1.2} text="REED COLLEGE" size={64} bg="#f4ecd8" fg="#5a2418" face={false} />
    {[-7, 7].map((x) => <group key={x} position={[x, 0, -2]}><Cyl p={[0, 2, 0]} rt={0.3} rb={0.4} h={4} color="#6a4426" line={2} /><Ball p={[0, 5, 0]} r={2.2} color="#3f8a3a" /></group>)}
    <Bench p={[-4.4, 0, 1.4]} rotY={0.4} /><StreetLamp p={[4.6, 0, 1.4]} h={5} flip />
    <Sign p={[3.2, 4.6, 1.6]} w={3.4} h={1.0} text="EARLY 1970s" k={yr} size={52} bg="#c0182e" fg="#fff" />
    <Person p={[-0.6, 0, 1.6]} h={3.8} look={steveY} f={f} pose={{ mood: "smile", lookX: 0.2 }} />{TAG("STEVE JOBS", [-0.6, 5.0, 1.6], tag)}
    {[0, 1, 2].map((i) => <Person key={i} p={[-5 + i * 5.2, 0, -3.4]} h={3.0} look={eng(i)} f={f + i * 5} pose={{ mood: "smile", walk: (t + i) * 3, speed: 0.4 }} />)}
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,250,220,.8)" />
    {void col}
  </>);
};

/* ============ S4 12.0 – 17.1  "He's dropped out and broke, but he keeps wandering into classes that interest him." ============ */
const SX = (t: number) => lerp(-6.2, 6.0, seg(t, 14.6, 17.1, Easing.linear));
const K4: Key[] = [
  { t: 11.8, pos: [-5.6, 3.4, 9.6], look: [-5.4, 2.8, 0], fov: 56 },
  { t: 14.4, pos: [-5.0, 3.4, 9.4], look: [-5.0, 2.8, 0], fov: 54 },
  ...[15.2, 16.0, 16.8, 17.3].map((tt) => ({ t: tt, pos: [SX(tt) + 0.6, 3.4, 9.6] as V3, look: [SX(tt) + 1.2, 2.8, 0] as V3, fov: 56 })),
];
export const S4 = ({ t, f }: Ctx) => {
  const stamp = seg(t, 13.17, 13.35, Easing.in(Easing.quad)), broke = seg(t, 13.99, 14.3), x = SX(t), walking = t > 14.6 && t < 17.1, peek = (dx: number) => Math.max(0, 1 - Math.abs(x - dx) / 1.2);
  const doors: [number, string][] = [[-2.4, "PHYSICS"], [1.4, "POETRY"], [5.2, "DANCE"], [9.0, "CALLIGRAPHY"]];
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff0d8" />
    <Floor kind="tile" a="#d8c8a8" b="#c8b898" unit={1.6} w={40} d={24} />
    <WallDoor z={-4} W={40} kind="plain" a="#e8dcc0" b="#e8dcc0" base="#a88a5a" />
    {doors.map(([dx, name], i) => <React.Fragment key={i}><Box p={[dx, 2.1, -3.9]} s={[2.0, 4.2, 0.16]} color="#8a5a32" line={3} /><Sign p={[dx, 4.8, -3.8]} w={2.6} h={0.6} text={name} size={30} bg="#2a2a38" fg="#fff" face={false} /><Box p={[dx + 0.7, 2.0, -3.78]} s={[0.2, 0.12, 0.1]} color="#c9a032" line={1} /></React.Fragment>)}
    <group position={[-5.6, 0, -0.4]}><Box p={[0, 0.9, 0]} s={[1.6, 0.1, 1.0]} color="#8a6a42" line={2} /><CanvasPlane p={[0, 3.8, 0.4]} s={[2.2, 1.6]} px={[220, 160]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "800 20px Inter, Arial"; c.textAlign = "center"; c.fillText("ENROLLMENT", W / 2, 30); for (let k = 0; k < 4; k++) { c.fillStyle = "#c8c8d4"; c.fillRect(30, 50 + k * 18, 160, 6); } if (stamp > 0.99) { c.save(); c.translate(W / 2, 110); c.rotate(-0.2); c.strokeStyle = "#e5233a"; c.fillStyle = "#e5233a"; c.lineWidth = 5; c.strokeRect(-90, -24, 180, 48); c.font = "900 28px Inter, Arial"; c.textBaseline = "middle"; c.fillText("DROPPED OUT", 0, 2); c.restore(); } }} /></group>
    <Sign p={[-3.0, 5.6, 0.4]} w={2.2} h={0.8} text="$0" k={broke} size={60} bg="#fff" fg="#c0182e" />
    <Person p={[t < 14.6 ? -4.2 : x, 0, 0.8]} h={3.8} look={steveY} f={f} pose={{ mood: walking ? "smile" : t > 13.9 ? "worry" : "deadpan", walk: walking ? x * WALK : undefined, speed: walking ? 0.6 : 0, arms: t > 13.9 && t < 14.6 ? "shrug" : undefined, armK: broke, lookX: walking ? (doors.some(([dx]) => peek(dx) > 0.5) ? -0.8 : 0.4) : 0.2 }} />
    <Plant p={[11, 0, -2.6]} s={1.3} pot="#c0643a" /><Bench p={[3.4, 0, -2.6]} /><Dust t={t} area={[12, 5, 4]} color="rgba(255,245,220,.8)" />
  </>);
};

/* ============ S5 17.1 – 23.7  "One is calligraphy. He learns serif and sans serif, the space between letter pairs, what makes type beautiful." ============ */
const K5: Key[] = [
  { t: 16.9, pos: [-2.5, 3.6, 11.0], look: [0, 3.2, -1], fov: 58 },
  { t: 19.0, pos: [0.0, 4.0, 10.0], look: [0, 4.0, -2], fov: 54 },
  { t: 21.6, pos: [0.0, 4.2, 9.4], look: [0, 4.2, -2], fov: 52 },
  { t: 23.9, pos: [0.6, 3.6, 10.5], look: [0.4, 3.4, -1], fov: 56 },
];
export const S5 = ({ t, f }: Ctx) => {
  const serif = seg(t, 18.96, 19.3, Easing.out(Easing.back(2))), sans = seg(t, 19.54, 19.9, Easing.out(Easing.back(2))), kern = seg(t, 20.9, 21.8, Easing.inOut(Easing.cubic)), beauty = seg(t, 23.02, 23.4);
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#fff0d0" />
    <Floor kind="plank" a="#8a6a42" b="#7a5c38" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#e8dcc0" b="#e8dcc0" base="#a88a5a" /><SideWall x={-9} kind="plain" a="#d8cca8" b="#d8cca8" /><SideWall x={9} kind="plain" a="#d8cca8" b="#d8cca8" />
    <CanvasPlane p={[0, 4.6, -4.9]} s={[8.4, 4.4]} px={[840, 440]} frame="#5a4228" draw={(c, W, H) => {
      c.fillStyle = "#24302a"; c.fillRect(0, 0, W, H); c.fillStyle = "#f4f0e0"; c.textAlign = "center"; c.textBaseline = "middle";
      c.font = "italic 700 60px Georgia, serif"; c.fillText("Calligraphy", W / 2, 60);
      if (serif > 0.01) { c.save(); c.translate(220, 200); c.scale(serif, serif); c.font = "700 130px Georgia, 'Times New Roman', serif"; c.fillText("Aa", 0, 0); c.font = "800 28px Inter, Arial"; c.fillText("SERIF", 0, 90); c.restore(); }
      if (sans > 0.01) { c.save(); c.translate(620, 200); c.scale(sans, sans); c.font = "800 130px Inter, Arial, sans-serif"; c.fillText("Aa", 0, 0); c.font = "800 28px Inter, Arial"; c.fillText("SANS SERIF", 0, 90); c.restore(); }
      if (t > 20.4) { c.font = "700 110px Georgia, serif"; const gap = lerp(70, 18, kern); c.fillText("A", W / 2 - gap, 360); c.fillText("V", W / 2 + gap, 360); c.strokeStyle = "#ffd36a"; c.lineWidth = 4; c.beginPath(); c.moveTo(W / 2 - 30, 420); c.lineTo(W / 2 + 30, 420); c.stroke(); }
      if (beauty > 0) { for (let i = 0; i < 14; i++) { const a = i * 0.45 + t * 2; c.fillStyle = `rgba(255,214,110,${beauty})`; c.beginPath(); c.arc(W / 2 + Math.cos(a) * (300 + (i % 3) * 30), 200 + Math.sin(a) * 160, 6, 0, 7); c.fill(); } }
    }} />
    {[-6.6, 6.6].map((x, i) => <CanvasPlane key={x} p={[x, 4.6, -4.9]} s={[2.2, 3.0]} px={[220, 300]} frame="#5a4228" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#1a1a22"; c.font = "italic 700 64px Georgia, serif"; c.textAlign = "center"; c.fillText(i ? "Grace" : "Ink", W / 2, 120); c.fillStyle = "#c0182e"; c.font = "700 120px Georgia, serif"; c.fillText(i ? "&" : "Q", W / 2, 250); }} />)}
    <Box p={[-1.4, 1.5, 1.2]} s={[3.2, 0.16, 1.6]} color="#a8804a" line={3} /><Box p={[-1.4, 0.75, 1.2]} s={[2.8, 1.5, 1.2]} color="#8a6a42" line={2} />
    <CanvasPlane p={[-1.4, 1.6, 1.3]} rot={[-Math.PI / 2, 0, 0]} s={[1.6, 1.1]} px={[160, 110]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.font = "italic 700 40px Georgia, serif"; c.textAlign = "center"; c.fillText("abc".slice(0, Math.max(1, Math.floor((t - 17.6) * 2) % 4)), W / 2, 70); }} />
    <Person p={[-1.4, 0, 2.6]} h={3.6} look={steveY} f={f} pose={{ mood: beauty > 0.5 ? "grin" : "smile", armR: [0.1 + 0.05 * Math.sin(t * 6), 0.45], armRK: 1, lookX: -0.2 }} />
    <Person p={[4.4, 0, 0.4]} h={3.9} look={teacher} f={f + 4} pose={{ mood: "smile", arms: "point", armK: 1, flip: true, lookX: -0.6 }} />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,245,210,.8)" />
  </>);
};

/* ============ S6 23.7 – 25.9  "None of it has any use in his life." ============ */
const K6: Key[] = [
  { t: 23.5, pos: [0, 3.0, 8.0], look: [0, 2.8, 0], fov: 52 },
  { t: 26.1, pos: [0.4, 3.0, 7.2], look: [0.2, 2.6, 0], fov: 48 },
];
export const S6 = ({ t, f }: Ctx) => {
  const drop = seg(t, 24.8, 25.5, Easing.in(Easing.quad)), q = seg(t, 24.53, 24.8, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#e8e0d8" />
    <Floor kind="plank" a="#6a5a4a" b="#5e4e40" unit={1.8} w={30} d={24} />
    <WallDoor z={-4} W={30} kind="plain" a="#8a8070" b="#8a8070" base="#4a4030" />
    <Box p={[2.2, 1.0, 0]} s={[2.4, 2.0, 1.6]} color="#7a6a50" line={3} /><Box p={[2.2, 1.6, 0.82]} s={[1.8, 0.5, 0.05]} color="#5a4a36" line={2} /><Sign p={[2.2, 2.4, 0.9]} w={2.0} h={0.5} text="SOMEDAY" size={30} bg="#f4ecd8" fg="#5a4228" face={false} />
    <CanvasPlane p={[lerp(-0.4, 2.2, drop), lerp(3.2, 1.6, drop), 0.9]} rot={[drop * -1.2, 0, Math.sin(t * 4) * 0.2 * (1 - drop)]} s={[1.3, 1.0]} px={[130, 100]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(2, 2, W - 4, H - 4); c.fillStyle = INK; c.font = "italic 700 46px Georgia, serif"; c.textAlign = "center"; c.fillText("Aa", W / 2, 66); }} />
    <Person p={[-1.2, 0, 1.0]} h={3.8} look={steveY} f={f} pose={{ mood: "deadpan", arms: t > 24.2 ? "shrug" : undefined, armK: seg(t, 24.2, 24.5) * (1 - seg(t, 25.4, 25.7)), armR: t < 24.2 ? [0.3, 0.75] : undefined, armRK: t < 24.2 ? 1 : 0, lookX: 0.4 }} />
    <Sign p={[-1.2, 5.6, 1.0]} w={2.6} h={1.0} text="USELESS?" k={q} size={50} bg="#fff" fg="#c0182e" />
    <Lamp p={[-5, 0, -2]} h={3.0} color="#ffe0a0" /><Dust t={t} area={[6, 5, 4]} color="rgba(240,230,210,.8)" />
  </>);
};

/* ============ S7 25.9 – 31.4  "Ten years later he's designing the first Macintosh, and that useless class comes rushing back." ============ */
const K7: Key[] = [
  { t: 25.7, pos: [0, 4.0, 13.0], look: [0, 3.4, -1], fov: 58 },
  { t: 28.0, pos: [-1.0, 3.6, 10.5], look: [0.2, 2.8, 0], fov: 54 },
  { t: 31.6, pos: [0.6, 3.6, 8.8], look: [0.4, 3.2, 0], fov: 50 },
];
const GLY = ["A", "&", "Q", "g", "ff", "R", "a", "?"];
export const S7 = ({ t, f }: Ctx) => {
  const yr = Math.round(lerp(1972, 1982, seg(t, 26.0, 26.9, Easing.linear))), mac = seg(t, 27.99, 28.3, Easing.out(Easing.back(2.6))), rush = clamp((t - 29.76) / 1.4);
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#eef0ff" />
    <Floor kind="tile" a="#d8dce8" b="#c8ccd8" unit={1.6} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#b8c4d8" b="#b8c4d8" base="#7a88a8" /><SideWall x={-9} kind="plain" a="#a8b4c8" b="#a8b4c8" /><SideWall x={9} kind="plain" a="#a8b4c8" b="#a8b4c8" />
    <CanvasPlane p={[-5.2, 5.4, -4.9]} s={[2.6, 2.8]} px={[260, 280]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#c0182e"; c.fillRect(0, 0, W, 64); c.fillStyle = "#fff"; c.font = "900 36px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("+10 YEARS", W / 2, 34); c.fillStyle = INK; c.font = "900 90px Inter, Arial"; c.fillText(String(yr), W / 2, 170); }} />
    <Frame p={[5.2, 5.2, -4.9]} s={[2.4, 1.6]} art={2} /><Shelf p={[7.0, 0, -4.4]} w={2.6} rows={4} seed={6} wood="#5a6a8a" />
    <Box p={[0, 1.3, 0]} s={[5.6, 0.2, 2.4]} color="#f4f4f4" line={3} />{[-2.5, 2.5].map((x) => <Box key={x} p={[x, 0.65, 0]} s={[0.2, 1.3, 2.0]} color="#8a98a8" line={2} />)}
    <Compact p={[0.2, 1.4, -0.4]} s={0.9} draw={(c, W, H) => { c.fillStyle = "#e8eef8"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.fillRect(0, 0, W, 18); c.fillStyle = "#1a1a22"; c.font = "italic 700 64px Georgia, serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(rush > 0.6 ? "Hello" : "hello", W / 2, H / 2 + 10); }} />
    <Sign p={[0.2, 5.6, 0.4]} w={4.2} h={1.0} text="FIRST MACINTOSH" k={mac} size={44} />
    {rush > 0 && rush < 1 ? GLY.map((g, i) => { const a = i * 0.8, r = (1 - rush) * 6 + 0.4; return <Sign key={i} p={[-1.4 + Math.cos(a + rush * 4) * r, 4.2 + Math.sin(a + rush * 4) * r * 0.5, 1.6]} w={0.9} h={0.9} text={g} size={60} bg="#fffaf0" fg="#14141c" font="italic 700 {s}px Georgia, serif" />; }) : null}
    {rush > 0.85 ? <Glow p={[-1.4, 3.6, 1.8]} r={2.4} color="rgba(255,220,130,1)" o={0.6 * (1 - (rush - 0.85) * 4)} /> : null}
    <Person p={[-1.6, 0, 1.8]} h={3.9} look={steveO} f={f} pose={{ mood: rush > 0.5 ? "grin" : "deadpan", armR: [0.3, 0.42], armRK: 1, lookX: 0.4, squash: rush > 0.9 ? -0.05 : 0 }} />
    {[0, 1].map((i) => <Person key={i} p={[2.6 + i * 1.7, 0, 1.2 - i * 0.6]} h={3.6} look={eng(i)} f={f + i * 5} pose={{ mood: "smile", lookX: -0.4, flip: true }} />)}
    <Dust t={t} area={[8, 6, 4]} color="rgba(230,240,255,.8)" />
  </>);
};

/* ============ S8 31.4 – 35.3  "He builds in multiple typefaces and proportionally spaced fonts." ============ */
const K8: Key[] = [
  { t: 31.2, pos: [0, 3.8, 12.5], look: [0, 3.6, 0], fov: 56 },
  { t: 35.5, pos: [0, 3.8, 11.0], look: [0, 3.8, 0], fov: 54 },
];
const FACES = ["Serif", "Sans", "Script", "Mono", "Display", "Outline"];
export const S8 = ({ t, f }: Ctx) => {
  const menu = Math.floor(clamp((t - 32.1) / 1.2) * 6), prop = seg(t, 33.55, 34.6, Easing.inOut(Easing.cubic));
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#eef0ff" />
    <Floor kind="tile" a="#2a2e44" b="#24283c" unit={1.6} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#1a1e34" b="#1a1e34" base="#0c0e1c" />
    <CanvasPlane p={[0, 4.0, -1]} s={[7.4, 5.6]} px={[740, 560]} frame="#e8dcc0" draw={(c, W, H) => {
      c.fillStyle = "#f4f6fb"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.fillRect(0, 0, W, 34); c.fillStyle = "#fff"; c.font = "800 22px Inter, Arial"; c.fillText("Font", 18, 24);
      c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 3; c.fillRect(10, 40, 300, 30 + menu * 46); c.strokeRect(10, 40, 300, 30 + menu * 46);
      const fonts = ["700 36px Georgia, serif", "800 36px Inter, Arial", "italic 700 36px Georgia, serif", "700 32px 'Courier New', monospace", "900 40px Inter, Arial", "700 36px Georgia, serif"];
      for (let i = 0; i < menu; i++) { c.fillStyle = i === menu - 1 ? "#1f4ad8" : INK; c.font = fonts[i]; c.fillText(FACES[i], 30, 88 + i * 46); }
      c.font = "800 22px Inter, Arial"; c.fillStyle = "#6a6a7a"; c.fillText("MONOSPACED", 360, 70); c.fillText(prop > 0.5 ? "PROPORTIONAL" : "", 360, 300);
      const word = "Mill"; const mono = 70, widths = [90, 28, 26, 26];
      let x = 360; for (let i = 0; i < 4; i++) { const w = lerp(mono, widths[i], prop); c.strokeStyle = "rgba(31,74,216,.5)"; c.strokeRect(x, 100, w, 110); c.fillStyle = INK; c.font = "700 90px Georgia, serif"; c.textAlign = "center"; c.fillText(word[i], x + w / 2, 190); c.textAlign = "left"; x += w; }
      if (prop > 0.5) { c.fillStyle = INK; c.font = "700 70px Georgia, serif"; c.fillText("Mill", 360, 400); }
    }} />
    <Box p={[0, 1.0, -1.1]} s={[8.4, 0.3, 0.6]} color="#e8dcc0" line={3} />
    <Person p={[-4.6, 0, 1.6]} h={3.9} look={steveO} f={f} pose={{ mood: "grin", arms: "point", armK: 1, lookX: 0.6 }} />
    <Glow p={[0, 4, 0.5]} r={6} color="rgba(220,235,255,1)" o={0.25} /><Dust t={t} area={[6, 5, 4]} color="rgba(220,230,255,.8)" />
  </>);
};

/* ============ S9 35.3 – 39.7  "Years later, Jobs said that without that class, the Mac would never have had them," ============ */
const K9: Key[] = [
  { t: 35.1, pos: [-2.0, 3.8, 12.5], look: [0, 3.4, -1], fov: 58 },
  { t: 37.3, pos: [0.0, 3.6, 10.5], look: [0, 3.2, -1], fov: 54 },
  { t: 39.9, pos: [3.4, 3.4, 9.0], look: [3.4, 2.8, 0], fov: 52 },
];
export const S9 = ({ t, f }: Ctx) => {
  const cross = seg(t, 37.22, 37.6), plain = seg(t, 38.52, 39.2);
  return (<>
    <Cam t={t} keys={K9} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#5a4630" b="#4e3c28" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#6a1a2a" b="#6a1a2a" base="#3a0a14" /><Curtain p={[-7, 4.6, -5.6]} s={[3, 9.2]} color="#8a1a2e" /><Curtain p={[7, 4.6, -5.6]} s={[3, 9.2]} color="#8a1a2e" />
    <Banner p={[0, 7.2, -5.4]} s={[5.6, 1.4]} text="COMMENCEMENT" size={52} bg="#1f3a6a" fg="#fff" />
    <Lectern p={[-1.4, 0, -1.4]} h={1.6} color="#3a2a1a" label="" /><Person p={[-1.4, 0, -2.4]} h={3.8} look={steveO} f={f} pose={{ mood: "smile", armR: [0.3, 0.55 + 0.06 * Math.sin(t * 4)], armRK: 1, lookX: 0.3 }} />
    <MicStand p={[-1.0, 1.6, -1.0]} h={0.9} />
    <CanvasPlane p={[-3.8, 4.8, -1.0]} s={[2.4, 1.6]} px={[240, 160]} face draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 5; c.strokeRect(3, 3, W - 6, H - 6); c.fillStyle = INK; c.font = "italic 700 44px Georgia, serif"; c.textAlign = "center"; c.fillText("Calligraphy", W / 2, 70); c.font = "800 20px Inter, Arial"; c.fillText("CLASS", W / 2, 110); if (cross > 0) { c.strokeStyle = "#e5233a"; c.lineWidth = 14; c.beginPath(); c.moveTo(20, 20); c.lineTo(20 + 200 * cross, 20 + 120 * cross); c.moveTo(220, 20); c.lineTo(220 - 200 * cross, 20 + 120 * cross); c.stroke(); } }} />
    <Compact p={[3.4, 0, 0.6]} s={1.1} draw={(c, W, H) => { c.fillStyle = "#e8eef8"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.textAlign = "center"; c.textBaseline = "middle"; if (plain < 0.5) { c.font = "italic 700 58px Georgia, serif"; c.fillText("Hello", W / 2, 80); c.font = "800 28px Inter, Arial"; c.fillText("Fonts", W / 2, 150); } else { c.font = "700 34px 'Courier New', monospace"; c.fillText("HELLO", W / 2, 80); c.fillText("FONTS", W / 2, 150); } }} glow={0.2} />
    <Sign p={[3.4, 5.6, 1.2]} w={3.6} h={1.0} text="NO FONTS?" k={plain} size={48} bg="#fff" fg="#c0182e" />
    {Array.from({ length: 10 }, (_, i) => <Box key={i} p={[-5 + (i % 5) * 2.2, 0.4, 2.2 + Math.floor(i / 5) * 1.0]} s={[1.0, 0.8, 0.8]} color="#14141c" line={2} />)}
    <CrowdField n={20} t={t} rate={2} at={(i) => [-6 + (i % 10) * 1.3, 0, 2.8 + Math.floor(i / 10) * 0.9] as V3} size={0.6} />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S10 39.7 – 43.3  "and since Windows copied the Mac, maybe no personal computer would." ============ */
const K10: Key[] = [
  { t: 39.5, pos: [-2.0, 4.0, 12.0], look: [-1.0, 2.8, -1], fov: 58 },
  { t: 41.4, pos: [0.0, 5.0, 14.0], look: [0, 2.6, -2], fov: 58 },
  { t: 43.5, pos: [0.0, 7.0, 16.0], look: [0, 2.2, -4], fov: 60 },
];
export const S10 = ({ t, f }: Ctx) => {
  const arrow = seg(t, 40.5, 41.0), drain = seg(t, 41.82, 42.9, Easing.linear);
  const scr = (fancy: boolean, label: string) => (c: CanvasRenderingContext2D, W: number, H: number) => { c.fillStyle = fancy ? "#e8eef8" : "#d8d8d8"; c.fillRect(0, 0, W, H); c.fillStyle = INK; c.textAlign = "center"; c.textBaseline = "middle"; c.font = fancy ? "italic 700 52px Georgia, serif" : "700 34px 'Courier New', monospace"; c.fillText(fancy ? "Aa Bb" : "AA BB", W / 2, 90); c.font = "800 24px Inter, Arial"; c.fillText(label, W / 2, 170); };
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#eef0ff" />
    <Floor kind="tile" a="#2a2e44" b="#24283c" unit={1.6} w={40} d={30} />
    <WallDoor z={-10} W={40} kind="plain" a="#1a1e34" b="#1a1e34" base="#0c0e1c" />
    <Compact p={[-3.2, 0, 0]} s={1.0} draw={scr(t < 41.82, "MAC")} />
    <Compact p={[3.2, 0, 0]} s={1.0} color="#c8ccd8" draw={scr(arrow > 0.9 && t < 41.9, "WINDOWS")} />
    <CanvasPlane p={[0, 3.0, 0.8]} s={[2.6 * arrow + 0.001, 1.0]} px={[260, 100]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#ffc23a"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.moveTo(10, 35); c.lineTo(180, 35); c.lineTo(180, 10); c.lineTo(250, 50); c.lineTo(180, 90); c.lineTo(180, 65); c.lineTo(10, 65); c.closePath(); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 24px Inter, Arial"; c.fillText("COPIED", 40, 58); }} />
    {Array.from({ length: 12 }, (_, i) => <Compact key={i} p={[-7.5 + (i % 6) * 3, 0, -4.5 - Math.floor(i / 6) * 3.2]} s={0.7} color={["#e8dcc0", "#c8ccd8", "#d8d0b8"][i % 3]} glow={0.15} draw={scr(drain < (i + 1) / 13, "PC")} />)}
    <Sign p={[0, 6.4, 0]} w={4.6} h={1.1} text="NO PERSONAL COMPUTER?" k={seg(t, 42.09, 42.4, Easing.out(Easing.back(2.6)))} size={34} bg="#fff" fg="#c0182e" />
    <Dust t={t} area={[10, 6, 6]} color="rgba(220,230,255,.8)" />
  </>);
};

/* ============ S11 43.3 – 46.1  "You can't connect the dots looking forward, he said." ============ */
const K11: Key[] = [
  { t: 43.1, pos: [0, 3.6, 11.0], look: [0, 3.4, -1], fov: 58 },
  { t: 46.3, pos: [0, 3.6, 9.4], look: [0, 3.6, -1], fov: 54 },
];
export const S11 = ({ t, f }: Ctx) => {
  const conn = seg(t, 45.2, 46.0, Easing.inOut(Easing.cubic)), fog = seg(t, 44.68, 45.1);
  const D: [number, number, string][] = [[90, 300, "DROP OUT"], [270, 170, "CALLIGRAPHY"], [470, 260, "BROKE"], [650, 120, "MAC"]];
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#2a2236" b="#241c30" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#1a1430" b="#1a1430" base="#0c0818" />
    <CanvasPlane p={[0, 4.4, -4.9]} s={[8.0, 4.6]} px={[800, 460]} frame="#ffc23a" draw={(c, W, H) => { c.fillStyle = "#14102a"; c.fillRect(0, 0, W, H); c.strokeStyle = "#ffd36a"; c.lineWidth = 8; c.setLineDash([16, 14]); c.beginPath(); for (let i = 0; i < D.length; i++) { const k = clamp(conn * (D.length - 1) - i + 1); if (i === 0) c.moveTo(D[0][0], D[0][1]); else if (k > 0) { const [x0, y0] = D[i - 1], [x1, y1] = D[i]; c.lineTo(x0 + (x1 - x0) * k, y0 + (y1 - y0) * k); } } c.stroke(); c.setLineDash([]); D.forEach(([x, y, l]) => { c.fillStyle = "#ffd36a"; c.beginPath(); c.arc(x, y, 22, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 5; c.stroke(); c.fillStyle = "#fff"; c.font = "800 22px Inter, Arial"; c.textAlign = "center"; c.fillText(l, x, y + 52); }); if (fog > 0 && conn < 0.1) { const g = c.createLinearGradient(400, 0, W, 0); g.addColorStop(0, "rgba(200,200,220,0)"); g.addColorStop(1, `rgba(200,200,220,${0.85 * fog})`); c.fillStyle = g; c.fillRect(0, 0, W, H); } }} />
    <Person p={[0, 0, 1.4]} h={3.9} look={steveO} f={f} pose={{ mood: conn > 0.3 ? "grin" : "worry", lookX: t < 45.2 ? 0.8 : -0.8, armR: t < 45.2 ? [0.12, 0.62] : undefined, armRK: t < 45.2 ? fog : 0, flip: t > 45.2 }} />
    <Sign p={[0, 7.6, -3]} w={6.0} h={1.0} text={t < 45.2 ? "LOOKING FORWARD →" : "← LOOKING BACK"} size={46} face={false} />
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,220,150,.8)" />
  </>);
};

/* ============ S12 46.1 – 52.0  "So here's the question: what small choice did you make this year that you won't understand for ten more?" ============ */
const K12: Key[] = [
  { t: 45.9, pos: [0, 3.0, 9.0], look: [0, 2.4, 0], fov: 56 },
  { t: 49.0, pos: [0, 4.4, 11.0], look: [0, 2.6, -6], fov: 58 },
  { t: 52.2, pos: [0, 6.0, 12.0], look: [0, 3.0, -14], fov: 60 },
];
export const S12 = ({ t, f }: Ctx) => {
  const path = clamp((t - 49.3) / 2.2), q = seg(t, 50.8, 51.3, Easing.out(Easing.back(2.2))), pick = seg(t, 47.95, 48.4);
  return (<>
    <Cam t={t} keys={K12} />
    <Lights warm="#ffe0c0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#2a1a5a" bottom="#ffb070" glowAt={[0.8, "rgba(255,200,120,1)"]} stars={0.4} t={t} />
    <Surface p={[0, -0.05, -14]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a5a3a" b="#3a5a3a" />
    {Array.from({ length: 16 }, (_, i) => { const k = clamp(path * 16 - i); return k > 0 ? <Ball key={i} p={[Math.sin(i * 0.5) * 1.2, 0.15, -1 - i * 1.3]} r={0.18 * k} color="#ffd36a" ink={0.02} /> : null; })}
    <Glow p={[Math.sin(8) * 1.2, 2, -22]} r={8} color="rgba(255,230,160,1)" o={0.4 * path} />
    <Sign p={[Math.sin(8) * 1.2, 5.6, -22]} w={4.4 * q + 0.001} h={4.4 * q + 0.001} text="?" size={360} fg="#ffd36a" bg="#14081e" />
    <Sign p={[-3.6, 4.6, -6]} w={3.0} h={1.0} text="THIS YEAR" size={46} k={seg(t, 49.01, 49.3, Easing.out(Easing.back(2.6)))} />
    <Sign p={[3.8, 7.8, -16]} w={3.6} h={1.1} text="+10 YEARS" size={56} k={seg(t, 50.97, 51.3, Easing.out(Easing.back(2.6)))} bg="#c0182e" fg="#fff" />
    {[-0.9, 0.9].map((x, i) => <Ball key={i} p={[x, 0.2 + (i === 0 ? 0.3 * pick : 0), 0.8]} r={0.22} color={i === 0 ? "#ffd36a" : "#8a8a96"} ink={0.03} />)}
    <Person p={[0, 0, 1.6]} h={3.8} look={you} f={f} pose={{ mood: t > 50 ? "smile" : "worry", armR: [0.2, lerp(0.3, 0.55, pick)], armRK: pick * (1 - seg(t, 49.2, 49.5)), lookX: 0 }} />
    <Dust t={t} area={[8, 6, 8]} color="rgba(255,230,170,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12 };
