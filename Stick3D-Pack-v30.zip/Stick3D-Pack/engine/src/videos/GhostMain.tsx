import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Ghost";
import { Captions } from "../Main";
export const GCUTS = [0, 2.55, 6.2, 10.6, 15.3, 19.3, 24.4, 28.9, 31.5, 36.3, 42.9, 45.0, 47.8, 50.7, 54.2];
const BG = ["#5aa8ff", "#5aa8ff", "#5aa8ff", "#6aa8ff", "#7a5a3a", "#5aa8ff", "#7a8a4a", "#0a1030", "#6aa0e0", "#7a98c0", "#6a88b0", "#2a2a34", "#ff9a50", "#0e1430"];
const TR: Trans[] = ["ghost", "ghost", "zoom", "ghost", "whip", "ghost", "ghost", "flash", "zoom", "ghost", "ghost", "flash", "ghost", "zoom"];
export const GhostMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 14 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={GCUTS[i]} end={GCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
