import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES, tintFor } from "./Kanye";
import { Captions } from "../Main";
export const KCUTS = [0, 4.6, 10.4, 14.1, 19.1, 23.7, 26.6, 30.5, 34.5, 40.7, 44.6, 49.9];
const BG = ["#1b1f3a", "#161a3a", "#4a2272", "#0f3f4a", "#04061a", "#04061a", "#0e3a4a", "#9ec4d2", "#5a1a24", "#2a1a10", "#1c1030"];
const TR: Trans[] = ["ghost", "ghost", "whip", "zoom", "ghost", "flash", "flash", "ghost", "whip", "ghost", "zoom"];
export const KanyeMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 11 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={KCUTS[i]} end={KCUTS[i + 1]} bg={BG[i]} trans={TR[i]} tint={tintFor(i)}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
