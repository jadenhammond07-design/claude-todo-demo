import React from "react";
import { AbsoluteFill } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { Box, Cyl, Ball, Surface } from "../style/toon";
import { Lights } from "../style/kit";
import { Glow } from "../style/props";
import { Cam } from "../style/extra";
import { Car } from "../style/studio";
import { Sky } from "../style/medieval";
import { Palm } from "../style/studio";
export const CarPfp: React.FC = () => (
  <AbsoluteFill style={{ background: "#ff7a3a", filter: "saturate(1.25) contrast(1.06)" }}>
    <ThreeCanvas width={1024} height={1024} camera={{ fov: 40, position: [5, 2.2, 7], near: 0.1, far: 200 }} gl={{ antialias: true }}>
      <color attach="background" args={["#ff7a3a"]} />
      <Cam t={0} keys={[{ t: 0, pos: [5.0, 1.3, 6.4], look: [0, 0.35, 0], fov: 36 }]} />
      <Lights warm="#ffd2a0" />
      <Sky p={[0, 18, -40]} s={[200, 90]} top="#6a2a9a" bottom="#ffb060" glowAt={[0.9, "rgba(255,230,150,1)"]} />
      <Ball p={[-9, 7, -38]} r={5.5} color="#fff0b0" ink={0} /><Glow p={[-9, 7, -37]} r={22} color="rgba(255,200,110,1)" o={0.6} />
      <Surface p={[0, 0, -4]} s={[80, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a2a5a" b="#3a2a5a" />
      {Array.from({ length: 12 }, (_, i) => <Box key={i} p={[-14 + i * 3.2, 0.02, -1.6]} s={[1.6, 0.03, 0.2]} color="#ffd36a" line={0} />)}
      <Palm p={[-13, 0, -7]} h={6} /><Palm p={[10, 0, -9]} h={7} />
      <Car p={[0, 0, 0]} color="#e5233a" rotZ={0} />
      <Glow p={[2.2, 0.8, 0.6]} r={2.4} color="rgba(255,240,180,1)" o={0.5} />
    </ThreeCanvas>
  </AbsoluteFill>
);
