import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Oobe";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const OCUTS = [0, 4.2, 10.37, 15.71, 19.62, 22.9, 27.01, 33.49, 39.32, 45.0];
const BG = ["#121c34", "#2a3a5a", "#2a3a5a", "#2a3a5a", "#2a3a5a", "#2a3a5a", "#0e1a30", "#2a3a5a", "#121c34"];
const TR: Trans[] = ["ghost", "zoom", "whip", "ghost", "dip", "flash", "zoom", "ghost", "dip"];
export const OobeMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={OCUTS[i]} end={OCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"SCIENTISTS PULLED PEOPLE OUT OF THEIR BODIES"} until={3.0} />
    <EndQuestion text={"Would YOU try the goggle experiment? Yes or no?"} from={42.0} end={44.96} />
  </AbsoluteFill>
);
