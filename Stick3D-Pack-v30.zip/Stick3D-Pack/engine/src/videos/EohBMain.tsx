import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./EohB";
import { Captions } from "../Main";
export const BCUTS2 = [0, 3.9, 9.0, 15.2, 22.6, 30.4, 35.0, 41.5, 43.6, 46.8];
const BG = ["#1c2444", "#6a5a4a", "#1a2444", "#7a98c0", "#fffaf0", "#2a3a5a", "#0e1430", "#0e1430", "#2a1a5a"];
const TR: Trans[] = ["ghost", "whip", "zoom", "ghost", "flash", "ghost", "zoom", "flash", "ghost"];
export const EohBMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={BCUTS2[i]} end={BCUTS2[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
