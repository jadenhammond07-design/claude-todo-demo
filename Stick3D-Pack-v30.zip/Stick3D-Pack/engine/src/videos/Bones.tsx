// YOUR BONES ARE ALREADY CHANGING — 9 scenes. Tennis arm, astronaut bone loss, remodeling, Wolff's law.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Glow, Dust, Frame, Rug } from "../style/props";
import { Cam, Globe, Stars } from "../style/extra";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const tennis = mk("#8d5a3a", "#ffffff", "shirt", "bob", "#2a1a10", { shoe: "#2fd46a" });
const astro = mk("#e8b88c", "#e8ecf4", "blazer", "short", "#3a2410", { shirt: "#c8d0e0", badge: "#2f8cff" });
const surgeon = mk("#f3d3b2", "#2a2a36", "blazer", "grey", "#c8c8c8", { shirt: "#fff" });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
/** cartoon bone along x; th = thickness factor */
const Bone: React.FC<{ p: V3; len: number; th?: number; rot?: V3; color?: string }> = ({ p, len, th = 1, rot = [0, 0, 0], color = "#f4ecd8" }) => (
  <group position={p} rotation={rot}>
    <Cyl p={[0, 0, 0]} rt={0.18 * th} h={len} color={color} line={3} rot={[0, 0, Math.PI / 2]} />
    {[-1, 1].map((s) => <React.Fragment key={s}><Ball p={[s * len / 2, 0.17 * th, 0]} r={0.24 * th} color={color} ink={0.05} /><Ball p={[s * len / 2, -0.17 * th, 0]} r={0.24 * th} color={color} ink={0.05} /></React.Fragment>)}
  </group>
);
/** an X-ray panel with two arm bones */
const Xray: React.FC<{ p: V3; s: [number, number]; thick: number; label?: boolean }> = ({ p, s, thick, label = true }) => (
  <CanvasPlane p={p} s={s} px={[400, 300]} draw={(c, W, H) => { c.fillStyle = "#0c1a30"; c.fillRect(0, 0, W, H); c.strokeStyle = "#5ab0ff"; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6);
    const bone = (x: number, w: number) => { c.fillStyle = "rgba(230,240,255,.95)"; c.beginPath(); c.roundRect(x - w / 2, 50, w, 190, w / 2); c.fill(); c.beginPath(); c.arc(x - w * 0.45, 50, w * 0.6, 0, 7); c.arc(x + w * 0.45, 50, w * 0.6, 0, 7); c.fill(); c.beginPath(); c.arc(x - w * 0.45, 240, w * 0.6, 0, 7); c.arc(x + w * 0.45, 240, w * 0.6, 0, 7); c.fill(); c.fillStyle = "rgba(90,140,200,.6)"; c.fillRect(x - w * 0.18, 70, w * 0.36, 150); };
    bone(120, 34); bone(290, 34 + 26 * thick);
    if (label) { c.fillStyle = "#9fd4ff"; c.font = "900 22px Inter, Arial"; c.textAlign = "center"; c.fillText("OTHER ARM", 120, 285); c.fillStyle = "#ffe14a"; c.fillText("RACKET ARM", 290, 285); } }} />
);
const Racket: React.FC<{ swing: number }> = ({ swing }) => (
  <group rotation={[0, 0, swing]}>
    <Cyl p={[0, 0.5, 0]} rt={0.06} h={1.0} color="#14141c" line={2} />
    <mesh position={[0, 1.45, 0]}><torusGeometry args={[0.45, 0.06, 8, 24]} /><meshToonMaterial color="#e5233a" /></mesh>
    <mesh position={[0, 1.45, 0]}><circleGeometry args={[0.42, 20]} /><meshBasicMaterial color="#ffffff" transparent opacity={0.35} /></mesh>
  </group>
);

/* ============ S1 0 – 2.6  hook: your skeleton morphs ============ */
export const S1 = ({ t, f }: Ctx) => {
  const m = 1 + 0.5 * Math.sin(t * 3);
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 4.4, 11], look: [0, 4.0, 0], fov: 56 }, { t: 2.8, pos: [0, 4.2, 10], look: [0, 4.0, 0], fov: 54 }])} />
    <Lights warm="#d8e8ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#1a2a4a" b="#162440" unit={1.6} />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#0c1a30" line={0} />
    <Person p={[-1.4, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: "worry", lookX: 0.6 }} />
    <Xray p={[1.5, 3.4, 0.4]} s={[3.0, 2.3]} thick={0.5 + 0.5 * Math.sin(t * 3)} label={false} />
    <Bone p={[1.5, 6.0, 0.6]} len={2.2} th={m} rot={[0, 0, Math.sin(t * 2) * 0.3]} />
    <Glow p={[1.5, 4.4, 0.8]} r={3} color="rgba(120,190,255,1)" o={0.4} />
  </>);
};

/* ============ S2 2.6 – 5.63  they already change, not on command ============ */
export const S2 = ({ t, f }: Ctx) => {
  const cmd = seg(t, 3.45, 3.8, back), nope = seg(t, 4.62, 4.95, back);
  return (<>
    <Cam t={t} keys={low([{ t: 2.4, pos: [0, 4.2, 11], look: [0, 3.8, 0], fov: 56 }, { t: 5.8, pos: [0, 4.0, 10], look: [0, 3.8, 0], fov: 54 }])} />
    <Lights warm="#fff0d8" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#7a5a3a" b="#6a4c30" unit={1.8} />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#c8865a" line={3} />
    <Person p={[0, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: nope > 0.5 ? "worry" : "angry", arms: "point", armK: cmd, lookX: 0.3, nerv: 0.2 * cmd }} />
    <Sign p={[-0.6, 6.4, 0.8]} w={2.6} h={0.85} text="CHANGE!" k={cmd * (1 - nope)} size={50} bg="#fff" fg="#e5233a" />
    <Sign p={[0, 6.4, 1.0]} w={3.8} h={0.85} text="NOT ON COMMAND" k={nope} size={40} bg="#14141c" fg="#ffe14a" />
    <Sign p={[2.0, 4.8, 1.0]} w={1.6} h={0.75} text="…" k={seg(t, 4.0, 4.3, back) * (1 - nope)} size={60} bg="#fff" fg="#14141c" />
  </>);
};

/* ============ S3 5.63 – 12.84  tennis player: racket arm has thicker bone ============ */
export const S3 = ({ t, f }: Ctx) => {
  const sc = seg(t, 7.37, 7.8, back), th = seg(t, 10.18, 11.6, ease), swing = -0.8 + 1.6 * Math.max(0, Math.sin(t * 4));
  return (<>
    <Cam t={t} keys={low([{ t: 5.4, pos: [0, 4.4, 12.5], look: [0, 4.0, 0], fov: 56 }, { t: 13.0, pos: [0, 4.4, 11.5], look: [0, 4.0, 0], fov: 55 }])} />
    <Lights warm="#fff4e0" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2f8a5a" b="#2f8a5a" />
    <Box p={[0, 0.02, 0.6]} s={[9, 0.02, 0.1]} color="#ffffff" line={0} />
    <Box p={[0, 6, -5]} s={[30, 14, 0.3]} color="#3a6ab0" line={3} />
    <Person p={[-1.6, 0, 1.0]} h={3.4} look={tennis} f={f} pose={{ mood: "grin", armR: [0.45, 0.62], armRK: 1, lookX: 0.4 }} />
    <group position={[-0.95, 2.1, 1.2]}><Racket swing={swing} /></group>
    <Ball p={[0.4 + Math.sin(t * 4) * 0.8, 2.8 + Math.abs(Math.cos(t * 4)) * 0.6, 1.2]} r={0.14} color="#d8f03a" ink={0.03} />
    <group scale={[sc + 0.001, sc + 0.001, sc + 0.001]} position={[1.5, 5.6, 0.2]}><Xray p={[0, 0, 0]} s={[3.2, 2.4]} thick={th} /></group>
    <Sign p={[1.5, 3.6, 0.6]} w={3.4} h={0.75} text="THICKER + DENSER" k={seg(t, 10.68, 11.0, back)} size={32} bg="#ffe14a" fg="#14141c" />
  </>);
};

/* ============ S4 12.84 – 14.93  years of impact told it to build more ============ */
export const S4 = ({ t, f }: Ctx) => {
  const n = Math.round(lerp(1, 100000, seg(t, 12.9, 14.0, Easing.in(Easing.quad)))), grow = seg(t, 14.11, 14.8, back);
  return (<>
    <Cam t={t} keys={[{ t: 12.7, pos: [0, 4.4, 10], look: [0, 4.4, 0], fov: 54 }, { t: 15.0, pos: [0, 4.4, 9], look: [0, 4.4, 0], fov: 52 }]} />
    <Lights warm="#fff4e0" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0c1a30" b="#0c1a30" />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#0c1a30" line={0} />
    <Bone p={[0, 4.4, 0]} len={3.2} th={1 + 0.7 * grow} />
    <Glow p={[0, 4.4, 0.5]} r={3} color="rgba(255,230,140,1)" o={0.5 * grow + 0.15 * Math.abs(Math.sin(t * 12))} />
    {Array.from({ length: 4 }, (_, i) => { const u = (t * 2 + i / 4) % 1; return <Ball key={i} p={[lerp(3.4, 0.9, u), 4.4 + Math.sin(i * 2) * 0.6, 0.3]} r={0.14} color="#d8f03a" ink={0.03} />; })}
    <Sign p={[0, 7.6, 0.4]} w={3.4} h={0.85} text={`${n.toLocaleString("en-US")} HITS`} k={1 - grow} size={42} bg="#14141c" fg="#d8f03a" />
    <Sign p={[0, 7.6, 0.6]} w={3.0} h={0.85} text="BUILD MORE" k={grow} size={44} bg="#2fd46a" fg="#14141c" />
  </>);
};

/* ============ S5 14.93 – 22.16  astronaut: ~1% density lost per month ============ */
export const S5 = ({ t, f }: Ctx) => {
  const mg = seg(t, 16.39, 16.7, back), loss = seg(t, 19.62, 21.6, ease), pc = seg(t, 20.32, 20.6, back);
  return (<>
    <Cam t={t} keys={[{ t: 14.7, pos: [0, 4.6, 12], look: [0, 4.6, 0], fov: 56 }, { t: 22.3, pos: [0, 4.6, 11], look: [0, 4.6, 0], fov: 55 }]} />
    <Lights warm="#e0e8ff" />
    <Stars p={[0, 10, -30]} s={[110, 70]} t={t} top="#05061a" bottom="#1a2050" n={160} />
    <Globe p={[3.2, 0.6, -6]} r={3.0} rotY={t * 0.2} />
    <group position={[-0.8, 3.2 + Math.sin(t * 1.2) * 0.3, 0.6]} rotation={[0, 0, Math.sin(t * 0.8) * 0.25]}>
      <Person p={[0, 0, 0]} h={3.2} look={astro} f={f} pose={{ mood: "smile", arms: "up", armK: 0.4, air: 1 }} shadow={false} />
      <mesh position={[0.05, 2.4, 0.1]}><sphereGeometry args={[0.9, 24, 16]} /><meshBasicMaterial color="#bfe8ff" transparent opacity={0.3} depthWrite={false} /></mesh>
    </group>
    <Sign p={[-0.6, 8.6, 0]} w={3.6} h={0.85} text="MICROGRAVITY" k={mg * (1 - pc)} size={42} bg="#14141c" fg="#9fd4ff" />
    {/* density bar */}
    <CanvasPlane p={[2.0, 5.6, 1.0]} s={[1.6, 3.0]} px={[160, 300]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(3, 3, W - 6, H - 6, 14); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 20px Inter, Arial"; c.textAlign = "center"; c.fillText("BONE", W / 2, 30); c.fillText("DENSITY", W / 2, 52); c.fillStyle = "#333"; c.fillRect(45, 70, 70, 210); const v = 1 - 0.35 * loss; c.fillStyle = v > 0.8 ? "#2fd46a" : "#ffd23a"; c.fillRect(45, 280 - 210 * v, 70, 210 * v); }} />
    <Sign p={[-0.6, 8.6, 0.2]} w={2.8} h={0.8} text="-1% / MONTH" k={pc} size={40} bg="#e5233a" fg="#fff" />
  </>);
};

/* ============ S6 22.16 – 28.71  bone is living: dissolving and rebuilding ============ */
export const S6 = ({ t, f }: Ctx) => {
  const fix = seg(t, 22.76, 23.1, back), live = seg(t, 24.29, 24.6, back), dis = seg(t, 25.55, 26.2), reb = seg(t, 26.37, 27.4);
  return (<>
    <Cam t={t} keys={[{ t: 22.0, pos: [0, 4.6, 11], look: [0, 4.6, 0], fov: 56 }, { t: 28.8, pos: [0, 4.6, 10], look: [0, 4.6, 0], fov: 54 }]} />
    <Lights warm="#fff0e8" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2a1420" b="#2a1420" />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#2a1420" line={0} />
    {/* magnified bone tissue */}
    <CanvasPlane p={[0, 4.4, 0]} s={[4.2, 4.2]} px={[400, 400]} draw={(c, W, H) => { c.fillStyle = "#2a1420"; c.fillRect(0, 0, W, H); c.save(); c.beginPath(); c.arc(W / 2, H / 2, 190, 0, 7); c.clip(); c.fillStyle = "#f4ecd8"; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(200,170,130,.7)"; c.lineWidth = 7; for (let i = 0; i < 40; i++) { const x = ((i * 9973) % 400), y = ((i * 7919) % 400), a = i * 1.3; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * 60, y + Math.sin(a) * 60); c.stroke(); }
      for (let i = 0; i < 26; i++) { const x = ((i * 9973 + 37) % 340) + 30, y = ((i * 6007 + 91) % 340) + 30, r = 14 + (i % 4) * 6; const hole = i % 3 === 0 ? dis * (1 - reb) : i % 3 === 1 ? dis * (1 - reb * 0.4) * 0.6 : 0.25; c.fillStyle = `rgba(150,60,70,${0.25 + 0.6 * hole})`; c.beginPath(); c.arc(x, y, r * (0.6 + hole), 0, 7); c.fill(); }
      if (reb > 0) { c.fillStyle = `rgba(80,220,120,${0.6 * reb})`; for (let i = 0; i < 9; i++) { const x = ((i * 7919) % 360) + 20, y = ((i * 104729) % 360) + 20; c.beginPath(); c.arc(x, y, 14 * reb, 0, 7); c.fill(); } }
      c.restore(); c.strokeStyle = "#ffffff"; c.lineWidth = 10; c.beginPath(); c.arc(W / 2, H / 2, 190, 0, 7); c.stroke(); }} />
    <Sign p={[0, 8.0, 0.6]} w={3.6} h={0.85} text="NOT A FIXED FRAME" k={fix * (1 - live)} size={36} bg="#14141c" fg="#ffe14a" />
    <Sign p={[0, 8.0, 0.8]} w={3.2} h={0.85} text="IT'S ALIVE" k={live * (1 - dis)} size={46} bg="#ff7aa8" fg="#fff" />
    <Sign p={[-1.2, 7.4, 1.0]} w={2.2} h={0.7} text="DISSOLVE" k={seg(t, 25.55, 25.85, back)} size={30} bg="#a83a46" fg="#fff" />
    <Sign p={[1.2, 7.4, 1.0]} w={2.2} h={0.7} text="REBUILD" k={seg(t, 26.37, 26.65, back)} size={32} bg="#2fd46a" fg="#14141c" />
  </>);
};

/* ============ S7 28.71 – 34.8  Julius Wolff, Wolff's law ============ */
export const S7 = ({ t, f }: Ctx) => {
  const nm = seg(t, 29.98, 30.3, back), law = seg(t, 31.7, 32.0, Easing.out(Easing.back(3))), ad = seg(t, 33.01, 33.3, back);
  return (<>
    <Cam t={t} keys={low([{ t: 28.5, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 56 }, { t: 34.9, pos: [0, 4.4, 11], look: [0, 4.2, 0], fov: 55 }])} />
    <Lights warm="#ffe8c8" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plank" a="#5a3e26" b="#4e3420" unit={1.6} />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#6a4a3a" line={3} />
    <CanvasPlane p={[-1.6, 6.0, -3.7]} s={[2.4, 1.0]} px={[240, 100]} frame="#c8a060" draw={(c, W, H) => { c.fillStyle = "#f0e0c0"; c.fillRect(0, 0, W, H); c.fillStyle = "#5a3e26"; c.font = "900 42px Georgia, serif"; c.textAlign = "center"; c.fillText("1800s", W / 2, 66); }} />
    <Person p={[-1.4, 0, 1.0]} h={3.5} look={surgeon} f={f} pose={{ mood: "smile", lookX: 0.4, armR: [0.35, 0.7], armRK: law }} />
    <Bone p={[1.6, 3.4, 0.6]} len={2.4} th={1 + 0.4 * ad} rot={[0, 0, -0.3]} />
    {Array.from({ length: 3 }, (_, i) => <Box key={i} p={[0.9 + i * 0.7, 4.9 - ad * 0.2, 0.6]} s={[0.08, 0.7, 0.08]} color="#ff5a6a" line={0} />)}
    <Sign p={[-1.4, 4.6, 1.4]} w={2.8} h={0.75} text="JULIUS WOLFF" k={nm * (1 - law)} size={34} bg="#fff" fg="#14141c" />
    <Sign p={[0, 7.2, 0.6]} w={3.4} h={1.0} text="WOLFF'S LAW" k={law} size={42} bg="#ffe14a" fg="#14141c" />
    <Sign p={[0.9, 1.6, 1.4]} w={3.2} h={0.7} text="ADAPTS TO LOAD" k={ad} size={32} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S8 34.8 – 41.21  can't choose by thought; every step/lift/sit votes ============ */
export const S8 = ({ t, f }: Ctx) => {
  const no = seg(t, 35.17, 35.5, back);
  const panels: [string, number, string][] = [["STEP", 37.45, "#2fd46a"], ["LIFT", 38.16, "#2f8cff"], ["SIT", 39.47, "#e5233a"]];
  const vote = seg(t, 40.41, 40.7, back);
  return (<>
    <Cam t={t} keys={low([{ t: 34.6, pos: [0, 4.6, 12.5], look: [0, 4.4, 0], fov: 56 }, { t: 41.3, pos: [0, 4.6, 12], look: [0, 4.4, 0], fov: 56 }])} />
    <Lights warm="#fff0d8" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8dcef" b="#c8cce0" unit={1.6} />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#3a2a6a" line={3} />
    {t < 37.1 ? <>
      <Person p={[0, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: "angry", lookX: 0, nerv: 0.3 }} />
      <Sign p={[0, 6.4, 0.6]} w={3.6} h={0.85} text="THINK: THICKER!" k={seg(t, 34.91, 35.2, back)} size={36} bg="#fff" fg="#14141c" />
      <Sign p={[1.6, 5.0, 1.2]} w={1.4} h={1.0} text="✕" k={no} size={70} bg="#e5233a" fg="#fff" />
    </> : <>
      {panels.map(([txt, at, col], i) => { const k = seg(t, at, at + 0.3, back), x = -2.0 + i * 2.0; return <React.Fragment key={i}>
        <Person p={[x, 0, 0.8]} h={2.7} look={you} f={f + i * 5} pose={i === 0 ? { mood: "smile", walk: t * 3, speed: 0.5 } : i === 1 ? { mood: "grin", arms: "up", armK: 0.5 + 0.5 * Math.sin(t * 5) } : { mood: "deadpan", hunch: 0.5 }} />
        {i === 1 ? <Box p={[x, 2.9 + 0.3 * Math.sin(t * 5), 0.9]} s={[1.6, 0.08, 0.08]} color="#14141c" line={2} /> : null}
        <Sign p={[x, 3.7, 1.0]} w={1.6} h={0.65} text={txt} k={k} size={36} bg={col} fg="#fff" />
        {k > 0.01 ? <Bone p={[x, 5.0, 0.8]} len={1.0 * k} th={(i === 2 ? 0.6 : 1.3) * k} /> : null}
      </React.Fragment>; })}
      <Sign p={[0, 7.0, 0.6]} w={3.0} h={0.85} text="= A VOTE" k={vote} size={46} bg="#ffe14a" fg="#14141c" />
    </>}
  </>);
};

/* ============ S9 41.21 – end  "what is your body being told to build?" ============ */
export const S9 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={low([{ t: 41.0, pos: [0, 4.2, 11.5], look: [0, 3.8, 0], fov: 56 }, { t: 44.6, pos: [0, 4.0, 10.5], look: [0, 3.6, 0], fov: 54 }])} />
  <Lights warm="#d8e8ff" />
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#1a2a4a" b="#162440" unit={1.6} />
  <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#0c1a30" line={0} />
  <Person p={[0, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: "smile", lookX: 0 }} />
  <Glow p={[0, 2.0, 1.4]} r={3} color="rgba(120,190,255,1)" o={0.35 + 0.15 * Math.sin(t * 4)} />
  <Bone p={[-2.0, 2.2, 0.8]} len={1.4} th={1.0 + 0.3 * Math.sin(t * 3)} rot={[0, 0, 0.6]} /><Bone p={[2.0, 2.4, 0.8]} len={1.4} th={1.0 + 0.3 * Math.cos(t * 3)} rot={[0, 0, -0.6]} />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
