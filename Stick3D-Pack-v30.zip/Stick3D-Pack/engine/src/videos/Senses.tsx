// NEW HUMAN SENSES — 10 scenes. Harbisson's antenna (generic figure + name sign), Caltech 2019 magnetic field study.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Calendar } from "../style/kit";
import { Glow, Dust, Chair } from "../style/props";
import { Cam } from "../style/extra";
import { CrowdField } from "../style/medieval";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const neil = mk("#f0d4b8", "#2f8cff", "blazer", "bob", "#c8a060", { shirt: "#ffd23a" });
const neilGrey = mk("#d0d0d0", "#7a7a7a", "blazer", "bob", "#9a9a9a", { shirt: "#b0b0b0", shoe: "#444" });
const vol = mk("#8d5a3a", "#2fd4a0", "shirt", "short", "#111");
const H = 3.4, HEAD = H * 0.73;
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, Hh) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, Hh - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, Hh / 2 + 3); }} />
);
const Room: React.FC<{ grey?: number }> = ({ grey = 0 }) => (<>
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a={grey > 0.5 ? "#8a8a8a" : "#e8d8f8"} b={grey > 0.5 ? "#7a7a7a" : "#d8c8ec"} unit={1.6} />
  <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color={grey > 0.5 ? "#5a5a5a" : "#4a2a8a"} line={3} />
</>);
/** antenna over the head, bending forward, with a sensor tip */
const Antenna: React.FC<{ x: number; z: number; k?: number }> = ({ x, z, k = 1 }) => (k <= 0.01 ? null :
  <group position={[x, HEAD + 0.55, z - 0.2]} scale={[k, k, k]}>
    <Cyl p={[0, 0.45, 0]} rt={0.05} h={0.9} color="#2b2b36" line={1} /><Cyl p={[0, 0.95, 0.3]} rt={0.05} h={0.7} color="#2b2b36" line={1} rot={[1.1, 0, 0]} />
    <Ball p={[0, 1.15, 0.65]} r={0.14} color="#14141c" ink={0.02} />
  </group>);
const Rings: React.FC<{ p: V3; t: number; o?: number; color?: string }> = ({ p, t, o = 1, color = "#ffe14a" }) => (<>{o > 0.02 ? [0, 1, 2].map((i) => { const u = (t * 1.2 + i / 3) % 1; return <mesh key={i} position={p}><torusGeometry args={[0.5 + u * 1.4, 0.035, 6, 32]} /><meshBasicMaterial color={color} transparent opacity={o * (1 - u)} /></mesh>; }) : null}</>);

/* ============ S1 0 – 4.85  hook: five senses... and a sixth? ============ */
export const S1 = ({ t, f }: Ctx) => {
  const senses = ["SIGHT", "HEARING", "SMELL", "TASTE", "TOUCH"];
  const six = seg(t, 4.17, 4.45, Easing.out(Easing.back(3)));
  return (<>
    <Cam t={t} keys={low([{ t: 0, pos: [0, 4.4, 12], look: [0, 4.0, 0], fov: 56 }, { t: 5.0, pos: [0, 4.2, 11], look: [0, 4.0, 0], fov: 55 }])} />
    <Lights warm="#f0e8ff" />
    <Room />
    <Person p={[0, 0, 1.0]} h={H} look={you} f={f} pose={{ mood: six > 0.5 ? "worry" : "smile", lookX: 0 }} />
    {senses.map((s, i) => { const a = Math.PI * (0.15 + 0.7 * (i / 4)), k = seg(t, 2.2 + i * 0.22, 2.5 + i * 0.22, back); return <Sign key={i} p={[Math.cos(a) * -2.4, 3.4 + Math.sin(a) * 2.2, 0.8]} w={1.7} h={0.6} text={s} k={k * (1 - six * 0.3)} size={26} bg="#fff" fg="#14141c" />; })}
    <Glow p={[0, 6.4, 1.2]} r={2} color="rgba(190,140,255,1)" o={0.7 * six} />
    <Sign p={[0, 6.4, 1.2]} w={1.4} h={1.2} text="6?" k={six} size={70} bg="#9a5ad8" fg="#fff" />
  </>);
};

/* ============ S2 4.85 – 9.13  Neil Harbisson, born seeing in grayscale ============ */
export const S2 = ({ t, f }: Ctx) => {
  const nm = seg(t, 6.75, 7.05, back), gs = seg(t, 8.49, 8.8, back);
  return (<>
    <Cam t={t} keys={low([{ t: 4.7, pos: [0, 4.2, 11.5], look: [0, 3.8, 0], fov: 56 }, { t: 9.3, pos: [0.3, 4.0, 10.5], look: [0.3, 3.8, 0], fov: 54 }])} />
    <Lights warm="#f4f4f4" />
    <Room grey={1} />
    {[[-3.0, "#999"], [2.6, "#777"]].map(([x, col], i) => <React.Fragment key={i}><Cyl p={[x as number, 0.6, -2]} rt={0.4} h={1.2} color={col as string} line={3} /><Ball p={[x as number, 1.7, -2]} r={0.8} color="#aaa" ink={0.04} /></React.Fragment>)}
    <Person p={[0, 0, 1.0]} h={H} look={neilGrey} f={f} pose={{ mood: "deadpan", lookX: 0.2 }} />
    <Sign p={[0, 5.4, 1.2]} w={3.2} h={0.75} text="NEIL HARBISSON" k={nm} size={32} bg="#fff" fg="#14141c" />
    <Sign p={[0, 7.0, 0.6]} w={3.0} h={0.85} text="GRAYSCALE" k={gs} size={44} bg="#555" fg="#fff" />
  </>);
};

/* ============ S3 9.13 – 15.26  2004: antenna turns light into sound through bone ============ */
export const S3 = ({ t, f }: Ctx) => {
  const yr = seg(t, 9.19, 9.5, back), ant = seg(t, 10.5, 11.0, back), wave = seg(t, 12.4, 12.8), bone = seg(t, 14.49, 14.8, back);
  return (<>
    <Cam t={t} keys={low([{ t: 9.0, pos: [0, 4.4, 11], look: [0, 4.2, 0], fov: 56 }, { t: 15.4, pos: [0, 4.6, 9.5], look: [0, 4.6, 0], fov: 52 }])} />
    <Lights warm="#f4f4f4" />
    <Room grey={1} />
    <Calendar p={[-2.4, 7.0, -4.6]} month="YEAR" day="2004" s={1.4 * yr * (1 - ant) + 0.001} />
    <Person p={[0, 0, 1.0]} h={H} look={neilGrey} f={f} pose={{ mood: "smile", lookX: 0 }} />
    <Antenna x={0} z={1.0} k={ant} />
    {/* light wave hitting the sensor */}
    {wave > 0 ? Array.from({ length: 14 }, (_, i) => { const x = 3.2 - i * 0.18 * wave * 1.6; return <Ball key={i} p={[x, HEAD + 1.85 + Math.sin(i * 0.9 + t * 8) * 0.18, 1.0]} r={0.08} color={`hsl(${(i * 26 + t * 120) % 360},90%,60%)`} ink={0} />; }) : null}
    <Rings p={[0, HEAD + 0.2, 1.1]} t={t} o={wave} />
    <Sign p={[0, 8.0, 0.8]} w={3.2} h={0.85} text="LIGHT → SOUND" k={wave} size={42} bg="#14141c" fg="#ffe14a" />
    <Sign p={[-1.8, 3.4, 1.4]} w={2.8} h={0.7} text="THROUGH BONE" k={bone} size={30} bg="#fff" fg="#14141c" />
  </>);
};

/* ============ S4 15.26 – 18.22  colors become a sensation ============ */
export const S4 = ({ t, f }: Ctx) => {
  const c = seg(t, 15.8, 17.2, ease), code = seg(t, 16.68, 16.95, back), sens = seg(t, 17.5, 17.8, back);
  return (<>
    <Cam t={t} keys={low([{ t: 15.1, pos: [0, 4.4, 11], look: [0, 4.0, 0], fov: 56 }, { t: 18.4, pos: [0, 4.4, 11.5], look: [0, 4.2, 0], fov: 57 }])} />
    <Lights warm="#fff0f8" />
    <Room grey={c < 0.5 ? 1 : 0} />
    {Array.from({ length: 22 }, (_, i) => { const a = (i / 22) * Math.PI * 2 + t * 0.5, r = 1.2 + c * 3; return <Ball key={i} p={[Math.cos(a) * r, 3.6 + Math.sin(a) * r * 0.8, -0.5]} r={0.24 * c + 0.01} color={`hsl(${i * 16},90%,60%)`} ink={0.03} />; })}
    <Person p={[0, 0, 1.0]} h={H} look={c > 0.5 ? neil : neilGrey} f={f} pose={{ mood: c > 0.5 ? "grin" : "smile", arms: c > 0.5 ? "up" : undefined, armK: c }} />
    <Antenna x={0} z={1.0} />
    <Sign p={[-1.4, 7.4, 0.8]} w={2.0} h={0.75} text="CODE" k={code * (1 - sens)} size={40} bg="#555" fg="#fff" />
    <Sign p={[0, 7.4, 1.0]} w={3.2} h={0.85} text="SENSATION" k={sens} size={46} bg="#ff5a8a" fg="#fff" />
  </>);
};

/* ============ S5 18.22 – 20.69  the stranger part might be inside everyone ============ */
export const S5 = ({ t, f }: Ctx) => {
  const glow = seg(t, 19.45, 20.2, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 18.0, pos: [0, 4.6, 13], look: [0, 4.0, 0], fov: 58 }, { t: 20.8, pos: [0, 4.4, 12], look: [0, 4.0, 0], fov: 56 }])} />
    <Lights warm="#d8d0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#1a1438" b="#1a1438" />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#120e2a" line={0} />
    <CrowdField n={24} t={t} rate={4} at={(i) => [-6 + (i % 8) * 1.7, 0, -2.6 - Math.floor(i / 8) * 1.0] as V3} size={1.0} />
    {[-2.4, 0, 2.4].map((x, i) => <React.Fragment key={i}><Person p={[x, 0, 1.0]} h={3.2} look={[you, vol, neil][i]} f={f + i * 4} pose={{ mood: "smile" }} /><Glow p={[x, 3.2 * 0.73, 1.4]} r={0.9} color="rgba(190,140,255,1)" o={0.9 * glow} /></React.Fragment>)}
    <Sign p={[0, 6.6, 0.6]} w={3.4} h={0.85} text="INSIDE EVERYONE" k={seg(t, 19.88, 20.15, back)} size={38} bg="#9a5ad8" fg="#fff" />
  </>);
};

/* ============ S6 20.69 – 27.57  2019 Caltech: rotating magnetic fields in a chamber ============ */
export const S6 = ({ t, f }: Ctx) => {
  const yr = seg(t, 20.79, 21.1, back), field = seg(t, 24.95, 25.6, ease), rot = t * 1.2 * field;
  return (<>
    <Cam t={t} keys={low([{ t: 20.5, pos: [0, 4.6, 12.5], look: [0, 4.0, 0], fov: 56 }, { t: 27.7, pos: [0.4, 4.6, 11.5], look: [0.2, 4.0, 0], fov: 55 }])} />
    <Lights warm="#e0e8ff" />
    <Room />
    {/* the chamber: a wire cage */}
    {[-2.2, 2.2].map((x, i) => <Box key={i} p={[x, 2.6, 0]} s={[0.12, 5.2, 0.12]} color="#8a8aa0" line={1} />)}
    {[0.4, 2.6, 5.2].map((y, i) => <Box key={i} p={[0, y, 0]} s={[4.5, 0.1, 0.1]} color="#8a8aa0" line={1} />)}
    <Chair p={[0, 0, -0.4]} color="#3b4a8a" />
    <Person p={[0, 0, 0.3]} h={H} look={vol} f={f} pose={{ mood: "deadpan" }} />
    {Array.from({ length: 7 }, (_, i) => { const a = (i / 7) * Math.PI * 2; return <Ball key={i} p={[Math.cos(a) * 0.38, HEAD + 0.35 + Math.sin(a) * 0.15, 0.55]} r={0.07} color="#2f8cff" ink={0.02} />; })}
    {/* rotating field arcs */}
    {field > 0 ? <group position={[0, 2.6, 0.2]} rotation={[0, rot, 0]}>{[0, 1, 2].map((i) => <mesh key={i} rotation={[0, (i * Math.PI) / 3, 0]}><torusGeometry args={[2.6, 0.04, 6, 48, Math.PI]} /><meshBasicMaterial color="#5ab0ff" transparent opacity={0.8 * field} /></mesh>)}</group> : null}
    <Sign p={[0, 7.6, 0.6]} w={3.4} h={0.85} text="2019 · CALTECH" k={yr} size={38} bg="#14141c" fg="#ffe14a" />
    <Sign p={[0, 6.2, 1.0]} w={3.8} h={0.75} text="EARTH-STRENGTH FIELD" k={seg(t, 25.52, 25.8, back)} size={25} bg="#5ab0ff" fg="#14141c" />
  </>);
};

/* ============ S7 27.57 – 30.51  brain waves reacted; nobody felt a thing ============ */
export const S7 = ({ t, f }: Ctx) => {
  const react = seg(t, 28.41, 28.8), felt = seg(t, 29.82, 30.1, back);
  return (<>
    <Cam t={t} keys={[{ t: 27.4, pos: [0, 4.4, 10], look: [0, 4.4, 0], fov: 55 }, { t: 30.6, pos: [0, 4.4, 9.5], look: [0, 4.4, 0], fov: 54 }]} />
    <Lights warm="#e0e8ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0a1428" b="#0a1428" />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#0a1428" line={0} />
    <CanvasPlane p={[0, 5.0, 0]} s={[5.0, 2.8]} px={[500, 280]} draw={(c, W, Hh) => { c.fillStyle = "#06101a"; c.fillRect(0, 0, W, Hh); c.strokeStyle = "#2a3a50"; c.lineWidth = 2; for (let y = 40; y < Hh; y += 40) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
      c.strokeStyle = "#3aff6a"; c.lineWidth = 5; c.beginPath(); for (let x = 0; x < W; x += 4) { const u = x / W, dip = u > 0.55 && u < 0.85 ? react : 0, amp = 30 * (1 - 0.75 * dip); const y = Hh / 2 + Math.sin(x * 0.12 + t * 10) * amp + Math.sin(x * 0.05) * 6; x === 0 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke();
      c.fillStyle = "#9fd4ff"; c.font = "900 24px Inter, Arial"; c.fillText("BRAIN WAVES (ALPHA)", 16, 30); c.strokeStyle = "#fff"; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, Hh - 6); }} />
    <Sign p={[0.5, 7.4, 0.6]} w={2.8} h={0.8} text="REACTED!" k={react} size={42} bg="#3aff6a" fg="#14141c" />
    <Sign p={[0, 2.8, 0.8]} w={3.0} h={0.75} text="FELT: NOTHING" k={felt} size={34} bg="#fff" fg="#e5233a" />
  </>);
};

/* ============ S8 30.51 – 34.9  a hidden magnetic sense ============ */
export const S8 = ({ t, f }: Ctx) => {
  const lab = seg(t, 32.28, 32.6, back), needle = Math.sin(t * 2) * 0.6 * seg(t, 31.0, 31.6);
  return (<>
    <Cam t={t} keys={low([{ t: 30.3, pos: [0, 4.6, 11], look: [0, 4.4, 0], fov: 55 }, { t: 35.0, pos: [0, 4.6, 10.5], look: [0, 4.6, 0], fov: 54 }])} />
    <Lights warm="#e8e0ff" />
    <Room />
    <Person p={[0, 0, 1.0]} h={H} look={you} f={f} pose={{ mood: "smile", lookX: 0 }} />
    {/* compass inside the head */}
    <group position={[0, HEAD, 1.6]} scale={[seg(t, 30.9, 31.3, back) + 0.001, seg(t, 30.9, 31.3, back) + 0.001, 1]}>
      <Cyl p={[0, 0, 0]} rt={0.45} h={0.06} color="#ffffff" line={2} rot={[Math.PI / 2, 0, 0]} />
      <group rotation={[0, 0, needle]}><Box p={[0, 0.18, 0.05]} s={[0.08, 0.36, 0.03]} color="#e5233a" line={0} /><Box p={[0, -0.18, 0.05]} s={[0.08, 0.36, 0.03]} color="#14141c" line={0} /></group>
    </group>
    <Glow p={[0, HEAD, 1.8]} r={1.4} color="rgba(120,190,255,1)" o={0.6} />
    <Sign p={[0, 6.8, 0.8]} w={3.8} h={0.8} text="HIDDEN MAGNETIC SENSE?" k={lab} size={26} bg="#2f8cff" fg="#fff" />
  </>);
};

/* ============ S9 34.9 – 39.41  maybe they're already there, waiting ============ */
export const S9 = ({ t, f }: Ctx) => {
  const lit = (i: number) => seg(t, 37.6 + i * 0.18, 37.9 + i * 0.18);
  return (<>
    <Cam t={t} keys={low([{ t: 34.7, pos: [0, 4.4, 11.5], look: [0, 4.0, 0], fov: 56 }, { t: 39.5, pos: [0, 4.4, 10.5], look: [0, 4.0, 0], fov: 55 }])} />
    <Lights warm="#e8e0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#2a2050" b="#221a44" unit={2} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#1a1438" line={3} />
    <Person p={[0, 0, 1.0]} h={H} look={you} f={f} pose={{ mood: "smile", lookX: 0 }} />
    {Array.from({ length: 8 }, (_, i) => { const a = (i / 8) * Math.PI * 2 + t * 0.4, x = Math.cos(a) * 2.2, y = 2.6 + Math.sin(a) * 1.8; return <React.Fragment key={i}><Ball p={[x, y, 0.8]} r={0.22} color={lit(i) > 0.5 ? `hsl(${i * 45},90%,65%)` : "#4a4470"} ink={0.03} /><Glow p={[x, y, 1.0]} r={0.6} color="rgba(220,200,255,1)" o={0.7 * lit(i)} /></React.Fragment>; })}
    <Sign p={[0, 6.8, 0.6]} w={3.6} h={0.85} text="ALREADY THERE?" k={seg(t, 37.59, 37.9, back)} size={40} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S10 39.41 – end  "what else is your body sensing?" ============ */
export const S10 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={low([{ t: 39.2, pos: [0, 4.2, 11], look: [0, 3.8, 0], fov: 56 }, { t: 42.9, pos: [0, 4.0, 10], look: [0, 3.6, 0], fov: 54 }])} />
  <Lights warm="#e8e0ff" />
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="marble" a="#2a2050" b="#221a44" unit={2} />
  <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#1a1438" line={3} />
  <Person p={[0, 0, 1.0]} h={H} look={you} f={f} pose={{ mood: "worry", lookX: 0, armR: [0.3, 0.75], armRK: seg(t, 41.4, 41.8) }} />
  <Rings p={[0, HEAD, 0.8]} t={t} o={0.7} color="#b8a8ff" />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10 };
