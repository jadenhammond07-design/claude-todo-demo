// THE END OF HISTORY ILLUSION — 11 scenes. Generic stick figures.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Curtain, Bench } from "../style/extra";
import { Sky, Banner, CrowdField } from "../style/medieval";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const HV: Look[] = [
  mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008"), mk("#d9a77c", "#2f8cff", "shirt", "swept", "#3a2a1a", { glasses: true }), mk("#d9a77c", "#8a4fb8", "blazer", "bob", "#5a3420", { shirt: "#fff" }),
  mk("#d9a77c", "#2fa86a", "hoodie", "grey", "#aaa", { hat: "#2a2a38" }), mk("#d9a77c", "#e5233a", "shirt", "short", "#111", { glasses: true, badge: "#ffc23a" }), mk("#d9a77c", "#1a1a22", "suit", "swept", "#444", { tie: "#c0182e" }),
];
const hero = HV[0];
const past = mk("#e8c098", "#f0b429", "hoodie", "bob", "#7a4a1c", { shoe: "#c9402e" });
const lab = mk("#f3d3b2", "#f4f4f4", "shirt", "swept", "#3b2a1a", { glasses: true, badge: "#2f8cff" });
const ages = (i: number): Look => mk(["#f3d3b2", "#c98e62", "#8d5a3a", "#e0b48c", "#fbe3c8", "#d9a77c"][i], ["#e55a8a", "#3a7fd6", "#2fa86a", "#f0b429", "#8a4fb8", "#c0402e"][i], i < 2 ? "hoodie" : "shirt", i < 4 ? (["short", "bob", "swept", "short"] as const)[i] : "grey", i < 4 ? "#3b2a1a" : "#aaa", { glasses: i >= 3 });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Cloud: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; col?: string; size?: number }> = ({ p, w, h, text, k = 1, col = "#6a5aa8", size = 44 }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); for (const [x, y, r] of [[W * 0.22, H * 0.5, H * 0.34], [W * 0.5, H * 0.38, H * 0.4], [W * 0.78, H * 0.5, H * 0.34], [W * 0.5, H * 0.62, H * 0.34]] as number[][]) { c.moveTo(x + r, y); c.arc(x, y, r, 0, 7); } c.fill(); c.stroke(); c.fillStyle = "#fff"; for (const [x, y, r] of [[W * 0.22, H * 0.5, H * 0.32], [W * 0.5, H * 0.38, H * 0.38], [W * 0.78, H * 0.5, H * 0.32], [W * 0.5, H * 0.62, H * 0.32]] as number[][]) { c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); } c.fillStyle = col; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2); }} />
);

/* ============ S1 0 – 3.9  "What if your personality is constantly changing without you noticing?" ============ */
const K1: Key[] = [
  { t: 0, pos: [0, 3.4, 11.0], look: [0, 3.0, 0], fov: 58 },
  { t: 4.1, pos: [0.4, 3.2, 8.4], look: [0, 3.0, 0], fov: 52 },
];
export const S1 = ({ t, f }: Ctx) => {
  const i = Math.floor(t * 1.9) % HV.length, fl = 1 - ((t * 1.9) % 1);
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff0e0" />
    <Floor kind="tile" a="#e8e0d8" b="#d8d0c8" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#bcd0e8" b="#bcd0e8" base="#8aa0c0" /><SideWall x={-9} kind="plain" a="#acc0d8" b="#acc0d8" /><SideWall x={9} kind="plain" a="#acc0d8" b="#acc0d8" />
    <Box p={[0, 3.6, -3.1]} s={[4.6, 6.4, 0.2]} color="#8a6a42" line={4} />
    <CanvasPlane p={[0, 3.6, -2.96]} s={[4.2, 6.0]} px={[210, 300]} draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, W, H); g.addColorStop(0, "#dff0ff"); g.addColorStop(1, "#9ab8e0"); c.fillStyle = g; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.6)"; c.lineWidth = 8; c.beginPath(); c.moveTo(20, 60); c.lineTo(80, 20); c.stroke(); }} />
    <Person p={[0, 0, -2.2]} h={3.9} look={{ ...HV[i], skin: "#e8d2bc" }} f={f} pose={{ mood: "smile", lookX: 0, armR: [0.3, 0.5], armRK: 0.5 }} />
    <Glow p={[0, 3.0, -1.8]} r={3.4} color="rgba(255,255,255,1)" o={0.7 * fl} />
    <Person p={[0, 0, 1.8]} h={3.9} look={hero} f={f} pose={{ mood: t > 2.78 ? "deadpan" : "smile", tilt: 0.03 * Math.sin(t * 2), lookX: 0, armR: [0.3, 0.7], armRK: seg(t, 2.78, 3.1) }} />
    <Cloud p={[2.4, 6.6, 1.8]} w={2.6} h={1.5} text="?" k={seg(t, 3.27, 3.6, Easing.out(Easing.back(2.6)))} size={80} col="#e5233a" />
    <Dust t={t} area={[6, 5, 4]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S2 3.9 – 9.0  "You probably aren't the exact same person you were five years ago, even if you feel like you are." ============ */
const K2: Key[] = [
  { t: 3.7, pos: [0, 3.6, 12.5], look: [0, 3.0, 0], fov: 58 },
  { t: 9.2, pos: [0.2, 3.6, 11.0], look: [0.2, 3.0, 0], fov: 56 },
];
export const S2 = ({ t, f }: Ctx) => {
  const c1 = seg(t, 6.4, 6.7, Easing.out(Easing.back(3))), c2 = seg(t, 6.7, 7.0, Easing.out(Easing.back(3))), c3 = seg(t, 7.0, 7.3, Easing.out(Easing.back(3))), same = seg(t, 7.79, 8.1, Easing.out(Easing.back(2.6)));
  const ring = (p: V3, k: number) => <CanvasPlane p={p} s={[1.6 * k + 0.001, 1.6 * k + 0.001]} px={[160, 160]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#e5233a"; c.lineWidth = 12; c.beginPath(); c.ellipse(80, 80, 66, 56, 0, 0, 7); c.stroke(); }} />;
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#8a6a42" b="#7a5c38" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#e8d8b8" b="#e8d8b8" base="#a8884a" /><SideWall x={-9} kind="plain" a="#d8c8a8" b="#d8c8a8" /><SideWall x={9} kind="plain" a="#d8c8a8" b="#d8c8a8" />
    <Box p={[0, 3.2, -4.8]} s={[0.12, 6.4, 0.1]} color="#8a6a42" line={2} />
    <Sign p={[-2.4, 6.6, -2]} w={3.0} h={0.9} text="5 YEARS AGO" size={38} bg="#6a5a48" fg="#fff" face={false} /><Sign p={[2.4, 6.6, -2]} w={2.0} h={0.9} text="NOW" size={56} bg="#1f6ad8" fg="#fff" face={false} />
    <Person p={[-2.4, 0, 0.4]} h={3.7} look={past} f={f} pose={{ mood: "grin", lookX: 0.2 }} />
    <Person p={[2.4, 0, 0.4]} h={3.9} look={hero} f={f + 4} pose={{ mood: t > 7.7 ? "smile" : "deadpan", lookX: -0.2, flip: false, arms: t > 7.79 ? "chest" : undefined, armK: same }} />
    {ring([-2.4, 5.0, 0.8], c1)}{ring([-2.4, 3.2, 0.8], c2)}{ring([-2.4, 0.6, 0.8], c3)}
    <Cloud p={[2.4, 6.0, 0.8]} w={3.0} h={1.4} text="SAME!" k={same} size={52} col="#1fa850" />
    <Frame p={[-7, 4.8, -4.9]} s={[1.6, 1.2]} art={1} /><Frame p={[7, 4.8, -4.9]} s={[1.6, 1.2]} art={2} /><Plant p={[0, 0, -3.6]} s={1.3} pot="#c0643a" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,240,200,.8)" />
  </>);
};

/* ============ S3 9.0 – 15.2  "In 2013, psychologists asked over 19,000 people, ages 18 to 68, a strange question." ============ */
const K3: Key[] = [
  { t: 8.8, pos: [-3.0, 3.6, 12.0], look: [-1.0, 3.0, 0], fov: 58 },
  { t: 11.4, pos: [0, 6.0, 15.0], look: [0, 1.6, -5], fov: 60 },
  { t: 13.2, pos: [0, 9.0, 17.0], look: [0, 1.0, -6], fov: 62 },
  { t: 15.4, pos: [-2.0, 4.0, 12.0], look: [-2.0, 3.2, 0], fov: 56 },
];
export const S3 = ({ t, f }: Ctx) => {
  const yr = seg(t, 9.05, 9.4, Easing.out(Easing.back(2.6))), cnt = Math.round(lerp(0, 19000, seg(t, 11.51, 12.9, Easing.out(Easing.cubic)))), hand68 = lerp(0, 1, seg(t, 13.54, 14.6, Easing.inOut(Easing.cubic))), q = seg(t, 15.0, 15.3, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff4e0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#e8f2ff" />
    <Surface p={[0, -0.05, -10]} s={[120, 80]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6aa84a" b="#6aa84a" />
    <CrowdField n={170} t={t} rate={2.4} at={(i) => [-9 + (i % 17) * 1.1 + (Math.floor(i / 17) % 2) * 0.5, 0, -3 - Math.floor(i / 17) * 1.1] as V3} size={1.0} />
    <Banner p={[0, 9.4, -2]} s={[6.4, 1.8]} text="STUDY 2013" size={64} bg="#1f3a6a" fg="#fff" />
    <Sign p={[3.4, 6.8, 0.6]} w={4.8} h={1.4} text={cnt.toLocaleString("en-US")} k={t > 11.5 ? 1 : 0} size={80} fg="#fff" bg="#1f6ad8" />
    <CanvasPlane p={[0, 0.04, 3.0]} rot={[-Math.PI / 2, 0, 0]} s={[8.4, 1.0]} px={[840, 100]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 6; c.strokeRect(3, 3, W - 6, H - 6); c.fillStyle = "#2fd46a"; c.fillRect(30, 30, (W - 60) * hand68, 40); c.fillStyle = INK; c.font = "900 40px Inter, Arial"; c.textBaseline = "middle"; c.textAlign = "left"; c.fillText("18", 30, 90 - 10); c.textAlign = "right"; c.fillText("68", W - 30, 90 - 10); }} />
    <Person p={[-3.0, 0, 1.4]} h={3.9} look={lab} f={f} pose={{ mood: "deadpan", armR: [0.3, 0.55], armRK: seg(t, 10.12, 10.6), lookX: 0.4 }} />
    <FaceGroup p={[-3.0, 0, 1.4]}><Box p={hand(3.9, [0.3, 0.55], 0, false, 0.1)} s={[0.5, 0.7, 0.05]} color="#c9a870" line={2} /></FaceGroup>
    <Sign p={[-3.0, 5.4, 1.4]} w={4.4 * seg(t, 9.05, 9.4, Easing.out(Easing.back(2.6))) + 0.001} h={0.8} text="PSYCHOLOGISTS" size={40} fg="#fff" bg="#2a2a38" />
    <Cloud p={[2.0, 6.4, 2.4]} w={2.6} h={1.6} text="?!" k={q} size={80} col="#e5233a" />
    <Dust t={t} area={[10, 6, 6]} color="rgba(255,255,230,.8)" />
    {void yr}
  </>);
};

/* ============ S4 15.2 – 19.6  "Some described how much they'd changed over the last ten years." ============ */
const K4: Key[] = [
  { t: 15.0, pos: [1.0, 3.6, 11.0], look: [0.4, 3.0, 0], fov: 58 },
  { t: 17.4, pos: [-4.0, 3.6, 11.0], look: [-4.0, 3.0, 0], fov: 56 },
  { t: 19.8, pos: [-5.0, 3.6, 10.4], look: [-5.0, 3.0, 0], fov: 54 },
];
export const S4 = ({ t, f }: Ctx) => {
  const lab1 = seg(t, 16.47, 16.8, Easing.out(Easing.back(2.6))), tenY = seg(t, 18.83, 19.15, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#7a98c0" bottom="#e8eef8" />
    <Surface p={[0, -0.05, -8]} s={[120, 60]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8aa860" b="#8aa860" />
    <Surface p={[-6, 0.0, 0.6]} s={[22, 3]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#c8b898" b="#b8a888" unit={1.2} />
    <Cyl p={[1.6, 2.2, 0.6]} rt={0.1} h={4.4} color="#5a5a6a" line={2} /><Sign p={[1.6, 5.0, 0.6]} w={2.0} h={0.8} text="NOW" size={50} bg="#1f6ad8" fg="#fff" />
    {[0, 1, 2, 3, 4].map((i) => <React.Fragment key={i}><Person p={[-0.4 - i * 2.8, 0, 0.6]} h={3.6} look={HV[(i + 1) % HV.length]} f={f + i * 4} pose={{ mood: "smile", lookX: 0.2, flip: false }} />
      <Sign p={[-0.4 - i * 2.8, 4.9, 0.6]} w={2.0} h={0.6} text={(i + 1) * 2 + " YRS AGO"} size={28} k={seg(t, 16.6 + i * 0.35, 16.9 + i * 0.35, Easing.out(Easing.back(2.6)))} bg="#fff" fg="#14141c" /></React.Fragment>)}
    <Sign p={[-5.4, 7.0, 0.6]} w={5.4 * lab1 + 0.001} h={1.1} text="DESCRIBED" size={52} />
    <Sign p={[-8.2, 8.4, 0.6]} w={5.0 * tenY + 0.001} h={1.0} text="LAST 10 YEARS" size={44} bg="#c0182e" fg="#fff" />
    <Person p={[1.6 + 1.6, 0, 0.8]} h={3.9} look={lab} f={f} pose={{ mood: "smile", arms: "point", armK: seg(t, 16.0, 16.4), flip: true, lookX: -0.5 }} />
    <Dust t={t} area={[12, 6, 4]} color="rgba(255,250,220,.8)" />
  </>);
};

/* ============ S5 19.6 – 22.6  "Others predicted how much they'd change in the next ten." ============ */
const K5: Key[] = [
  { t: 19.4, pos: [-1.0, 3.6, 11.0], look: [0.4, 3.0, 0], fov: 58 },
  { t: 21.2, pos: [4.0, 3.6, 11.0], look: [4.0, 3.0, 0], fov: 56 },
  { t: 22.8, pos: [5.0, 3.6, 10.4], look: [5.0, 3.0, 0], fov: 54 },
];
export const S5 = ({ t, f }: Ctx) => {
  const lab1 = seg(t, 20.17, 20.5, Easing.out(Easing.back(2.6))), nx = seg(t, 21.89, 22.2, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#e8eeff" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#4a68a0" bottom="#c8d8f0" />
    <Surface p={[0, -0.05, -8]} s={[120, 60]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#7a98a8" b="#7a98a8" />
    <Surface p={[6, 0.0, 0.6]} s={[22, 3]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8e4f4" b="#c8d4e8" unit={1.2} />
    <Cyl p={[-1.6, 2.2, 0.6]} rt={0.1} h={4.4} color="#5a5a6a" line={2} /><Sign p={[-1.6, 5.0, 0.6]} w={2.0} h={0.8} text="NOW" size={50} bg="#1f6ad8" fg="#fff" />
    {[0, 1, 2, 3, 4].map((i) => <React.Fragment key={i}><Person p={[0.6 + i * 2.8, 0, 0.6]} h={3.6} look={{ ...hero, skin: "#dfe8f4", body: "#9ab8e0" }} f={f + i * 4} pose={{ mood: "deadpan", lookX: -0.2 }} />
      <Sign p={[0.6 + i * 2.8, 4.9, 0.6]} w={2.0} h={0.6} text={"+" + (i + 1) * 2 + " YRS"} size={28} k={seg(t, 20.5 + i * 0.3, 20.8 + i * 0.3, Easing.out(Easing.back(2.6)))} bg="#fff" fg="#14141c" /></React.Fragment>)}
    <Sign p={[5.4, 7.0, 0.6]} w={5.6 * lab1 + 0.001} h={1.1} text="PREDICTED" size={52} />
    <Sign p={[8.6, 8.4, 0.6]} w={5.0 * nx + 0.001} h={1.0} text="NEXT 10 YEARS" size={44} bg="#1f6ad8" fg="#fff" />
    <Person p={[-3.2, 0, 0.8]} h={3.9} look={lab} f={f} pose={{ mood: "smile", arms: "point", armK: seg(t, 19.9, 20.3), lookX: 0.5 }} />
    <Dust t={t} area={[12, 6, 4]} color="rgba(220,230,255,.8)" />
  </>);
};

/* ============ S6 22.6 – 27.4  "Everyone, from teenagers to sixty-year-olds, said they'd changed a lot in the past." ============ */
const K6: Key[] = [
  { t: 22.4, pos: [-5.0, 3.6, 12.0], look: [-3.0, 3.0, 0], fov: 58 },
  { t: 25.0, pos: [0, 3.8, 12.5], look: [0, 3.0, 0], fov: 58 },
  { t: 27.6, pos: [3.0, 3.8, 12.0], look: [2.0, 3.0, 0], fov: 56 },
];
export const S6 = ({ t, f }: Ctx) => {
  const lbl = ["TEENS", "20s", "30s", "40s", "50s", "60s"];
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#fff4d8" />
    <Floor kind="tile" a="#d8e4f0" b="#c8d4e4" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#8aa8d0" b="#8aa8d0" base="#5a78a8" /><SideWall x={-9} kind="plain" a="#7a98c0" b="#7a98c0" /><SideWall x={9} kind="plain" a="#7a98c0" b="#7a98c0" />
    {[0, 1, 2, 3, 4, 5].map((i) => { const x = -5.6 + i * 2.25, born = 22.9 + i * 0.7, k = seg(t, born, born + 0.3, Easing.out(Easing.back(2.6))), bar = seg(t, born + 0.2, born + 0.8);
      return <React.Fragment key={i}><Person p={[x, 0, 0.4]} h={3.0 + i * 0.16} look={ages(i)} f={f + i * 4} pose={{ mood: "grin", arms: "up", armK: 0.6 * k, squash: -0.02 }} />
        <Sign p={[x, 4.6 + i * 0.1, 0.4]} w={2.2} h={0.8} text="CHANGED A LOT!" size={22} k={k} bg="#fff" fg="#14141c" />
        <Sign p={[x, 0.02, 2.2]} w={1.8} h={0.5} text={lbl[i]} size={30} bg="#2a2a38" fg="#fff" face={false} />
        <Box p={[x, 0.1 + 1.2 * bar, 3.2]} s={[1.0, 0.2 + 2.4 * bar, 0.5]} color="#2fd46a" line={3} /></React.Fragment>; })}
    <Sign p={[0, 7.4, -1]} w={6.2} h={1.2} text="PAST: CHANGED A LOT" size={46} face={false} />
    <Dust t={t} area={[12, 6, 5]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S7 27.4 – 30.4  "Almost no one believed they'd change much in the future." ============ */
const K7: Key[] = [
  { t: 27.2, pos: [-4.0, 3.6, 12.0], look: [-2.0, 3.0, -2], fov: 58 },
  { t: 30.6, pos: [3.0, 3.8, 12.0], look: [2.0, 3.0, -2], fov: 56 },
];
export const S7 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={K7} />
  <Lights warm="#ffe8c8" />
  <Sky p={[0, 26, -60]} s={[300, 150]} top="#ff9a50" bottom="#ffe8b0" glowAt={[0.8, "rgba(255,220,130,1)"]} />
  <Surface p={[0, -0.05, -14]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#c8a868" b="#c8a868" />
  <Surface p={[0, 0.01, -14]} s={[5, 70]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#6a6a76" b="#6a6a76" />
  {Array.from({ length: 12 }, (_, i) => <Box key={i} p={[0, 0.03, 4 - i * 3.4]} s={[0.2, 0.03, 1.4]} color="#f4e8a0" line={0} />)}
  {[0, 1, 2, 3, 4, 5].map((i) => { const x = -6 + i * 2.4, k = seg(t, 27.9 + i * 0.35, 28.2 + i * 0.35, Easing.out(Easing.back(2.6)));
    return <React.Fragment key={i}><Person p={[x, 0, 0.6 - (i % 2) * 1.2]} h={3.0 + i * 0.16} look={ages(i)} f={f + i * 4} pose={{ mood: "smile", arms: "chest", armK: 1, lookX: 0 }} />
      <Sign p={[x, 4.5 + i * 0.1 + (i % 2) * 1.0, 0.6 - (i % 2) * 1.2]} w={2.2} h={0.8} text="I'LL STAY THE SAME" size={20} k={k} bg="#fff" fg="#14141c" />
      <Box p={[x, 0.1, 2.6]} s={[1.0, 0.16, 0.5]} color="#e5233a" line={2} /></React.Fragment>; })}
  <Sign p={[0, 7.8, -3]} w={6.4} h={1.2} text="FUTURE: NO CHANGE" size={44} face={false} bg="#c0182e" fg="#fff" />
  <Dust t={t} area={[12, 6, 5]} color="rgba(255,240,200,.8)" />
</>);

/* ============ S8 30.4 – 35.0  "But when researchers compared the two, people changed far more than they predicted." ============ */
const K8: Key[] = [
  { t: 30.2, pos: [-2.0, 3.8, 12.5], look: [0, 3.6, 0], fov: 58 },
  { t: 33.0, pos: [0, 3.8, 11.0], look: [0, 3.6, 0], fov: 54 },
  { t: 35.2, pos: [0, 3.8, 10.0], look: [0, 3.6, 0], fov: 52 },
];
export const S8 = ({ t, f }: Ctx) => {
  const pr = seg(t, 31.5, 32.4, Easing.out(Easing.cubic)), ac = seg(t, 32.9, 34.4, Easing.out(Easing.back(1.4))), far = seg(t, 33.29, 33.6, Easing.out(Easing.back(2.6))), shock = seg(t, 33.9, 34.2);
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#e8f0ff" />
    <Floor kind="tile" a="#d8e0ec" b="#c8d0dc" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#2a3a5a" b="#2a3a5a" base="#141e30" />
    <CanvasPlane p={[0, 4.6, -4.9]} s={[8.2, 5.4]} px={[820, 540]} frame="#e8dcc0" draw={(c, W, H) => { c.fillStyle = "#f4f6fb"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 5; c.beginPath(); c.moveTo(60, 40); c.lineTo(60, H - 70); c.lineTo(W - 30, H - 70); c.stroke();
      ["TEENS", "40s", "60s"].forEach((l, i) => { const x = 120 + i * 230; c.fillStyle = "#ffc23a"; c.fillRect(x, H - 70 - 70 * pr, 70, 70 * pr); c.fillStyle = "#e5233a"; c.fillRect(x + 80, H - 70 - 300 * ac * (0.8 + 0.1 * i), 70, 300 * ac * (0.8 + 0.1 * i)); c.fillStyle = INK; c.font = "800 26px Inter, Arial"; c.textAlign = "center"; c.fillText(l, x + 75, H - 40); });
      c.fillStyle = "#ffc23a"; c.fillRect(60, 18, 24, 24); c.fillStyle = "#e5233a"; c.fillRect(270, 18, 24, 24); c.fillStyle = INK; c.font = "800 26px Inter, Arial"; c.textAlign = "left"; c.fillText("PREDICTED", 92, 38); c.fillText("ACTUAL", 302, 38); }} />
    <Sign p={[0, 8.4, 0]} w={5.4 * far + 0.001} h={1.4 * far + 0.001} text="FAR MORE!" size={72} fg="#fff" bg="#c0182e" />
    <Person p={[-4.6, 0, 1.2]} h={3.9} look={lab} f={f} pose={{ mood: "grin", arms: "point", armK: seg(t, 32.0, 32.4), lookX: 0.6 }} />
    <Person p={[4.6, 0, 1.4]} h={3.6} look={HV[2]} f={f + 4} pose={{ mood: shock > 0.5 ? "shock" : "smile", arms: shock > 0.5 ? "head" : undefined, armK: shock, flip: true, squash: shock > 0.5 ? -0.08 * Math.exp(-(t - 33.9) * 4) : 0 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(230,240,255,.8)" />
  </>);
};

/* ============ S9 35.0 – 41.5  "Psychologists named it the end of history illusion: the feeling that the person you are right now is the finished version." ============ */
const K9: Key[] = [
  { t: 34.8, pos: [-2.0, 3.8, 12.5], look: [-1.0, 3.2, 0], fov: 58 },
  { t: 37.4, pos: [0, 4.0, 11.5], look: [0, 3.4, 0], fov: 56 },
  { t: 40.2, pos: [2.8, 3.8, 10.5], look: [3.4, 3.2, 0], fov: 54 },
  { t: 41.7, pos: [3.4, 3.8, 10.0], look: [3.4, 3.2, 0], fov: 52 },
];
export const S9 = ({ t, f }: Ctx) => {
  const close = seg(t, 36.1, 36.5, Easing.in(Easing.quad)), end = seg(t, 36.55, 36.7, Easing.in(Easing.quad)), ill = seg(t, 37.38, 37.7, Easing.out(Easing.back(2.6))), fin = seg(t, 40.64, 40.95, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K9} impacts={[[36.7, 0.03]]} />
    <Lights warm="#fff0d8" />
    <Floor kind="marble" a="#2a2438" b="#241e32" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#1a1630" b="#1a1630" base="#0c0818" /><Curtain p={[-7, 4.6, -5.6]} s={[3, 9.2]} color="#5a1a8a" /><Curtain p={[7, 4.6, -5.6]} s={[3, 9.2]} color="#5a1a8a" />
    <group position={[-0.4, 1.6, 0.4]}><Box p={[0, 0.2, 0]} s={[3.4, 0.4, 2.4]} color="#4a2a14" line={3} />
      <group position={[-1.7, 0.4, 0]} rotation={[0, 0, (1 - close) * 1.3]}><Box p={[1.7, 0.1, 0]} s={[3.4, 0.2, 2.4]} color="#8a2a2a" line={3} /></group>
      <CanvasPlane p={[0, 0.42, 0]} rot={[-Math.PI / 2, 0, 0]} s={[3.0, 2.0]} px={[300, 200]} draw={(c, W, H) => { c.fillStyle = "#8a2a2a"; c.fillRect(0, 0, W, H); c.fillStyle = "#ffd36a"; c.font = "900 54px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("HISTORY", W / 2, 70); if (end > 0.99) { c.save(); c.translate(W / 2, 140); c.rotate(-0.1); c.strokeStyle = "#fff"; c.fillStyle = "#fff"; c.lineWidth = 6; c.strokeRect(-100, -30, 200, 60); c.font = "900 44px Inter, Arial"; c.fillText("THE END", 0, 3); c.restore(); } }} /></group>
    <Sign p={[-0.4, 6.0, 0.4]} w={3.4 * seg(t, 36.51, 36.8, Easing.out(Easing.back(2.6))) + 0.001} h={1.0} text="THE END" size={64} fg="#fff" bg="#c0182e" />
    <Sign p={[-0.4, 7.2, 0.4]} w={3.4 * ill + 0.001} h={0.9} text="ILLUSION" size={56} bg="#8a4fb8" fg="#fff" />
    <Person p={[-2.8, 0, 2.2]} h={3.7} look={hero} f={f} pose={{ mood: t > 38.15 ? "smile" : "deadpan", arms: t > 38.15 ? "chest" : undefined, armK: seg(t, 38.15, 38.5), lookX: 0.5 }} />
    {/* the pedestal: the "finished version" */}
    <Cyl p={[3.4, 0.7, 0]} rt={1.3} rb={1.5} h={1.4} color="#e8e4dc" line={3} /><SpotCone p={[3.4, 9, 0]} h={9} r={1.8} color="#fff2c0" o={0.15} />
    <Person p={[3.4, 1.4, 0]} sy={1.4} h={3.6} look={mk("#e8c86a", "#d8b84a", "suit", "short", "#c9a032", { tie: "#c9a032", shoe: "#c9a032" })} f={f} pose={{ mood: "grin", arms: "chest", armK: 1 }} />
    <Sign p={[3.4, 6.4, 0.8]} w={4.4 * fin + 0.001} h={1.2 * fin + 0.001} text="FINAL VERSION" size={48} fg="#14141c" bg="#ffd36a" />
    {t > 40.64 ? Array.from({ length: 14 }, (_, i) => { const u = (t - 40.64) * 1.0 + i * 0.07; return <Box key={i} p={[1.4 + (i % 7) * 0.6, 7 - u * 2 - (i % 3) * 0.3, 0.6]} s={[0.14, 0.05, 0.1]} rot={[0, 0, t * 6 + i]} color={["#e5233a", "#2f8cff", "#ffc23a", "#2fd46a"][i % 4]} line={0} />; }) : null}
    <Glow p={[3.4, 3.4, 1]} r={4} color="rgba(255,220,120,1)" o={0.4 * fin} /><Dust t={t} area={[8, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S10 41.5 – 43.6  "You aren't." ============ */
const K10: Key[] = [
  { t: 41.3, pos: [3.4, 3.8, 10.0], look: [3.4, 3.2, 0], fov: 52 },
  { t: 43.8, pos: [2.4, 3.6, 8.6], look: [2.4, 3.0, 0], fov: 48 },
];
export const S10 = ({ t, f }: Ctx) => {
  const crack = seg(t, 41.76, 42.3), burst = seg(t, 42.3, 42.5, Easing.out(Easing.cubic)), beta = seg(t, 42.2, 42.5), prog = seg(t, 42.3, 43.5, Easing.out(Easing.cubic));
  return (<>
    <Cam t={t} keys={K10} impacts={[[42.3, 0.04]]} />
    <Lights warm="#fff0d8" />
    <Floor kind="marble" a="#2a2438" b="#241e32" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#1a1630" b="#1a1630" base="#0c0818" />
    <Cyl p={[3.4, 0.7, 0]} rt={1.3} rb={1.5} h={1.4} color="#e8e4dc" line={3} />
    {burst < 0.5 ? <Person p={[3.4, 1.4, 0]} sy={1.4} h={3.6} look={mk("#e8c86a", "#d8b84a", "suit", "short", "#c9a032", { tie: "#c9a032", shoe: "#c9a032" })} f={f} pose={{ mood: "shock", arms: "chest", armK: 1, nerv: 0.6 * crack }} /> : null}
    {crack > 0.01 && burst < 0.5 ? <CanvasPlane p={[3.4, 3.2, 0.6]} s={[2.4, 3.6]} px={[240, 360]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#14141c"; c.lineWidth = 8; c.lineCap = "round"; c.beginPath(); c.moveTo(120, 20); c.lineTo(100 + 20 * crack, 90 * crack); c.lineTo(140, 160 * crack); c.lineTo(110, 240 * crack); c.lineTo(130, 330 * crack); c.stroke(); c.beginPath(); c.moveTo(100 + 20 * crack, 90 * crack); c.lineTo(40, 130 * crack); c.moveTo(140, 160 * crack); c.lineTo(200, 190 * crack); c.stroke(); }} /> : null}
    {burst > 0 ? Array.from({ length: 12 }, (_, i) => { const a = i * 0.52, r = burst * 2.4; return <Box key={i} p={[3.4 + Math.cos(a) * r, 3.0 + Math.sin(a) * r * 0.8 - burst * 0.5, 0.4]} s={[0.36, 0.24, 0.1]} rot={[0, 0, a + burst * 4]} color="#d8b84a" line={2} />; }) : null}
    {burst >= 0.5 ? <Person p={[3.4, 1.4, 0]} sy={1.4} h={3.6} look={hero} f={f} pose={{ mood: "grin", arms: "up", armK: seg(t, 42.5, 42.8), squash: -0.05 * Math.exp(-(t - 42.5) * 5) }} /> : null}
    <Sign p={[3.4, 6.4, 0.8]} w={4.6} h={1.2} text={beta < 0.5 ? "FINAL VERSION" : "v1.0 · NOT FINAL"} size={beta < 0.5 ? 48 : 38} fg="#14141c" bg={beta < 0.5 ? "#ffd36a" : "#ff8a4a"} />
    <CanvasPlane p={[3.4, 8.0, 0.6]} s={[4.6, 0.9]} px={[460, 90]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 6; c.fillRect(6, 6, W - 12, H - 12); c.fillStyle = "#2a2a3a"; c.fillRect(20, 28, W - 40, 34); c.fillStyle = "#2fd46a"; c.fillRect(20, 28, (W - 40) * 0.47 * prog, 34); c.fillStyle = "#fff"; c.font = "800 22px Inter, Arial"; c.textAlign = "center"; c.fillText(prog > 0.05 ? "BECOMING... " + Math.round(47 * prog) + "%" : "", W / 2, 20); }} />
    <Dust t={t} area={[6, 6, 4]} color="rgba(255,235,200,.8)" />
  </>);
};

/* ============ S11 43.6 – 46.8  "So who will you be in ten years, and what are you already becoming?" ============ */
const K11: Key[] = [
  { t: 43.4, pos: [0, 3.0, 9.0], look: [0, 2.8, -2], fov: 56 },
  { t: 45.4, pos: [0.0, 4.0, 11.0], look: [0, 3.0, -6], fov: 58 },
  { t: 47.0, pos: [0.0, 5.0, 12.5], look: [0, 3.4, -12], fov: 60 },
];
export const S11 = ({ t, f }: Ctx) => {
  const look = t < 44.9 ? HV[0] : t < 45.6 ? HV[1] : HV[2], flash = Math.max(Math.exp(-(t - 44.9) * 8) * (t > 44.9 ? 1 : 0), Math.exp(-(t - 45.6) * 8) * (t > 45.6 ? 1 : 0)), q = seg(t, 45.33, 45.7, Easing.out(Easing.back(2.2)));
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#ffe0c0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#2a1a5a" bottom="#ffb070" glowAt={[0.9, "rgba(255,210,120,1)"]} stars={0.4} t={t} />
    <Surface p={[0, -0.05, -14]} s={[120, 90]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a5a3a" b="#3a5a3a" />
    <Surface p={[0, 0.01, -14]} s={[3.4, 70]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#c8b898" b="#b8a888" unit={1.2} />
    {[1, 2, 3].map((i) => <Person key={i} p={[Math.sin(i * 2) * 1.2, 0, -3 - i * 4]} h={3.6 - i * 0.2} look={{ ...HV[(i + 2) % HV.length], skin: "#cfd8f0", body: ["#9ab8e0", "#b8a8e8", "#a8d8e0"][i - 1] }} f={f + i * 5} pose={{ mood: "smile", lookX: 0, walk: t * 2, speed: 0.15 }} />)}
    <Sign p={[3.6, 7.6, -14]} w={3.6} h={1.1} text="+10 YEARS" size={56} bg="#c0182e" fg="#fff" k={seg(t, 43.81, 44.1, Easing.out(Easing.back(2.6)))} />
    <Person p={[0, 0, 1.2]} h={3.9} look={look} f={f} pose={{ mood: "smile", lookX: 0, armR: [0.3, 0.55], armRK: 0.6, squash: flash > 0.3 ? -0.05 : 0 }} />
    {flash > 0.02 ? <Glow p={[0, 2.6, 1.8]} r={3.4} color="rgba(255,255,255,1)" o={0.9 * flash} /> : null}
    <group position={[1.2, 0, 1.6]} scale={Math.max(0.001, seg(t, 45.13, 45.8))}><Cyl p={[0, 0.3, 0]} rt={0.05} h={0.6} color="#3fb84a" line={2} /><Ball p={[-0.2, 0.6, 0]} r={0.2} color="#4fd85a" s={[1.4, 0.6, 1]} ink={0.04} /><Ball p={[0.2, 0.7, 0]} r={0.2} color="#4fd85a" s={[1.4, 0.6, 1]} ink={0.04} /></group>
    <Sign p={[0, 8.6, -8]} w={4.4 * q + 0.001} h={4.4 * q + 0.001} text="?" size={360} fg="#ffd36a" bg="#14081e" />
    <Glow p={[0, 5, -14]} r={12} color="rgba(255,230,160,1)" o={0.4} /><Dust t={t} area={[8, 6, 8]} color="rgba(255,230,170,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11 };
