import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES, tintFor } from "./Alert";
import { Captions } from "../Main";
export const ACUTS = [0, 3.0, 6.0, 10.2, 15.9, 19.4, 24.4, 28.1, 30.0, 35.0, 37.4, 41.0, 46.0, 51.9];
const BG = ["#cfe8ff", "#0e1a3a", "#10183a", "#e8f2ff", "#0c2a22", "#7aa8d8", "#3a1660", "#1a1424", "#2a1a3a", "#c2185b", "#7a8a9a", "#2a3a5a", "#1c2440"];
const TR: Trans[] = ["ghost", "whip", "ghost", "zoom", "flash", "ghost", "whip", "flash", "ghost", "zoom", "flash", "ghost", "ghost"];
export const AlertMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 13 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={ACUTS[i]} end={ACUTS[i + 1]} bg={BG[i]} trans={TR[i]} tint={tintFor(i)}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
