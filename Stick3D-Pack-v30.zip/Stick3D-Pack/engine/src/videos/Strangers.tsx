// EVERY STRANGER HAS A STORY — 9 scenes (Epley & Schroeder 2014 commuter study, kept generic).
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Calendar } from "../style/kit";
import { Glow, Dust, WindowCity } from "../style/props";
import { Cam, Building, StreetLamp } from "../style/extra";
import { Sky, CrowdField } from "../style/medieval";
import { Heart } from "../style/studio2";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
/** lift subjects above the caption band (captions sit at ~69% of frame height) */
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.6, q.pos[2] + 0.8] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const you = mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008", { glasses: true });
const stranger = mk("#8d5a3a", "#2f8cff", "blazer", "bob", "#2a1a10", { shirt: "#fff" });
const greyed = mk("#a8a8b0", "#7a7a88", "blazer", "bob", "#55555e", { shirt: "#c8c8d0" });
const sci = (i: number): Look => mk(["#f3d3b2", "#c68e62"][i], "#f4f4f4", "shirt", i ? "short" : "swept", "#3b2a1a", { glasses: true, badge: "#2f8cff" });
const extras: Look[] = [mk("#f3d3b2", "#e5233a", "hoodie", "swept", "#7a4a20"), mk("#c68e62", "#2fd4a0", "shirt", "short", "#111"), mk("#e8b88c", "#9a5ad8", "blazer", "bob", "#c08a3a", { shirt: "#fff" })];
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Bubble: React.FC<{ p: V3; w: number; h: number; text: string; k: number; col?: string; size?: number }> = ({ p, w, h, text, k, col = "#14141c", size = 44 }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k, h * k]} px={[Math.round(w * 100), Math.round(h * 100)]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 34, 26); c.fill(); c.stroke(); c.beginPath(); c.moveTo(W * 0.3, H - 30); c.lineTo(W * 0.22, H - 4); c.lineTo(W * 0.42, H - 30); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.fillRect(W * 0.3 - 2, H - 36, W * 0.12 + 4, 8); c.fillStyle = col; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, (H - 28) / 2 + 2); }} />
);
const Sidewalk: React.FC<{ t: number }> = ({ t }) => (<>
  <Sky p={[0, 26, -40]} s={[200, 90]} top="#7ab0e8" bottom="#ffe8c8" />
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#b8b8c4" b="#a8a8b6" unit={1.4} />
  {[[-6.2, 9, "#c87a5a"], [-3.2, 12, "#6a7aa8"], [-0.2, 10, "#8aa06a"], [2.8, 13, "#a86a8a"], [5.8, 9, "#5a8aa0"]].map(([x, h, col], i) => <Building key={i} p={[x as number, 0, -7]} s={[2.8, h as number, 2.4]} color={col as string} seed={i + 2} lit={0.2} />)}
  <StreetLamp p={[-4.4, 0, -3.6]} /><StreetLamp p={[4.4, 0, -3.6]} flip />
</>);
/** commuter train interior */
const Train: React.FC<{ t: number; dusk?: boolean }> = ({ t, dusk }) => (<>
  <Surface p={[0, 0, 0]} s={[30, 20]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#5a6070" b="#525868" unit={1.2} />
  <Box p={[0, 4, -3.2]} s={[20, 8, 0.3]} color="#c8ccd8" line={3} />
  {[-5.2, -1.7, 1.8, 5.3].map((x, i) => <WindowCity key={i} p={[x, 4.4, -3.0]} s={[3.0, 2.2]} dusk={dusk} />)}
  {/* city streaking past */}
  {Array.from({ length: 6 }, (_, i) => { const x = ((i * 3.3 - t * 9) % 20 + 20) % 20 - 10; return <Box key={i} p={[x, 4.4, -2.9]} s={[0.12, 2.0, 0.02]} color="rgba(255,255,255,1)" line={0} />; })}
  <Box p={[0, 1.0, -2.4]} s={[20, 0.3, 1.2]} color="#2f6ad8" line={3} /><Box p={[0, 1.8, -2.9]} s={[20, 1.4, 0.2]} color="#2f6ad8" line={3} />
  {[-3.6, 0, 3.6].map((x, i) => <Cyl key={i} p={[x, 4, 0.8]} rt={0.07} h={8} color="#c0c4d0" line={2} />)}
  <Box p={[0, 7.4, 0.8]} s={[20, 0.12, 0.12]} color="#c0c4d0" line={2} />
</>);

/* ============ S1 0 – 3.86  hook: crowd, everyone has a "?" ============ */
export const S1 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={low([{ t: 0, pos: [0, 4.0, 15], look: [0, 3.0, 0], fov: 56 }, { t: 4.0, pos: [0, 3.8, 12.5], look: [0, 3.0, 0], fov: 54 }])} />
  <Lights warm="#fff0d8" />
  <Sidewalk t={t} />
  <CrowdField n={30} t={t} rate={4} at={(i) => [-7 + (i % 10) * 1.5 + ((t * (i % 2 ? 0.8 : -0.8)) % 1.5), 0, -3 - Math.floor(i / 10) * 0.9] as V3} size={1.0} />
  {[you, stranger, ...extras].map((lk, i) => { const x = -3.4 + i * 1.7, k = seg(t, 2.03 + i * 0.12, 2.35 + i * 0.12, back); return <React.Fragment key={i}>
    <Person p={[x + Math.sin(t + i) * 0.1, 0, 1.4 + (i % 2) * 0.8]} h={3.2} look={lk} f={f + i * 4} pose={{ mood: "deadpan", walk: t * 3 + i, speed: 0.5, flip: i % 2 === 1 }} />
    <Bubble p={[x, 4.6 + (i % 2) * 0.4, 1.6]} w={1.0} h={1.0} text="?" k={k} col="#e5233a" size={60} /></React.Fragment>; })}
</>);

/* ============ S2 3.86 – 9.43  the stranger's hidden life ============ */
export const S2 = ({ t, f }: Ctx) => {
  const pass = seg(t, 3.86, 5.4, ease);
  const items: [string, number, V3, string][] = [["CHILDHOOD", 5.68, [-2.0, 7.4, 0.5], "#2fa86a"], ["MEMORIES", 6.43, [2.0, 7.0, 0.5], "#2f8cff"], ["FEARS", 7.14, [-2.2, 5.4, 0.5], "#6a3ad8"], ["DREAMS", 7.79, [2.2, 5.0, 0.5], "#ff7a29"]];
  return (<>
    <Cam t={t} keys={low([{ t: 3.7, pos: [0, 4.4, 14], look: [0, 4.0, 0], fov: 56 }, { t: 9.6, pos: [0, 4.6, 12], look: [0, 4.6, 0], fov: 54 }])} />
    <Lights warm="#fff0d8" />
    <Sidewalk t={t} />
    <Person p={[lerp(-3.5, -1.2, pass), 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: "deadpan", walk: pass < 1 ? t * 3 : undefined, speed: pass < 1 ? 0.5 : 0, lookX: -0.4 }} />
    <Person p={[lerp(3.5, 1.4, pass), 0, 1.4]} h={3.4} look={stranger} f={f + 4} pose={{ mood: t > 7.14 && t < 7.79 ? "worry" : "smile", walk: pass < 1 ? t * 3 : undefined, speed: pass < 1 ? 0.5 : 0, flip: true, lookX: 0.4 }} />
    <Glow p={[1.4, 2.4, 1.6]} r={3} color="rgba(255,220,140,1)" o={0.45 * seg(t, 5.5, 6.0)} />
    {items.map(([txt, at, p, col], i) => <Sign key={i} p={p} w={2.8} h={0.75} text={txt} k={seg(t, at, at + 0.3, back)} size={38} bg={col} fg="#fff" />)}
    <Sign p={[0, 7.6, 0.5]} w={1.4} h={1.4} text="?" k={seg(t, 8.42, 8.7, back)} size={110} bg="#14141c" fg="#ff5a8a" />
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,240,210,.8)" />
  </>);
};

/* ============ S3 9.43 – 15.75  2014 study on Chicago trains and buses ============ */
export const S3 = ({ t, f }: Ctx) => {
  const yr = seg(t, 9.54, 9.9, back), chi = seg(t, 12.76, 13.1, back), awf = seg(t, 15.2, 15.5, back);
  return (<>
    <Cam t={t} keys={low([{ t: 9.2, pos: [0, 4.0, 13.5], look: [0, 3.4, 0], fov: 56 }, { t: 12.2, pos: [0, 4.0, 13], look: [0, 3.4, 0], fov: 56 }, { t: 15.9, pos: [0.4, 3.8, 11.5], look: [0.2, 3.4, 0], fov: 54 }])} />
    <Lights warm="#f0f4ff" />
    <Train t={t} />
    <Calendar p={[-2.6, 6.4, -2.6]} month="YEAR" day="2014" s={1.6 * yr + 0.001} />
    {[0, 1].map((i) => <React.Fragment key={i}><Person p={[-1.6 + i * 3.4, 0, 1.4]} h={3.6} look={sci(i)} f={f + i * 5} pose={{ mood: "smile", armR: [0.3, 0.55], armRK: seg(t, 10.8, 11.2), lookX: i ? -0.4 : 0.4, flip: i === 1 }} />
      <Box p={[-1.6 + i * 3.4 + (i ? -0.5 : 0.5), 2.1, 1.7]} s={[0.55, 0.75, 0.05]} color="#c9a870" line={2} /></React.Fragment>)}
    <Sign p={[1.8, 6.6, -2.0]} w={3.0} h={0.85} text="CHICAGO" k={chi} size={50} bg="#c0182e" fg="#fff" face={false} />
    <Sign p={[0, 5.0, 1.8]} w={3.0} h={0.9} text="AWFUL?!" k={awf} size={56} bg="#fff" fg="#e5233a" />
  </>);
};

/* ============ S4 15.75 – 19.02  "start a conversation with the stranger beside them" ============ */
export const S4 = ({ t, f }: Ctx) => {
  const turn = seg(t, 16.45, 16.9), hi = seg(t, 16.74, 17.1, back), nerv = seg(t, 17.75, 18.2);
  return (<>
    <Cam t={t} keys={low([{ t: 15.6, pos: [0, 3.8, 11], look: [0, 3.2, 0], fov: 54 }, { t: 19.2, pos: [0, 3.6, 9.5], look: [0, 3.2, 0], fov: 52 }])} />
    <Lights warm="#f0f4ff" />
    <Train t={t} />
    <Person p={[-1.3, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: nerv > 0.5 ? "worry" : "smile", lookX: lerp(-0.2, 0.6, turn), sweat: nerv > 0.5 ? 1 : 0, nerv: 0.3 * nerv, armR: [0.3, 0.75], armRK: turn }} />
    <Person p={[1.4, 0, 1.0]} h={3.4} look={stranger} f={f + 4} pose={{ mood: "deadpan", flip: true, lookX: 0.2 }} />
    <Bubble p={[-1.0, 5.4, 1.2]} w={1.9} h={1.2} text="hi…?" k={hi} size={50} />
    <Sign p={[0, 7.0, 0.5]} w={4.6} h={0.9} text="TALK TO A STRANGER" k={seg(t, 17.75, 18.05, back)} size={40} bg="#ff7a29" fg="#fff" />
  </>);
};

/* ============ S5 19.02 – 24.37  predictions: ignored, silence better ============ */
export const S5 = ({ t, f }: Ctx) => {
  const bad = seg(t, 20.19, 20.5, back), ign = seg(t, 21.69, 22.0, Easing.out(Easing.back(3.2))), sil = seg(t, 23.05, 23.4, back);
  return (<>
    <Cam t={t} keys={low([{ t: 18.8, pos: [0, 4.2, 12.5], look: [0, 4.0, 0], fov: 56 }, { t: 24.5, pos: [0, 4.4, 11.5], look: [0, 4.4, 0], fov: 54 }])} />
    <Lights warm="#d8dcf0" />
    <Train t={t} dusk />
    <Person p={[1.2, 0, 1.2]} h={3.4} look={you} f={f} pose={{ mood: "worry", arms: "chest", armK: seg(t, 19.3, 19.8), lookX: 0.3, hunch: 0.2 }} />
    {/* imagined scene in a thought cloud */}
    <CanvasPlane p={[0, 6.4, 0.6]} s={[4.4 * bad + 0.001, 2.6 * bad + 0.001]} px={[440, 260]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 60); c.fill(); c.stroke();
      const head = (x: number, mood: number) => { c.fillStyle = "#e8c8a8"; c.beginPath(); c.arc(x, 110, 42, 0, 7); c.fill(); c.stroke(); c.fillStyle = INK; c.beginPath(); c.arc(x - 14, 100, 5, 0, 7); c.arc(x + 14, 100, 5, 0, 7); c.fill(); c.beginPath(); c.arc(x, 135 + mood * 10, 14, mood > 0 ? Math.PI * 1.15 : 0.15, mood > 0 ? Math.PI * 1.85 : Math.PI - 0.15); c.stroke(); };
      head(140, 1); head(300, 1); c.fillStyle = "#e5233a"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.fillText("AWKWARD…", W / 2, 215); }} />
    <Sign p={[0, 6.6, 2.0]} w={3.6} h={1.0} text="IGNORED" k={ign} size={64} bg="#e5233a" fg="#fff" />
    <Sign p={[0, 4.6, 2.2]} w={4.4} h={0.9} text="SILENCE > TALK" k={sil} size={48} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S6 24.37 – 30.75  they tried it: talkers had a better ride ============ */
export const S6 = ({ t, f }: Ctx) => {
  const talk = seg(t, 24.7, 25.3), chart = seg(t, 26.53, 26.9, back), bars = seg(t, 27.26, 28.2, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 24.2, pos: [0, 4.2, 12.5], look: [0, 4.0, 0], fov: 56 }, { t: 30.9, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 55 }])} />
    <Lights warm="#fff0d8" />
    <Train t={t} />
    <Person p={[-1.2, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: talk > 0.5 ? "grin" : "smile", lookX: 0.6, armR: [0.35, 0.6], armRK: 0.5 + 0.5 * Math.sin(t * 6) * talk }} />
    <Person p={[1.3, 0, 1.0]} h={3.4} look={stranger} f={f + 4} pose={{ mood: talk > 0.5 ? "grin" : "deadpan", flip: true, lookX: 0.6 }} />
    {talk > 0.3 ? Array.from({ length: 5 }, (_, i) => { const u = ((t - 24.7) * 0.5 + i / 5) % 1; return <Heart key={i} p={[Math.sin(i * 2.3) * 1.0, 4.0 + u * 2.2, 1.4]} s={0.45} />; }) : null}
    <CanvasPlane p={[0, 6.8, 2.4]} s={[4.0 * chart + 0.001, 2.2 * chart + 0.001]} px={[460, 220]} draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(4, 4, W - 8, H - 8, 18); c.fill(); c.stroke();
      c.fillStyle = "#14141c"; c.font = "900 26px Inter, Arial"; c.textAlign = "left"; c.fillText("PLEASANT RIDE", 20, 40);
      c.font = "900 24px Inter, Arial"; c.fillText("TALKED", 20, 100); c.fillText("SILENT", 20, 170);
      c.fillStyle = "#2fd46a"; c.fillRect(140, 75, 290 * bars, 36); c.fillStyle = "#9a9aa8"; c.fillRect(140, 145, 170 * bars, 36); c.strokeStyle = INK; c.lineWidth = 3; c.strokeRect(140, 75, 290 * bars, 36); c.strokeRect(140, 145, 170 * bars, 36); }} />
  </>);
};

/* ============ S7 30.75 – 34.08  the stranger turned out to be a person with a story ============ */
export const S7 = ({ t, f }: Ctx) => {
  const color = seg(t, 32.14, 32.7), book = seg(t, 33.47, 33.8, back), open = seg(t, 33.6, 34.0, ease);
  return (<>
    <Cam t={t} keys={low([{ t: 30.6, pos: [0, 4.0, 11.5], look: [0, 3.8, 0], fov: 54 }, { t: 34.2, pos: [0, 4.2, 10], look: [0, 4.2, 0], fov: 52 }])} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -40]} s={[200, 90]} top="#ffb070" bottom="#ffe8c0" glowAt={[0.8, "rgba(255,220,140,1)"]} />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#b8b8c4" b="#a8a8b6" unit={1.4} />
    <Person p={[0, 0, 1.0]} h={3.6} look={color > 0.5 ? stranger : greyed} f={f} pose={{ mood: color > 0.5 ? "grin" : "deadpan", arms: color > 0.5 ? "up" : undefined, armK: color }} />
    <Glow p={[0, 2.4, 1.4]} r={4} color="rgba(255,220,140,1)" o={0.6 * color} />
    <Sign p={[0, 7.0, 0.5]} w={3.4} h={0.85} text="DREADED" k={seg(t, 31.56, 31.9, back) * (1 - color)} size={52} bg="#6a6a7a" fg="#fff" />
    {/* the opened story book */}
    <group position={[0, 5.6, 1.6]} scale={[0.85 * book + 0.001, 0.85 * book + 0.001, 0.85 * book + 0.001]}>
      <group rotation={[0, -open * 0.5, 0]}><Box p={[-0.85, 0, 0]} s={[1.7, 2.2, 0.12]} color="#c0402e" line={3} /></group>
      <group rotation={[0, open * 0.5, 0]}><Box p={[0.85, 0, 0]} s={[1.7, 2.2, 0.12]} color="#c0402e" line={3} /></group>
      <CanvasPlane p={[0, 0, 0.12]} s={[3.0 * open + 0.001, 1.9]} px={[300, 190]} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.strokeStyle = "#c8b8a0"; c.lineWidth = 4; for (let y = 50; y < H - 20; y += 22) { c.beginPath(); c.moveTo(20, y); c.lineTo(W / 2 - 14, y); c.moveTo(W / 2 + 14, y); c.lineTo(W - 20, y); c.stroke(); } c.fillStyle = "#c0402e"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.fillText("A STORY", W / 2, 34); }} />
    </group>
    <Dust t={t} area={[8, 6, 4]} color="rgba(255,240,210,.8)" />
  </>);
};

/* ============ S8 34.08 – 39.57  "mistakenly seeking solitude" ============ */
export const S8 = ({ t, f }: Ctx) => {
  const lab = seg(t, 35.03, 35.4, back), walls = seg(t, 36.99, 37.6, Easing.out(Easing.quad)), better = seg(t, 38.82, 39.1, back);
  return (<>
    <Cam t={t} keys={low([{ t: 33.9, pos: [0, 4.4, 13], look: [0, 4.0, 0], fov: 56 }, { t: 39.7, pos: [0.4, 4.6, 12.5], look: [0.4, 4.0, 0], fov: 56 }])} />
    <Lights warm="#e8e4f8" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#cfd4e4" b="#bcc2d4" unit={1.6} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#4a3a6a" line={3} />
    <Person p={[-1.6, 0, 1.0]} h={3.4} look={you} f={f} pose={{ mood: "deadpan", flip: true, lookX: -0.6, arms: "chest", armK: walls }} />
    {/* walls it builds around itself */}
    {[[-2.9, 0], [-0.3, 0]].map(([x], i) => <Box key={i} p={[x, 1.5 * walls + 0.01, 1.0]} s={[0.25, 3.0 * walls + 0.02, 2.4]} color="#8a8aa0" line={3} />)}
    <Box p={[-1.6, 1.5 * walls + 0.01, -0.2]} s={[2.8, 3.0 * walls + 0.02, 0.25]} color="#8a8aa0" line={3} />
    {/* the thing that would help: a warm open door with people */}
    <group position={[2.6, 0, -0.6]}>
      <Box p={[0, 2.0, -0.2]} s={[2.4, 4.0, 0.25]} color="#3a2a5a" line={3} /><Box p={[0, 1.8, -0.05]} s={[1.8, 3.6, 0.05]} color="#ffd36a" line={2} />
      <Glow p={[0, 2.0, 0.4]} r={3.4} color="rgba(255,210,120,1)" o={0.55} />
      {extras.slice(0, 2).map((lk, i) => <Person key={i} p={[-0.4 + i * 0.8, 0, 0.3]} h={2.6} look={lk} f={f + i * 6} pose={{ mood: "grin", arms: i ? "up" : undefined, armK: 0.6 }} />)}
    </group>
    <Sign p={[2.6, 5.0, 0.4]} w={3.0} h={0.8} text="FEEL BETTER" k={better} size={42} bg="#2fd46a" fg="#14141c" />
    <CanvasPlane p={[0, 7.2, 0.6]} s={[5.6 * lab + 0.001, 1.8 * lab + 0.001]} px={[560, 180]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 20); c.fill(); c.stroke(); c.fillStyle = "#ffe14a"; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.fillText("MISTAKENLY SEEKING", W / 2, 72); c.fillStyle = "#fff"; c.fillText("SOLITUDE", W / 2, 132); }} />
  </>);
};

/* ============ S9 39.57 – end  "who did you walk past today?" ============ */
export const S9 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={low([{ t: 39.4, pos: [0, 4.4, 14], look: [0, 3.2, 0], fov: 56 }, { t: 43.0, pos: [0, 4.0, 12], look: [0, 3.0, 0], fov: 54 }])} />
  <Lights warm="#ffe8c8" />
  <Sidewalk t={t} />
  <CrowdField n={30} t={t} rate={4} at={(i) => [-7 + (i % 10) * 1.5, 0, -3 - Math.floor(i / 10) * 0.9] as V3} size={1.0} />
  {[stranger, ...extras].map((lk, i) => { const x = -3.2 + i * 2.1; return <React.Fragment key={i}>
    <Person p={[x, 0, 1.0 + (i % 2) * 0.8]} h={3.2} look={lk} f={f + i * 4} pose={{ mood: "smile", walk: t * 3 + i, speed: 0.5, flip: i % 2 === 1 }} />
    <Glow p={[x, 2.0, 1.4]} r={2} color="rgba(255,220,140,1)" o={0.4 * seg(t, 41.46 + i * 0.1, 41.9 + i * 0.1)} /></React.Fragment>; })}
  <Person p={[0, 0, 3.0]} h={3.4} look={you} f={f} pose={{ mood: "smile", lookX: 0, armR: [0.3, 0.75], armRK: seg(t, 40.1, 40.6) }} />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
