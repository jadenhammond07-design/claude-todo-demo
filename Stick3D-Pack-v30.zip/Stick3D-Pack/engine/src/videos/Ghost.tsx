// THE GHOST ARMY — 14 scenes. Cartoon-safe WWII history; no violence, no insignia except a white star.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Chair, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Barrier, Curtain } from "../style/extra";
import { Sky, Timber, Banner, Barrel, Crate, CrowdField, Flame, danceBeat } from "../style/medieval";
import { Speaker } from "../style/studio";
import { Heart } from "../style/studio2";
import { Tank, HalfTrack, RadioSet, Easel } from "../style/mil";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#3a2a1a", ...extra });
const gi = (i: number): Look => mk(["#f3d3b2", "#e0b48c", "#8d5a3a", "#fbe3c8", "#c98e62"][i % 5], "#6a7a3a", "shirt", (["short", "bob", "swept"] as const)[i % 3], ["#3b2a1a", "#111", "#7a4a1c"][i % 3], { hat: "#5a6a3a" });
const german = mk("#f3d3b2", "#6a7078", "shirt", "short", "#3b2a1a", { hat: "#4a4a52", shoe: "#222" });
const artist = (i: number): Look => mk(["#f3d3b2", "#c98e62"][i % 2], "#6a7a3a", "shirt", "swept", "#3b2a1a", { hat: "#c0182e" });
const engineer = mk("#e0b48c", "#6a7a3a", "hoodie", "short", "#111", { glasses: true, hat: "#5a6a3a" });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
const Ground: React.FC<{ a?: string }> = ({ a = "#7ab84a" }) => <Surface p={[0, -0.05, -14]} s={[140, 100]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={a} b={a} />;
const Hedge: React.FC<{ p: V3; w?: number }> = ({ p, w = 8 }) => (<group position={p}><Box p={[0, 0.7, 0]} s={[w, 1.4, 1.0]} color="#3f8a3a" line={3} />{Array.from({ length: Math.floor(w / 1.4) }, (_, i) => <Ball key={i} p={[-w / 2 + 0.7 + i * 1.4, 1.5, 0]} r={0.6} color={i % 2 ? "#4a9a42" : "#3a8a38"} ink={0.05} />)}</group>);
const Rings: React.FC<{ p: V3; t: number; t0: number; n?: number }> = ({ p, t, t0, n = 4 }) => <>{t > t0 ? Array.from({ length: n }, (_, i) => { const u = ((t - t0) * 1.1 + i / n) % 1; return <CanvasPlane key={i} p={p} s={[1 + u * 7, 1 + u * 7]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = `rgba(255,255,255,${1 - u})`; c.lineWidth = 12; c.beginPath(); c.arc(100, 100, 86, -0.9, 0.9); c.stroke(); }} />; }) : null}</>;

/* ============ S1 0 – 2.55  "Summer 1944, France." ============ */
const K1: Key[] = [
  { t: 0, pos: [9, 13, 18], look: [0, 1, -8], fov: 60 },
  { t: 2.6, pos: [1.5, 3.8, 11], look: [0, 3.2, -8], fov: 56 },
];
export const S1 = ({ t, f }: Ctx) => {
  const pop = seg(t, 0.2, 0.55, Easing.out(Easing.back(2.4))), pop2 = seg(t, 1.77, 2.1, Easing.out(Easing.back(2.4)));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff4d0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#5aa8ff" bottom="#ffeec8" glowAt={[0.6, "rgba(255,230,160,1)"]} />
    <Ground />
    {[0, 1, 2, 3].map((i) => <Box key={i} p={[-16 + i * 11, 0, -12 - (i % 2) * 6]} s={[9, 0.08, 7]} color={i % 2 ? "#d8b84a" : "#9ac85a"} line={0} />)}
    <Hedge p={[-6, 0, -6]} w={10} /><Hedge p={[7, 0, -9]} w={12} /><Hedge p={[-8, 0, -16]} w={9} />
    <Timber p={[-4.5, 0, -12]} s={[5.4, 3.8, 4]} wall="#e8dcc0" roof="#a8442c" lit={0} seed={2} /><Timber p={[3.8, 0, -16]} s={[4.4, 3.4, 3.4]} wall="#d8c8a8" roof="#8a3a2a" seed={4} />
    {[-9, -2.4, 6.4, 11].map((x, i) => <group key={x} position={[x, 0, -10 - (i % 2) * 4]}><Cyl p={[0, 2.4, 0]} rt={0.18} rb={0.26} h={4.8} color="#6a4426" line={2} /><Ball p={[0, 5.2, 0]} r={1.0} color="#3f8a3a" s={[0.8, 2.4, 0.8]} ink={0.06} /></group>)}
    {Array.from({ length: 30 }, (_, i) => <Ball key={i} p={[-8 + ((i * 37) % 160) / 10, 0.12, -2 - ((i * 53) % 90) / 10]} r={0.12} color={i % 3 ? "#e5233a" : "#fff"} ink={0.02} />)}
    <group position={[5.6, 0, 1]}><Cyl p={[0, 3, 0]} rt={0.07} h={6} color="#8a8a96" line={2} /><Box p={[0.5, 5.4, 0]} s={[0.4, 0.8, 0.04]} color="#1f4ad8" line={1} /><Box p={[0.9, 5.4, 0]} s={[0.4, 0.8, 0.04]} color="#f4f4f4" line={1} /><Box p={[1.3, 5.4, 0]} s={[0.4, 0.8, 0.04]} color="#e5233a" line={1} /></group>
    <Sign p={[-0.4, 6.4, 2]} w={4.4 * pop + 0.001} h={1.2 * pop + 0.001} text="SUMMER 1944" size={62} bg="#1f3a6a" fg="#fff" /><Sign p={[0.6, 4.6, 2]} w={3.0 * pop2 + 0.001} h={1.0 * pop2 + 0.001} text="FRANCE" size={64} />
    <Dust t={t} area={[10, 8, 6]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S2 2.55 – 6.2  "A German scout spots an American tank column across the field." ============ */
const K2: Key[] = [
  { t: 2.4, pos: [-2.0, 2.6, 8.0], look: [0.4, 1.6, -10], fov: 56 },
  { t: 5.0, pos: [-1.0, 2.4, 6.4], look: [1.0, 1.6, -12], fov: 52 },
  { t: 6.4, pos: [-0.6, 2.4, 5.8], look: [1.0, 1.8, -12], fov: 48 },
];
export const S2 = ({ t, f }: Ctx) => {
  const spot = seg(t, 4.46, 4.75, Easing.out(Easing.back(2.6))), lift = seg(t, 3.0, 3.6, ease);
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff4d0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#5aa8ff" bottom="#ffeec8" />
    <Ground />
    <Box p={[3, 0, -12]} s={[40, 0.06, 14]} color="#d8b84a" line={0} />
    <Hedge p={[-1.2, 0, 2.4]} w={7} /><Hedge p={[9, 0, -22]} w={16} />
    {[0, 1, 2, 3].map((i) => <Tank key={i} p={[-4 + i * 4.6, 0, -13]} s={0.7} />)}
    {[0, 1, 2, 3, 4, 5].map((i) => <Person key={i} p={[-5 + i * 3.2, 0, -10.6]} h={2.2} look={gi(i)} f={f + i * 5} pose={{ mood: "smile", lookX: 0.3 }} />)}
    <Person p={[-0.8, 0, -0.4]} h={3.4} look={german} f={f} pose={{ mood: "deadpan", hunch: 0.3 * (1 - lift), armR: [0.12, lerp(0.35, 0.62, lift)], armRK: 1, armL: [-0.12, lerp(0.35, 0.62, lift)], armLK: 1, lookX: 0.4 }} />
    <FaceGroup p={[-0.8, 0, -0.4]}>{[-0.13, 0.13].map((x) => <Cyl key={x} p={[x, 3.4 * lerp(0.35, 0.62, lift) + 0.02, 0.28]} rt={0.1} h={0.3} color="#2a2a30" line={2} rot={[Math.PI / 2, 0, 0]} />)}</FaceGroup>
    <Sign p={[-0.8, 4.6, -0.4]} w={1.0 * spot + 0.001} h={1.2 * spot + 0.001} text="!" size={90} fg="#fff" bg="#e5233a" />
    <Dust t={t} area={[10, 6, 6]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S3 6.2 – 10.6  "The tanks are rubber, inflated by air, light enough for four men to carry." ============ */
const K3: Key[] = [
  { t: 6.0, pos: [-2.0, 3.0, 10.0], look: [0, 1.8, 0], fov: 56 },
  { t: 8.5, pos: [0.0, 3.4, 11.0], look: [0, 2.4, 0], fov: 56 },
  { t: 10.8, pos: [2.0, 3.6, 11.5], look: [1.2, 3.0, 0], fov: 56 },
];
export const S3 = ({ t, f }: Ctx) => {
  const puff = t < 7.4 ? 0.12 : lerp(0.12, 1, Easing.out(Easing.back(1.8))(clamp((t - 7.5) / 0.9))), wob = t > 6.9 && t < 7.4 ? Math.sin((t - 6.9) * 40) * Math.exp(-(t - 6.9) * 6) : 0;
  const lift = seg(t, 9.6, 10.1, Easing.out(Easing.cubic)), walk = seg(t, 10.0, 10.8, ease), tx = lerp(0, 1.8, walk);
  const air = Array.from({ length: 5 }, (_, i) => { const u = ((t * 2 + i / 5) % 1); return [-3.2 + u * 1.6, 1.0 + 0.4 * Math.sin(u * 6), 0.8] as V3; });
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#fff4d0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#5aa8ff" bottom="#ffeec8" />
    <Ground />
    <Hedge p={[0, 0, -6]} w={20} /><Barrel p={[-6.4, 0, -2]} /><Crate p={[6.6, 0, -2]} /><Crate p={[7.4, 0, -1.2]} s={0.8} />
    {/* air pump + hose */}
    <Box p={[-3.8, 0.6, 1.0]} s={[1.2, 1.2, 1.0]} color="#4a5a2a" line={3} /><Cyl p={[-3.8, 1.4, 1.0]} rt={0.12} h={0.8} color="#8a8a96" line={2} /><Box p={[-2.4, 0.2, 0.8]} s={[2.8, 0.12, 0.12]} color="#14141c" line={0} />
    {t > 7.3 && t < 8.7 ? air.map((a, i) => <Ball key={i} p={a} r={0.16} color="#fff" ink={0.03} />) : null}
    <Tank p={[tx, 0.2 + 3.1 * lift, 0]} s={1.0} puff={puff} wob={wob} color="#7a8a4a" />
    <Sign p={[0.4, 5.6, 0.6]} w={3.0 * seg(t, 6.9, 7.2, Easing.out(Easing.back(2.6))) + 0.001} h={1.0} text="RUBBER" size={64} fg="#fff" bg="#2a2a38" />
    <Sign p={[2.4, 6.9, 0.6]} w={3.4 * seg(t, 9.34, 9.7, Easing.out(Easing.back(2.6))) + 0.001} h={1.0} text="4 MEN" size={64} />
    {[-3.2, -2.4, 2.4, 3.2].map((x, i) => <Person key={i} p={[x + tx, 0, 0.6 + (i % 2) * 0.5]} h={3.7} look={gi(i)} f={f + i * 4} pose={{ mood: lift > 0.5 ? "grin" : "deadpan", walk: walk > 0 && walk < 1 ? tx * WALK : undefined, speed: walk > 0 && walk < 1 ? 0.5 : 0, armR: [0.3, 0.82 * lift], armRK: lift, armL: [-0.3, 0.82 * lift], armLK: lift, squash: lift > 0 ? -0.03 : 0 }} />)}
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S4 10.6 – 15.3  "Behind them, speakers on half-tracks blast the recorded roar of engines," ============ */
const K4: Key[] = [
  { t: 10.4, pos: [-6.0, 3.2, 10.0], look: [-1.5, 2.4, 0], fov: 58 },
  { t: 13.0, pos: [-0.5, 3.6, 10.5], look: [-1.0, 2.6, 0], fov: 56 },
  { t: 15.5, pos: [3.5, 3.8, 10.0], look: [-1.5, 2.6, 0], fov: 56 },
];
export const S4 = ({ t, f }: Ctx) => {
  const roar = seg(t, 14.0, 14.3, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff0d0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#6aa8ff" bottom="#ffeec8" />
    <Ground />
    {[0, 1, 2].map((i) => <Tank key={i} p={[-8 + i * 6.4, 0, -9]} s={0.8} puff={1} />)}
    <Hedge p={[0, 0, -14]} w={22} />
    <HalfTrack p={[-1.0, 0, 0]} s={1.3} t={t} />
    <Rings p={[-5.2, 3.2, 0.4]} t={t} t0={12.9} /><Rings p={[-5.2, 3.2, -0.4]} t={t} t0={13.3} n={3} />
    <Sign p={[-3.6, 7.4, 0.8]} w={5.0 * roar + 0.001} h={1.5 * roar + 0.001} text="VROOOM!" size={86} fg="#ffc23a" bg="#c0182e" />
    <Sign p={[2.8, 5.8, 1.0]} w={3.2 * seg(t, 13.43, 13.7, Easing.out(Easing.back(2.6))) + 0.001} h={0.9} text="RECORDED" size={46} fg="#fff" bg="#2a2a38" />
    <Person p={[3.6, 0, 2.6]} h={3.7} look={gi(2)} f={f} pose={{ mood: "grin", armR: [0.3, 0.6], armRK: 1, lookX: -0.4 }} />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S5 15.3 – 19.3  "while radio operators send fake messages in the style of real units." ============ */
const K5: Key[] = [
  { t: 15.1, pos: [-2.0, 3.4, 10.5], look: [0, 2.8, 0], fov: 58 },
  { t: 17.6, pos: [0.4, 3.6, 10.0], look: [0.4, 2.9, 0], fov: 54 },
  { t: 19.5, pos: [0.4, 3.6, 9.4], look: [0.4, 2.9, 0], fov: 52 },
];
const PATCH = ["#c0182e", "#1f6ad8", "#ffc23a", "#2fa86a", "#8a4fb8", "#ff7a29"];
export const S5 = ({ t, f }: Ctx) => {
  const match = seg(t, 17.7, 18.5);
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#7a5a3a" b="#6a4c30" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#5a6a3a" b="#5a6a3a" base="#3a4a22" /><SideWall x={-9} kind="plain" a="#4e5e30" b="#4e5e30" /><SideWall x={9} kind="plain" a="#4e5e30" b="#4e5e30" />
    <CanvasPlane p={[0.4, 5.4, -4.9]} s={[7, 3.4]} px={[700, 340]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#06120a"; c.fillRect(0, 0, W, H); c.strokeStyle = "rgba(61,255,122,.25)"; c.lineWidth = 2; for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(0, i * H / 6); c.lineTo(W, i * H / 6); c.stroke(); } const tr = (y: number, off: number, col: string, k: number) => { c.strokeStyle = col; c.lineWidth = 6; c.beginPath(); for (let x = 20; x < W - 20; x++) { const v = Math.sin(x * 0.06 + t * 8) * 30 * Math.sin(x * 0.011 + off * (1 - match)); x === 20 ? c.moveTo(x, y + v * k) : c.lineTo(x, y + v * k); } c.stroke(); }; tr(120, 2.2, "#3dff7a", 1); tr(240, 0, "#ff8a4a", 1); c.fillStyle = "#3dff7a"; c.font = "800 28px Inter, Arial"; c.fillText("REAL UNIT", 24, 40); c.fillStyle = "#ff8a4a"; c.fillText("GHOST ARMY", 24, 330); if (match > 0.8) { c.fillStyle = "#fff"; c.font = "900 40px Inter, Arial"; c.textAlign = "right"; c.fillText("SAME STYLE", W - 24, 40); } }} />
    <Box p={[-4.0, 0.5, -1.6]} s={[3.0, 1.0, 1.8]} color="#7a5a3a" line={3} /><RadioSet p={[-4.0, 1.0, -1.6]} t={t} s={1.1} /><Box p={[4.8, 0.5, -1.6]} s={[3.0, 1.0, 1.8]} color="#7a5a3a" line={3} /><RadioSet p={[4.8, 1.0, -1.6]} t={t + 1} s={1.1} />
    {PATCH.map((c2, i) => <CanvasPlane key={i} p={[-6.2 + i * 2.4, 2.4 + (i % 2) * 0.1, -4.8]} s={[0.9, 1.0]} px={[90, 100]} draw={(c, W, H) => { c.fillStyle = c2; c.strokeStyle = INK; c.lineWidth = 6; c.beginPath(); c.moveTo(6, 6); c.lineTo(W - 6, 6); c.lineTo(W - 6, H * 0.55); c.quadraticCurveTo(W / 2, H + 6, 6, H * 0.55); c.closePath(); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 40px Inter, Arial"; c.textAlign = "center"; c.fillText(String(i + 1), W / 2, 56); }} />)}
    {[0, 1, 2].map((i) => { const u = ((t * 0.7 + i / 3) % 1); return <Sign key={i} p={[lerp(4.8, 0.4, u), 3.6 + u * 2.2, -0.6]} w={1.9} h={0.6} text={["MOVE OUT", "HOLD", "ADVANCE"][i]} size={34} bg="#fffaf0" fg="#1a1a22" />; })}
    <Person p={[-1.8, 0, 1.4]} h={3.8} look={gi(1)} f={f} pose={{ mood: "deadpan", armR: [0.3, 0.45 + 0.04 * Math.sin(t * 22)], armRK: 1, lookX: -0.4 }} /><Sign p={[-1.8, 5.2, 1.4]} w={2.4} h={0.7} text="REAL UNIT" size={36} bg="#1fa850" fg="#fff" />
    <Person p={[2.8, 0, 1.4]} h={3.8} look={engineer} f={f + 4} pose={{ mood: "grin", armR: [0.3, 0.45 + 0.04 * Math.sin(t * 22 + 1)], armRK: 1, lookX: 0.4, flip: true }} /><Sign p={[2.8, 5.2, 1.4]} w={2.6} h={0.7} text="GHOST" size={36} bg="#ff7a29" fg="#fff" />
    <Lamp p={[7.4, 0, -3]} h={3.2} color="#ffe0a0" /><Dust t={t} area={[6, 5, 4]} color="rgba(255,240,200,.8)" />
  </>);
};

/* ============ S6 19.3 – 24.4  "The crew is just over a thousand artists, sound engineers, and radio men," ============ */
const K6: Key[] = [
  { t: 19.1, pos: [-4.5, 3.6, 11.0], look: [-4.0, 2.8, 0], fov: 58 },
  { t: 21.4, pos: [-3.0, 3.6, 11.0], look: [-3.4, 2.8, 0], fov: 56 },
  { t: 22.4, pos: [0.4, 3.6, 11.0], look: [0.4, 2.8, 0], fov: 56 },
  { t: 23.4, pos: [4.2, 3.6, 11.0], look: [4.4, 2.8, 0], fov: 56 },
  { t: 24.6, pos: [3.0, 4.2, 12.5], look: [2.0, 3.0, 0], fov: 58 },
];
export const S6 = ({ t, f }: Ctx) => {
  const a = seg(t, 21.11, 21.4, Easing.out(Easing.back(2.6))), b = seg(t, 22.0, 22.3, Easing.out(Easing.back(2.6))), c = seg(t, 22.94, 23.25, Easing.out(Easing.back(2.6))), n = seg(t, 20.53, 20.9, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K6} />
    <Lights warm="#fff4d0" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#5aa8ff" bottom="#ffeec8" />
    <Ground a="#8ab85a" />
    {[-9, -3, 3, 9].map((x, i) => <group key={x} position={[x, 0, -7]}><Box p={[0, 1.5, 0]} s={[4.6, 3.0, 3]} color="#7a8a4a" line={3} /><Box p={[0, 3.3, 0]} s={[3.6, 0.6, 2.6]} color="#6a7a3a" rot={[0, 0, 0]} line={3} /><Box p={[0, 1.0, 1.52]} s={[1.2, 2.0, 0.06]} color="#3a4a22" line={2} /></group>)}
    <CrowdField n={70} t={t} rate={3.2} at={(i) => [-12 + (i % 14) * 1.9, 0, -9.6 - Math.floor(i / 14) * 1.2] as V3} size={1.0} />
    <Sign p={[0.4, 7.4, 0]} w={4.2 * n + 0.001} h={1.1 * n + 0.001} text="1,000+ MEN" size={58} fg="#fff" bg="#1f3a6a" />
    {/* artists */}
    <Easel p={[-5.4, 0, 0.4]} draw={(cx, W, H) => { cx.fillStyle = "#fff"; cx.fillRect(0, 0, W, H); cx.fillStyle = "#6a7a3a"; cx.fillRect(30, 100, 130, 60); cx.fillStyle = "#14141c"; cx.fillRect(40, 70, 80, 30); cx.fillStyle = "#e5233a"; cx.beginPath(); cx.arc(140, 60, 20, 0, 7); cx.fill(); }} />
    <Person p={[-3.8, 0, 1.4]} h={3.8} look={artist(0)} f={f} pose={{ mood: "smile", armR: [0.34, 0.6 + 0.05 * Math.sin(t * 6)], armRK: 1, lookX: -0.5 }} />
    {/* sound engineers */}
    <Box p={[-0.4, 0.5, 0.6]} s={[1.8, 1.0, 1.0]} color="#4a5a2a" line={3} /><CanvasPlane p={[-0.4, 1.06, 0.6]} rot={[-Math.PI / 2, 0, 0]} s={[1.6, 0.8]} px={[160, 80]} draw={(cx, W, H) => { cx.fillStyle = "#14141c"; cx.fillRect(0, 0, W, H); for (const x of [40, 120]) { cx.save(); cx.translate(x, 40); cx.rotate(t * 5); cx.strokeStyle = "#c9d3e0"; cx.lineWidth = 5; cx.beginPath(); cx.arc(0, 0, 26, 0, 7); cx.moveTo(-26, 0); cx.lineTo(26, 0); cx.moveTo(0, -26); cx.lineTo(0, 26); cx.stroke(); cx.restore(); } }} />
    <Person p={[1.0, 0, 1.4]} h={3.8} look={engineer} f={f + 3} pose={{ mood: "smile", armR: [0.3, 0.5], armRK: 1, lookX: -0.4 }} />
    <Cyl p={[-1.8, 2.2, 0.8]} rt={0.04} h={3.2} color="#8a8a96" line={1} /><Ball p={[-1.8, 3.9, 0.8]} r={0.2} color="#2a2a30" />
    {/* radio men */}
    <Box p={[4.4, 0.5, 0.4]} s={[2.0, 1.0, 1.2]} color="#7a5a3a" line={3} /><RadioSet p={[4.4, 1.0, 0.4]} t={t} s={1.1} />
    <Person p={[6.0, 0, 1.4]} h={3.8} look={gi(3)} f={f + 6} pose={{ mood: "deadpan", armR: [0.3, 0.45 + 0.03 * Math.sin(t * 20)], armRK: 1, lookX: -0.5, flip: true }} />
    <Sign p={[-4.6, 6.2, 0.6]} w={3.0 * a + 0.001} h={0.9 * a + 0.001} text="ARTISTS" size={46} /><Sign p={[0.4, 6.2, 0.6]} w={3.8 * b + 0.001} h={0.9 * b + 0.001} text="SOUND ENGINEERS" size={34} /><Sign p={[5.2, 6.2, 0.6]} w={3.2 * c + 0.001} h={0.9 * c + 0.001} text="RADIO MEN" size={42} />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S7 24.4 – 28.9  "including future designer Bill Blass and painter Ellsworth Kelly." ============ */
const K7: Key[] = [
  { t: 24.2, pos: [-3.0, 3.6, 10.5], look: [-3.0, 2.8, 0], fov: 58 },
  { t: 26.2, pos: [0.0, 3.6, 10.5], look: [0, 2.8, 0], fov: 56 },
  { t: 27.4, pos: [3.2, 3.6, 10.0], look: [3.2, 2.8, 0], fov: 54 },
  { t: 29.0, pos: [3.0, 3.6, 9.6], look: [3.0, 2.8, 0], fov: 52 },
];
export const S7 = ({ t, f }: Ctx) => {
  const dress = clamp((t - 24.8) / 2.2), color = clamp((t - 26.7) / 1.8), t1 = seg(t, 25.10, 25.4, Easing.out(Easing.back(2.6))), t2 = seg(t, 26.64, 26.95, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#7a5a3a" b="#6a4c30" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#7a8a4a" b="#7a8a4a" base="#4a5a2a" /><SideWall x={-9} kind="plain" a="#6a7a3a" b="#6a7a3a" /><SideWall x={9} kind="plain" a="#6a7a3a" b="#6a7a3a" />
    <Easel p={[-3.6, 0, 0]} w={2.4} h={3.0} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 6; c.lineCap = "round"; c.lineJoin = "round"; const pts: [number, number][] = [[120, 40], [105, 90], [90, 110], [60, 230], [20, 290], [220, 290], [180, 230], [150, 110], [135, 90], [120, 40]]; c.beginPath(); const n = Math.floor(pts.length * dress); for (let i = 0; i <= Math.min(n, pts.length - 1); i++) i ? c.lineTo(pts[i][0], pts[i][1]) : c.moveTo(pts[i][0], pts[i][1]); c.stroke(); if (dress > 0.9) { c.fillStyle = "rgba(229,35,58,.5)"; c.fill(); c.strokeStyle = "#c9a032"; c.beginPath(); c.moveTo(92, 112); c.lineTo(148, 112); c.stroke(); } }} />
    <Person p={[-1.8, 0, 1.2]} h={3.8} look={mk("#f3d3b2", "#6a7a3a", "shirt", "swept", "#3b2a1a", { hat: "#5a6a3a" })} f={f} pose={{ mood: "smile", armR: [0.36, 0.62 + 0.05 * Math.sin(t * 7)], armRK: 1, lookX: -0.5 }} />
    <Sign p={[-1.0, 6.0, 1.0]} w={3.2 * t1 + 0.001} h={1.0 * t1 + 0.001} text="BILL BLASS" size={42} /><Sign p={[-1.0, 7.1, 1.0]} w={3.0 * t1 + 0.001} h={0.8 * t1 + 0.001} text="FUTURE DESIGNER" size={26} bg="#fff" fg="#14141c" />
    <Easel p={[3.4, 0, 0]} w={2.4} h={3.0} draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f6ad8"; c.fillRect(20, 20, 200 * clamp(color * 3), 140); c.fillStyle = "#ffc23a"; c.fillRect(20, 160, 100 * clamp(color * 3 - 1), 120); c.fillStyle = "#e5233a"; c.fillRect(120, 160, 100 * clamp(color * 3 - 2), 120); }} />
    <Person p={[5.2, 0, 1.2]} h={3.8} look={mk("#e0b48c", "#6a7a3a", "shirt", "short", "#111", { hat: "#c0182e" })} f={f + 4} pose={{ mood: "smile", flip: true, armR: [0.36, 0.62 + 0.05 * Math.sin(t * 6)], armRK: 1, lookX: 0.5 }} />
    <Sign p={[3.0, 6.0, 1.0]} w={3.8 * t2 + 0.001} h={1.0 * t2 + 0.001} text="ELLSWORTH KELLY" size={30} /><Sign p={[3.0, 7.1, 1.0]} w={2.2 * t2 + 0.001} h={0.8 * t2 + 0.001} text="PAINTER" size={30} bg="#fff" fg="#14141c" />
    <Box p={[0.6, 0.4, -3.4]} s={[2.6, 0.5, 1.2]} color="#c9a870" line={3} /><Box p={[7.2, 0.4, -3.4]} s={[2.6, 0.5, 1.2]} color="#c9a870" line={3} /><Lamp p={[-7.6, 0, -2]} h={3.2} color="#ffe0a0" /><Dust t={t} area={[8, 5, 4]} color="rgba(255,240,200,.8)" />
  </>);
};

/* ============ S8 28.9 – 31.5  "They are the Ghost Army. Across more than twenty operations," ============ */
const K8: Key[] = [
  { t: 28.7, pos: [0, 4.0, 13.0], look: [0, 3.6, 0], fov: 58 },
  { t: 30.2, pos: [0, 9.0, 10.0], look: [0, 0.6, 0], fov: 56 },
  { t: 31.7, pos: [0, 10.0, 7.6], look: [0, 0.4, 0], fov: 50 },
];
export const S8 = ({ t, f }: Ctx) => {
  const title = seg(t, 28.45, 28.8, Easing.out(Easing.back(2.4))), map = seg(t, 29.7, 30.1), pins = Math.floor(clamp((t - 30.3) / 1.0) * 22), mode = t > 29.5;
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#d8e0ff" />
    <Sky p={[0, 26, -40]} s={[300, 150]} top="#0a1030" bottom="#3a4a8a" stars={0.8} t={t} />
    <Surface p={[0, -0.05, 0]} s={[60, 60]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#12183a" b="#0e1330" unit={2.2} />
    {!mode ? <><Banner p={[0, 5.6, 0]} s={[6.4, 2.4]} text="THE GHOST ARMY" size={64} bg="#1a2a5a" fg="#cfe0ff" />
      <CanvasPlane p={[0, 2.4 + 0.2 * Math.sin(t * 3), 1.0]} s={[2.8 * title + 0.001, 3.2 * title + 0.001]} px={[200, 230]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.fillStyle = "#e8f0ff"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.moveTo(20, H - 20); c.lineTo(20, 90); c.arc(W / 2, 90, 80, Math.PI, 0); c.lineTo(W - 20, H - 20); for (let i = 0; i < 4; i++) c.quadraticCurveTo(W - 20 - i * 40 - 20, H - 60, W - 60 - i * 40, H - 20); c.closePath(); c.fill(); c.stroke(); c.fillStyle = INK; c.beginPath(); c.arc(70, 100, 14, 0, 7); c.arc(130, 100, 14, 0, 7); c.fill(); c.fillStyle = "#5a6a3a"; c.beginPath(); c.ellipse(W / 2, 40, 70, 24, 0, Math.PI, 0); c.fill(); c.stroke(); }} />
      <Glow p={[0, 3, 1]} r={5} color="rgba(190,210,255,1)" o={0.4} /></> : null}
    <CanvasPlane p={[0, 0.02, 0]} rot={[-Math.PI / 2, 0, 0]} s={[10 * map + 0.001, 7 * map + 0.001]} px={[1000, 700]} draw={(c, W, H) => { c.fillStyle = "#cfd8c0"; c.fillRect(0, 0, W, H); c.fillStyle = "#e8e4d4"; c.beginPath(); c.moveTo(120, 160); c.lineTo(420, 60); c.lineTo(760, 140); c.lineTo(900, 340); c.lineTo(700, 600); c.lineTo(260, 640); c.lineTo(80, 420); c.closePath(); c.fill(); c.strokeStyle = INK; c.lineWidth = 8; c.stroke(); c.strokeStyle = "#4aa8e8"; c.lineWidth = 14; c.beginPath(); c.moveTo(640, 90); c.bezierCurveTo(560, 240, 700, 380, 600, 560); c.stroke(); for (let i = 0; i < pins; i++) { const x = 140 + ((i * 197) % 700), y = 120 + ((i * 131) % 440); c.fillStyle = "#e5233a"; c.beginPath(); c.arc(x, y, 14, 0, 7); c.fill(); c.strokeStyle = INK; c.lineWidth = 4; c.stroke(); } }} />
    {mode ? <Sign p={[0, 6.0, 2.0]} w={4.0} h={1.5} text={"20+ OPERATIONS"} size={46} fg="#fff" bg="#1f3a6a" /> : null}
    <Dust t={t} area={[8, 6, 6]} color="rgba(190,210,255,.8)" />
  </>);
};

/* ============ S9 31.5 – 36.3  "they pretended to be whole divisions to pull enemy attention away from the real ones." ============ */
const K9: Key[] = [
  { t: 31.3, pos: [-6.0, 3.8, 14.0], look: [-5.0, 2.4, -4], fov: 58 },
  { t: 33.6, pos: [-1.0, 4.6, 15.0], look: [-1.0, 2.4, -3], fov: 60 },
  { t: 35.0, pos: [3.0, 4.2, 14.0], look: [4.0, 2.2, -3], fov: 58 },
  { t: 36.5, pos: [8.0, 4.0, 13.0], look: [9.0, 2.2, -3], fov: 56 },
];
export const S9 = ({ t, f }: Ctx) => {
  const pop = (i: number) => seg(t, 32.46 + i * 0.07, 32.8 + i * 0.07, Easing.out(Easing.back(2.2))), look = seg(t, 33.67, 34.0), sneak = seg(t, 35.35, 36.3, Easing.linear);
  return (<>
    <Cam t={t} keys={K9} />
    <Lights warm="#fff0d0" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#6aa0e0" bottom="#ffeec8" />
    <Ground />
    {Array.from({ length: 12 }, (_, i) => <Tank key={i} p={[-9 + (i % 4) * 4.2, 0, -4 - Math.floor(i / 4) * 4.2]} s={Math.max(0.01, pop(i)) * 0.7} puff={1} wob={Math.sin(t * 4 + i) * 0.2} color="#7a8a4a" />)}
    <Rings p={[-6, 3.6, 0.6]} t={t} t0={31.6} n={3} /><Rings p={[-1, 3.6, 0.6]} t={t} t0={32.0} n={3} />
    <Sign p={[-5.0, 7.8, -2]} w={4.6 * pop(0) + 0.001} h={1.2 * pop(0) + 0.001} text="WHOLE DIVISIONS" size={44} fg="#fff" bg="#1f3a6a" />
    {/* the enemy scout on a rise, buying it */}
    <Box p={[2.4, 0.4, 3]} s={[3, 0.8, 2.4]} color="#8aa060" line={3} />
    <Person p={[2.4, 0.8, 3]} sy={0.8} h={3.4} look={german} f={f} pose={{ mood: look > 0.3 ? "shock" : "deadpan", armR: [0.12, 0.6], armRK: look, armL: [-0.12, 0.6], armLK: look, lookX: -0.6 }} />
    <Sign p={[2.4, 5.6, 3]} w={3.2 * look + 0.001} h={1.2 * look + 0.001} text="BIG ARMY!" size={50} fg="#fff" bg="#e5233a" />
    {/* the real column quietly slipping away */}
    {[0, 1, 2].map((i) => <Tank key={i} p={[7 + sneak * 10 + i * 5.2, 0, -3]} s={0.7} color="#5a6a3a" />)}
    <Sign p={[10, 6.0, 0]} w={3.0 * seg(t, 35.41, 35.7, Easing.out(Easing.back(2.6))) + 0.001} h={1.0} text="REAL ONES" size={46} fg="#fff" bg="#1fa850" />
    <Dust t={t} area={[14, 6, 6]} color="rgba(255,250,210,.8)" />
  </>);
};

/* ============ S10 36.3 – 42.9  "At the Rhine in March 1945, about 1,100 men played the part of around 30,000" ============ */
const K10: Key[] = [
  { t: 36.1, pos: [0, 4.2, 14.0], look: [0, 2.6, -4], fov: 58 },
  { t: 39.5, pos: [0, 5.4, 13.0], look: [0, 3.2, -2], fov: 58 },
  { t: 42.0, pos: [0, 6.0, 14.0], look: [0, 4.0, -2], fov: 60 },
  { t: 43.1, pos: [0, 6.0, 14.0], look: [0, 4.0, -2], fov: 60 },
];
export const S10 = ({ t, f }: Ctx) => {
  const h1 = seg(t, 39.29, 40.0, Easing.out(Easing.cubic)), h2 = seg(t, 41.69, 42.6, Easing.out(Easing.cubic)), a = seg(t, 36.49, 36.8, Easing.out(Easing.back(2.6))), b = seg(t, 37.08, 37.4, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#7a98c0" bottom="#e8eef8" />
    <Ground a="#8aa860" />
    <Surface p={[0, 0.01, -9]} s={[120, 5]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a78b8" b="#3a78b8" />
    <Hedge p={[-9, 0, -12.6]} w={14} /><Hedge p={[9, 0, -12.6]} w={14} />
    <Sign p={[-3.4, 7.8, -5]} w={3.0 * a + 0.001} h={1.0 * a + 0.001} text="THE RHINE" size={46} fg="#fff" bg="#1f6ad8" /><Sign p={[3.4, 7.8, -5]} w={4.0 * b + 0.001} h={1.0 * b + 0.001} text="MARCH 1945" size={46} />
    {[0, 1, 2, 3].map((i) => <Tank key={i} p={[-9 + i * 4.8, 0, -5.8]} s={0.6} color="#7a8a4a" />)}
    {Array.from({ length: 12 }, (_, i) => <Person key={i} p={[-6.6 + (i % 6) * 2.4, 0, 1.6 - Math.floor(i / 6) * 1.6]} h={2.8} look={gi(i)} f={f + i * 3} pose={{ mood: "grin", ...danceBeat(t, i, 0.0).pose, armR: [0.28, 0.62], armRK: 1 }} />)}
    <CrowdField n={60} t={t} rate={3} at={(i) => [-7 + (i % 12) * 1.3, 0, -1.2 - Math.floor(i / 12) * 0.9] as V3} size={0.9} />
    {/* bars: 1,100 vs 30,000 */}
    <Box p={[4.6, 0.7 + 0.5 * h1, 1.4]} s={[1.6, 1.4 + 1.0 * h1, 1.2]} color="#2fd46a" line={3} /><Sign p={[4.6, 2.8 + 1.0 * h1, 1.4]} w={2.0 * h1 + 0.001} h={0.8 * h1 + 0.001} text="1,100" size={46} fg="#fff" bg="#1fa850" />
    <Box p={[7.6, 0.5 + 4.6 * h2, 1.0]} s={[1.6, 1.0 + 9.2 * h2, 1.2]} color="#2f8cff" line={3} /><Sign p={[7.6, 2.0 + 9.2 * h2, 1.0]} w={2.4 * h2 + 0.001} h={0.8 * h2 + 0.001} text="30,000" size={46} fg="#fff" bg="#1f6ad8" />
    <Dust t={t} area={[14, 6, 6]} color="rgba(255,250,220,.8)" />
  </>);
};

/* ============ S11 42.9 – 45.0  "while the real crossing was prepared elsewhere." ============ */
const K11: Key[] = [
  { t: 42.7, pos: [-4.0, 4.0, 14.0], look: [-4.0, 2.2, -4], fov: 58 },
  { t: 43.6, pos: [8.0, 4.2, 12.0], look: [10.0, 2.0, -5], fov: 58 },
  { t: 45.2, pos: [10.5, 4.0, 11.0], look: [11.5, 2.0, -5], fov: 54 },
];
export const S11 = ({ t, f }: Ctx) => {
  const build = clamp((t - 43.3) / 1.6);
  return (<>
    <Cam t={t} keys={K11} />
    <Lights warm="#e8e8f8" />
    <Sky p={[6, 26, -60]} s={[300, 150]} top="#6a88b0" bottom="#d8e0ee" />
    <Ground a="#7a9858" />
    <Surface p={[10, 0.01, -6]} s={[80, 7]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a78b8" b="#3a78b8" />
    {Array.from({ length: 6 }, (_, i) => { const u = clamp(build * 6 - i); return u > 0 ? <group key={i} position={[8.0 + i * 1.5, 0.3, -6]} scale={[1, Math.max(0.01, u), 1]}><Box p={[0, 0, 0]} s={[1.3, 0.5, 2.2]} color="#6a7a3a" line={3} /><Box p={[0, 0.35, 0]} s={[1.3, 0.1, 2.6]} color="#8a6a42" line={2} /></group> : null; })}
    {[0, 1, 2, 3].map((i) => <Person key={i} p={[8.4 + i * 1.8, 0, -2.4]} h={3.0} look={gi(i + 1)} f={f + i * 4} pose={{ mood: "deadpan", armR: [0.3, 0.5 + 0.06 * Math.sin(t * 8 + i)], armRK: 1, lookX: 0.3 }} />)}
    {[0, 1, 2].map((i) => <Tank key={i} p={[12 + i * 5.2, 0, 1.4]} s={0.6} color="#5a6a3a" />)}
    <Sign p={[11.5, 5.8, -1]} w={4.6 * seg(t, 43.96, 44.3, Easing.out(Easing.back(2.6))) + 0.001} h={1.3 * seg(t, 43.96, 44.3, Easing.out(Easing.back(2.6))) + 0.001} text="REAL CROSSING" size={50} fg="#fff" bg="#1fa850" />
    <Sign p={[-4.0, 6.2, -4]} w={3.2} h={1.0} text="DECOYS" size={50} fg="#fff" bg="#8a8a96" />{[0, 1, 2].map((i) => <Tank key={"d" + i} p={[-8 + i * 4.8, 0, -3]} s={0.6} color="#a8b87a" />)}
    <Dust t={t} area={[18, 6, 6]} color="rgba(235,235,250,.8)" />
  </>);
};

/* ============ S12 45.0 – 47.8  "Their work stayed secret for fifty years." ============ */
const K12: Key[] = [
  { t: 44.8, pos: [0, 3.6, 12.0], look: [0, 3.2, 0], fov: 58 },
  { t: 48.0, pos: [0, 3.6, 9.4], look: [0, 3.2, 0], fov: 52 },
];
export const S12 = ({ t, f }: Ctx) => {
  const yr = Math.round(lerp(1945, 1995, seg(t, 45.4, 47.2, Easing.linear))), stamp = seg(t, 45.25, 45.4, Easing.in(Easing.quad));
  return (<>
    <Cam t={t} keys={K12} impacts={[[45.4, 0.04]]} />
    <Lights warm="#e8e0d0" />
    <Floor kind="plank" a="#3a3a44" b="#34343e" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#2a2a34" b="#2a2a34" base="#14141c" /><SideWall x={-9} kind="plain" a="#24242e" b="#24242e" /><SideWall x={9} kind="plain" a="#24242e" b="#24242e" />
    <Box p={[0, 3.2, -3.4]} s={[5.0, 5.6, 1.4]} color="#5a5a66" line={5} /><Cyl p={[0, 3.2, -2.6]} rt={1.3} h={0.3} color="#8a8a96" line={4} rot={[Math.PI / 2, 0, 0]} /><Cyl p={[0, 3.2, -2.4]} rt={0.4} h={0.2} color="#c9a032" line={3} rot={[Math.PI / 2, 0, 0]} />
    <CanvasPlane p={[0, 5.4, -2.6]} s={[3.6, 1.0]} px={[360, 100]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); if (stamp > 0.99) { c.save(); c.translate(W / 2, H / 2); c.rotate(-0.1); c.strokeStyle = "#e5233a"; c.fillStyle = "#e5233a"; c.lineWidth = 8; c.strokeRect(-165, -38, 330, 76); c.font = "900 54px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("TOP SECRET", 0, 4); c.restore(); } }} />
    <group position={[0, 8 - 4.4 * stamp, -2.2]}><Box p={[0, 0, 0]} s={[1.2, 0.2, 0.8]} color="#c0182e" line={3} /><Cyl p={[0, 0.5, 0]} rt={0.16} h={0.8} color="#3a2a22" line={2} /></group>
    <CanvasPlane p={[-5.6, 4.8, -4.9]} s={[2.4, 2.8]} px={[240, 280]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#fffaf0"; c.fillRect(0, 0, W, H); c.fillStyle = "#c0182e"; c.fillRect(0, 0, W, 70); c.fillStyle = "#fff"; c.font = "900 38px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("YEAR", W / 2, 38); c.fillStyle = INK; c.font = "900 90px Inter, Arial"; c.fillText(String(yr), W / 2, 170); }} />
    <Sign p={[5.4, 5.0, -4.6]} w={3.4 * seg(t, 46.52, 46.9, Easing.out(Easing.back(2.6))) + 0.001} h={1.2 * seg(t, 46.52, 46.9, Easing.out(Easing.back(2.6))) + 0.001} text="50 YEARS" size={56} />
    <CanvasPlane p={[-3.2, 6.2, -2.7]} s={[2.4, 2.4]} px={[160, 160]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.8)"; c.lineWidth = 2; for (let k = 0; k < 6; k++) { const a = k * 0.28; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 160, Math.sin(a) * 160); c.stroke(); } for (let r = 24; r < 150; r += 28) { c.beginPath(); c.arc(0, 0, r, 0, 1.6); c.stroke(); } }} />
    <Dust t={t} area={[6, 6, 4]} color="rgba(220,210,190,.8)" />
  </>);
};

/* ============ S13 47.8 – 50.7  "Some estimates say they saved thousands of lives." ============ */
const K13: Key[] = [
  { t: 47.6, pos: [-2.0, 3.6, 12.0], look: [0, 3.0, 0], fov: 58 },
  { t: 50.9, pos: [0.4, 3.8, 10.4], look: [0.4, 3.2, 0], fov: 52 },
];
export const S13 = ({ t, f }: Ctx) => {
  const est = seg(t, 48.09, 48.4, Easing.out(Easing.back(2.6))), th = seg(t, 49.32, 49.7, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K13} />
    <Lights warm="#ffe8c8" />
    <Sky p={[0, 26, -50]} s={[300, 150]} top="#ff9a50" bottom="#ffe8b0" glowAt={[0.8, "rgba(255,220,130,1)"]} />
    <Ground a="#8ab85a" />
    <Timber p={[1, 0, -6]} s={[6.4, 4.4, 4.4]} wall="#f1dfb8" roof="#a8442c" lit={1} seed={3} /><Plant p={[-4.6, 0, -3]} s={1.4} pot="#c0643a" /><Plant p={[7.4, 0, -3]} s={1.4} pot="#c0643a" />
    {[0, 1, 2, 3].map((i) => <React.Fragment key={i}><Person p={[-3.4 + i * 1.8, 0, 1.2 + (i % 2) * 0.6]} h={3.7} look={gi(i)} f={f + i * 4} pose={{ mood: "grin", arms: "up", armK: 0.7 + 0.2 * Math.sin(t * 5 + i), squash: -0.03 }} />
      <Person p={[-2.5 + i * 1.8, 0, 2.0 + (i % 2) * 0.4]} h={2.5} look={mk("#fbe3c8", ["#e55a8a", "#3a7fd6", "#f0b429", "#8a4fb8"][i], "hoodie", "bob", "#7a4a1c")} f={f + i * 5} pose={{ mood: "smile", air: Math.abs(Math.sin(t * 6 + i)) > 0.85 ? 1 : 0 }} /></React.Fragment>)}
    {Array.from({ length: 10 }, (_, i) => { const u = ((t * 0.5 + i / 10) % 1); return <Heart key={i} p={[-3 + (i % 5) * 1.8 + Math.sin(i + u * 3) * 0.3, 4.6 + u * 3.4, 1.2]} s={0.6 + 0.2 * (i % 3)} />; })}
    <Sign p={[-3.4, 8.8, 0.6]} w={3.0 * est + 0.001} h={0.9 * est + 0.001} text="ESTIMATES" size={44} bg="#fff" fg="#c0182e" /><Sign p={[2.8, 8.8, 0.6]} w={5.2 * th + 0.001} h={1.3 * th + 0.001} text="THOUSANDS OF LIVES" size={40} fg="#fff" bg="#c0182e" />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,235,190,.8)" />
  </>);
};

/* ============ S14 50.7 – 54.2  "They won battles with paint, rubber, and radio." ============ */
const K14: Key[] = [
  { t: 50.5, pos: [-3.0, 3.6, 13.0], look: [0, 3.0, 0], fov: 58 },
  { t: 52.2, pos: [0.4, 3.8, 12.0], look: [0.4, 3.0, 0], fov: 56 },
  { t: 54.4, pos: [0, 3.8, 10.5], look: [0, 3.2, 0], fov: 52 },
];
export const S14 = ({ t, f }: Ctx) => {
  const a = seg(t, 51.75, 52.1, Easing.out(Easing.back(2.4))), b = seg(t, 52.37, 52.7, Easing.out(Easing.back(2.4))), c = seg(t, 53.06, 53.4, Easing.out(Easing.back(2.4)));
  return (<>
    <Cam t={t} keys={K14} />
    <Lights warm="#fff0d8" />
    <Floor kind="marble" a="#1a2038" b="#141a30" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e1430" b="#0e1430" base="#060a1a" /><SideWall x={-9} kind="plain" a="#0b1128" b="#0b1128" /><SideWall x={9} kind="plain" a="#0b1128" b="#0b1128" />
    <Banner p={[0, 7.0, -5.0]} s={[6.4, 2.2]} text="GHOST ARMY" sub="1944–1945" size={72} bg="#1a2a5a" fg="#cfe0ff" />
    {[-4.2, 0, 4.2].map((x) => <React.Fragment key={x}><Cyl p={[x, 0.6, 0]} rt={1.4} rb={1.6} h={1.2} color="#e8e4dc" line={3} /><SpotCone p={[x, 9, 0]} h={9} r={1.8} color="#fff2c0" o={0.13} /></React.Fragment>)}
    <group position={[-4.2, 1.3, 0]} scale={Math.max(0.001, a)}><CanvasPlane p={[0, 1.2, 0]} s={[1.9, 2.3]} px={[190, 230]} frame="#5a4228" draw={(cx, W, H) => { cx.fillStyle = "#fffaf0"; cx.fillRect(0, 0, W, H); cx.fillStyle = "#e5233a"; cx.fillRect(20, 20, 90, 90); cx.fillStyle = "#1f6ad8"; cx.fillRect(80, 100, 90, 100); cx.fillStyle = "#ffc23a"; cx.beginPath(); cx.arc(60, 170, 40, 0, 7); cx.fill(); }} /><Cyl p={[0.9, 0.3, 0.2]} rt={0.05} h={1.6} color="#8a6a42" line={2} rot={[0, 0, 0.6]} /></group>
    <Tank p={[0, 1.3, 0]} s={0.7 * Math.max(0.001, b)} puff={1} wob={b < 1 ? Math.sin(t * 30) * 0.3 : 0} color="#7a8a4a" />
    <group position={[4.2, 1.3, 0]} scale={Math.max(0.001, c)}><RadioSet p={[0, 0, 0]} t={t} s={1.6} /></group>
    <Sign p={[-4.2, 5.0, 0.6]} w={2.0 * a + 0.001} h={0.8 * a + 0.001} text="PAINT" size={46} /><Sign p={[0, 5.0, 0.6]} w={2.4 * b + 0.001} h={0.8 * b + 0.001} text="RUBBER" size={46} /><Sign p={[4.2, 5.0, 0.6]} w={2.0 * c + 0.001} h={0.8 * c + 0.001} text="RADIO" size={46} />
    {[-2.0, 2.0].map((x, i) => <Person key={i} p={[x, 0, 2.8]} h={3.8} look={gi(i)} f={f + i * 5} pose={{ mood: "smile", armR: [0.28, 0.78], armRK: seg(t, 53.4, 53.7), flip: i === 1, lookX: 0 }} />)}
    <Dust t={t} area={[8, 6, 5]} color="rgba(255,240,200,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14 };
