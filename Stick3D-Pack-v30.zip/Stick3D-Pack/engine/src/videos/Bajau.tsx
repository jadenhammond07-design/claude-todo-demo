// THE BAJAU: EVOLVING FOR THE SEA — 9 scenes (Ilardo 2018: bigger spleens, PDE10A). Respectful, generic figures.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Calendar } from "../style/kit";
import { Glow, Dust, Shaft } from "../style/props";
import { Cam, Globe } from "../style/extra";
import { Sky } from "../style/medieval";
import { Water } from "../style/nature";
import { Fish } from "../style/birds";
import { Look } from "../style/puppet";
import { Ctx } from "./dancecommon";

const ease = Easing.inOut(Easing.sin), back = Easing.out(Easing.back(2.6));
const low = (ks: { t: number; pos: V3; look: V3; fov: number }[]) => ks.map((q) => ({ ...q, pos: [q.pos[0], q.pos[1] - 0.4, q.pos[2] + 1.0] as V3, look: [q.look[0], q.look[1] - 2.0, q.look[2]] as V3 }));
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const diver = mk("#a8693e", "#2f8cff", "shirt", "short", "#140c06", { shoe: "#a8693e" });
const diver2 = mk("#9a5f38", "#e5233a", "shirt", "short", "#140c06", { shoe: "#9a5f38" });
const sci = mk("#e8b88c", "#f4f4f4", "shirt", "bob", "#3a2410", { glasses: true, badge: "#2f8cff" });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean; edge?: string }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 60, face = true, edge = INK }) => (
  k <= 0.01 ? null : <CanvasPlane p={p} s={[w * k * 1.15, h * k * 1.15]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = edge; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
/** underwater set: blue gradient, sand floor, light shafts, bubbles */
const Under: React.FC<{ t: number; deep?: number }> = ({ t, deep = 0 }) => (<>
  <Sky p={[0, 10, -30]} s={[120, 80]} top={deep > 0.5 ? "#0a3a6a" : "#2a9ad8"} bottom={deep > 0.5 ? "#02142a" : "#0a4a8a"} />
  <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a={deep > 0.5 ? "#4a5a6a" : "#d8c890"} b={deep > 0.5 ? "#4a5a6a" : "#d8c890"} />
  {[-3, 0.5, 3.5].map((x, i) => <Shaft key={i} p={[x, 5, -3]} s={[1.4, 12]} rot={[0, 0, 0.2]} color="200,240,255" o={0.18 * (1 - deep)} />)}
  {Array.from({ length: 14 }, (_, i) => { const u = (t * 0.35 + i * 0.137) % 1; return <Ball key={i} p={[Math.sin(i * 2.7) * 4 + Math.sin(t * 2 + i) * 0.15, u * 10, -1 + Math.cos(i) * 2]} r={0.06 + (i % 3) * 0.04} color="#d8f4ff" ink={0.02} />; })}
</>);
/** a swimming person: whole figure rotated to horizontal */
const Swimmer: React.FC<{ p: V3; look: Look; f: number; t: number; dive?: number; flip?: boolean }> = ({ p, look, f, t, dive = 0.4, flip }) => (
  <group position={p} rotation={[0, 0, (flip ? 1 : -1) * (Math.PI / 2 - 0.3 + dive * 0.4)]}>
    <Person p={[0, -1.6, 0]} h={3.2} look={look} f={f} pose={{ mood: "deadpan", arms: "up", armK: 0.9, walk: t * 2.5, speed: 0.6 }} shadow={false} />
  </group>
);
const Spleen: React.FC<{ p: V3; s: number; color?: string }> = ({ p, s, color = "#9a3a6a" }) => (
  <group position={p}><Ball p={[0, 0, 0]} r={0.8 * s} s={[1.5, 0.8, 0.6]} color={color} ink={0.05} /><Ball p={[0.4 * s, 0.25 * s, 0.1]} r={0.25 * s} color="#c86a9a" ink={0.02} /></group>
);

/* ============ S1 0 – 3.05  hook: a human gliding underwater ============ */
export const S1 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={[{ t: 0, pos: [0, 4.0, 11], look: [0, 3.6, 0], fov: 56 }, { t: 3.2, pos: [0.4, 3.6, 9.5], look: [0.4, 3.4, 0], fov: 54 }]} />
  <Lights warm="#b8e0ff" />
  <Under t={t} />
  <Swimmer p={[lerp(-3, 1.2, seg(t, 0, 3.2)), 4.0, 0.6]} look={diver} f={f} t={t} />
  {Array.from({ length: 5 }, (_, i) => <Fish key={i} p={[2.6 - ((t * 0.8 + i * 0.9) % 6), 2.0 + i * 0.6, -1 - (i % 2)]} t={t} s={0.8} color={["#ffa23a", "#ffd23a", "#ff5a8a"][i % 3]} flip />)}
</>);

/* ============ S2 3.05 – 6.92  Southeast Asia; not with gills ============ */
export const S2 = ({ t, f }: Ctx) => {
  const pin = seg(t, 3.64, 4.0, back), no = seg(t, 6.31, 6.6, back);
  return (<>
    <Cam t={t} keys={[{ t: 2.9, pos: [0, 4.4, 11], look: [0, 4.4, 0], fov: 56 }, { t: 7.0, pos: [0, 4.4, 9], look: [0, 4.4, 0], fov: 54 }]} />
    <Lights warm="#f0f4ff" />
    <Sky p={[0, 10, -30]} s={[120, 80]} top="#0a1a3a" bottom="#2a4a8a" />
    <Globe p={[0, 4.4, -1]} r={2.4} rotY={2.6 + t * 0.05} tilt={0.1} />
    <group position={[0.9, 4.0, 1.4]} scale={[pin + 0.001, pin + 0.001, pin + 0.001]}><Ball p={[0, 0.5, 0]} r={0.3} color="#e5233a" ink={0.05} /><Box p={[0, 0.1, 0]} s={[0.08, 0.5, 0.08]} color="#e5233a" line={1} /></group>
    <Sign p={[0, 7.8, 0.6]} w={3.6} h={0.8} text="SOUTHEAST ASIA" k={pin * (1 - no)} size={38} bg="#14141c" fg="#ffe14a" />
    <Sign p={[0, 7.8, 0.8]} w={2.8} h={0.85} text="NO GILLS ✕" k={no} size={44} bg="#e5233a" fg="#fff" />
  </>);
};

/* ============ S3 6.92 – 14.12  the Bajau: stilt houses, boats, free-diving ============ */
export const S3 = ({ t, f }: Ctx) => {
  const under = seg(t, 10.2, 10.9, ease), tanks = seg(t, 11.37, 11.7, back), nm = seg(t, 6.98, 7.3, back);
  return (<>
    {under < 0.5 ? <>
      <Cam t={t} keys={low([{ t: 6.7, pos: [0, 4.6, 14], look: [0, 4.0, 0], fov: 58 }, { t: 10.6, pos: [0, 4.0, 12], look: [0, 3.0, 0], fov: 56 }])} />
      <Lights warm="#fff0d8" />
      <Sky p={[0, 26, -40]} s={[200, 90]} top="#ffb070" bottom="#ffe8c0" glowAt={[0.8, "rgba(255,220,140,1)"]} />
      <Water p={[0, -2, 0]} w={60} d={40} level={2} color="#1f8ad8" o={0.9} />
      {[[-3.0, -3], [0.4, -4], [3.6, -3]].map(([x, z], i) => <group key={i} position={[x, 0, z]}>
        {[-0.8, 0.8].map((dx, j) => <Cyl key={j} p={[dx, 0.8, 0]} rt={0.1} h={2.4} color="#6a4426" line={2} />)}
        <Box p={[0, 2.6, 0]} s={[2.4, 1.6, 1.8]} color={["#c8865a", "#b8a070", "#a87a5a"][i]} line={3} /><Box p={[0, 3.7, 0]} s={[2.8, 0.5, 2.2]} rot={[0, 0, 0]} color="#8a5a32" line={3} />
      </group>)}
      <group position={[-0.6, 0.15 + Math.sin(t * 2) * 0.05, 1.6]}><Box p={[0, 0, 0]} s={[3.4, 0.4, 1.0]} color="#a8693e" line={3} /><Person p={[0.4, 0.2, 0]} h={2.8} look={diver} f={f} pose={{ mood: "smile", armR: [0.35, 0.8], armRK: 1 }} /><Cyl p={[0.9, 2.2, 0.1]} rt={0.04} h={2.4} color="#6a4426" line={1} rot={[0, 0, -0.3]} /></group>
      <Sign p={[0, 7.2, 0]} w={2.6} h={0.85} text="THE BAJAU" k={nm} size={46} bg="#14141c" fg="#ffe14a" />
    </> : <>
      <Cam t={t} keys={[{ t: 10.2, pos: [0, 4.0, 10.5], look: [0, 3.4, 0], fov: 56 }, { t: 14.3, pos: [0, 3.6, 9.5], look: [0, 3.0, 0], fov: 54 }]} />
      <Lights warm="#b8e0ff" />
      <Under t={t} />
      <Swimmer p={[lerp(-2.4, 0.4, seg(t, 10.5, 13.5)), lerp(5.5, 2.6, seg(t, 10.5, 13.5)), 0.6]} look={diver} f={f} t={t} dive={0.9} />
      <Cyl p={[lerp(-1.4, 1.4, seg(t, 10.5, 13.5)), lerp(4.6, 1.8, seg(t, 10.5, 13.5)), 0.7]} rt={0.04} h={2.6} color="#6a4426" line={1} rot={[0, 0, -1.0]} />
      {Array.from({ length: 4 }, (_, i) => <Fish key={i} p={[2.4 - ((t * 0.6 + i * 1.2) % 5), 1.4 + i * 0.5, -0.6]} t={t} s={0.8} flip />)}
      {[-1.6, 0.6, 2.4].map((x, i) => <Ball key={i} p={[x, 0.2, 0.8]} r={0.3} s={[1.3, 0.6, 1]} color={["#f0b8a0", "#e8a8c8", "#f4e0b0"][i]} ink={0.05} />)}
      <Sign p={[0, 7.0, 0.4]} w={3.6} h={0.8} text="NO OXYGEN TANKS" k={tanks} size={33} bg="#e5233a" fg="#fff" />
    </>}
  </>);
};

/* ============ S4 14.12 – 17.26  ~70 m on one breath ============ */
export const S4 = ({ t, f }: Ctx) => {
  const d = seg(t, 14.4, 16.4, Easing.inOut(Easing.quad)), m = Math.round(70 * d);
  return (<>
    <Cam t={t} keys={[{ t: 14.0, pos: [0, 4.0, 10.5], look: [0, 3.6, 0], fov: 56 }, { t: 17.4, pos: [0, 3.8, 10], look: [0, 3.4, 0], fov: 55 }]} />
    <Lights warm={d > 0.5 ? "#8aa8d8" : "#b8e0ff"} />
    <Under t={t} deep={d} />
    <Swimmer p={[-0.8, lerp(6.0, 2.4, d), 0.6]} look={diver2} f={f} t={t} dive={1.0} />
    <CanvasPlane p={[2.0, 4.6, 1.0]} s={[1.4, 3.4]} px={[140, 340]} draw={(c, W, H) => { c.fillStyle = "#14141c"; c.strokeStyle = "#fff"; c.lineWidth = 6; c.beginPath(); c.roundRect(3, 3, W - 6, H - 6, 14); c.fill(); c.stroke(); c.fillStyle = "#9fd4ff"; c.font = "900 20px Inter, Arial"; c.textAlign = "center"; c.fillText("DEPTH", W / 2, 30); c.fillStyle = "#333"; c.fillRect(50, 50, 40, 240); c.fillStyle = "#2f8cff"; c.fillRect(50, 50, 40, 240 * d); c.fillStyle = "#fff"; c.font = "900 34px Inter, Arial"; c.fillText(`${m}m`, W / 2, 325); }} />
    <Sign p={[-0.4, 8.0, 0.4]} w={2.8} h={0.8} text="ONE BREATH" k={seg(t, 16.45, 16.75, back)} size={42} bg="#fff" fg="#14141c" />
  </>);
};

/* ============ S5 17.26 – 25.18  2018: Ilardo finds spleens ~50% larger ============ */
export const S5 = ({ t, f }: Ctx) => {
  const yr = seg(t, 17.36, 17.7, back), nm = seg(t, 19.27, 19.6, back), sp = seg(t, 20.32, 20.8, back), big = seg(t, 21.15, 22.0, back);
  return (<>
    <Cam t={t} keys={low([{ t: 17.1, pos: [0, 4.4, 12], look: [0, 4.2, 0], fov: 56 }, { t: 25.3, pos: [0, 4.4, 11], look: [0, 4.2, 0], fov: 55 }])} />
    <Lights warm="#f0f4ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#d8e0ee" b="#c8d0e0" unit={1.6} />
    <Box p={[0, 6, -5]} s={[30, 12, 0.3]} color="#2a3a5a" line={3} />
    <Calendar p={[-2.6, 7.0, -4.6]} month="YEAR" day="2018" s={1.4 * yr * (1 - nm) + 0.001} />
    <Person p={[-2.0, 0, 1.2]} h={3.4} look={sci} f={f} pose={{ mood: "smile", lookX: 0.5, armR: [0.4, 0.7], armRK: sp }} />
    <Sign p={[-1.0, 4.6, 1.4]} w={3.0} h={0.75} text="MELISSA ILARDO" k={nm} size={30} bg="#fff" fg="#14141c" />
    {/* two ultrasound panels */}
    {[0, 1].map((i) => <group key={i} position={[0.4 + i * 2.1, 3.6, 0]} scale={[sp + 0.001, sp + 0.001, sp + 0.001]}>
      <Box p={[0, 0, -0.2]} s={[1.9, 2.4, 0.1]} color="#0c1a30" line={3} />
      <Spleen p={[0, 0.1, 0]} s={i === 0 ? 0.55 * (1 + 0.5 * big) : 0.55} />
      <Sign p={[0, -1.6, 0.2]} w={1.9} h={0.55} text={i === 0 ? "BAJAU" : "SALUAN"} size={28} bg={i === 0 ? "#2f8cff" : "#8a8aa0"} fg="#fff" />
    </group>)}
    <Sign p={[0.4, 6.4, 0.6]} w={2.2} h={0.85} text="+50%" k={big} size={56} bg="#ffe14a" fg="#14141c" />
  </>);
};

/* ============ S6 25.18 – 29.18  spleen squeezes out oxygen-rich red cells ============ */
export const S6 = ({ t, f }: Ctx) => {
  const sq = seg(t, 25.95, 26.6, ease), ox = seg(t, 26.84, 27.2, back);
  return (<>
    <Cam t={t} keys={[{ t: 25.0, pos: [0, 4.4, 10], look: [0, 4.4, 0], fov: 55 }, { t: 29.3, pos: [0, 4.4, 9], look: [0, 4.4, 0], fov: 53 }]} />
    <Lights warm="#ffe8f0" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#2a0a1a" b="#2a0a1a" />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#2a0a1a" line={0} />
    <group position={[-1.2, 4.6, 0]} scale={[1 - 0.15 * sq * Math.abs(Math.sin(t * 4)), 1 - 0.2 * sq * Math.abs(Math.sin(t * 4)), 1]}><Spleen p={[0, 0, 0]} s={1.3} /></group>
    <Cyl p={[2.0, 4.6, -0.4]} rt={0.6} h={8} color="#7a1a2a" line={3} />
    {Array.from({ length: 12 }, (_, i) => { const u = ((t - 25.95) * 0.6 + i / 12) % 1; return sq > 0.05 ? <Ball key={i} p={[lerp(-0.2, 2.0, Math.min(1, u * 2)), u < 0.5 ? 4.6 + Math.sin(i) * 0.4 : lerp(4.6, 9, u * 2 - 1), 0.4]} r={0.22} s={[1, 1, 0.45]} color="#e5233a" ink={0.04} /> : null; })}
    <Sign p={[0, 8.0, 0.6]} w={3.2} h={0.85} text="+ OXYGEN" k={ox} size={48} bg="#e5233a" fg="#fff" />
    <Sign p={[-0.6, 6.6, 1.0]} w={2.2} h={0.7} text="SPLEEN" k={seg(t, 25.55, 25.85, back)} size={36} bg="#9a3a6a" fg="#fff" />
  </>);
};

/* ============ S7 29.18 – 36.16  gene PDE10A; selection; ~1,000 years ============ */
export const S7 = ({ t, f }: Ctx) => {
  const gene = seg(t, 30.84, 31.2, back), sel = seg(t, 33.2, 33.5, back), yrs = seg(t, 35.18, 35.5, back);
  return (<>
    <Cam t={t} keys={[{ t: 29.0, pos: [0, 4.6, 11], look: [0, 4.6, 0], fov: 56 }, { t: 36.3, pos: [0, 4.6, 10], look: [0, 4.6, 0], fov: 55 }]} />
    <Lights warm="#e8f0ff" />
    <Surface p={[0, 0, 0]} s={[60, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#0a1a30" b="#0a1a30" />
    <Box p={[0, 6, -4]} s={[30, 14, 0.3]} color="#0a1a30" line={0} />
    {/* DNA helix */}
    {Array.from({ length: 16 }, (_, i) => { const y = 1.4 + i * 0.42, a = i * 0.55 + t * 1.2, hl = i >= 6 && i <= 8 ? gene : 0; return <React.Fragment key={i}>
      <Ball p={[Math.cos(a) * 1.1, y, Math.sin(a) * 1.1]} r={0.2} color={hl > 0.5 ? "#ffe14a" : "#5ab0ff"} ink={0.03} />
      <Ball p={[-Math.cos(a) * 1.1, y, -Math.sin(a) * 1.1]} r={0.2} color={hl > 0.5 ? "#ffe14a" : "#ff7aa8"} ink={0.03} />
      <Box p={[0, y, 0]} s={[2.2, 0.06, 0.06]} rot={[0, -a, 0]} color={hl > 0.5 ? "#ffe14a" : "#c8d0e0"} line={0} />
    </React.Fragment>; })}
    <Glow p={[0, 4.3, 1.0]} r={2.2} color="rgba(255,230,80,1)" o={0.5 * gene} />
    <Sign p={[1.7, 4.3, 1.2]} w={2.0} h={0.75} text="PDE10A" k={gene} size={36} bg="#ffe14a" fg="#14141c" />
    <Sign p={[0, 8.6, 0.4]} w={4.0} h={0.8} text="NATURAL SELECTION" k={sel * (1 - yrs)} size={31} bg="#2fd46a" fg="#14141c" />
    <Sign p={[0, 8.6, 0.6]} w={3.4} h={0.85} text="~1,000 YEARS" k={yrs} size={44} bg="#14141c" fg="#ffe14a" />
  </>);
};

/* ============ S8 36.16 – 39.0  no gills; a body that holds its breath better ============ */
export const S8 = ({ t, f }: Ctx) => {
  const no = seg(t, 36.37, 36.65, back), better = seg(t, 38.19, 38.5, back);
  return (<>
    <Cam t={t} keys={[{ t: 36.0, pos: [0, 4.0, 10], look: [0, 3.8, 0], fov: 55 }, { t: 39.1, pos: [0, 3.8, 9.2], look: [0, 3.6, 0], fov: 53 }]} />
    <Lights warm="#b8e0ff" />
    <Under t={t} />
    <Swimmer p={[0, 3.8, 0.6]} look={diver} f={f} t={t} dive={0.2} />
    <Sign p={[-0.4, 6.8, 0.8]} w={2.6} h={0.8} text="GILLS ✕" k={no * (1 - better)} size={44} bg="#e5233a" fg="#fff" />
    <Sign p={[0, 6.8, 1.0]} w={3.6} h={0.8} text="BREATH-HOLD ↑" k={better} size={40} bg="#2fd46a" fg="#14141c" />
  </>);
};

/* ============ S9 39.0 – end  "what will it do next?" ============ */
export const S9 = ({ t, f }: Ctx) => (<>
  <Cam t={t} keys={[{ t: 38.8, pos: [0, 2.6, 10], look: [0, 4.6, 0], fov: 56 }, { t: 43.0, pos: [0, 2.4, 9], look: [0, 5.0, 0], fov: 54 }]} />
  <Lights warm="#b8e0ff" />
  <Under t={t} />
  <Glow p={[0, 9, -2]} r={6} color="rgba(220,250,255,1)" o={0.5} />
  <Swimmer p={[0.4, lerp(3.0, 4.2, seg(t, 39.0, 43.0)), 0.6]} look={diver} f={f} t={t} dive={-0.9} />
</>);

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
