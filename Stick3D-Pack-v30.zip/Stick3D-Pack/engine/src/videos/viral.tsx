// Viral overlays used on EVERY video: on-screen HOOK (first ~2.4 s) and END QUESTION card (last ~2.8 s). Top area only, never over captions (y 880).
import React from "react";
import { useCurrentFrame, interpolate, Easing } from "remotion";
const FPS = 30;
const box = (extra: React.CSSProperties): React.CSSProperties => ({ position: "absolute", left: 36, right: 36, textAlign: "center", fontFamily: "Inter, Arial", fontWeight: 900, WebkitTextStroke: "10px #000", paintOrder: "stroke fill", ...extra });
export const HookOverlay: React.FC<{ text: string; until?: number }> = ({ text, until = 2.4 }) => {
  const t = useCurrentFrame() / FPS;
  const pop = interpolate(t, [0, 0.22], [0.6, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.back(2.8)) });
  const out = interpolate(t, [until - 0.25, until], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  if (t > until) return null;
  return <div style={box({ top: 60, fontSize: 88, lineHeight: 1.02, color: "#ffe14a", opacity: out, transform: `scale(${pop})`, textShadow: "0 8px 0 rgba(0,0,0,.4)" })}>{text}</div>;
};
export const EndQuestion: React.FC<{ text: string; from: number; end: number }> = ({ text, from, end }) => {
  const t = useCurrentFrame() / FPS;
  if (t < from || t > end + 1) return null;
  const pop = interpolate(t, [from, from + 0.3], [0.5, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.back(2.6)) });
  const pulse = 1 + 0.025 * Math.sin((t - from) * 7);
  return (
    <div style={{ position: "absolute", left: 40, right: 40, top: 110, transform: `scale(${pop * pulse})`, background: "#fff", border: "10px solid #000", borderRadius: 36, padding: "26px 28px", textAlign: "center", fontFamily: "Inter, Arial", fontWeight: 900, fontSize: 64, lineHeight: 1.08, color: "#e5233a", boxShadow: "0 12px 0 rgba(0,0,0,.35)" }}>
      <div style={{ fontSize: 34, color: "#14141c", marginBottom: 10 }}>💬 COMMENT BELOW</div>{text}
    </div>
  );
};
