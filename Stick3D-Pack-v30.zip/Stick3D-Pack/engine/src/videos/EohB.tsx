// THE END OF HISTORY ILLUSION — version B (different concept): sliders, gallery, mosaic, hill, stairs, scale, progress bar, trail. 9 scenes.
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3 } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Plant, Frame, Lamp, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, SpotCone, Bench } from "../style/extra";
import { Sky } from "../style/medieval";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const HV: Look[] = [
  mk("#d9a77c", "#ff7a29", "hoodie", "short", "#1a1008"), mk("#d9a77c", "#2f8cff", "shirt", "swept", "#3a2a1a", { glasses: true }), mk("#d9a77c", "#8a4fb8", "blazer", "bob", "#5a3420", { shirt: "#fff" }),
  mk("#d9a77c", "#2fa86a", "hoodie", "grey", "#aaa", { hat: "#2a2a38" }), mk("#d9a77c", "#e5233a", "shirt", "short", "#111", { glasses: true, badge: "#ffc23a" }), mk("#d9a77c", "#1a1a22", "suit", "swept", "#444", { tie: "#c0182e" }),
];
const hero = HV[0];
const lab = mk("#f3d3b2", "#f4f4f4", "shirt", "swept", "#3b2a1a", { glasses: true, badge: "#2f8cff" });
const ages = (i: number): Look => mk(["#f3d3b2", "#c98e62", "#8d5a3a", "#e0b48c", "#fbe3c8", "#d9a77c"][i], ["#e55a8a", "#3a7fd6", "#2fa86a", "#f0b429", "#8a4fb8", "#c0402e"][i], i < 2 ? "hoodie" : "shirt", i < 4 ? (["short", "bob", "swept", "short"] as const)[i] : "grey", i < 4 ? "#3b2a1a" : "#aaa", { glasses: i >= 3 });
const Sign: React.FC<{ p: V3; w: number; h: number; text: string; k?: number; bg?: string; fg?: string; size?: number; face?: boolean }> = ({ p, w, h, text, k = 1, bg = "#14141c", fg = "#ffe14a", size = 70, face = true }) => (
  <CanvasPlane p={p} s={[w * k + 0.001, h * k + 0.001]} px={[Math.round(w * 100), Math.round(h * 100)]} face={face} draw={(c, W, H) => { c.fillStyle = bg; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(5, 5, W - 10, H - 10, 18); c.fill(); c.stroke(); c.fillStyle = fg; c.font = `900 ${size}px Inter, Arial`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);

/* ============ S1 0 – 3.9  sliders drifting by themselves ============ */
const K1: Key[] = [
  { t: 0, pos: [0, 3.6, 12.0], look: [0, 3.6, 0], fov: 58 },
  { t: 4.1, pos: [0.2, 3.6, 9.2], look: [0, 3.8, 0], fov: 52 },
];
const TRAITS = ["CALM", "CURIOUS", "BOLD", "KIND", "FUNNY", "PATIENT"];
export const S1 = ({ t, f }: Ctx) => {
  const pop = seg(t, 2.78, 3.1, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff0e0" />
    <Floor kind="carpet" a="#3a2a5a" b="#322450" unit={1.8} w={30} d={24} />
    <WallDoor z={-5} W={30} kind="plain" a="#1c2444" b="#1c2444" base="#0c1226" /><SideWall x={-9} kind="plain" a="#161c3a" b="#161c3a" /><SideWall x={9} kind="plain" a="#161c3a" b="#161c3a" />
    <CanvasPlane p={[0, 5.0, -4.9]} s={[8.0, 5.6]} px={[800, 560]} frame="#8a8aa0" draw={(c, W, H) => {
      c.fillStyle = "#0e1428"; c.fillRect(0, 0, W, H); c.fillStyle = "#8fd0ff"; c.font = "900 44px Inter, Arial"; c.textAlign = "center"; c.fillText("PERSONALITY", W / 2, 54);
      TRAITS.forEach((tr, i) => { const y = 120 + i * 70, v = 0.5 + 0.38 * Math.sin(t * (0.5 + i * 0.13) + i * 1.7); c.fillStyle = "#2a3358"; c.fillRect(200, y, 520, 14); c.fillStyle = "#ffd36a"; c.fillRect(200, y, 520 * v, 14); c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 4; c.beginPath(); c.arc(200 + 520 * v, y + 7, 20, 0, 7); c.fill(); c.stroke(); c.fillStyle = "#cfe0ff"; c.font = "800 28px Inter, Arial"; c.textAlign = "left"; c.fillText(tr, 24, y + 20); });
    }} />
    {[-6.2, 6.2].map((x, i) => <group key={x} position={[x, 4.0, -4.7]} rotation={[0, 0, t * (i ? -0.8 : 0.8)]}><Cyl p={[0, 0, 0]} rt={1.0} h={0.3} color="#6a7090" line={3} rot={[Math.PI / 2, 0, 0]} />{[0, 1, 2, 3, 4, 5].map((k) => <Box key={k} p={[Math.cos(k * 1.05) * 1.1, Math.sin(k * 1.05) * 1.1, 0]} s={[0.4, 0.4, 0.3]} rot={[0, 0, k * 1.05]} color="#6a7090" line={2} />)}</group>)}
    <Box p={[-0.4, 0.6, 1.8]} s={[4.6, 1.2, 1.8]} color="#6a3a8a" line={4} /><Box p={[-0.4, 1.4, 2.5]} s={[4.6, 1.6, 0.4]} color="#5a2e7a" line={3} />
    <Person p={[-0.4, 1.2, 1.8]} sy={1.2} h={3.4} look={hero} f={f} pose={{ mood: t > 2.78 ? "worry" : "smile", armR: [0.14, 0.62], armRK: 1, lookX: t > 2.78 ? 0.6 : 0.2 }} />
    <FaceGroup p={[-0.4, 1.2, 1.8]}><Box p={hand(3.4, [0.14, 0.64], 0, false, 0.12)} s={[0.3, 0.5, 0.04]} color="#14141c" line={2} /></FaceGroup>
    <Sign p={[2.8, 6.6, 1.6]} w={2.6 * pop + 0.001} h={1.0} text="?!" size={80} fg="#fff" bg="#c0182e" />
    <Dust t={t} area={[8, 6, 5]} color="rgba(160,200,255,.8)" />
  </>);
};

/* ============ S2 3.9 – 9.0  gallery of past selves ============ */
const GX = (t: number) => lerp(-6.4, 6.0, seg(t, 4.2, 8.6, Easing.linear));
const K2: Key[] = [3.9, 5.4, 6.8, 8.2, 9.2].map((tt) => ({ t: tt, pos: [GX(tt) + 0.8, 3.6, 11.0] as V3, look: [GX(tt) + 1.2, 3.2, 0] as V3, fov: 58 }));
export const S2 = ({ t, f }: Ctx) => {
  const x = GX(t), walking = t > 4.2 && t < 8.6, neq = seg(t, 7.79, 8.1, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K2} />
    <Lights warm="#fff4e0" />
    <Floor kind="marble" a="#e8e4dc" b="#d8d4cc" unit={2} w={50} d={24} />
    <WallDoor z={-5} W={50} kind="plain" a="#6a5a4a" b="#6a5a4a" base="#3a2e22" />
    {[0, 1, 2, 3, 4].map((i) => { const fx = -5.2 + i * 3.4, lbl = ["5 YEARS AGO", "4", "3", "2", "1 YEAR AGO"][i]; return <React.Fragment key={i}>
      <Box p={[fx, 3.6, -4.8]} s={[2.8, 4.4, 0.3]} color="#c9a032" line={4} /><Box p={[fx, 3.6, -4.6]} s={[2.4, 4.0, 0.1]} color={["#e8d8b8", "#d8e4f4", "#f4d8d8", "#d8f0d8", "#e8d8f4"][i]} line={2} />
      <Person p={[fx, 0.4, -3.4]} h={3.0} look={HV[(i + 3) % HV.length]} f={f + i * 5} pose={{ mood: "smile", lookX: 0 }} />
      <Sign p={[fx, 6.2, -4.4]} w={2.6} h={0.6} text={lbl === "4" || lbl === "3" || lbl === "2" ? lbl + " YEARS AGO" : lbl} size={22} bg="#fff" fg="#14141c" face={false} />
      <Sign p={[fx, 1.0, -2.2]} w={1.0 * neq + 0.001} h={1.0 * neq + 0.001} text="≠" size={80} bg="#c0182e" fg="#fff" /></React.Fragment>; })}
    <Person p={[x, 0, 1.2]} h={3.9} look={hero} f={f} pose={{ mood: t > 7.7 ? "smile" : "deadpan", walk: walking ? x * WALK : undefined, speed: walking ? 0.5 : 0, arms: t > 7.79 ? "chest" : undefined, armK: seg(t, 7.79, 8.2), lookX: 0.5 }} />
    <Sign p={[x, 5.0, 1.2]} w={3.0 * seg(t, 7.79, 8.1, Easing.out(Easing.back(2.6))) + 0.001} h={0.9} text="THAT'S STILL ME" size={26} bg="#fff" fg="#1fa850" />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,245,220,.8)" />
  </>);
};

/* ============ S3 9.0 – 15.2  mosaic of 19,000 ============ */
const K3: Key[] = [
  { t: 8.8, pos: [-1.0, 4.4, 12.0], look: [0, 4.6, 0], fov: 58 },
  { t: 12.0, pos: [0, 5.0, 14.5], look: [0, 4.8, 0], fov: 58 },
  { t: 15.4, pos: [0.4, 4.6, 12.0], look: [0, 4.8, 0], fov: 56 },
];
export const S3 = ({ t, f }: Ctx) => {
  const n = Math.round(lerp(0, 19000, seg(t, 11.51, 13.4, Easing.out(Easing.cubic)))), q = seg(t, 15.0, 15.3, Easing.out(Easing.back(2.6))), slide = seg(t, 13.54, 14.8, ease);
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#e8f0ff" />
    <Floor kind="tile" a="#cfd8e8" b="#bcc8dc" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#1a2444" b="#1a2444" base="#0a1022" />
    <CanvasPlane p={[0, 5.2, -4.9]} s={[7.2, 8.0]} px={[360, 400]} frame="#e8dcc0" draw={(c, W, H) => {
      c.fillStyle = "#0a1022"; c.fillRect(0, 0, W, H); const cols = 100, rows = 190, cw = W / cols, ch = (H - 60) / rows;
      const total = Math.min(cols * rows, Math.floor(n)), per = Math.floor(total / rows);
      for (let r = 0; r < rows; r++) { const rowN = r < Math.floor(total / cols) ? cols : r === Math.floor(total / cols) ? total % cols : 0; for (let k = 0; k < rowN; k++) { const age = (k / cols); c.fillStyle = `hsl(${200 - age * 160}, 80%, ${70 - age * 30}%)`; c.fillRect(k * cw, 14 + Math.floor(r / 2) * (ch * 2) * 0 + r * ch, cw - 0.3, ch - 0.1); } }
      void per; c.fillStyle = "#fff"; c.font = "800 22px Inter, Arial"; c.textAlign = "left"; c.fillText("18", 6, H - 18); c.textAlign = "right"; c.fillText("68", W - 6, H - 18);
    }} />
    <Sign p={[3.6, 9.6, 0.4]} w={4.2} h={1.3} text={n.toLocaleString("en-US")} k={t > 11.5 ? 1 : 0} size={78} fg="#fff" bg="#1f6ad8" />
    <Sign p={[-3.2, 9.6, 0.4]} w={3.4 * seg(t, 9.05, 9.4, Easing.out(Easing.back(2.6))) + 0.001} h={1.0} text="2013" size={72} bg="#c0182e" fg="#fff" />
    <Sign p={[-1.6 + 4.6 * slide, 0.8, 1.0]} w={2.4} h={0.7} text={slide < 0.5 ? "AGE 18" : "AGE 68"} k={t > 13.5 ? 1 : 0} size={40} bg="#fff" fg="#14141c" />
    <Person p={[-3.8, 0, 1.8]} h={3.9} look={lab} f={f} pose={{ mood: "deadpan", armR: [0.3, 0.55], armRK: seg(t, 10.12, 10.6), lookX: 0.4 }} />
    <FaceGroup p={[-3.8, 0, 1.8]}><Box p={hand(3.9, [0.3, 0.55], 0, false, 0.1)} s={[0.5, 0.7, 0.05]} color="#c9a870" line={2} /></FaceGroup>
    <Sign p={[2.6, 7.0, 1.8]} w={2.4 * q + 0.001} h={2.0 * q + 0.001} text="?" size={160} fg="#ff5a8a" bg="#14081e" />
    <Dust t={t} area={[8, 6, 5]} color="rgba(220,230,255,.8)" />
  </>);
};

/* ============ S4 15.2 – 22.6  looking back vs looking forward ============ */
const K4: Key[] = [
  { t: 15.0, pos: [-1.5, 3.8, 11.5], look: [-1.5, 3.0, 0], fov: 58 },
  { t: 18.8, pos: [-3.5, 3.8, 11.5], look: [-3.5, 3.0, 0], fov: 56 },
  { t: 20.0, pos: [0.0, 3.8, 11.5], look: [0, 3.0, 0], fov: 56 },
  { t: 21.4, pos: [4.0, 3.8, 11.5], look: [4.0, 3.0, 0], fov: 56 },
  { t: 22.8, pos: [4.8, 3.8, 11.0], look: [4.8, 3.0, 0], fov: 54 },
];
export const S4 = ({ t, f }: Ctx) => {
  const back = seg(t, 16.47, 16.8, Easing.out(Easing.back(2.6))), fwd = seg(t, 20.17, 20.5, Easing.out(Easing.back(2.6))), turn = seg(t, 19.6, 20.0);
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#fff0d8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#7a98c0" bottom="#f0e8d8" />
    <Surface p={[0, -0.05, -10]} s={[140, 70]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#8aa860" b="#8aa860" />
    {/* behind (left): a winding colourful trail with milestones */}
    {Array.from({ length: 12 }, (_, i) => <React.Fragment key={i}><Box p={[-2 - i * 1.4, 0.04, 1.6 + Math.sin(i * 0.9) * 1.2]} s={[1.5, 0.08, 1.2]} rot={[0, Math.sin(i) * 0.3, 0]} color={["#e5233a", "#ffc23a", "#2fd46a", "#2f8cff", "#c24fff", "#ff7a29"][i % 6]} line={2} />
      <Cyl p={[-2 - i * 1.4, 1.2, 0.2 + Math.sin(i * 0.9) * 0.8]} rt={0.05} h={2.4} color="#6a4426" line={1} /><Box p={[-1.6 - i * 1.4, 2.2, 0.2 + Math.sin(i * 0.9) * 0.8]} s={[0.8, 0.5, 0.04]} color={["#e5233a", "#ffc23a", "#2fd46a", "#2f8cff", "#c24fff", "#ff7a29"][(i + 2) % 6]} line={1} /></React.Fragment>)}
    {[0, 1, 2, 3].map((i) => <Person key={i} p={[-3.4 - i * 2.6, 0, -1.2]} h={3.2} look={HV[(i + 1) % HV.length]} f={f + i * 4} pose={{ mood: "grin", lookX: 0.3, arms: "up", armK: 0.4 }} />)}
    {/* ahead (right): a plain straight road into fog */}
    <Surface p={[8, 0.01, 0.8]} s={[16, 2.4]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#b8b8c4" b="#b8b8c4" />
    {Array.from({ length: 5 }, (_, i) => <Person key={i} p={[3.8 + i * 2.6, 0, -1.2]} h={3.2} look={{ ...hero, skin: "#dfe8f4", body: "#9ab8e0" }} f={f + i * 4} pose={{ mood: "deadpan", lookX: 0 }} />)}
    <CanvasPlane p={[11, 3, -2]} s={[10, 6]} px={[100, 60]} draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, "rgba(235,238,245,0)"); g.addColorStop(1, "rgba(235,238,245,1)"); c.fillStyle = g; c.fillRect(0, 0, W, H); }} />
    <Sign p={[-5.0, 6.8, 0.6]} w={5.4 * back + 0.001} h={1.1} text="LAST 10 YEARS: A LOT" size={34} bg="#c0182e" fg="#fff" /><Sign p={[6.4, 6.8, 0.6]} w={5.6 * fwd + 0.001} h={1.1} text="NEXT 10 YEARS: ?" size={34} bg="#1f6ad8" fg="#fff" />
    <Person p={[0.4, 0, 1.4]} h={3.9} look={lab} f={f} pose={{ mood: "smile", flip: turn > 0.5, arms: "point", armK: 1, lookX: turn > 0.5 ? 0.6 : -0.6 }} />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,250,220,.8)" />
  </>);
};

/* ============ S5 22.6 – 30.4  age staircase: changed a lot / will not change ============ */
const K5: Key[] = [
  { t: 22.4, pos: [-3.0, 3.8, 13.0], look: [-3.0, 3.0, 0], fov: 58 },
  { t: 26.0, pos: [0.0, 4.4, 14.0], look: [0, 3.4, 0], fov: 60 },
  { t: 28.8, pos: [2.5, 4.6, 14.0], look: [2.0, 3.4, 0], fov: 60 },
  { t: 30.6, pos: [2.5, 4.6, 13.0], look: [2.0, 3.4, 0], fov: 58 },
];
export const S5 = ({ t, f }: Ctx) => {
  const fwd = seg(t, 27.4, 27.9);
  return (<>
    <Cam t={t} keys={K5} />
    <Lights warm="#fff4d8" />
    <Floor kind="tile" a="#d8e4f0" b="#c8d4e4" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#fffaf0" b="#fffaf0" base="#c8b898" />
    <CanvasPlane p={[-2.4, 3.2, -4.9]} s={[13, 5]} px={[1300, 500]} draw={(c, W, H) => { const g = c.createLinearGradient(0, 0, W, 0); g.addColorStop(0, "#e5233a"); g.addColorStop(0.3, "#ffc23a"); g.addColorStop(0.55, "#2fd46a"); g.addColorStop(0.8, "#2f8cff"); g.addColorStop(1, "#c24fff"); c.fillStyle = g; c.beginPath(); for (let x = 0; x <= W; x += 10) c.lineTo(x, H / 2 + Math.sin(x * 0.012) * 120 - 50); for (let x = W; x >= 0; x -= 10) c.lineTo(x, H / 2 + Math.sin(x * 0.012 + 0.6) * 120 + 70); c.closePath(); c.fill(); c.fillStyle = "#fff"; c.font = "900 60px Inter, Arial"; c.textAlign = "center"; c.fillText("THE PAST: A LOT HAS CHANGED", W / 2, 80); }} />
    {[0, 1, 2, 3, 4, 5].map((i) => { const x = -7 + i * 2.4, b = 22.9 + i * 0.7, k = seg(t, b, b + 0.3, Easing.out(Easing.back(2.6)));
      return <React.Fragment key={i}><Box p={[x, 0.3 + i * 0.25, 0]} s={[2.2, 0.6 + i * 0.5, 2.2]} color={["#8a98b0", "#7a88a0"][i % 2]} line={3} />
        <Person p={[x, 0.6 + i * 0.5, 0]} sy={0.6 + i * 0.5} h={3.0 + i * 0.1} look={ages(i)} f={f + i * 4} pose={{ mood: fwd > 0.5 ? "deadpan" : "grin", arms: fwd > 0.5 ? "chest" : "up", armK: fwd > 0.5 ? 1 : 0.7 * k, flip: fwd > 0.5 }} />
        <Sign p={[x, 6.4 + i * 0.5, 0]} w={2.2} h={0.8} text={fwd > 0.5 ? "SAME" : "A LOT!"} size={30} k={k} bg={fwd > 0.5 ? "#6a6a7a" : "#fff"} fg={fwd > 0.5 ? "#fff" : "#c0182e"} /></React.Fragment>; })}
    {/* the future: a short grey stub */}
    <Box p={[9.0, 0.05, 0]} s={[3.0, 0.1, 2.0]} color="#9a9aa6" line={3} /><Sign p={[9.0, 3.2, 0]} w={3.4 * fwd + 0.001} h={1.0} text="FUTURE: NOT MUCH" size={26} bg="#6a6a7a" fg="#fff" />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S6 30.4 – 35.0  balance scale: predicted vs actual ============ */
const K6: Key[] = [
  { t: 30.2, pos: [-1.0, 3.8, 15.5], look: [0, 3.8, 0], fov: 60 },
  { t: 33.0, pos: [0.0, 4.0, 15.0], look: [0, 3.8, 0], fov: 58 },
  { t: 35.2, pos: [0.0, 4.0, 14.0], look: [0, 3.8, 0], fov: 56 },
];
export const S6 = ({ t, f }: Ctx) => {
  const tip = t < 33.0 ? -0.04 * Math.sin((t - 31.5) * 3) * seg(t, 31.5, 32.0) : lerp(-0.0, 0.42, Easing.out(Easing.bounce)(seg(t, 33.0, 33.9))), far = seg(t, 33.29, 33.6, Easing.out(Easing.back(2.6)));
  const L = 3.2, py = 4.2;
  const lx = -Math.cos(tip) * L, ly = py + Math.sin(tip) * L * -1 * -1 * 0 + Math.sin(-tip) * L * -1 * -1 + 0;
  const leftY = py - Math.sin(tip) * L, rightY = py + Math.sin(tip) * L;
  return (<>
    <Cam t={t} keys={K6} impacts={[[33.5, 0.03]]} />
    <Lights warm="#e8f0ff" />
    <Floor kind="tile" a="#d8e0ec" b="#c8d0dc" unit={1.8} w={34} d={24} />
    <WallDoor z={-5} W={34} kind="plain" a="#2a3a5a" b="#2a3a5a" base="#141e30" />
    <Cyl p={[0, 2.1, 0]} rt={0.18} rb={0.4} h={4.2} color="#8a8aa0" line={3} /><Box p={[0, 0.1, 0]} s={[2.2, 0.2, 1.4]} color="#6a6a7a" line={3} />
    <group position={[0, py, 0]} rotation={[0, 0, -tip]}><Box p={[0, 0, 0]} s={[L * 2 + 0.4, 0.24, 0.3]} color="#c9a032" line={3} /></group>
    {/* left pan: a feather (predicted) */}
    <group position={[-Math.cos(tip) * L, leftY - 1.2, 0]}><Cyl p={[0, 0.6, 0]} rt={0.02} h={1.2} color="#c9d3e0" line={1} /><Cyl p={[0, 0, 0]} rt={1.2} rb={1.0} h={0.15} color="#e8d8a0" line={3} />
      <Box p={[0, 0.3, 0]} s={[0.9, 0.04, 0.3]} color="#fff" rot={[0, 0, 0.2]} line={2} /><Sign p={[0, 1.7, 0.6]} w={2.6} h={0.7} text="PREDICTED" size={30} /></group>
    {/* right pan: heavy stack (actual) */}
    <group position={[Math.cos(tip) * L, rightY - 1.2, 0]}><Cyl p={[0, 0.6, 0]} rt={0.02} h={1.2} color="#c9d3e0" line={1} /><Cyl p={[0, 0, 0]} rt={1.2} rb={1.0} h={0.15} color="#e8d8a0" line={3} />
      {[0, 1, 2].map((i) => <Box key={i} p={[(i - 1) * 0.5, 0.4 + (i % 2) * 0.4, 0]} s={[0.9, 0.7, 0.9]} color={["#2a2a38", "#3a3a4a", "#1a1a22"][i]} line={3} />)}<Sign p={[0, 2.4, 0.6]} w={2.2} h={0.7} text="ACTUAL" size={34} bg="#c0182e" fg="#fff" /></group>
    <Sign p={[0, 8.0, 0.4]} w={5.6 * far + 0.001} h={1.4 * far + 0.001} text="FAR MORE!" size={72} fg="#fff" bg="#c0182e" />
    <Person p={[-4.8, 0, 1.4]} h={3.9} look={lab} f={f} pose={{ mood: far > 0.5 ? "shock" : "smile", arms: "point", armK: seg(t, 31.8, 32.2), lookX: 0.6 }} />
    <Dust t={t} area={[8, 6, 5]} color="rgba(230,240,255,.8)" />
    {void lx}{void ly}
  </>);
};

/* ============ S7 35.0 – 41.5  100% complete ============ */
const K7: Key[] = [
  { t: 34.8, pos: [-2.0, 3.8, 12.5], look: [0, 3.8, 0], fov: 58 },
  { t: 38.5, pos: [0.0, 4.0, 11.0], look: [0, 3.8, 0], fov: 54 },
  { t: 41.7, pos: [0.0, 4.0, 10.0], look: [0, 3.8, 0], fov: 52 },
];
export const S7 = ({ t, f }: Ctx) => {
  const ill = seg(t, 37.38, 37.7, Easing.out(Easing.back(2.6))), bar = seg(t, 35.4, 36.6, Easing.out(Easing.cubic)), fin = seg(t, 40.64, 40.95, Easing.out(Easing.back(2.6)));
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#e8f0ff" />
    <Floor kind="marble" a="#1a2038" b="#141a30" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e1430" b="#0e1430" base="#060a1a" />
    <CanvasPlane p={[0, 5.4, -5.9]} s={[7.8, 4.4]} px={[780, 440]} frame="#8a8aa0" draw={(c, W, H) => { c.fillStyle = "#0a1020"; c.fillRect(0, 0, W, H); c.fillStyle = "#8fd0ff"; c.font = "900 48px Inter, Arial"; c.textAlign = "center"; c.fillText("YOU", W / 2, 70); c.fillStyle = "#2a3358"; c.fillRect(60, 150, W - 120, 70); c.fillStyle = "#2fd46a"; c.fillRect(60, 150, (W - 120) * bar, 70); c.fillStyle = "#fff"; c.font = "900 64px Inter, Arial"; c.fillText(Math.round(100 * bar) + "%", W / 2, 290); if (bar > 0.99) { c.fillStyle = "#ffd36a"; c.font = "900 52px Inter, Arial"; c.fillText("COMPLETE ✓", W / 2, 370); } }} />
    <Person p={[-1.2, 0, 1.2]} h={3.7} look={hero} f={f} pose={{ mood: "grin", arms: "up", armK: seg(t, 36.8, 37.2), squash: -0.03 }} />
    <Sign p={[2.0, 7.8, 0.6]} w={5.4 * ill + 0.001} h={1.2 * ill + 0.001} text="ILLUSION" size={64} bg="#8a4fb8" fg="#fff" />
    <Sign p={[2.6, 2.8, 1.0]} w={4.6 * fin + 0.001} h={1.2 * fin + 0.001} text="FINISHED VERSION" size={34} fg="#14141c" bg="#ffd36a" />
    <SpotCone p={[-1.2, 9, 1]} h={9} r={1.8} color="#fff2c0" o={0.14} /><Dust t={t} area={[8, 6, 4]} color="rgba(200,220,255,.8)" />
  </>);
};

/* ============ S8 41.5 – 43.6  glitch: update available ============ */
const K8: Key[] = [
  { t: 41.3, pos: [0, 3.8, 10.0], look: [0, 3.8, 0], fov: 52 },
  { t: 43.8, pos: [0.3, 3.8, 8.6], look: [0, 3.8, 0], fov: 48 },
];
export const S8 = ({ t, f }: Ctx) => {
  const g = seg(t, 41.76, 42.1), pop = seg(t, 42.2, 42.5, Easing.out(Easing.back(2.6))), j = Math.sin(t * 90) * 0.06 * g * (1 - pop);
  return (<>
    <Cam t={t} keys={K8} impacts={[[41.9, 0.04]]} />
    <Lights warm="#e8f0ff" />
    <Floor kind="marble" a="#1a2038" b="#141a30" unit={2} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0e1430" b="#0e1430" base="#060a1a" />
    <CanvasPlane p={[j, 5.4, -5.9]} s={[7.8, 4.4]} px={[780, 440]} frame="#8a8aa0" draw={(c, W, H) => { c.fillStyle = "#0a1020"; c.fillRect(0, 0, W, H); c.fillStyle = "#8fd0ff"; c.font = "900 48px Inter, Arial"; c.textAlign = "center"; c.fillText("YOU", W / 2, 70); const v = lerp(1, 0.47, Easing.out(Easing.cubic)(seg(t, 41.9, 42.6))); c.fillStyle = "#2a3358"; c.fillRect(60, 150, W - 120, 70); c.fillStyle = g > 0.3 ? "#ff8a4a" : "#2fd46a"; c.fillRect(60, 150, (W - 120) * v, 70); c.fillStyle = "#fff"; c.font = "900 64px Inter, Arial"; c.fillText(Math.round(100 * v) + "%", W / 2, 290); if (g > 0.3) { c.fillStyle = "#ff8a4a"; c.font = "900 44px Inter, Arial"; c.fillText("STILL LOADING...", W / 2, 370); } for (let k = 0; k < 6 * g; k++) { c.fillStyle = `rgba(255,${60 + k * 30},120,.5)`; c.fillRect(((t * 700 + k * 211) % W), (k * 83) % H, 120, 8); } }} />
    <CanvasPlane p={[0.8, 3.2, 0.6]} s={[4.2 * pop + 0.001, 2.4 * pop + 0.001]} px={[420, 240]} face frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#f4f6fb"; c.fillRect(0, 0, W, H); c.fillStyle = "#1f4ad8"; c.fillRect(0, 0, W, 50); c.fillStyle = "#fff"; c.font = "800 26px Inter, Arial"; c.textAlign = "left"; c.fillText("UPDATE AVAILABLE", 14, 34); c.fillStyle = INK; c.font = "900 52px Inter, Arial"; c.textAlign = "center"; c.fillText("You 2.0", W / 2, 120); c.fillStyle = "#2fd46a"; c.fillRect(110, 160, 200, 54); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.fillText("INSTALL", W / 2, 195); }} />
    <Person p={[-1.2, 0, 1.2]} h={3.7} look={hero} f={f} pose={{ mood: g > 0.4 ? "shock" : "grin", arms: g > 0.4 ? "head" : "up", armK: g > 0.4 ? seg(t, 41.9, 42.2) : 1, squash: g > 0.4 ? -0.1 * Math.exp(-(t - 41.9) * 4) : 0 }} />
    <Dust t={t} area={[6, 6, 4]} color="rgba(200,220,255,.8)" />
  </>);
};

/* ============ S9 43.6 – 46.8  the trail of selves ============ */
const TX = (t: number) => lerp(-6, 8, seg(t, 43.8, 46.8, Easing.inOut(Easing.sin)));
const K9: Key[] = [43.4, 44.6, 45.6, 46.6, 47.0].map((tt) => ({ t: tt, pos: [TX(tt) - 0.6, 3.6, 11.5] as V3, look: [TX(tt) + 0.4, 3.0, 0] as V3, fov: 58 }));
export const S9 = ({ t, f }: Ctx) => {
  const x = TX(t), q = seg(t, 45.33, 45.7, Easing.out(Easing.back(2.2))), sun = seg(t, 43.6, 46.8, Easing.linear);
  return (<>
    <Cam t={t} keys={K9} />
    <Lights warm="#ffe0c0" />
    <Sky p={[x, 26, -60]} s={[300, 150]} top="#2a1a5a" bottom="#ffb070" glowAt={[0.9, "rgba(255,210,120,1)"]} stars={0.5} t={t} />
    <Ball p={[x - 14 + sun * 28, 14 + Math.sin(sun * Math.PI) * 10, -50]} r={4} color="#fff0b0" ink={0} /><Glow p={[x - 14 + sun * 28, 14 + Math.sin(sun * Math.PI) * 10, -49]} r={14} color="rgba(255,220,130,1)" o={0.5} />
    <Surface p={[0, -0.05, -14]} s={[140, 70]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a5a3a" b="#3a5a3a" />
    <Surface p={[2, 0.01, 0.4]} s={[40, 3]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#c8b898" b="#b8a888" unit={1.2} />
    {Array.from({ length: 9 }, (_, i) => { const gx = -6 + i * 1.8; return gx < x - 1 ? <Person key={i} p={[gx, 0, 0.4]} h={3.7} look={{ ...HV[(i + 1) % HV.length], skin: "#d8e0f4" }} f={f + i * 3} pose={{ mood: "smile", lookX: 0.3 }} /> : null; })}
    <Person p={[x, 0, 0.8]} h={3.9} look={HV[Math.min(5, Math.floor((x + 6) / 2.4))]} f={f} pose={{ mood: "smile", walk: x * WALK, speed: 0.5, lookX: 0.5 }} />
    <Sign p={[11, 4.4, -2]} w={3.6} h={1.1} text="+10 YEARS" size={56} bg="#c0182e" fg="#fff" k={seg(t, 43.81, 44.1, Easing.out(Easing.back(2.6)))} />
    <Sign p={[10, 8.4, -3]} w={4.2 * q + 0.001} h={4.2 * q + 0.001} text="?" size={340} fg="#ffd36a" bg="#14081e" />
    <Dust t={t} area={[14, 6, 6]} color="rgba(255,230,170,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9 };
