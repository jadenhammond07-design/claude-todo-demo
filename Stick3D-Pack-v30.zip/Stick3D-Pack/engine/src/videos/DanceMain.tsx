import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { S1, S2, S3, S4, S5, S6, S7, tint3 } from "./Dance";
import { Captions } from "../Main";
import { SCENES as EXTRA, tintFor } from "./Dance2";
export const CUTS = [0, 2.65, 5.8, 10.45, 15.0, 18.7, 22.4, 25.2, 31.0, 34.5, 38.3, 41.0, 44.6, 48.6, 52.2];
const BG = ["#ffcf8a", "#ffcf8a", "#7aa2e0", "#ee9a40", "#4a2a18", "#ff9a50", "#9ab8f0", "#1a1038", "#4a1620", "#e08a4a", "#4a3a2a", "#6a7a8a", "#2a1a3a", "#0a0618"];
const TR: Trans[] = ["ghost", "ghost", "zoom", "whip", "ghost", "ghost", "dip", "flash", "ghost", "whip", "ghost", "dip", "flash", "ghost"];
export const DanceMain: React.FC<{ only?: number }> = () => {
  const all: React.FC<any>[] = [S1, S2, S3, S4, S5, S6, S7, ...["S8", "S9", "S10", "S11", "S12", "S13", "S14"].map((k) => EXTRA[k]).filter(Boolean)];
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <Audio src={staticFile("mix.wav")} />
      {all.map((S, i) => <Scene key={i} first={i === 0} start={CUTS[i]} end={CUTS[i + 1]} bg={BG[i]} trans={TR[i]} tint={i === 2 ? tint3 : tintFor(i)}>{(c) => <S {...c} />}</Scene>)}
      <Captions />
    </AbsoluteFill>
  );
};
