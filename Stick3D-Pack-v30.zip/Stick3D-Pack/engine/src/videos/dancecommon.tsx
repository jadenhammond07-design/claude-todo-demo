// Shared scene wrapper, looks and helpers for the 1518 dancing-plague video.
import React from "react";
import { AbsoluteFill, Sequence, useCurrentFrame, Easing } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { Look } from "../style/puppet";
import { V3, lerp, clamp } from "../style/kit";

export const FPS = 30, LEAD = 6, TAIL = 8, WALK = 3.4;
export type Ctx = { t: number; f: number };
export type Trans = "ghost" | "zoom" | "flash" | "whip" | "dip";

export const Scene: React.FC<{ start: number; end: number; first?: boolean; trans?: Trans; bg: string; tint?: (t: number) => string; children: (c: Ctx) => React.ReactNode }> = ({ start, end, first, trans = "ghost", bg, tint, children }) => {
  const from = Math.round(start * FPS) - (first ? 0 : LEAD), dur = Math.round(end * FPS) - from + TAIL;
  return <Sequence from={from} durationInFrames={dur} layout="none"><Inner from={from} first={first} trans={trans} bg={bg} tint={tint} children={children} /></Sequence>;
};
const Inner: React.FC<{ from: number; first?: boolean; trans: Trans; bg: string; tint?: (t: number) => string; children: (c: Ctx) => React.ReactNode }> = ({ from, first, trans, bg, tint, children }) => {
  const f = useCurrentFrame(), t = (f + from) / FPS;
  const k = first ? 1 : clamp(f / (LEAD + 2)), ke = Easing.out(Easing.cubic)(k);
  const sc = !first && trans === "zoom" ? lerp(1.35, 1, ke) : 1;
  const tx = !first && trans === "whip" ? (1 - ke) * 720 : 0, blur = !first && trans === "whip" ? (1 - ke) * 14 : 0;
  const tc = tint ? tint(t) : "";
  return (
    <AbsoluteFill style={{ opacity: first || trans === "flash" || trans === "whip" ? 1 : k, transform: `translateX(${tx}px) scale(${sc})`, background: bg, filter: `saturate(1.32) contrast(1.07) brightness(1.02)${blur > 0.2 ? ` blur(${blur.toFixed(1)}px)` : ""}` }}>
      <ThreeCanvas width={720} height={1280} camera={{ fov: 60, position: [0, 2, 8], near: 0.1, far: 220 }} gl={{ antialias: true }}>
        <color attach="background" args={[bg]} />{children({ t, f })}
      </ThreeCanvas>
      {tc ? <AbsoluteFill style={{ background: tc, mixBlendMode: "multiply" }} /> : null}
      {!first && trans === "flash" ? <AbsoluteFill style={{ background: "#fff", opacity: 1 - clamp(f / 7) }} /> : null}
    </AbsoluteFill>
  );
};

export const yawTo = (cam: V3, p: V3) => Math.atan2(cam[0] - p[0], cam[2] - p[2]);
export const toWorld = (p: V3, loc: V3, cam: V3): V3 => { const y = yawTo(cam, p); return [p[0] + loc[0] * Math.cos(y) + loc[2] * Math.sin(y), p[1] + loc[1], p[2] - loc[0] * Math.sin(y) + loc[2] * Math.cos(y)]; };

/* ---- characters ---- */
export const troffea: Look = { skin: "#fbe3c8", body: "#b8326a", outfit: "shirt", hair: "bob", hairColor: "#6a3a1c", hat: "#f6f0dc", shoe: "#5a3320" };
export const troffeaBleed: Look = { ...troffea, shoe: "#d01a2c" };
export const villagers: Look[] = [
  { skin: "#f3d3b2", body: "#7a5a3a", outfit: "shirt", hair: "short", hairColor: "#3a2410", shoe: "#3a2a1a" },
  { skin: "#e5bd94", body: "#4f7a3c", outfit: "hoodie", hair: "bob", hairColor: "#2a1a10", shoe: "#3a2a1a" },
  { skin: "#fbe3c8", body: "#8f4a3a", outfit: "shirt", hair: "grey", shoe: "#3a2a1a" },
  { skin: "#c98e62", body: "#3a5f7e", outfit: "hoodie", hair: "swept", hairColor: "#1a1008", shoe: "#3a2a1a" },
  { skin: "#f6d6bd", body: "#a8802a", outfit: "shirt", hair: "short", hairColor: "#7a4a1c", hat: "#6a4a2a", shoe: "#3a2a1a" },
  { skin: "#e0b48c", body: "#6a4a8a", outfit: "hoodie", hair: "bob", hairColor: "#4a2a14", shoe: "#3a2a1a" },
  { skin: "#fbe3c8", body: "#c85a3a", outfit: "shirt", hair: "swept", hairColor: "#b8742a", shoe: "#3a2a1a" },
  { skin: "#a86b45", body: "#3a7a6a", outfit: "hoodie", hair: "short", hairColor: "#111", shoe: "#3a2a1a" },
];
export const doctor: Look = { skin: "#f1d0b0", body: "#25203a", outfit: "suit", tie: "#c9a032", hair: "grey", glasses: true, hat: "#15121f", hatKind: "tall", shoe: "#0b0b14" };
export const doctor2: Look = { ...doctor, body: "#2a3a4a", tie: "#9c1f2e", hair: "none", glasses: false };
export const councilor: Look = { skin: "#f3d3b2", body: "#8e1b2e", outfit: "leather", hair: "grey", hat: "#1b1220", hatKind: "tall", shoe: "#1b1220" };
export const councilor2: Look = { ...councilor, skin: "#e5bd94", hair: "none", body: "#6e1a3c" };
export const carpenter: Look = { skin: "#f0cfae", body: "#b5823e", outfit: "hoodie", hair: "short", hairColor: "#5a3a1a", hat: "#7a4a26", shoe: "#3a2a1a" };
export const drummer: Look = { skin: "#e5bd94", body: "#2f8a5a", outfit: "shirt", hair: "swept", hairColor: "#1a1008", hat: "#c9402e", shoe: "#3a2a1a" };
export const piper: Look = { skin: "#fbe3c8", body: "#d6a43a", outfit: "shirt", hair: "bob", hairColor: "#a8602a", hat: "#2a6a8a", shoe: "#3a2a1a" };
export const guard: Look = { skin: "#f0cfae", body: "#5a6a7a", outfit: "leather", hair: "short", hairColor: "#222", hat: "#9aa3b0", shoe: "#2a2a30" };
export const historian: Look = { skin: "#fbe3c8", body: "#5a4a8a", outfit: "blazer", shirt: "#f2f2f2", hair: "grey", glasses: true, badge: "#c9a032", shoe: "#2a1a10" };
export const historian2: Look = { skin: "#d9a77c", body: "#2a6a6a", outfit: "blazer", shirt: "#fff", hair: "swept", hairColor: "#222", glasses: true, shoe: "#2a1a10" };
export const shrineWalker = (i: number): Look => ({ ...villagers[i % 8], shoe: "#d01a2c", shoeCross: true });
