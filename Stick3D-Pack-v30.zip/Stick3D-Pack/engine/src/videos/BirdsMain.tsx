import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Birds";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const BCUTS = [0, 3.94, 10.42, 14.76, 18.14, 19.66, 25.07, 28.75, 32.28, 37.78, 42.1];
const BG = ["#6ab0f0", "#3a8ae0", "#6ab0f0", "#6ab0f0", "#e89a6a", "#2f7de0", "#6ab0f0", "#05061a", "#0a1a3a", "#5aa0e8"];
const TR: Trans[] = ["ghost", "zoom", "whip", "ghost", "whip", "ghost", "dip", "flash", "zoom", "ghost"];
export const BirdsMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 10 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={BCUTS[i]} end={BCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"EVERY BIRD ON EARTH GROUNDED FOR 1 DAY"} until={2.9} />
    <EndQuestion text={"Which animal do you think we'd miss the MOST?"} from={38.9} end={42.01} />
  </AbsoluteFill>
);
