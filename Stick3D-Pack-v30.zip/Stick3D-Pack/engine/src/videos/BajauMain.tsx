import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Bajau";
import { Captions } from "../Main";
import { HookOverlay, EndQuestion } from "./viral";
export const BJCUTS = [0, 3.05, 6.92, 14.12, 17.26, 25.18, 29.18, 36.16, 39.0, 42.9];
const BG = ["#0a4a8a", "#0a1a3a", "#ffb070", "#0a3a6a", "#2a3a5a", "#2a0a1a", "#0a1a30", "#0a4a8a", "#0a4a8a"];
const TR: Trans[] = ["ghost", "zoom", "whip", "dip", "ghost", "zoom", "flash", "ghost", "dip"];
export const BajauMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 9 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={BJCUTS[i]} end={BJCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
    <HookOverlay text={"SOME HUMANS ARE EVOLVING FOR THE OCEAN"} until={2.8} />
    <EndQuestion text={"What do you think humans evolve into next? 👇"} from={39.8} end={42.83} />
  </AbsoluteFill>
);
