import React from "react";
import { AbsoluteFill, Audio, staticFile } from "remotion";
import { Scene, Trans } from "./dancecommon";
import { SCENES } from "./Jobs";
import { Captions } from "../Main";
export const JCUTS = [0, 3.9, 9.4, 12.0, 17.1, 23.7, 25.9, 31.4, 35.3, 39.7, 43.3, 46.1, 52.0];
const BG = ["#2a1a5a", "#1c1a3a", "#7ab0e8", "#e8dcc0", "#e8dcc0", "#8a8070", "#b8c4d8", "#1a1e34", "#6a1a2a", "#1a1e34", "#14102a", "#2a1a5a"];
const TR: Trans[] = ["ghost", "ghost", "zoom", "whip", "ghost", "ghost", "flash", "zoom", "ghost", "ghost", "flash", "ghost"];
export const JobsMain: React.FC = () => (
  <AbsoluteFill style={{ background: "#000" }}>
    <Audio src={staticFile("mix.wav")} />
    {Array.from({ length: 12 }, (_, i) => { const S = SCENES["S" + (i + 1)]; return <Scene key={i} first={i === 0} start={JCUTS[i]} end={JCUTS[i + 1]} bg={BG[i]} trans={TR[i]}>{(c) => <S {...c} />}</Scene>; })}
    <Captions />
  </AbsoluteFill>
);
