// THE NOVEMBER 17 ALERT TEST — 13 scenes. Generic stand-ins; no brand logos (agency / software names appear only as generic signage).
import React from "react";
import { Easing } from "remotion";
import { Box, Cyl, Ball, CanvasPlane, Surface, INK } from "../style/toon";
import { Person, Lights, seg, lerp, clamp, V3, Desk, Calendar } from "../style/kit";
import { Floor, WallDoor, SideWall, Glow, Shaft, Plant, Shelf, Frame, Lamp, Monitor, Chair, Cooler, Rug, Dust } from "../style/props";
import { Cam, Key, FaceGroup, hand, Curtain, SpotCone, Building, StreetLamp, Hydrant, Bin, Bench, Taxi, Globe, Stars } from "../style/extra";
import { Sky, Banner, Barrel, Crate, Flame, CrowdField, danceBeat } from "../style/medieval";
import { Console, Palm } from "../style/studio";
import { AnalogClock, Phone, Heart, Robot, Router, Clapper } from "../style/studio2";
import { Look } from "../style/puppet";
import { Ctx, WALK } from "./dancecommon";

const ease = Easing.inOut(Easing.sin);
const mk = (skin: string, body: string, outfit: Look["outfit"], hair: Look["hair"], hairColor = "#1a1008", extra: Partial<Look> = {}): Look => ({ skin, body, outfit, hair, hairColor, shoe: "#222", ...extra });
const ppl: Look[] = [
  mk("#f3d3b2", "#3a7fd6", "hoodie", "short", "#3b2a1a"), mk("#8d5a3a", "#e5533a", "shirt", "bob", "#111"), mk("#fbe3c8", "#2fa86a", "hoodie", "swept", "#b8742a"), mk("#c98e62", "#8a4fb8", "shirt", "short", "#111", { glasses: true }),
  mk("#e0b48c", "#f0b429", "hoodie", "bob", "#5a3420"), mk("#fbe3c8", "#2d3142", "blazer", "grey", "#999"), mk("#a86b45", "#ff7a9a", "shirt", "swept", "#111"), mk("#f6d6bd", "#4a9aa8", "hoodie", "short", "#7a4a1c"),
];
const official: Look = mk("#f3d3b2", "#1f2f5a", "suit", "short", "#2a2a2a", { tie: "#c0182e", badge: "#ffc23a", shoe: "#111" });
const officialB: Look = mk("#8d5a3a", "#2a2a38", "suit", "short", "#111", { tie: "#2f8cff", glasses: true, shoe: "#111" });
const techie: Look = mk("#fbe3c8", "#5a6a7a", "hoodie", "swept", "#3a2a1a", { glasses: true });
const hero: Look = mk("#d9a77c", "#ff8a1c", "hoodie", "short", "#1a1008");

/* ============ S1 0 – 3.0  "2:20 p.m. Eastern, November 17th." ============ */
const K1: Key[] = [
  { t: 0, pos: [0.5, 20, 24], look: [0, 9, -22], fov: 62 },
  { t: 1.5, pos: [0.4, 9.0, 17], look: [0, 9, -22], fov: 58 },
  { t: 3.2, pos: [0.8, 4.6, 12], look: [0, 8.2, -22], fov: 56 },
];
export const S1 = ({ t, f }: Ctx) => {
  const pop = seg(t, 0.59, 0.9, Easing.out(Easing.back(2.4))), pop2 = seg(t, 1.72, 2.05, Easing.out(Easing.back(2.4)));
  return (<>
    <Cam t={t} keys={K1} />
    <Lights warm="#fff0d0" />
    <Sky p={[0, 30, -90]} s={[300, 150]} top="#4d8fe8" bottom="#cfe8ff" glowAt={[0.3, "rgba(255,240,200,1)"]} />
    <Surface p={[0, 0, -20]} s={[60, 100]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#3a3a46" b="#3a3a46" />
    {Array.from({ length: 12 }, (_, i) => <Box key={i} p={[0, 0.02, 12 - i * 5]} s={[0.25, 0.03, 2.2]} color="#f4e8a0" line={0} />)}
    <Box p={[-6.6, 0.15, -20]} s={[2.4, 0.3, 80]} color="#9a9aa6" line={2} /><Box p={[6.6, 0.15, -20]} s={[2.4, 0.3, 80]} color="#9a9aa6" line={2} />
    {Array.from({ length: 8 }, (_, k) => <React.Fragment key={k}>
      <Building p={[-9.5, 0, 12 - k * 8.5]} s={[5, 10 + (k % 3) * 6, 7]} color={["#6a7a9a", "#8a6a5a", "#5a8a8a"][k % 3]} face="+x" lit={0.3} trim="#2b3350" />
      <Building p={[9.5, 0, 9 - k * 8.5]} s={[5, 12 - (k % 3) * 2 + 4, 7]} color={["#8a7a6a", "#5a6a8a", "#9a6a6a"][k % 3]} face="-x" lit={0.3} trim="#2b3350" /></React.Fragment>)}
    {/* the clock tower at the end of the avenue */}
    <Box p={[0, 9, -26]} s={[7, 18, 7]} color="#a8643e" /><Box p={[0, 18.4, -26]} s={[8, 0.8, 8]} color="#5a3a22" line={3} /><Cyl p={[0, 22, -26]} rt={0} rb={3.8} h={6} color="#2a5a8a" line={4} />
    <AnalogClock p={[0, 14.5, -22.4]} r={2.8} h={2} m={20} />
    <CanvasPlane p={[0, 9.4, -22.4]} s={[5.2 * pop + 0.001, 1.9 * pop + 0.001]} px={[520, 190]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#06101a"; c.fillRect(0, 0, W, H); c.fillStyle = "#ffe14a"; c.font = "900 110px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("2:20 PM", W / 2, 74); c.fillStyle = "#8fd0ff"; c.font = "800 34px Inter, Arial"; c.fillText("EASTERN", W / 2, 154); }} />
    <group position={[-5.2, 6.6, 3]} ><Cyl p={[0, -3.6, 0]} rt={0.1} h={7.2} color="#2b3350" line={2} /><Calendar p={[0, 0, 0.2]} month="NOV" day="17" s={2.6 * pop2 + 0.001} /></group>
    <Taxi p={[2.4, 0, 2]} rotY={0} /><Taxi p={[-2.4, 0, -6]} rotY={Math.PI} color="#e5533a" />
    <StreetLamp p={[-5.6, 0, -2]} h={5.6} /><StreetLamp p={[5.6, 0, -9]} h={5.6} flip /><Hydrant p={[5.4, 0, 5]} /><Bin p={[-5.6, 0, -12]} /><Bench p={[5.8, 0, -16]} rotY={-Math.PI / 2} />
    {[[-5.6, 6, 0], [5.8, 2, 1], [-5.8, -6, 2], [5.6, -14, 3]].map(([x, z, i]) => <Person key={String(i)} p={[x, 0.3, z]} sy={0.3} h={3.3} look={ppl[i]} f={f + i * 6} pose={{ mood: "deadpan", lookX: 0.3, armR: [0.18, 0.62], armRK: 1 }} />)}
    <Dust t={t} area={[8, 9, 6]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S2 3.0 – 6.0  "Every phone in America is about to scream." ============ */
const US: [number, number][] = [[-124.7, 48.4], [-123.2, 48.2], [-122.8, 49], [-95.2, 49], [-94.6, 48.7], [-91.4, 48.1], [-88.4, 48.3], [-84.9, 46.9], [-82.4, 45.3], [-82.1, 43.6], [-83.1, 42.1], [-79.8, 42.2], [-76.5, 43.6], [-75, 45], [-71.5, 45], [-69.2, 47.4], [-67.8, 47.1], [-67, 44.8], [-70.2, 43.6], [-70, 41.8], [-73.7, 40.9], [-74.1, 39.5], [-75.5, 38], [-76, 36.9], [-75.5, 35.3], [-78.5, 33.8], [-79.9, 32.7], [-81.4, 30.2], [-80.2, 27.5], [-80.4, 25.2], [-81.1, 25.2], [-82.8, 28.6], [-84, 30], [-86.5, 30.4], [-89.6, 30.1], [-89.4, 29], [-93.8, 29.6], [-95, 29.2], [-97.2, 26], [-99.1, 26.4], [-100.7, 29.1], [-103.1, 29], [-104.5, 29.6], [-106.5, 31.8], [-108.2, 31.8], [-111, 31.3], [-114.8, 32.5], [-117.1, 32.5], [-118.5, 34], [-120.6, 34.5], [-121.9, 36.6], [-122.5, 37.8], [-123.8, 39.5], [-124.3, 40.4], [-124.1, 43], [-124.5, 46.2]];
const mapXY = (lon: number, lat: number, W: number, H: number): [number, number] => [((lon + 125) / 59) * (W - 40) + 20, (1 - (lat - 24.5) / 25.5) * (H - 40) + 20];
const DOTS: [number, number][] = [[-74, 40.7], [-71, 42.4], [-77, 38.9], [-80.2, 25.8], [-81.7, 28.5], [-84.4, 33.7], [-87.6, 41.9], [-83, 42.3], [-90, 30], [-93.3, 45], [-96.8, 32.8], [-98.5, 29.4], [-95.4, 29.8], [-104.9, 39.7], [-112, 33.4], [-111.9, 40.8], [-118.2, 34], [-122.4, 37.8], [-122.3, 47.6], [-117.2, 32.7], [-115.1, 36.2], [-90.2, 38.6], [-86.8, 36.2], [-79.9, 40.4], [-97.5, 35.5], [-94.6, 39.1], [-106.6, 35.1], [-84.5, 39.1], [-81.7, 41.5], [-73.9, 42.7], [-82.5, 35.6], [-78.9, 35.8], [-100, 44], [-110, 45], [-120, 45], [-96, 41]];
const K2: Key[] = [
  { t: 2.8, pos: [0, 14.5, 8.5], look: [0, 0, 1.2], fov: 56 },
  { t: 4.6, pos: [0, 12.5, 7.8], look: [0, 0, 1.0], fov: 54 },
  { t: 6.2, pos: [0, 10.5, 6.8], look: [0, 0, 0.8], fov: 52 },
];
export const S2 = ({ t, f }: Ctx) => {
  const front = lerp(-66, -124, seg(t, 4.2, 5.06, Easing.linear)), scr = t > 5.06, ps = Math.max(0, t - 5.06);
  return (<>
    <Cam t={t} keys={K2} impacts={[[5.06, 0.015]]} />
    <Lights warm="#d0e0ff" />
    <Surface p={[0, -0.02, 0]} s={[60, 60]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#0e1a3a" b="#0a1430" unit={2} />
    <CanvasPlane p={[0, 0.02, 0]} rot={[-Math.PI / 2, 0, 0]} s={[7.0, 4.06]} px={[1080, 626]} draw={(c, W, H) => {
      c.fillStyle = "#0a1430"; c.fillRect(0, 0, W, H); c.beginPath(); US.forEach(([lo, la], i) => { const [x, y] = mapXY(lo, la, W, H); i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.closePath(); c.fillStyle = "#1d3f78"; c.fill(); c.strokeStyle = "#9fd0ff"; c.lineWidth = 6; c.lineJoin = "round"; c.stroke();
      c.strokeStyle = "rgba(160,210,255,.25)"; c.lineWidth = 2; for (let k = 0; k < 6; k++) { const [x] = mapXY(-125 + k * 10, 30, W, H); c.beginPath(); c.moveTo(x, 20); c.lineTo(x, H - 20); c.stroke(); }
      DOTS.forEach(([lo, la]) => { const [x, y] = mapXY(lo, la, W, H); const lit = lo > front; c.fillStyle = lit ? "#ff3b3b" : "#7fd0ff"; c.beginPath(); c.arc(x, y, lit ? 11 : 7, 0, 7); c.fill(); if (scr) { c.strokeStyle = "rgba(255,80,80,.8)"; c.lineWidth = 5; const rr = 18 + ((((ps * 120 + lo * 5) % 80) + 80) % 80); c.globalAlpha = 1 - rr / 100; c.beginPath(); c.arc(x, y, rr, 0, 7); c.stroke(); c.globalAlpha = 1; } });
    }} />
    {DOTS.map(([lo, la], i) => { const [x, y] = mapXY(lo, la, 1080, 626), wx = (x / 1080 - 0.5) * 7.0, wz = (y / 626 - 0.5) * 4.06, lit = lo > front, jit = scr ? Math.sin(t * 60 + i) * 0.06 : 0;
      return <Phone key={i} p={[wx + jit, 0.55, wz]} rot={[-0.2, 0, scr ? Math.sin(t * 50 + i) * 0.15 : 0]} s={0.5} glow={lit ? "rgba(255,60,60,1)" : undefined} o={0.7} draw={(c, W, H) => { c.fillStyle = lit ? "#c0182e" : "#2a4a8a"; c.fillRect(0, 0, W, H); if (lit) { c.fillStyle = "#fff"; c.font = "900 60px Inter, Arial"; c.textAlign = "center"; c.fillText("!", W / 2, H / 2 + 20); } }} />; })}
    <Glow p={[0, 4, 0]} r={9} color="rgba(255,60,60,1)" o={scr ? 0.3 : 0} /><Dust t={t} area={[8, 5, 5]} color="rgba(160,200,255,.8)" />
  </>);
};

/* ============ S3 6.0 – 10.2  "FEMA has scheduled a nationwide emergency alert test down to the minute." ============ */
const K3: Key[] = [
  { t: 5.8, pos: [-2.0, 4.2, 17.0], look: [0, 3.6, -1], fov: 58 },
  { t: 8.2, pos: [0.0, 4.0, 14.0], look: [0, 3.4, -1], fov: 56 },
  { t: 9.6, pos: [0.3, 3.4, 11.0], look: [0.1, 2.8, 0], fov: 52 },
  { t: 10.5, pos: [0.3, 3.2, 10.0], look: [0.1, 2.7, 0], fov: 50 },
];
export const S3 = ({ t, f }: Ctx) => {
  const min = lerp(19, 20, seg(t, 9.55, 9.7, Easing.out(Easing.back(3))) * (t > 9.28 ? 1 : 0)), lid = seg(t, 9.8, 10.1, Easing.out(Easing.back(1.8))), checks = Math.floor(clamp((t - 7.0) / 0.5) * 3 + (t > 8.5 ? 1 : 0)), spin = t * 5;
  return (<>
    <Cam t={t} keys={K3} />
    <Lights warm="#c8d8ff" />
    <Floor kind="tile" a="#1a2444" b="#141c38" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#10183a" b="#10183a" base="#080c20" /><SideWall x={-9} kind="plain" a="#0e1632" b="#0e1632" /><SideWall x={9} kind="plain" a="#0e1632" b="#0e1632" />
    <CanvasPlane p={[0, 5.6, -5.9]} s={[8.6, 4.4]} px={[860, 440]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#06122a"; c.fillRect(0, 0, W, H); c.fillStyle = "#ff5a5a"; c.font = "900 54px Inter, Arial"; c.textAlign = "center"; c.fillText("NATIONAL ALERT CENTER", W / 2, 80); c.fillStyle = "#ffe14a"; c.font = "900 96px Inter, Arial"; c.fillText("TEST 2:20", W / 2, 230); c.textAlign = "left"; c.fillStyle = "#9fd0ff"; c.font = "800 40px Inter, Arial"; ["ALL STATES", "ALL CARRIERS", "ALL SCREENS"].forEach((s2, i) => { c.fillText((i < checks ? "✔ " : "☐ ") + s2, 60 + i * 270, 340 + (i % 2) * 0); }); c.fillStyle = "#ff3b3b"; c.fillRect(0, H - 36, W * seg(t, 6, 9.55, Easing.linear), 12); }} />
    <AnalogClock p={[-6.2, 4.8, -5.8]} r={1.5} h={2} m={min} /><AnalogClock p={[6.2, 4.8, -5.8]} r={1.5} h={2} m={min} />
    <Console p={[-5.6, 0, -2]} w={3.4} t={t} live={0.5} /><Console p={[5.6, 0, -2]} w={3.4} t={t} live={0.5} /><Monitor p={[-5.6, 2.8, -2.4]} screen="#2fd46a" /><Monitor p={[5.6, 2.8, -2.4]} screen="#2fd46a" />
    {/* red button under a hinged cover on the desk */}
    <Box p={[0, 1.0, 1.0]} s={[4.4, 0.2, 2.0]} color="#4a4a58" line={3} /><Box p={[0, 0.5, 1.0]} s={[4.0, 1.0, 1.6]} color="#2a2a38" line={2} />
    <Cyl p={[0, 1.2, 1.0]} rt={0.7} h={0.3} color="#2a2a38" line={3} /><Cyl p={[0, 1.45, 1.0]} rt={0.5} h={0.22} color="#e5233a" line={3} /><Glow p={[0, 1.7, 1.6]} r={1.8} color="rgba(255,50,50,1)" o={0.45} />
    <group position={[-0.8, 1.55, 1.0]} rotation={[0, 0, lid * 1.4]}><Box p={[0.8, 0.25, 0]} s={[1.6, 0.5, 1.6]} color="#bfe8ff" line={2} /></group>
    <Cyl p={[-4.0, 4.6, -4.6]} rt={0.4} h={0.7} color="#ff3b3b" line={2} /><Glow p={[-4.0, 4.8, -4.2]} r={3.4} color="rgba(255,40,40,1)" o={0.4 + 0.3 * Math.sin(spin)} /><Cyl p={[4.0, 4.6, -4.6]} rt={0.4} h={0.7} color="#ff3b3b" line={2} /><Glow p={[4.0, 4.8, -4.2]} r={3.4} color="rgba(255,40,40,1)" o={0.4 + 0.3 * Math.sin(spin + 3)} />
    <Plant p={[-8, 0, 2]} s={1.2} pot="#3a6a9a" /><Chair p={[-2.8, 0, 3]} rotY={0.5} color="#2a3a6a" /><Dust t={t} area={[6, 5, 4]} color="rgba(160,200,255,.8)" />
    <Person p={[0, 0, -0.7]} h={4.0} look={official} f={f} pose={{ mood: t < 9.2 ? "deadpan" : "worry", sweat: t > 9.3 ? 1 : 0, nerv: 0.15, lookX: 0, armR: [0.12, t < 9.55 ? 0.5 : lerp(0.5, 0.42, lid)], armRK: seg(t, 8.0, 8.8), armL: [-0.3, 0.5], armLK: seg(t, 8.0, 8.8), hunch: 0.2 }} />
    <Person p={[-3.6, 0, -1.4]} h={3.7} look={officialB} f={f + 4} pose={{ mood: "deadpan", lookX: 0.6, arms: "chest", armK: 1 }} />
  </>);
};

/* ============ S4 10.2 – 15.9  "And online, a rumor is racing ahead of it: the internet and the banks will go dark worldwide," ============ */
const RX = (t: number) => -4 + (t - 10.2) * 4.6;
const K4: Key[] = [10.0, 11.5, 13.0, 14.5, 16.2].map((tt) => ({ t: tt, pos: [RX(tt) + 1.2, 3.4, 11.0] as V3, look: [RX(tt) + 1.8, 2.6, 0] as V3, fov: 58 }));
const BUB = ["BANKS DOWN!", "NO INTERNET!", "$0.00!!", "BLACKOUT!", "SHARE THIS!"];
export const tintFor = (i: number): ((t: number) => string) | undefined => i === 3 ? (t: number) => { const k = seg(t, 14.5, 15.4, Easing.linear); return k > 0.01 ? `rgb(${Math.round(255 - 190 * k)},${Math.round(255 - 180 * k)},${Math.round(255 - 140 * k)})` : ""; } : i === 10 ? (t: number) => { const k = Math.max(0, 1 - (t - 38.97) / 0.5) * (t > 38.97 ? 1 : 0); return k > 0.02 ? `rgb(255,${Math.round(255 - 130 * k)},${Math.round(255 - 130 * k)})` : ""; } : undefined;
export const S4 = ({ t, f }: Ctx) => {
  const x = RX(t), off = seg(t, 14.7, 15.2, Easing.linear);
  return (<>
    <Cam t={t} keys={K4} />
    <Lights warm="#ffe8c0" />
    <Sky p={[x + 8, 26, -60]} s={[300, 150]} top="#6aa8ff" bottom="#e8f2ff" />
    <Surface p={[x + 10, 0, -4]} s={[120, 40]} rot={[-Math.PI / 2, 0, 0]} kind="plain" a="#4a4a56" b="#4a4a56" />
    {Array.from({ length: 30 }, (_, i) => <Box key={i} p={[-12 + i * 4, 0.02, 4.6]} s={[2, 0.03, 0.22]} color="#f4e8a0" line={0} />)}
    {Array.from({ length: 12 }, (_, i) => <Building key={i} p={[-10 + i * 9, 0, -10 - (i % 2) * 3]} s={[6, 8 + (i % 4) * 3, 5]} color={["#8a7a6a", "#5a6a8a", "#9a6a6a", "#6a8a7a"][i % 4]} lit={0.4 * (1 - off)} trim="#2b3350" />)}
    {Array.from({ length: 14 }, (_, i) => <StreetLamp key={i} p={[-8 + i * 7, 0, -3]} h={5.4} on={1 - off} flip={i % 2 === 0} />)}
    <Hydrant p={[RX(10.5) + 6, 0, -1.4]} /><Bin p={[RX(12) + 5, 0, -1.6]} /><Bench p={[RX(11.5) + 4, 0, -1.8]} />
    {/* finish: globe + bank */}
    <Globe p={[RX(13.4) + 4.4, 3.2, -4]} r={1.9} rotY={t * 0.6} /><Cyl p={[RX(13.4) + 4.4, 1.0, -4]} rt={0.2} h={2.0} color="#5a5a6a" line={2} />
    <group position={[RX(13.6) + 9.5, 0, -4]}><Box p={[0, 3, 0]} s={[6, 6, 4]} color="#d8d0c0" /><Box p={[0, 6.3, 0]} s={[6.8, 0.7, 4.6]} color="#8a7a5a" line={3} />{[-2.2, -0.7, 0.7, 2.2].map((px) => <Cyl key={px} p={[px, 2.6, 2.1]} rt={0.28} h={4.2} color="#f0e8d8" line={2} />)}
      <CanvasPlane p={[0, 6.9, 2.4]} s={[4.6, 1]} px={[460, 100]} draw={(c, W, H) => { c.fillStyle = off > 0.5 ? "#2a2a30" : "#1f3a7a"; c.fillRect(0, 0, W, H); c.fillStyle = off > 0.5 ? "#555" : "#ffe14a"; c.font = "900 66px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("BANK", W / 2, H / 2 + 4); }} /></group>
    {/* the rumor, sprinting; the clock rolling after it */}
    <Person p={[x, 0, 1.2]} h={3.5} look={hero} f={f} pose={{ mood: "grin", walk: x * WALK * 0.75, speed: 1, arms: "up", armK: 0.7, tilt: 0.1, lookX: 0.4 }} />
    <FaceGroup p={[x, 0, 1.2]}><Cyl p={[0.6, 2.9, 0.1]} rt={0.5} rb={0.15} h={0.9} color="#ffc23a" line={3} rot={[0, 0, -1.4]} /></FaceGroup>
    <group position={[x - 8.5, 2.2, 1.0]} rotation={[0, 0, -(x - 8.5) / 2.2]}><Cyl p={[0, 0, 0]} rt={2.2} h={1.4} color="#e23b3b" line={4} rot={[Math.PI / 2, 0, 0]} /></group>
    <group position={[x - 8.5, 2.2, 1.0]}><AnalogClock p={[0, 0, 0.75]} r={1.95} h={2} m={19.2 + (t - 10) * 0.1} rim="#c0182e" /><Ball p={[-0.2, -0.3, 0.9]} r={0.01} color="#000" ink={0} /></group>
    {BUB.map((txt, i) => { const born = 10.5 + i * 0.95, u = clamp((t - born) / 1.6), bx = RX(born) - 1.5 - u * 3; return u > 0 && u < 1 ? <CanvasPlane key={i} p={[bx + (x - RX(born)), 4.2 + Math.sin(u * 5 + i) * 0.4 + i * 0.05, 1.5]} s={[2.8, 0.9]} px={[280, 90]} face draw={(c, W, H) => { c.globalAlpha = 1 - u * 0.7; c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 14, 20); c.fill(); c.stroke(); c.fillStyle = "#e5233a"; c.font = "900 38px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(txt, W / 2, H / 2 - 2); }} /> : null; })}
    <Dust t={t} area={[10, 6, 4]} color="rgba(255,255,230,.8)" />
  </>);
};

/* ============ S5 15.9 – 19.4  "accounts will read zero dollars, and nothing comes back." ============ */
const K5: Key[] = [
  { t: 15.7, pos: [-1.0, 3.6, 10.2], look: [0.4, 3.0, 0], fov: 56 },
  { t: 17.4, pos: [0.2, 3.5, 9.0], look: [0.6, 3.0, 0], fov: 54 },
  { t: 19.6, pos: [0.4, 3.3, 8.2], look: [0.8, 3.0, 0], fov: 52 },
];
export const S5 = ({ t, f }: Ctx) => {
  const bal = lerp(4812.3, 0, seg(t, 16.3, 17.2, Easing.in(Easing.quad))), zero = t > 17.2, shake = zero ? Math.exp(-(t - 17.36) * 5) * Math.sin(t * 60) * 0.04 : 0, retry = t > 18.2;
  const roll = seg(t, 18.4, 19.6, Easing.linear);
  return (<>
    <Cam t={t} keys={K5} impacts={[[17.36, 0.03]]} />
    <Lights warm="#c0ffd8" />
    <Floor kind="tile" a="#0f2a22" b="#0a201a" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#0c2a22" b="#0c2a22" base="#061812" /><SideWall x={-9} kind="plain" a="#0a241c" b="#0a241c" /><SideWall x={9} kind="plain" a="#0a241c" b="#0a241c" />
    <group position={[1.6 + shake, 0, -1.4]}><Box p={[0, 2.6, 0]} s={[3.2, 5.2, 1.6]} color="#2a3a46" line={4} /><Box p={[0, 3.6, 0.82]} s={[2.5, 1.9, 0.05]} color="#0b0d1a" line={2} />
      <CanvasPlane p={[0, 3.6, 0.86]} s={[2.3, 1.7]} px={[230, 170]} draw={(c, W, H) => { c.fillStyle = zero ? "#2a0a0a" : "#052a14"; c.fillRect(0, 0, W, H); c.textAlign = "center"; c.textBaseline = "middle"; c.fillStyle = zero ? "#ff4a4a" : "#3dff7a"; c.font = "800 22px Inter, Arial"; c.fillText(retry ? "RETRYING..." : "BALANCE", W / 2, 24); c.font = "900 52px Inter, Arial"; c.fillText("$" + bal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), W / 2, 90); if (retry) { c.strokeStyle = "#ff9a4a"; c.lineWidth = 9; c.beginPath(); c.arc(W / 2, 134, 18, t * 8, t * 8 + 4); c.stroke(); } }} />
      <Box p={[0, 1.9, 0.85]} s={[1.6, 0.14, 0.2]} color="#14141c" line={2} /><Box p={[0.9, 2.6, 0.85]} s={[0.5, 0.7, 0.1]} color="#4a5a66" line={2} /><Glow p={[0, 3.6, 1.4]} r={3} color={zero ? "rgba(255,60,60,1)" : "rgba(60,255,120,1)"} o={0.45} />
      {zero ? <Box p={[0, 1.4 - 0.5 * seg(t, 17.6, 18.4), 0.86]} s={[0.9, 1.0 * seg(t, 17.6, 18.4) + 0.01, 0.02]} color="#f4f4f4" line={1} /> : null}</group>
    <group position={[-3.6, 0, -1.8]}><Box p={[0, 2.2, 0]} s={[2.4, 4.4, 1.4]} color="#2a3a46" line={3} /><Box p={[0, 3.2, 0.72]} s={[1.8, 1.4, 0.05]} color="#05140c" line={2} /><Glow p={[0, 3.2, 1.2]} r={2.2} color="rgba(60,255,120,1)" o={0.3} /></group>
    {[-6.6, 6.8].map((x) => <Box key={x} p={[x, 1.6, -4.6]} s={[0.3, 3.2, 0.3]} color="#c9a032" line={2} />)}<Plant p={[-7.6, 0, 1]} s={1.3} pot="#2a6a4a" /><Lamp p={[7.4, 0, -2]} h={3.4} color="#b0ffd0" />
    <Box p={[3.8, 4.6, -5.6]} s={[0.5, 0.4, 0.7]} color="#14141c" line={2} /><Rug p={[0, 0.01, 3.6]} s={[8, 3]} a="#0a3a2a" b="#0f5a3a" />
    {/* tumbleweed */}
    {roll > 0 ? <group position={[lerp(-7, 8, roll), 0.7 + 0.25 * Math.abs(Math.sin(roll * 18)), 3.2]} rotation={[0, 0, -roll * 22]}><Ball p={[0, 0, 0]} r={0.6} color="#a8884a" ink={0.05} />{[0, 1, 2, 3].map((i) => <Box key={i} p={[0, 0, 0]} s={[1.4, 0.06, 0.06]} rot={[0, 0, i * 0.8]} color="#6a4a22" line={0} />)}</group> : null}
    <Person p={[-0.6, 0, 0.6]} h={3.8} look={hero} f={f} pose={{ mood: zero ? "shock" : "worry", sweat: zero ? 1 : 0, nerv: zero ? 0.9 : 0.1, hunch: 0.2, armR: t < 17.2 ? [0.3, 0.5] : undefined, armRK: t < 17.2 ? 1 : 0, arms: zero ? "head" : undefined, armK: seg(t, 17.3, 17.6), lookX: 0.6, squash: zero ? -0.1 * Math.exp(-(t - 17.2) * 6) : 0 }} />
  </>);
};

/* ============ S6 19.4 – 24.4  "Days earlier, Microsoft 365 had crashed. Fear had its proof." ============ */
const K6: Key[] = [
  { t: 19.2, pos: [-1.5, 3.8, 10.5], look: [-0.5, 3.6, -3], fov: 56 },
  { t: 21.0, pos: [-3.5, 4.0, 11.5], look: [-3.8, 3.2, -2], fov: 56 },
  { t: 22.5, pos: [0.6, 4.0, 12.5], look: [0.4, 3.0, -1.5], fov: 58 },
  { t: 22.95, pos: [3.4, 3.0, 8.0], look: [3.4, 1.6, 0], fov: 52 },
  { t: 24.6, pos: [3.4, 3.2, 7.2], look: [3.4, 1.6, 0], fov: 50 },
];
export const S6 = ({ t, f }: Ctx) => {
  const day = Math.round(lerp(17, 12, seg(t, 19.56, 20.5, Easing.linear))), crash = t > 22.16, ss = crash ? Math.exp(-(t - 22.16) * 4) : 0, stamp = seg(t, 23.55, 23.79, Easing.in(Easing.quad)), pressed = t > 23.79;
  return (<>
    <Cam t={t} keys={K6} impacts={[[22.16, 0.04], [23.79, 0.05]]} />
    <Lights warm="#f0f8ff" />
    <Floor kind="tile" a="#dfe8f0" b="#cfdae6" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#7aa8d8" b="#7aa8d8" base="#4a78a8" /><SideWall x={-9} kind="plain" a="#6a98c8" b="#6a98c8" /><SideWall x={9} kind="plain" a="#6a98c8" b="#6a98c8" />
    <Calendar p={[-4.4, 5.8, -5.88]} month="NOV" day={String(day)} s={2.6} />
    <CanvasPlane p={[2.2, 6.4, -5.88]} s={[4.8, 1.6]} px={[480, 160]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = crash ? "#0a2a8a" : "#1f6ad8"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 52px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("OFFICE CLOUD 365", W / 2, H / 2 - 12); c.font = "800 30px Inter, Arial"; c.fillText(crash ? ":( SERVICE DOWN" : "ALL SYSTEMS OK", W / 2, H / 2 + 38); }} />
    {[-5.8, -1.8, 2.2, 6.2].map((x, i) => <React.Fragment key={x}><Desk p={[x, 0, -2.4]} w={3.2} top="#f4f4f4" leg="#8a98a8" />
      <CanvasPlane p={[x, 2.45, -2.5]} s={[1.9, 1.2]} px={[190, 120]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = crash ? "#1f4ad8" : "#ffffff"; c.fillRect(0, 0, W, H); if (crash) { c.fillStyle = "#fff"; c.font = "900 54px Inter, Arial"; c.textAlign = "center"; c.fillText(":(", W / 2, 60); c.font = "800 15px Inter, Arial"; c.fillText("SERVICE UNAVAILABLE", W / 2, 96); } else { c.fillStyle = "#c8d8f0"; for (let k = 0; k < 5; k++) c.fillRect(14, 14 + k * 20, W - 28 - (k % 3) * 30, 10); } }} />
      <Person p={[x, 0, -0.9]} h={3.6} look={i === 1 ? techie : ppl[i + 2]} f={f + i * 5} pose={{ mood: crash ? "shock" : "deadpan", sweat: crash ? 1 : 0, nerv: crash ? 0.8 : 0.1, arms: crash ? "head" : undefined, armK: seg(t, 22.2, 22.45), armR: crash ? undefined : [0.2, 0.5 + 0.05 * Math.sin(t * 9 + i)], armRK: crash ? 0 : 1, squash: crash ? -0.12 * ss : 0, air: crash && ss > 0.8 ? 1 : 0 }} /></React.Fragment>)}
    <group position={[8.0, 0, -3.8]}><Box p={[0, 2.2, 0]} s={[1.8, 4.4, 1.4]} color="#2a3446" line={3} />{[0, 1, 2, 3, 4, 5].map((k) => <Ball key={k} p={[-0.4 + (k % 2) * 0.8, 0.8 + Math.floor(k / 2) * 1.2, 0.74]} r={0.1} color={crash ? "#ff3b3b" : "#2fd46a"} ink={0.02} />)}</group>
    {crash ? [0, 1, 2].map((i) => { const u = ((t - 22.16) * 0.9 + i / 3) % 1; return <Ball key={i} p={[8.0 + Math.sin(i * 2) * 0.4, 4.6 + u * 2, -3.6]} r={0.2 + 0.4 * u} color="#555" ink={0.03} />; }) : null}
    {crash ? <Glow p={[8.0, 4.4, -3.4]} r={2.4} color="rgba(255,200,80,1)" o={0.6 * Math.exp(-(t - 22.16) * 3)} /> : null}
    {/* the evidence desk: PROOF stamp */}
    <Box p={[3.4, 1.0, 0]} s={[3.6, 0.16, 2.2]} color="#7a5a3a" line={3} /><Box p={[3.4, 0.5, 0]} s={[3.2, 1.0, 1.8]} color="#5a3e26" line={2} />
    <CanvasPlane p={[3.4, 1.11, 0.1]} rot={[-Math.PI / 2, 0, 0]} s={[2.0, 1.4]} px={[200, 140]} draw={(c, W, H) => { c.fillStyle = "#f6edc8"; c.fillRect(0, 0, W, H); c.strokeStyle = INK; c.lineWidth = 5; c.strokeRect(3, 3, W - 6, H - 6); c.fillStyle = INK; c.font = "900 18px Inter, Arial"; c.textAlign = "center"; c.fillText("EXHIBIT A", W / 2, 28); c.font = "800 15px Inter, Arial"; c.fillText("THE OFFICE CRASH", W / 2, 52); if (pressed) { c.save(); c.translate(W / 2, 100); c.rotate(-0.2); c.strokeStyle = "#e5233a"; c.fillStyle = "#e5233a"; c.lineWidth = 6; c.strokeRect(-70, -26, 140, 52); c.font = "900 42px Inter, Arial"; c.fillText("PROOF", 0, 14); c.restore(); } }} />
    <group position={[3.4, 1.12 + lerp(2.6, 0.18, stamp) + (pressed ? 0 : 0), 0.1]}><Box p={[0, 0.0, 0]} s={[0.9, 0.16, 0.7]} color="#c0182e" line={3} /><Cyl p={[0, 0.6, 0]} rt={0.18} h={1.0} color="#3a2a22" line={3} /><Ball p={[0, 1.2, 0]} r={0.28} color="#3a2a22" ink={0.04} /></group>
    {t > 22.98 ? [-0.8, 0.8, 2.6].map((x, i) => <Person key={i} p={[x + 3.4 - 0.4, 0, -2.6]} h={3.2} look={ppl[(i + 4) % 8]} f={f + i * 3} pose={{ mood: "shock", nerv: 0.7, sweat: 1, hunch: 0.3, arms: "chest", armK: 1, lookX: 0.4 }} />) : null}
    <Plant p={[-8, 0, 2]} s={1.3} pot="#3a6a9a" /><Cooler p={[9, 0, -1]} /><Dust t={t} area={[6, 6, 4]} color="rgba(230,240,255,.9)" />
  </>);
};

/* ============ S7 24.4 – 28.1  "Then one viral reel asked the question nobody wanted answered:" ============ */
const K7: Key[] = [
  { t: 24.2, pos: [-5.5, 3.2, 12.5], look: [0, 4.2, 0], fov: 58 },
  { t: 26.0, pos: [0.0, 3.8, 12.0], look: [0, 4.4, 0], fov: 56 },
  { t: 28.3, pos: [3.5, 4.2, 11.0], look: [0, 4.4, 0], fov: 54 },
];
export const S7 = ({ t, f }: Ctx) => {
  const hearts = Array.from({ length: 14 }, (_, i) => { const u = ((t - 24.6) * 0.45 + i / 14) % 1; return { x: 2.3 + Math.sin(i * 2.3 + u * 4) * 1.4, y: 2 + u * 7, o: 1 - u, s: 0.5 + (i % 3) * 0.2 }; });
  const cover = seg(t, 26.93, 27.2);
  return (<>
    <Cam t={t} keys={K7} />
    <Lights warm="#ffd0f0" />
    <Floor kind="tile" a="#2a1148" b="#220d3c" unit={1.8} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#3a1660" b="#3a1660" base="#1a0a30" /><SideWall x={-9} kind="plain" a="#30124f" b="#30124f" /><SideWall x={9} kind="plain" a="#30124f" b="#30124f" />
    <group position={[0, 0, -1.6]}><Box p={[0, 4.6, 0]} s={[4.4, 8.0, 0.5]} color="#14141c" line={4} />
      <CanvasPlane p={[0, 4.6, 0.28]} s={[4.0, 7.6]} px={[400, 760]} draw={(c, W, H) => {
        const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#5a1a9a"); g.addColorStop(1, "#c2185b"); c.fillStyle = g; c.fillRect(0, 0, W, H);
        c.fillStyle = "#0b0b14"; c.beginPath(); c.arc(190, 300, 90, 0, 7); c.fill(); c.fillRect(70, 380, 240, 330); c.fillStyle = "#1a1a28"; c.beginPath(); c.arc(190, 290, 100, Math.PI, 0); c.fill();
        c.fillStyle = "#ffe14a"; c.beginPath(); c.arc(160, 300, 12, 0, 7); c.arc(220, 300, 12, 0, 7); c.fill();
        const s = 0.85 + 0.15 * seg(t, 25.8, 26.1, Easing.out(Easing.back(2.5))); c.save(); c.translate(200, 110); c.scale(s, s); c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(-170, -70, 340, 130, 30); c.fill(); c.stroke(); c.fillStyle = "#e5233a"; c.font = "900 56px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("WHAT IF...?", 0, -4); c.restore();
        c.fillStyle = "#fff"; c.font = "800 26px Inter, Arial"; c.textAlign = "left"; c.fillText("@viral_reel", 20, H - 70); c.fillStyle = "rgba(255,255,255,.8)"; c.fillText("#question", 20, H - 36);
        drawRail(c, W, H, t);
      }} /></group>
    {hearts.map((h, i) => <Heart key={i} p={[h.x, h.y, 0.4]} s={h.s * (h.o > 0.1 ? 1 : 0.001)} />)}
    {[-5.2, -3.4, 3.6, 5.4].map((x, i) => <Person key={i} p={[x, 0, 1.2 + (i % 2) * 0.8]} h={3.6} look={ppl[i + 1]} f={f + i * 4} pose={{ mood: t < 26.93 ? "deadpan" : "worry", sweat: t > 26.93 ? 1 : 0, nerv: 0.2, arms: t > 26.93 ? "head" : undefined, armK: cover, armR: t < 26.93 ? [0.14, 0.62] : undefined, armRK: t < 26.93 ? 1 : 0, lookX: x < 0 ? 0.7 : -0.7, flip: x > 0 }} />)}
    <Glow p={[0, 4.6, 1.6]} r={6.5} color="rgba(220,90,255,1)" o={0.35} /><Dust t={t} area={[6, 6, 4]} color="rgba(240,180,255,.9)" />
  </>);
};
function drawRail(c: CanvasRenderingContext2D, W: number, H: number, t: number) { c.fillStyle = "#fff"; c.font = "900 34px Inter, Arial"; c.textAlign = "center"; c.fillText("♥", W - 36, H - 330); c.font = "800 20px Inter, Arial"; c.fillText(String(Math.round(1000 + Math.max(0, t - 24.5) * 2400)), W - 36, H - 296); c.font = "900 30px Inter, Arial"; c.fillText("💬", W - 36, H - 240); c.fillText("➦", W - 36, H - 170); }

/* ============ S8 28.1 – 30.0  "what if this isn't a glitch?" ============ */
const K8: Key[] = [
  { t: 27.9, pos: [-0.6, 3.2, 9.5], look: [0, 3.0, 0], fov: 56 },
  { t: 30.2, pos: [0.2, 3.1, 6.8], look: [0.1, 3.0, 0], fov: 46 },
];
export const S8 = ({ t, f }: Ctx) => {
  const x = seg(t, 28.89, 29.1, Easing.out(Easing.cubic)), j = Math.sin(t * 90) * 5 * (t < 28.89 ? 1 : 0.4);
  return (<>
    <Cam t={t} keys={K8} />
    <Lights warm="#80a0ff" />
    <Floor kind="plank" a="#2a2230" b="#241c2a" unit={1.8} w={30} d={24} />
    <WallDoor z={-6} W={30} kind="plain" a="#1a1424" b="#1a1424" base="#0e0a16" /><SideWall x={-9} kind="plain" a="#161020" b="#161020" /><SideWall x={9} kind="plain" a="#161020" b="#161020" />
    <Box p={[0, 3.2, -2.4]} s={[6.6, 4.4, 0.7]} color="#0b0d14" line={4} />
    <CanvasPlane p={[0, 3.2, -2.02]} s={[6.1, 3.9]} px={[610, 390]} draw={(c, W, H) => {
      c.fillStyle = "#060a14"; c.fillRect(0, 0, W, H); const txt = (dx: number, col: string) => { c.fillStyle = col; c.font = "900 130px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("GLITCH", W / 2 + dx + j, H / 2 + 6); };
      c.globalCompositeOperation = "lighter"; txt(-9, "#ff2a4a"); txt(9, "#2affd0"); txt(0, "#4a6aff"); c.globalCompositeOperation = "source-over";
      for (let y = 0; y < H; y += 6) { c.fillStyle = "rgba(0,0,0,.22)"; c.fillRect(0, y, W, 2); } for (let k = 0; k < 5; k++) { c.fillStyle = "rgba(255,255,255,.12)"; c.fillRect(0, ((t * 400 + k * 97) % H), W, 6 + k * 3); }
      c.fillStyle = "#ff3b3b"; c.font = "900 80px Inter, Arial"; c.fillText("?", 560, 70);
      if (x > 0) { c.strokeStyle = "#ff2b2b"; c.lineWidth = 26; c.lineCap = "round"; c.beginPath(); c.moveTo(60, 70 + 260 * 0); c.lineTo(60 + 490 * x, 70 + 250 * x); c.moveTo(550, 70); c.lineTo(550 - 490 * x, 70 + 250 * x); c.stroke(); }
    }} />
    <Glow p={[0, 3.2, -0.8]} r={8} color="rgba(120,140,255,1)" o={0.35} /><Lamp p={[-6, 0, -2]} h={3.2} color="#8aa0ff" /><Frame p={[-5.6, 4.6, -5.9]} s={[1.4, 1.8]} art={2} /><Frame p={[5.6, 4.8, -5.9]} s={[1.6, 1.2]} art={1} />
    <Box p={[0, 0.5, -1.4]} s={[4.4, 1.0, 1.0]} color="#2a1e38" line={3} /><Plant p={[6.6, 0, -2.4]} s={1.3} pot="#4a3a8a" /><Dust t={t} area={[5, 4, 3]} color="rgba(150,170,255,.8)" />
    <Person p={[0, 0, 1.2]} h={3.9} look={hero} f={f} pose={{ mood: t < 28.9 ? "worry" : "shock", sweat: 1, nerv: 0.4, lookX: 0, hunch: 0.15, armR: [0.3, 0.5], armRK: seg(t, 28.0, 28.3), squash: t > 28.9 ? -0.05 : 0 }} />
  </>);
};

/* ============ S9 30.0 – 35.0  "What if it's a rehearsal for the day an AI grows too smart and humans have to pull the plug?" ============ */
const K9: Key[] = [
  { t: 29.8, pos: [-3.0, 3.6, 13.5], look: [0, 3.0, -1], fov: 58 },
  { t: 31.8, pos: [1.0, 3.8, 12.5], look: [1.4, 3.4, -1], fov: 56 },
  { t: 33.0, pos: [0.0, 3.4, 12.0], look: [-1.6, 2.6, -1], fov: 56 },
  { t: 34.3, pos: [-2.6, 2.8, 9.0], look: [-4.2, 1.8, -1], fov: 50 },
  { t: 35.3, pos: [-1.0, 3.2, 11.5], look: [-1.0, 2.6, -1], fov: 54 },
];
export const S9 = ({ t, f }: Ctx) => {
  const grow = seg(t, 32.2, 32.9, Easing.out(Easing.back(1.6))), k = lerp(1.0, 1.7, grow), power = t < 34.41 ? 1 : 0, eye = t > 32.8 && t < 34.41 ? "#ff3b3b" : "#4ad0ff", pull = seg(t, 34.0, 34.41, Easing.in(Easing.quad)), after = Math.max(0, t - 34.41), droop = power ? 0 : Math.min(1, after * 2.2);
  const plug: V3 = power ? [-6.2 + 1.6 * pull, 1.2, -1.0 + 0.4 * pull] : [-4.6 + after * 0.1, 1.5 + 0.4 * seg(t, 34.5, 34.9), -0.6];
  const rob: V3 = [1.2, 0, -2.2];
  const n = 12, pts = Array.from({ length: n + 1 }, (_, i) => { const u = i / n; return [lerp(plug[0], rob[0] - 0.3, u), lerp(plug[1], 0.4, u) - Math.sin(u * Math.PI) * (power ? 0.5 - pull * 0.4 : 0.9), lerp(plug[2], rob[2] + 0.4, u)] as V3; });
  return (<>
    <Cam t={t} keys={K9} impacts={[[34.41, 0.03]]} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#6a4a30" b="#5e4028" unit={1.7} w={34} d={24} />
    <WallDoor z={-6} W={34} kind="plain" a="#2a1a3a" b="#2a1a3a" base="#140a20" /><SideWall x={-9} kind="plain" a="#241632" b="#241632" /><SideWall x={9} kind="plain" a="#241632" b="#241632" />
    <Curtain p={[-7, 4.6, -5.8]} s={[3, 9.2]} color="#8a1a2e" /><Curtain p={[7, 4.6, -5.8]} s={[3, 9.2]} color="#8a1a2e" /><Curtain p={[0, 8.8, -5.6]} s={[18, 1.8]} color="#8a1a2e" folds={14} />
    <Banner p={[0, 7.4, -5.2]} s={[5.4, 1.5]} text="REHEARSAL" size={64} bg="#14141c" fg="#ffc23a" />
    <SpotCone p={[1.2, 10, -2]} h={10} r={2.6} color="#fff2c0" o={0.15} /><Glow p={[1.2, 0.2, -2]} r={3} color="rgba(255,240,200,1)" o={0.35} />
    {/* wall socket */}
    <Box p={[-6.4, 1.2, -1.0]} s={[0.4, 0.8, 0.6]} color="#e8e0c8" line={3} /><Box p={[-6.2, 1.2, -0.6]} s={[0.1, 0.5, 0.1]} color="#111" line={0} />
    <Robot p={rob} k={k} eye={eye} power={power} droop={droop} t={t} />
    {pts.slice(0, -1).map((a, i) => { const b = pts[i + 1], dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy); return <Cyl key={i} p={[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]} rt={0.06} h={len + 0.05} color="#16161e" line={1} rot={[0, 0, Math.atan2(dx, dy) * -1]} />; })}
    <Box p={plug} s={[0.4, 0.5, 0.3]} color="#e8e0c8" line={3} />
    {t > 34.41 && t < 34.9 ? <Glow p={[-5.0, 1.2, -0.6]} r={2.4} color="rgba(255,230,120,1)" o={0.9 * Math.exp(-(t - 34.41) * 8)} /> : null}
    {after > 0 && after < 1.2 ? [0, 1, 2].map((i) => <Ball key={i} p={[1.2 + Math.sin(i * 2) * 0.5, 3.2 + after * (1 + i * 0.4), -2]} r={0.2 + after * 0.2} color="#666" ink={0.03} />) : null}
    {/* director + two humans */}
    <Person p={[-2.6, 0, 1.6]} h={3.9} look={officialB} f={f} pose={{ mood: t < 32.2 ? "smile" : "shock", arms: t > 30.2 && t < 32.2 ? "point" : "hold", armK: 1, sweat: t > 32.5 ? 1 : 0, nerv: t > 32.5 ? 0.6 : 0 }} />
    <Chair p={[-4.4, 0, 3.0]} rotY={0.6} color="#2a2a38" />
    <Person p={[-4.7 + 0.0, 0, -0.4]} h={3.5} look={ppl[1]} f={f + 3} pose={{ mood: t > 33.48 ? "angry" : "worry", flip: false, armR: t > 33.5 && power ? [0.34 + 0.02 * pull, 0.34] : t > 34.41 ? [0.3, 0.62] : undefined, armRK: t > 33.5 ? seg(t, 33.48, 33.7) : 0, tilt: t > 34.0 && power ? -0.12 * pull : 0, lookX: -0.7 }} />
    <Person p={[-3.4, 0, -0.9]} h={3.5} look={ppl[3]} f={f + 7} pose={{ mood: t > 33.48 ? "angry" : "worry", armR: t > 33.6 && power ? [-0.1, 0.34] : undefined, armRK: t > 33.6 ? 1 : 0, lookX: -0.7 }} />
    {Array.from({ length: 12 }, (_, i) => <Box key={i} p={[-5 + (i % 6) * 2.6, 0.6, 5 + Math.floor(i / 6) * 1.6]} s={[1.3, 1.2, 1.0]} color="#7a1a2e" line={2} />)}
    <Dust t={t} area={[7, 6, 4]} color="rgba(255,230,190,.9)" />
  </>);
};

/* ============ S10 35.0 – 37.4  "Tens of thousands of people liked it." ============ */
const K10: Key[] = [
  { t: 34.8, pos: [0, 3.0, 11.0], look: [0, 3.4, -2], fov: 58 },
  { t: 36.4, pos: [0, 7.5, 15.0], look: [0, 3.6, -3], fov: 60 },
  { t: 37.8, pos: [0, 10.0, 17.0], look: [0, 3.4, -3], fov: 60 },
];
export const S10 = ({ t, f }: Ctx) => {
  const burst = seg(t, 36.76, 37.1, Easing.out(Easing.back(2.5))), pop = seg(t, 35.4, 35.7, Easing.out(Easing.back(2.5)));
  const hs = Array.from({ length: 24 }, (_, i) => { const u = ((t - 35.0) * 0.55 + i / 24) % 1; return { x: -7 + ((i * 53) % 140) / 10, y: 1.5 + u * 8, z: -3 - (i % 5) * 1.4, o: 1 - u }; });
  return (<>
    <Cam t={t} keys={K10} />
    <Lights warm="#ffd0e0" />
    <Sky p={[0, 26, -70]} s={[300, 150]} top="#c2185b" bottom="#ff9ac0" />
    <Surface p={[0, 0, -8]} s={[80, 50]} rot={[-Math.PI / 2, 0, 0]} kind="tile" a="#3a1a4a" b="#2e1440" unit={2.2} />
    <CrowdField n={170} t={t} at={(i) => [-10 + (i % 17) * 1.2 + (Math.floor(i / 17) % 2) * 0.6, Math.floor(i / 17) * 0.45, -2 - Math.floor(i / 17) * 1.3] as V3} size={1.1} rate={6} />
    {Array.from({ length: 10 }, (_, i) => <Phone key={i} p={[-9 + i * 2, 2.8 + (i % 3) * 0.5, -2.4 - (i % 3) * 2]} s={1.2} glow="rgba(255,255,255,1)" o={0.2} draw={(c, W, H) => { drawHeart(c, W, H * 0 + W, "#ff3b6b"); }} />)}
    {hs.map((h, i) => h.o > 0.08 ? <Heart key={i} p={[h.x, h.y, h.z]} s={0.9} /> : null)}
    <Heart p={[0, 6.6, -4]} s={4.4 * (1 + 0.12 * Math.sin(t * 14) + 0.6 * burst)} />
    <CanvasPlane p={[0, 3.2, -1.0]} s={[9.2 * pop + 0.001, 2.2 * pop + 0.001]} px={[920, 220]} frame="#0b0d1a" draw={(c, W, H) => { c.fillStyle = "#14081e"; c.fillRect(0, 0, W, H); c.fillStyle = "#ff5a8a"; c.font = "900 72px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("♥ TENS OF THOUSANDS", W / 2, H / 2 + 4); }} />
    <Glow p={[0, 5, -3]} r={10} color="rgba(255,90,160,1)" o={0.3} />
    {[-3, 0, 3].map((x, i) => <Person key={i} p={[x, 0, 3.2]} h={3.4} look={ppl[i + 2]} f={f + i * 5} pose={{ mood: "grin", ...danceBeat(t, i, 0.3).pose, arms: "up", armK: 1 }} />)}
  </>);
};

/* ============ S11 37.4 – 41.0  "The clock hit 2:20. The alert sounded. Phones buzzed." ============ */
const K11: Key[] = [
  { t: 37.2, pos: [0, 1.6, 12.5], look: [0, 9.5, -6], fov: 58 },
  { t: 38.6, pos: [0.4, 2.2, 11.0], look: [0, 8.5, -6], fov: 54 },
  { t: 39.3, pos: [-2.0, 3.0, 10.0], look: [-1.0, 2.6, 0], fov: 54 },
  { t: 40.6, pos: [0.0, 2.8, 7.6], look: [0, 2.6, 1.0], fov: 48 },
  { t: 41.4, pos: [0.0, 2.8, 7.2], look: [0, 2.6, 1.0], fov: 48 },
];
export const S11 = ({ t, f }: Ctx) => {
  const tick = seg(t, 38.13, 38.28, Easing.out(Easing.back(3))), min = lerp(19, 20, tick), alert = t >= 38.97, buzz = t >= 40.03, rings = alert ? (t - 38.97) : 0;
  return (<>
    <Cam t={t} keys={K11} impacts={[[38.13, 0.015], [38.97, 0.03], [40.03, 0.02]]} />
    <Lights warm="#e8e8e8" />
    <Sky p={[0, 26, -60]} s={[300, 150]} top="#7a8a9a" bottom="#dfe4ea" />
    <Surface p={[0, 0, -10]} s={[80, 50]} rot={[-Math.PI / 2, 0, 0]} kind="brick" a="#a8a49a" b="#98948a" unit={1.6} />
    <Box p={[0, 7.5, -8]} s={[6, 15, 6]} color="#9a7a5a" /><Box p={[0, 15.4, -8]} s={[7, 0.8, 7]} color="#5a4a3a" line={3} /><Cyl p={[0, 18.6, -8]} rt={0} rb={3.2} h={5.5} color="#4a6a8a" line={4} />
    <AnalogClock p={[0, 11.4, -4.9]} r={2.4} h={2} m={min} />
    <group position={[0, 14.4, -4.8]}><Cyl p={[0, 0, 0]} rt={0.2} rb={0.8} h={1.4} color="#c9a032" line={3} rot={[Math.PI / 2, 0, 0]} /></group>
    {alert ? [0, 1, 2, 3].map((i) => { const u = (rings * 1.2 + i * 0.25) % 1; return <CanvasPlane key={i} p={[0, 14.4, -4.0]} s={[2 + u * 14, 2 + u * 14]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = `rgba(255,50,50,${1 - u})`; c.lineWidth = 14; c.beginPath(); c.arc(100, 100, 86, 0, 7); c.stroke(); }} />; }) : null}
    {[-12, -8, 8, 12].map((x, i) => <Building key={x} p={[x, 0, -14 - (i % 2) * 2]} s={[5, 9 + i * 2, 5]} color={["#8a7a6a", "#6a7a8a", "#8a6a6a", "#6a8a7a"][i]} lit={0.3} trim="#2b3350" />)}
    <StreetLamp p={[-6, 0, -2]} h={5.4} /><StreetLamp p={[6, 0, -2]} h={5.4} flip /><Bench p={[-5, 0, -5]} /><Hydrant p={[5.4, 0, -4]} /><Bin p={[-5.6, 0, 1]} />
    {[-5, -2.8, -0.6, 1.6, 3.8, 5.8].map((x, i) => { const sh = buzz ? Math.sin(t * 70 + i * 3) * 0.05 : 0;
      return <React.Fragment key={i}><Person p={[x + sh, buzz ? 0.15 * Math.abs(Math.sin(t * 20 + i)) : 0, 0.6 + (i % 2) * 0.9]} sy={0} h={3.5} look={ppl[i + 1]} f={f + i * 4} pose={{ mood: buzz ? "shock" : alert ? "worry" : "deadpan", nerv: buzz ? 0.8 : 0.1, sweat: buzz ? 1 : 0, armR: [0.18, 0.62], armRK: 1, lookX: 0.2, squash: buzz ? -0.05 * Math.abs(Math.sin(t * 20 + i)) : 0 }} />
        {buzz ? <FaceGroup p={[x + sh, 0, 0.6 + (i % 2) * 0.9]}><Glow p={hand(3.5, [0.18, 0.7], 0, false, 0.2)} r={0.9} color="rgba(255,60,60,1)" o={0.7} /></FaceGroup> : null}</React.Fragment>; })}
    {buzz ? [-2.8, 1.6, 5.8].map((x, i) => <CanvasPlane key={i} p={[x, 6.0, 1.6]} s={[1.3, 0.8]} px={[130, 80]} face draw={(c, W, H) => { c.fillStyle = "#e5233a"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 14); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 30px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("ALERT!", W / 2, H / 2 + 2); }} />) : null}
    <Dust t={t} area={[8, 8, 5]} color="rgba(255,255,255,.8)" />
  </>);
};

/* ============ S12 41.0 – 46.0  "And the internet stayed on. No grid failure, no reset, no takeover." ============ */
const ST = [0, 4.8, 9.6, 14.4];
const K12: Key[] = [
  { t: 40.8, pos: [0.5, 3.2, 8.4], look: [0.4, 2.6, 0], fov: 52 },
  { t: 42.6, pos: [2.6, 3.4, 8.8], look: [2.6, 2.6, 0], fov: 52 },
  { t: 43.5, pos: [4.8, 3.4, 8.6], look: [4.8, 2.8, 0], fov: 52 },
  { t: 44.5, pos: [9.4, 3.2, 8.6], look: [9.6, 2.6, 0], fov: 52 },
  { t: 45.5, pos: [14.2, 3.2, 8.6], look: [14.4, 2.6, 0], fov: 52 },
  { t: 46.6, pos: [14.4, 3.4, 9.6], look: [14.4, 2.7, 0], fov: 52 },
];
const Verdict: React.FC<{ p: V3; k: number; ok?: boolean; text: string }> = ({ p, k, ok, text }) => (
  <CanvasPlane p={p} s={[2.8 * k + 0.001, 1.0 * k + 0.001]} px={[280, 100]} face draw={(c, W, H) => { c.fillStyle = ok ? "#1fa850" : "#e5233a"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 18); c.fill(); c.stroke(); c.fillStyle = "#fff"; c.font = "900 46px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(text, W / 2, H / 2 + 3); }} />
);
export const S12 = ({ t, f }: Ctx) => {
  const v = (a: number) => seg(t, a, a + 0.25, Easing.out(Easing.back(2.6)));
  const gx = Math.min(14.4, ST[0] + 0.5 + seg(t, 41.4, 46, ease) * 14);
  return (<>
    <Cam t={t} keys={K12} />
    <Lights warm="#fff0d8" />
    <Floor kind="marble" a="#d8d4cc" b="#c8c4bc" unit={2} w={60} d={24} />
    <WallDoor z={-6} W={60} kind="plain" a="#2a3a5a" b="#2a3a5a" base="#141c30" />
        {ST.map((x, i) => <React.Fragment key={i}><Cyl p={[x, 0.7, 0]} rt={1.5} rb={1.7} h={1.4} color="#e8e4dc" line={3} /><SpotCone p={[x, 9, 0]} h={9} r={1.9} color="#fff2c0" o={0.13} /><Glow p={[x, 1.6, 0.4]} r={2.6} color="rgba(255,240,200,1)" o={0.3} /></React.Fragment>)}
    {/* 1 router + wifi */}
    <Router p={[ST[0], 1.4, 0]} t={t} />
    <CanvasPlane p={[ST[0], 4.2, 0]} s={[2.0, 2.0]} px={[200, 200]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "#1f6ad8"; c.lineCap = "round"; c.lineWidth = 16; for (let k = 1; k <= 3; k++) { c.beginPath(); c.arc(100, 150, 28 * k, -Math.PI * 0.82, -Math.PI * 0.18); c.stroke(); } c.fillStyle = "#1f6ad8"; c.beginPath(); c.arc(100, 150, 12, 0, 7); c.fill(); }} />
    <Verdict p={[ST[0], 5.6, 0.3]} k={v(41.5)} ok text="STILL ON ✔" />
    {/* 2 power pole + lamp */}
    <Cyl p={[ST[1], 3.0, 0]} rt={0.14} rb={0.2} h={3.2} color="#8a6a42" line={3} /><Box p={[ST[1], 4.5, 0]} s={[1.8, 0.14, 0.14]} color="#5a3a22" line={2} /><Cyl p={[ST[1] + 0.8, 4.9, 0]} rt={0.12} h={0.5} color="#e8e8f0" line={2} /><Cyl p={[ST[1] - 0.8, 4.9, 0]} rt={0.12} h={0.5} color="#e8e8f0" line={2} />
    <Ball p={[ST[1], 3.9, 0.3]} r={0.45} color="#ffe28a" ink={0.05} /><Glow p={[ST[1], 3.9, 0.6]} r={2.6} color="rgba(255,226,120,1)" o={0.6 + 0.05 * Math.sin(t * 6)} />
    <Verdict p={[ST[1], 5.9, 0.3]} k={v(43.2)} text="NO BLACKOUT" />
    {/* 3 reset button under cobwebs */}
    <Cyl p={[ST[2], 1.55, 0]} rt={0.8} h={0.3} color="#2a2a38" line={3} /><Cyl p={[ST[2], 1.85, 0]} rt={0.6} h={0.3} color="#e5233a" line={3} /><Ball p={[ST[2], 2.4, 0]} r={1.1} color="#bfe8ff" s={[1, 0.85, 1]} ink={0.04} />
    <CanvasPlane p={[ST[2], 2.4, 1.15]} s={[2.4, 2.0]} px={[240, 200]} draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.strokeStyle = "rgba(255,255,255,.85)"; c.lineWidth = 3; for (let k = 0; k < 7; k++) { const a = -0.3 + k * 0.3; c.beginPath(); c.moveTo(10, 10); c.lineTo(10 + Math.cos(a) * 220, 10 + Math.sin(a) * 220); c.stroke(); } for (let r = 40; r < 200; r += 38) { c.beginPath(); c.arc(10, 10, r, 0.05, 1.5); c.stroke(); } }} />
    <Verdict p={[ST[2], 5.0, 0.3]} k={v(44.4)} text="NO RESET" />
    {/* 4 sleeping robot */}
    <Robot p={[ST[3], 1.4, 0]} k={0.8} power={0} droop={1} t={t} />
    {[0, 1, 2].map((i) => { const u = ((t * 0.7 + i / 3) % 1); return <CanvasPlane key={i} p={[ST[3] + 0.9 + u * 0.8, 4.3 + u * 1.3, 0.8]} s={[0.5 + 0.3 * u, 0.5 + 0.3 * u]} px={[80, 80]} face draw={(c, W, H) => { c.clearRect(0, 0, W, H); c.globalAlpha = 1 - u * 0.8; c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 6; c.font = "900 64px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.strokeText("Z", 40, 44); c.fillText("Z", 40, 44); }} />; })}
    <Verdict p={[ST[3], 5.4, 0.3]} k={v(45.4)} text="NO TAKEOVER" />
    <Person p={[gx + 1.6, 0, 1.8]} h={3.2} look={official} f={f} pose={{ mood: t < 41.3 ? "worry" : "smile", walk: seg(t, 41.4, 46, ease) < 1 ? gx * WALK : undefined, speed: t > 41.4 && t < 45.9 ? 0.45 : 0, arms: "hold", armK: 0.5, sweat: t < 41.5 ? 1 : 0, lookX: 0.4 }} />
    <Dust t={t} area={[14, 6, 5]} color="rgba(255,240,200,.8)" />
  </>);
};

/* ============ S13 46.0 – 51.8  "Just a test, a software outage, and a crowd that had already written the apocalypse before it started." ============ */
const K13: Key[] = [
  { t: 45.8, pos: [-6.6, 3.0, 8.6], look: [-6.6, 2.4, 0], fov: 52 },
  { t: 47.0, pos: [-1.6, 3.2, 8.4], look: [-1.6, 2.6, 0], fov: 52 },
  { t: 48.1, pos: [2.0, 3.4, 9.0], look: [3.0, 2.8, 0], fov: 54 },
  { t: 49.4, pos: [3.0, 5.0, 15.0], look: [3.0, 3.0, -2], fov: 60 },
  { t: 51.2, pos: [3.0, 4.4, 12.4], look: [3.0, 2.8, -1], fov: 56 },
  { t: 52.4, pos: [3.0, 4.2, 11.6], look: [3.0, 2.8, -1], fov: 54 },
];
export const S13 = ({ t, f }: Ctx) => {
  const clap = t < 50.95 ? 0.9 : Math.max(0, 0.9 * (1 - seg(t, 50.95, 51.05, Easing.linear))), writers = seg(t, 48.04, 48.6);
  return (<>
    <Cam t={t} keys={K13} impacts={[[51.02, 0.05]]} />
    <Lights warm="#fff0d8" />
    <Floor kind="plank" a="#7a5a3a" b="#6a4c30" unit={1.8} w={50} d={24} />
    <WallDoor z={-6} W={50} kind="plain" a="#1c2440" b="#1c2440" base="#0c1226" />
    <Banner p={[3.0, 6.9, -5.7]} s={[8.4, 2.0]} text="THE APOCALYPSE" sub="WRITTEN BY EVERYONE" size={78} bg="#14141c" fg="#ff5a3a" />
    <AnalogClock p={[-8.0, 5.4, -5.8]} r={1.5} h={2} m={19.9} /><Box p={[-8.0, 3.3, -5.8]} s={[0.1, 0.1, 0.1]} color="#000" line={0} />
    {/* 1: TEST sign + tiny buzzing phone */}
    <Box p={[-6.6, 0.7, 0]} s={[2.4, 1.4, 1.4]} color="#e8e4dc" line={3} /><Phone p={[-6.6 + (t > 46.0 && t < 46.9 ? Math.sin(t * 60) * 0.05 : 0), 1.95, 0.2]} s={1.1} draw={(c, W, H) => { c.fillStyle = "#2a6ad8"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 24px Inter, Arial"; c.textAlign = "center"; c.fillText("TEST", W / 2, H / 2); }} />
    <CanvasPlane p={[-6.6, 4.3, 0]} s={[2.2, 1.0]} px={[220, 100]} face draw={(c, W, H) => { c.fillStyle = "#ffe14a"; c.strokeStyle = INK; c.lineWidth = 8; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 16); c.fill(); c.stroke(); c.fillStyle = INK; c.font = "900 58px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("JUST A TEST", W / 2, H / 2 + 3); }} />
    {/* 2: software outage */}
    <Desk p={[-1.6, 0, 0]} w={2.8} top="#f4f4f4" leg="#8a98a8" />
    <CanvasPlane p={[-1.6, 2.3, -0.1]} s={[2.0, 1.3]} px={[200, 130]} frame="#14141c" draw={(c, W, H) => { c.fillStyle = "#1f4ad8"; c.fillRect(0, 0, W, H); c.fillStyle = "#fff"; c.font = "900 56px Inter, Arial"; c.textAlign = "center"; c.fillText(":(", W / 2, 64); c.font = "800 15px Inter, Arial"; c.fillText("SOFTWARE OUTAGE", W / 2, 100); }} />
    <CanvasPlane p={[-1.6, 4.6, 0]} s={[3.0, 0.9]} px={[300, 90]} face draw={(c, W, H) => { c.fillStyle = "#fff"; c.strokeStyle = INK; c.lineWidth = 7; c.beginPath(); c.roundRect(6, 6, W - 12, H - 12, 16); c.fill(); c.stroke(); c.fillStyle = "#1f4ad8"; c.font = "900 38px Inter, Arial"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText("A SOFTWARE OUTAGE", W / 2, H / 2 + 3); }} />
    <Person p={[-1.6, 0, 1.2]} h={3.7} look={techie} f={f} pose={{ mood: "deadpan", arms: "shrug", armK: seg(t, 46.9, 47.2), lookX: 0.2 }} />
    {/* 3: a crowd writing the apocalypse before it started */}
    <Box p={[3.0, 1.0, -0.6]} s={[7.6, 0.2, 2.4]} color="#8a6a42" line={3} />{[-3, 3].map((x) => <Box key={x} p={[3.0 + x, 0.5, -0.6]} s={[0.3, 1.0, 2.0]} color="#5a4228" line={2} />)}
    <CanvasPlane p={[3.0, 1.12, -0.6]} rot={[-Math.PI / 2, 0, 0]} s={[7.0, 2.0]} px={[700, 200]} draw={(c, W, H) => { c.fillStyle = "#f6edc8"; c.fillRect(0, 0, W, H); c.strokeStyle = "#5a4228"; c.lineWidth = 4; c.strokeRect(2, 2, W - 4, H - 4); c.fillStyle = INK; c.font = "900 34px Inter, Arial"; c.textAlign = "left"; const lines = ["THE END OF THE WORLD.", "SCENE 1: ALL SCREENS DARK.", "SCENE 2: THE MACHINES WAKE.", "SCENE 3: NOTHING COMES BACK."]; lines.forEach((l, i) => { const n = Math.floor(l.length * clamp((writers * 1.4) - i * 0.25)); c.fillText(l.slice(0, n), 24, 50 + i * 46); }); }} />
    {[0, 1, 2, 3, 4, 5].map((i) => { const x = 0.2 + i * 1.18, b = Math.sin(t * 9 + i * 1.7); return <Person key={i} p={[x, 0, -2.2 - (i % 2) * 0.1]} h={3.6} look={ppl[i + 1]} f={f + i * 3} pose={{ mood: writers > 0.5 ? "grin" : "deadpan", armR: [0.2 + 0.04 * b, 0.5 + 0.03 * b], armRK: writers, armL: [-0.2, 0.5], armLK: writers, tilt: 0.04 * b * writers, lookX: 0 }} />; })}
    <CrowdField n={46} t={t} rate={4} at={(i) => { const a = i * 2.399, r = 3 + (i % 8) * 1.3; return [3 + Math.cos(a) * r * 1.2, 0, -5 - Math.abs(Math.sin(a)) * r * 0.5] as V3; }} size={1.15} />
    <Clapper p={[3.0, 0.0, 6.0]} open={clap * 0.8} s={0.6} />
    <Dust t={t} area={[10, 6, 5]} color="rgba(255,240,200,.8)" />
  </>);
};

export const SCENES: Record<string, any> = { S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13 };
function drawHeart(c: CanvasRenderingContext2D, W: number, H: number, col: string) { c.fillStyle = col; c.strokeStyle = INK; c.lineWidth = 3; c.clearRect(0, 0, W, H); c.beginPath(); c.moveTo(W / 2, H * 0.82); c.bezierCurveTo(-W * 0.1, H * 0.5, W * 0.1, H * 0.1, W / 2, H * 0.32); c.bezierCurveTo(W * 0.9, H * 0.1, W * 1.1, H * 0.5, W / 2, H * 0.82); c.fill(); c.stroke(); }
