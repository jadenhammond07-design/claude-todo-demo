#!/usr/bin/env python3
"""Free offline voiceover (Kokoro). usage: /root/.tts-venv/bin/python tools/tts.py script.txt out.mp3 [voice=am_adam] [speed=1.05]
Setup (once per container): python3 -m venv /root/.tts-venv && /root/.tts-venv/bin/pip install kokoro-onnx soundfile
models in /root/.tts-models (kokoro-v1.0.onnx, voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx releases model-files-v1.0)."""
import sys, re, subprocess, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro
src, out = sys.argv[1], sys.argv[2]; voice = sys.argv[3] if len(sys.argv) > 3 else "am_adam"; speed = float(sys.argv[4]) if len(sys.argv) > 4 else 1.2
GAP = 0.08
k = Kokoro("/root/.tts-models/kokoro-v1.0.onnx", "/root/.tts-models/voices-v1.0.bin")
text = open(src).read().strip()
sents = [s for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]
chunks, sr = [], 24000
for s in sents:
    a, sr = k.create(s, voice=voice, speed=speed, lang="en-us")
    chunks += [a, np.zeros(int(sr * GAP), dtype=a.dtype)]
wav = out.rsplit(".", 1)[0] + ".wav"
sf.write(wav, np.concatenate(chunks), sr)
if out.endswith(".mp3"): subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", wav, "-b:a", "192k", out], check=True)
print("wrote", out)
